import { faSave } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  CircularProgress,
  FormHelperText,
  Grid,
  IconButton,
  InputAdornment,
  TextField,
} from '@material-ui/core';
import React, { useEffect, useState } from 'react';

interface Props {
  id: string;
  originalValue: string;
  onUpdate: (id: string, value: string) => void | Promise<void>;
  onError?: (err?: Error) => void;
  iconButton?: JSX.Element;
  multiline?: boolean;
  subtext?: string | JSX.Element;
  label?: string;
}

const EditableText: React.FC<Props> = ({
  id,
  originalValue,
  onUpdate,
  onError,
  iconButton,
  subtext,
  label,
  multiline = false,
}) => {
  const [isUpdating, setIsUpdating] = useState(false);
  const [showSaveButton, setShowSaveButton] = useState(false);
  const [value, setValue] = useState(originalValue);

  useEffect(() => {
    setValue(originalValue);
  }, [originalValue]);

  useEffect(() => {
    if (!showSaveButton && value !== originalValue) {
      setShowSaveButton(true);
    } else if (showSaveButton && value === originalValue) {
      setShowSaveButton(false);
    }
  }, [value, showSaveButton, originalValue]);

  const onChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setValue(event.target.value);
  };

  const onKeyPress = (event: React.KeyboardEvent) => {
    if (event.key === 'Enter') {
      event.preventDefault();
      onClickSave();
    }
  };

  const onKeyDown = (event: React.KeyboardEvent) => {
    if (event.key === 'Escape' || event.key === 'Esc') {
      setValue(originalValue);

      const inputElement = event.target as HTMLInputElement;

      inputElement.blur();
    }
  };

  const onClickSave = async () => {
    if (originalValue !== value) {
      try {
        setIsUpdating(true);
        await onUpdate(id, value.trim());
      } catch (err) {
        onError && onError(err);
      } finally {
        setIsUpdating(false);
      }
    }
  };

  return (
    <Grid container spacing={1} alignItems="center">
      {iconButton && <Grid item>{iconButton}</Grid>}
      <Grid item xs>
        <TextField
          value={value}
          onChange={onChange}
          disabled={isUpdating}
          size="small"
          margin="dense"
          fullWidth
          onKeyPress={onKeyPress}
          onKeyDown={onKeyDown}
          multiline={multiline}
          label={label}
          InputProps={{
            endAdornment: isUpdating ? (
              <InputAdornment position="end">
                <IconButton aria-label="text-updating">
                  <CircularProgress color="primary" size={14} />
                </IconButton>
              </InputAdornment>
            ) : showSaveButton ? (
              <InputAdornment position="end">
                <IconButton aria-label="text-update-button" onClick={onClickSave}>
                  <FontAwesomeIcon icon={faSave} size="sm" />
                </IconButton>
              </InputAdornment>
            ) : undefined,
          }}
        />
        {subtext && <FormHelperText margin="dense">{subtext}</FormHelperText>}
      </Grid>
    </Grid>
  );
};

export default EditableText;
