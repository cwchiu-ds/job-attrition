import { CircularProgress } from '@material-ui/core';
import React, { useContext } from 'react';
import { useAuthState } from 'react-firebase-hooks/auth';
import { Redirect, Route, RouteProps } from 'react-router-dom';

import { firebaseAuth } from '../../config/firebase';
import { NavigationPath } from '../../utils/constants';
import { AuthContext } from './AuthProvider';

const PrivateRoute: React.FC<RouteProps> = ({ component, ...options }) => {
  const { user, client } = useContext(AuthContext);
  const [authUser, loadingAuth] = useAuthState(firebaseAuth);

  if (authUser && !(user && client)) {
    return <CircularProgress style={{ marginLeft: '50%', marginTop: '30%' }} />;
  } else if (!loadingAuth && !authUser) {
    return <Redirect to={NavigationPath.LOGIN} />;
  }

  const renderComponent = user && client ? component : () => null;

  return <Route {...options} component={renderComponent} />;
};

export default PrivateRoute;
