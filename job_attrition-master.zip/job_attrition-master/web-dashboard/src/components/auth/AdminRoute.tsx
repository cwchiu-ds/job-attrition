import React, { useContext } from 'react';
import { Redirect, Route, RouteProps } from 'react-router-dom';

import { NavigationPath, UserType } from '../../utils/constants';
import { AuthContext } from './AuthProvider';

const AdminRoute: React.FC<RouteProps> = ({ children, ...options }) => {
  const { user } = useContext(AuthContext);

  if (user?.userType !== UserType.INTERNAL) {
    return <Redirect to={NavigationPath.MAIN} />;
  }

  return <Route {...options}>{children}</Route>;
};

export default AdminRoute;
