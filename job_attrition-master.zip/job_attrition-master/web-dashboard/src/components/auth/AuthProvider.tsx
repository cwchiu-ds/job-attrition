import React, { useEffect, useState } from 'react';
import { useAuthState } from 'react-firebase-hooks/auth';

import { firebaseAuth } from '../../config/firebase';
import { analyticsLoginEvent, analyticsSetUserOnLogin, logError, setLogUser } from '../../modules/analytics';
import { subscribeDocument, updateUser } from '../../modules/firestore';
import { ClientPaymentStatus, ClientStatus, COLLECTION } from '../../utils/constants';

export const AuthContext = React.createContext<AuthContextData>({} as AuthContextData);

const AuthProvider: React.FC = ({ children }) => {
  const [authUser, loadingAuth, error] = useAuthState(firebaseAuth);
  const [user, setUser] = useState<FullUser>();
  const [client, setClient] = useState<Client>();
  const [errorMessage, setErrorMessage] = useState<string>('');

  useEffect(() => {
    // This useEffect handles loading auth data only
    if (authUser) {
      setErrorMessage('');
    } else if (!loadingAuth && error) {
      setErrorMessage('An error occurred during authentication, please verifiy your credentials');
    }
  }, [authUser, loadingAuth, error]);

  useEffect(() => {
    // This useEffect handles retrieving user / client data after user has authenticated
    // The app is subscribed to the Users document, so any changes will be reflected in real time
    let unsubscribe = () => {};
    const handleError = (err: Error) => {
      logError(err, 'Error retrieving user data');
      setErrorMessage('An error occurred when retrieving your information. The team has been notified of the issue');
    };

    if (authUser?.uid) {
      const handleUserDocChange = async (
        userDoc: firebase.firestore.DocumentSnapshot<firebase.firestore.DocumentData>
      ) => {
        try {
          if (userDoc.exists && authUser.email) {
            const userData = userDoc.data() as UserData;
            const fullUser = { id: userDoc.id, ...userData, email: authUser.email };
            if (userData.email !== authUser.email) {
              updateUser(userDoc.id, { email: authUser.email });
            }
            setLogUser({ id: userDoc.id, email: authUser.email, userType: userData.userType });
            setUser(fullUser as FullUser);
          }
        } catch (err) {
          handleError(err);
        }
      };

      try {
        unsubscribe = subscribeDocument(COLLECTION.USERS, authUser.uid, handleUserDocChange, handleError);
      } catch (err) {
        handleError(err);
      }
    } else {
      setUser(undefined);
    }

    return unsubscribe;
  }, [authUser]);

  useEffect(() => {
    // This useEffect handles retrieving client data after user has authenticated and user data has been retrieved
    // The app is subscribed to the Client document, so any changes will be reflected in real time
    let unsubscribe = () => {};
    const handleError = (err: Error) => {
      logError(err, 'Error getting client data for user');
      setErrorMessage('An error occurred when retrieving your information. The team has been notified of the issue');
    };

    if (authUser?.uid && user?.clientId) {
      const handleClientDocChange = async (
        clientDoc: firebase.firestore.DocumentSnapshot<firebase.firestore.DocumentData>
      ) => {
        try {
          if (clientDoc.exists) {
            const client = { ...(clientDoc.data() as Client), id: clientDoc.id };
            setClient(client);

            // Upon successful login and retrieving User / Client info, we set the analytics user data
            analyticsSetUserOnLogin({
              userId: user.id,
              firstName: user.firstName,
              lastName: user.lastName,
              clientName: client.name,
              clientId: client.id,
              userType: user.userType,
              paymentStatus: client.paymentStatus || ClientPaymentStatus.NOT_PAID,
              status: client.status || ClientStatus.NOT_SET,
              fullName: `${user.firstName}_${user.lastName}`,
              companyName_fullName: `${client.name}_${user.firstName}_${user.lastName}`,
            });

            // Once analytics user data is set, we record this as a login event
            analyticsLoginEvent(
              user.firstName,
              user.lastName,
              client.name,
              client.id,
              user.userType,
              client.paymentStatus || ClientPaymentStatus.NOT_PAID,
              client.status || ClientStatus.NOT_SET,
              `${user.firstName}_${user.lastName}`,
              `${client.name}_${user.firstName}_${user.lastName}`
            );
          } else {
            throw new Error('No client found for clientId ' + user.clientId + '\n\n' + JSON.stringify(clientDoc));
          }
        } catch (err) {
          handleError(err);
        }
      };

      try {
        unsubscribe = subscribeDocument(COLLECTION.CLIENTS, user.clientId, handleClientDocChange, handleError);
      } catch (err) {
        handleError(err);
      }
    } else {
      setClient(undefined);
    }

    return unsubscribe;
  }, [user, authUser]);

  const signOut = () => {
    firebaseAuth.signOut().then(() => {
      setErrorMessage('');
    });
  };

  return (
    <AuthContext.Provider
      value={{
        signOut,
        authUser,
        user,
        client,
        errorMessage,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export default AuthProvider;
