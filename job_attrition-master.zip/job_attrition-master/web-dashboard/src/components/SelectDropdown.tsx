import { Grid, MenuItem, Select } from '@material-ui/core';
import React from 'react';

interface Props {
  options: SelectOption[];
  selectedValue?: string;
  onSelect: (value: string) => Promise<void> | void;
}

const SelectDropdown: React.FC<Props> = ({ options, selectedValue = '', onSelect }) => {
  const handleChange = (event: React.ChangeEvent<{ value: unknown }>) => {
    const newValue = event.target.value as string;

    onSelect(newValue);
  };

  return (
    <Grid container>
      <Select value={selectedValue} onChange={handleChange} displayEmpty fullWidth>
        <MenuItem value="">
          <em>None</em>
        </MenuItem>
        {options.map((option) => {
          return (
            <MenuItem key={option.value} value={option.value}>
              {option.label}
            </MenuItem>
          );
        })}
      </Select>
    </Grid>
  );
};

export default SelectDropdown;
