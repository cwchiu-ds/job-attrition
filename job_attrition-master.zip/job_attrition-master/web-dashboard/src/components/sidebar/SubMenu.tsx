import { Box, makeStyles } from '@material-ui/core';
import React from 'react';
import { useHistory, useLocation } from 'react-router-dom';

import { NavigationPath } from '../../utils/constants';

// This is the exact pixel offset required to make the submenu line up with the
// main menu text
const FIXED_MARGIN_LEFT = '52px';

const useStyles = makeStyles((theme) => ({
  selectedItem: {
    marginLeft: FIXED_MARGIN_LEFT,
    cursor: 'pointer',
    fontWeight: theme.typography.fontWeightMedium,
    color: theme.palette.primary.main,
  },
  notSelectedItem: {
    marginLeft: FIXED_MARGIN_LEFT,
    cursor: 'pointer',
    color: theme.palette.grey[600],
  },
}));

export type SubMenuItem = {
  navigationPath: NavigationPath;
  navigationLabel: string;
};

interface Props {
  subMenuItems: SubMenuItem[];
}

const SubMenu: React.FC<Props> = ({ subMenuItems }) => {
  const classes = useStyles();
  const history = useHistory();
  const location = useLocation();

  const navigateTo = (destination: NavigationPath) => {
    return () => {
      history.push(destination);
    };
  };

  const getSelectedClassName = (pathName: NavigationPath) => {
    return location.pathname.startsWith(pathName) ? classes.selectedItem : classes.notSelectedItem;
  };

  return (
    <>
      {subMenuItems.map((item) => {
        return (
          <Box
            key={item.navigationLabel}
            marginBottom={1}
            className={getSelectedClassName(item.navigationPath)}
            onClick={navigateTo(item.navigationPath)}
          >
            {item.navigationLabel}
          </Box>
        );
      })}
    </>
  );
};

export default SubMenu;
