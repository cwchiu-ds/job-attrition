import { Box, Grid } from '@material-ui/core';
import { CircularProgress } from '@material-ui/core';
import React, { useContext, useRef, useState } from 'react';
import { CSVLink } from 'react-csv';

import { getAllClientDataContactByClientId, getContactDataByIds } from '../../modules/firestore';
import { ContactContext } from '../../pages/Main';
import { ClientDownloadCSVHeaders, JobChangeStatusMap, QADownloadCSVHeaders } from '../../utils/constants';

const DownloadCSV = ({ headerFlag }: { headerFlag: string }) => {
  const { selectedClientId } = useContext(ContactContext);
  const [allContacts, setAllContacts] = useState<Partial<ClientContact>[]>([]);
  const csvRef = useRef();
  const [isLoading, setIsLoading] = useState(false);

  let headers;
  switch (headerFlag) {
    case 'CLIENT':
      headers = ClientDownloadCSVHeaders;
      break;
    case 'QA':
      headers = QADownloadCSVHeaders;
      break;
    default:
      headers = ClientDownloadCSVHeaders;
      break;
  }

  const handleClick = async () => {
    if (!selectedClientId) {
      return;
    }

    setIsLoading(true);
    const clientContacts = await getAllClientDataContactByClientId(selectedClientId);

    const contactDataIds = clientContacts.map((clientContact) => clientContact.contactDataId || '').filter((id) => id);

    const contactDataById = await getContactDataByIds(contactDataIds);

    const combinedContacts = clientContacts.map((contact) => {
      const updatedContact: any = contact;

      if (contact.contactDataId) {
        const updatedEmail = contactDataById[contact.contactDataId].emailData?.reduce((finalEmail, currentEmail) => {
          if (currentEmail.isValid === true) {
            finalEmail = currentEmail;
          }
          return finalEmail;
        }, {} as EmailData);

        updatedContact.contactDataCompanyName = contactDataById[contact.contactDataId].currentJob![0].companyName;
        updatedContact.contactDataTitle = contactDataById[contact.contactDataId].currentJob![0].title;
        updatedContact.contactDataLinkedInURL = contactDataById[contact.contactDataId].linkedInURL;
        updatedContact.contactDataStartDate = contactDataById[contact.contactDataId].currentJob![0].startDate || '';
        updatedContact.contactDataEndDate = contactDataById[contact.contactDataId].currentJob![0].endDate || '';
        updatedContact.contactDataDuration = contactDataById[contact.contactDataId].currentJob![0].duration || '';
        updatedContact.contactDataCompanyURL = contactDataById[contact.contactDataId].currentJob![0].companyURL || '';
        updatedContact.contactDataUpdatedEmail = updatedEmail!.email || '';
        return updatedContact;
      } else {
        return contact;
      }
    });

    const filteredClientContacts = combinedContacts.map(
      ({
        QAJobChangeStatus,
        QAJobChangeStatusDate,
        QADate,
        QAAssessment,
        QAUserId,
        QAEmail,
        QALinkedInURL,
        QALinkedInStatus,
        QANotes,
        QAResetDate,
        email,
        firstName,
        lastName,
        fullName,
        currentJob,
        dateUpdated,
        jobChanged,
        verified,
        jobChangedStatus,
        crmData,
        contactDataLinkedInURL,
        contactDataCompanyName,
        contactDataTitle,
        contactDataStartDate,
        contactDataEndDate,
        contactDataDuration,
        contactDataCompanyURL,
        contactDataUpdatedEmail,
      }) => {
        return {
          QAJobChangeStatus,
          QAJobChangeStatusDate,
          QADate,
          QAAssessment,
          QAUserId,
          QAEmail,
          QALinkedInURL,
          QALinkedInStatus,
          QANotes,
          QAResetDate,
          email,
          firstName,
          lastName,
          fullName,
          title: currentJob?.title,
          companyName: currentJob?.companyName,
          linkedInURL: crmData?.crmLinkedInURL,
          jobChanged,
          verified,
          jobChangedStatus: JobChangeStatusMap[jobChangedStatus],
          contactDataLinkedInURL,
          contactDataCompanyName,
          contactDataTitle,
          contactDataStartDate,
          contactDataEndDate,
          contactDataDuration,
          contactDataCompanyURL,
          contactDataUpdatedEmail,
          // TODO: Add back after formatting it to human-readable format.
          // dateUpdated: dateUpdated,
        };
      }
    );

    setAllContacts(filteredClientContacts);

    // @ts-ignore
    csvRef.current.link.click();

    setIsLoading(false);
  };

  return (
    <div>
      <Grid container item direction="row" alignItems="center" justify="space-between">
        <div onClick={handleClick}>Download CSV</div>
        <Box ml={2}>{isLoading && <CircularProgress size={18} />}</Box>
      </Grid>
      <div style={{ display: 'none' }}>
        <CSVLink
          data={allContacts}
          headers={headers}
          //  @ts-ignore
          ref={csvRef}
          filename={'warmly-crm.csv'}
          className="btn btn-primary"
          target="_blank"
        >
          Download me
        </CSVLink>
      </div>
    </div>
  );
};

export default DownloadCSV;
