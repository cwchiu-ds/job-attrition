import { faSalesforce } from '@fortawesome/free-brands-svg-icons';
import {
  faAt,
  faCloudUploadAlt,
  faCog,
  faKey,
  faPeopleArrows,
  faSignOutAlt,
  faUsers,
} from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { Box, Icon, Typography } from '@material-ui/core';
import Divider from '@material-ui/core/Divider';
import Drawer from '@material-ui/core/Drawer';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import { makeStyles, withStyles } from '@material-ui/core/styles';
import React, { useContext } from 'react';
import { useHistory, useLocation } from 'react-router-dom';

import {
  CURRENT_ENVIRONMENT,
  Environment,
  IntegrationType,
  NavigationPath,
  UserType,
  WARMLY_LOGO_ICON,
  WarmlyColor,
} from '../utils/constants';
import { AuthContext } from './auth/AuthProvider';
import SubMenu, { SubMenuItem } from './sidebar/SubMenu';

const FIXED_DRAWER_WIDTH = 160;

const useStyles = makeStyles((theme) => ({
  drawer: {
    width: FIXED_DRAWER_WIDTH,
    flexShrink: 0,
  },
  drawerPaper: {
    width: FIXED_DRAWER_WIDTH,
  },
  selectedItem: {
    borderLeft: 'solid 6px',
    borderLeftColor: theme.palette.primary.main,
  },
  notSelectedItem: {
    borderLeft: 'solid 6px',
    borderLeftColor: theme.palette.common.white,
  },
}));

const NavListItemIcon = withStyles({
  root: {
    minWidth: 30,
  },
})(ListItemIcon);

const settingsSubMenuItems: SubMenuItem[] = [
  {
    navigationPath: NavigationPath.ACCOUNT_SETTINGS,
    navigationLabel: 'Account',
  },
  {
    navigationPath: NavigationPath.NOTIFICATION_SETTINGS,
    navigationLabel: 'Notifications',
  },
  {
    navigationPath: NavigationPath.USERS_SETTINGS,
    navigationLabel: 'Users',
  },
];

const adminSubMenuItems: SubMenuItem[] = [
  {
    navigationPath: NavigationPath.ADMIN_CLIENT_MANAGEMENT,
    navigationLabel: 'Client',
  },
  {
    navigationPath: NavigationPath.ADMIN_CLIENTS_MANAGEMENT,
    navigationLabel: 'Clients',
  },
  {
    navigationPath: NavigationPath.ADMIN_QA_USERS_MANAGEMENT,
    navigationLabel: 'QA Users',
  },
  {
    navigationPath: NavigationPath.ADMIN_QA_CLIENTS_MANAGEMENT,
    navigationLabel: 'QA Clients',
  },
  {
    navigationPath: NavigationPath.ADMIN_QA_DATA_REVIEW,
    navigationLabel: 'QA Data',
  },
  // {
  //   navigationPath: NavigationPath.ADMIN_QA_COLLECTOR_VIEW,
  //   navigationLabel: 'QA Collector',
  // },
  // {
  //   navigationPath: NavigationPath.ADMIN_QA_APPROVER_VIEW,
  //   navigationLabel: 'QA Approver',
  // },
];

const Sidebar = () => {
  const { user, client, signOut } = useContext(AuthContext);

  const classes = useStyles();
  const history = useHistory();
  const location = useLocation();

  const navigateTo = (destination: NavigationPath) => {
    return () => {
      history.push(destination);
    };
  };

  const logOut = () => {
    signOut();
    const signedOutURL =
      CURRENT_ENVIRONMENT !== Environment.Production ? NavigationPath.MAIN : 'https://getwarmly.com';
    window.location.assign(signedOutURL);
  };

  const getSelectedClassName = (pathName: NavigationPath) => {
    return location.pathname.startsWith(pathName) ? classes.selectedItem : classes.notSelectedItem;
  };

  return (
    <Drawer
      className={classes.drawer}
      variant="permanent"
      classes={{
        paper: classes.drawerPaper,
      }}
      anchor="left"
    >
      <Box textAlign="center" marginTop={4} marginBottom={2}>
        <Icon>
          <img style={{ width: 45 }} alt="warmly-logo" src={WARMLY_LOGO_ICON} />
        </Icon>
      </Box>
      <Box textAlign="center" marginBottom={6}>
        <Typography variant="subtitle1" color="textSecondary">
          Warmly,
        </Typography>
      </Box>

      <List>
        <ListItem
          button
          onClick={navigateTo(NavigationPath.JOB_CHANGES)}
          className={getSelectedClassName(NavigationPath.JOB_CHANGES)}
        >
          <NavListItemIcon>
            <FontAwesomeIcon size="lg" icon={faPeopleArrows} color={WarmlyColor.DARK_BLUE} />
          </NavListItemIcon>
          <ListItemText primaryTypographyProps={{ color: 'primary' }} primary="Job Changes" />
        </ListItem>

        <ListItem
          button
          onClick={navigateTo(NavigationPath.ENRICHED_CRM)}
          className={getSelectedClassName(NavigationPath.ENRICHED_CRM)}
        >
          <NavListItemIcon>
            <FontAwesomeIcon size="lg" icon={faUsers} color={WarmlyColor.DARK_BLUE} />
          </NavListItemIcon>
          <ListItemText primaryTypographyProps={{ color: 'primary' }} primary="CRM" />
        </ListItem>

        {client?.integrationType !== IntegrationType.SALESFORCE && (
          <ListItem
            button
            onClick={navigateTo(NavigationPath.UPLOAD)}
            className={getSelectedClassName(NavigationPath.UPLOAD)}
          >
            <NavListItemIcon>
              <FontAwesomeIcon size="lg" icon={faCloudUploadAlt} color={WarmlyColor.DARK_BLUE} />
            </NavListItemIcon>
            <ListItemText primaryTypographyProps={{ color: 'primary' }} primary="Upload" />
          </ListItem>
        )}

        {client?.integrationType === IntegrationType.SALESFORCE && (
          <ListItem
            button
            onClick={navigateTo(NavigationPath.INTEGRATION_SALESFORCE)}
            className={getSelectedClassName(NavigationPath.INTEGRATION_SALESFORCE)}
          >
            <NavListItemIcon>
              <FontAwesomeIcon size="lg" icon={faSalesforce} color={WarmlyColor.DARK_BLUE} />
            </NavListItemIcon>
            <ListItemText primaryTypographyProps={{ color: 'primary' }} primary="Salesforce Integration" />
          </ListItem>
        )}
      </List>
      <Divider />
      <List>
        {user?.userType === UserType.INTERNAL && (
          <>
            <ListItem
              button
              onClick={navigateTo(NavigationPath.ADMIN)}
              className={getSelectedClassName(NavigationPath.ADMIN)}
            >
              <NavListItemIcon>
                <FontAwesomeIcon size="lg" icon={faKey} color={WarmlyColor.DARK_BLUE} />
              </NavListItemIcon>
              <ListItemText primaryTypographyProps={{ color: 'primary' }} primary="Admin" />
            </ListItem>
            {location.pathname.startsWith(NavigationPath.ADMIN) && <SubMenu subMenuItems={adminSubMenuItems} />}
          </>
        )}

        <ListItem
          button
          onClick={navigateTo(NavigationPath.CONTACT_US)}
          className={getSelectedClassName(NavigationPath.CONTACT_US)}
        >
          <NavListItemIcon>
            <FontAwesomeIcon size="lg" icon={faAt} color={WarmlyColor.DARK_BLUE} />
          </NavListItemIcon>
          <ListItemText primaryTypographyProps={{ color: 'primary' }} primary="Contact Us" />
        </ListItem>

        <ListItem
          button
          onClick={navigateTo(NavigationPath.SETTINGS)}
          className={getSelectedClassName(NavigationPath.SETTINGS)}
        >
          <NavListItemIcon>
            <FontAwesomeIcon size="lg" icon={faCog} color={WarmlyColor.DARK_BLUE} />
          </NavListItemIcon>
          <ListItemText primaryTypographyProps={{ color: 'primary' }} primary="Settings" />
        </ListItem>
        {location.pathname.startsWith(NavigationPath.SETTINGS) && <SubMenu subMenuItems={settingsSubMenuItems} />}

        <ListItem button onClick={logOut} className={classes.notSelectedItem}>
          <NavListItemIcon>
            <FontAwesomeIcon size="lg" icon={faSignOutAlt} color={WarmlyColor.DARK_BLUE} />
          </NavListItemIcon>
          <ListItemText primaryTypographyProps={{ color: 'primary' }} primary="Logout" />
        </ListItem>
      </List>

      <Box marginTop="auto" marginBottom={2} textAlign="center" style={{ overflowWrap: 'anywhere', cursor: 'default' }}>
        {user?.email}
      </Box>
    </Drawer>
  );
};

export default Sidebar;
