import { Box } from '@material-ui/core';
import React from 'react';

const CodeText: React.FC = ({ children, ...props }) => {
  return (
    <Box bgcolor="grey.200" fontWeight="fontWeightRegular" borderRadius={4} padding={1} display="inline" {...props}>
      {children}
    </Box>
  );
};

export default CodeText;
