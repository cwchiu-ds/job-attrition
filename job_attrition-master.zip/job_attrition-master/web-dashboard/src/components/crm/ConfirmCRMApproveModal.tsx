import { faLinkedin } from '@fortawesome/free-brands-svg-icons';
import { faAddressCard, faPeopleArrows } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  List,
  ListItem,
  ListItemIcon,
} from '@material-ui/core';
import React, { useContext } from 'react';

import { ContactContext } from '../../pages/Main';
import { IntegrationType, WarmlyColor } from '../../utils/constants';

interface ConfirmCRMApproveModalProps {
  checkedClientContactsCount: number;
  showConfirmCRMApproveModal: boolean;
  setShowConfirmCRMApproveModal: React.Dispatch<React.SetStateAction<boolean>>;
  approveSelectedChanges: () => void;
}

export const ConfirmCRMApproveModal: React.FC<ConfirmCRMApproveModalProps> = ({
  checkedClientContactsCount,
  showConfirmCRMApproveModal,
  setShowConfirmCRMApproveModal,
  approveSelectedChanges,
}) => {
  const { selectedClient } = useContext(ContactContext);
  const onClose = () => {
    setShowConfirmCRMApproveModal(false);
  };

  const getContent = () => {
    if (selectedClient?.integrationType === IntegrationType.HUBSPOT) {
      return (
        <>
          Job title and company name will be synced back to Hubspot for <strong>{checkedClientContactsCount}</strong>{' '}
          contact(s)
        </>
      );
    }

    if (selectedClient?.integrationType === IntegrationType.SALESFORCE) {
      return (
        <>
          We will synced back the following data to Salesforce for <strong>{checkedClientContactsCount}</strong>{' '}
          contact(s):
          <List dense={true}>
            <ListItem>
              <ListItemIcon>
                <FontAwesomeIcon icon={faPeopleArrows} color={WarmlyColor.DARK_BLUE} />
              </ListItemIcon>
              Whether we detected a job change
            </ListItem>
            <ListItem>
              <ListItemIcon>
                <FontAwesomeIcon icon={faLinkedin} color={WarmlyColor.DARK_BLUE} />
              </ListItemIcon>
              Latest LinkedIn URL
            </ListItem>
            <ListItem>
              <ListItemIcon>
                <FontAwesomeIcon icon={faAddressCard} color={WarmlyColor.DARK_BLUE} />
              </ListItemIcon>
              Latest job company name and title
            </ListItem>
          </List>
        </>
      );
    }
  };

  return (
    <Dialog open={showConfirmCRMApproveModal} onClose={onClose}>
      <DialogTitle>Sync data back to CRM</DialogTitle>
      <DialogContent>
        {getContent()}
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose} variant="outlined" color="primary">
          Cancel
        </Button>
        <Button onClick={approveSelectedChanges} variant="contained" color="primary">
          Confirm
        </Button>
      </DialogActions>
    </Dialog>
  );
};
