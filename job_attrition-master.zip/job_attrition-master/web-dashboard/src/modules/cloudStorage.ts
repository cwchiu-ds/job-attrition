import firebase from 'firebase/app';

const cloudStorageRef = firebase.storage().ref();

export const uploadFileToCloudStorage = async (file: File, folder: string, subFolder: string) => {
  const uploadPath = `${folder}/${subFolder}/${file.name}`

  const fileRef = cloudStorageRef.child(uploadPath)

  const fileSnapshot = await fileRef.put(file)

  const fileStoragePath = fileSnapshot.ref.fullPath

  return fileStoragePath
}