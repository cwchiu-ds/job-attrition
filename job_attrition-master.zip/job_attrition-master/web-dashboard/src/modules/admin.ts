import Axios from 'axios';

import { cloudFunctionsURL, UserField, UserType } from '../utils/constants';
import { getAuthToken } from './auth';

export const generateJobChanges = async (clientId: string) => {
  const functionURL = `${cloudFunctionsURL.ADMIN_GENERATE_JOB_CHANGES}/${clientId}`;

  const authToken = await getAuthToken();

  return Axios.get<string>(functionURL, {
    headers: {
      Authorization: 'Bearer ' + authToken,
      'Cache-Control': 'no-cache',
    },
  });
};

export const denormalizeContacts = async (clientId: string) => {
  const functionURL = `${cloudFunctionsURL.ADMIN_DENORMALIZE_CONTACTS}/${clientId}`;

  const authToken = await getAuthToken();

  return Axios.get<string>(functionURL, {
    headers: {
      Authorization: 'Bearer ' + authToken,
      'Cache-Control': 'no-cache',
    },
  });
};

export const appendCompanyURL = async (clientId: string) => {
  const functionURL = `${cloudFunctionsURL.ADMIN_APPEND_COMPANY_URL}/${clientId}`;

  const authToken = await getAuthToken();

  return Axios.get<string>(functionURL, {
    headers: {
      Authorization: 'Bearer ' + authToken,
      'Cache-Control': 'no-cache',
    },
  });
};

export const updateContactDataIdtoClientContact = async (clientId: string) => {
  const functionURL = `${cloudFunctionsURL.CREATE_CONTACT_DATA_ID}`;

  const authToken = await getAuthToken();

  const body = {
    clientId,
  };

  return Axios.post<string>(functionURL, body, {
    headers: {
      Authorization: 'Bearer ' + authToken,
      'Cache-Control': 'no-cache',
    },
  });
};

export const scrapeAllContacts = async (clientId: string, minutes: string) => {
  const functionURL = `${cloudFunctionsURL.SCRAPE_CONTACTS}`;

  const body = {
    clientId,
    minutes,
  };

  const authToken = await getAuthToken();

  return Axios.post<string>(functionURL, body, {
    headers: {
      Authorization: 'Bearer ' + authToken,
      'Cache-Control': 'no-cache',
    },
  });
};

export const deleteClient = async (clientId: string) => {
  const functionURL = `${cloudFunctionsURL.CLIENT_API}/${clientId}`;

  const authToken = await getAuthToken();

  return Axios.delete<string>(functionURL, {
    headers: {
      Authorization: 'Bearer ' + authToken,
      'Cache-Control': 'no-cache',
    },
  });
};

export const sendWeeklyJobChangeReport = async (clientId: string, testEmail: string | undefined = undefined) => {
  const functionURL = `${cloudFunctionsURL.SEND_WEEKLY_JOB_CHANGE_REPORT}`;

  const body = {
    clientId,
    testEmail,
  };

  const authToken = await getAuthToken();

  return Axios.post<string>(functionURL, body, {
    headers: {
      Authorization: 'Bearer ' + authToken,
      'Cache-Control': 'no-cache',
    },
  });
};

export const emailValidationCheck = async (clientId: string) => {
  const functionURL = `${cloudFunctionsURL.EMAIL_VALIDATION_CHECK}`;

  const body = {
    clientId,
  };

  const authToken = await getAuthToken();

  return Axios.post<string>(functionURL, body, {
    headers: {
      Authorization: 'Bearer ' + authToken,
      'Cache-Control': 'no-cache',
    },
  });
};

export interface CreateNewUser {
  [UserField.EMAIL]: string;
  [UserField.FIRST_NAME]: string;
  [UserField.LAST_NAME]: string;
  [UserField.USER_TYPE]: UserType;
  [UserField.PHONE_NUMBER]?: string;
  [UserField.CLIENT_ID]?: string;
  companyName: string;
  password: string;
}

export const adminCreateNewUser = async (body: CreateNewUser) => {
  const functionURL = cloudFunctionsURL.ADMIN_CREATE_NEW_USER;

  const authToken = await getAuthToken();

  return Axios.post(functionURL, body, {
    headers: {
      Authorization: 'Bearer ' + authToken,
      'Cache-Control': 'no-cache',
    },
  });
};
