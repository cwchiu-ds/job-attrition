import Axios from 'axios';

import { cloudFunctionsURL } from "../utils/constants";
import { getAuthToken } from './auth';

export const updateClient = async (clientId: string, updatedClient: Partial<Client>) => {
  const functionURL = `${cloudFunctionsURL.CLIENT_API}/${clientId}`;

  const authToken = await getAuthToken();

  return Axios.put(functionURL, updatedClient, {
    headers: {
      Authorization: 'Bearer ' + authToken,
      'Cache-Control': 'no-cache',
    },
  });
}