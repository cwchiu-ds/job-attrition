import Axios, { AxiosResponse } from 'axios';

import { cloudFunctionsURL } from '../utils/constants';
import { getAuthToken } from './auth';

export const inviteNewUser = async (inviteeEmail: string): Promise<AxiosResponse<{}>> => {
  const functionURL = cloudFunctionsURL.INVITE_NEW_USER;
  const body = {
    inviteeEmail,
  };

  const authToken = await getAuthToken();

  return Axios.post(functionURL, body, {
    headers: {
      Authorization: 'Bearer ' + authToken,
    },
  });
};
