import Axios from 'axios';

import { cloudFunctionsURL } from '../utils/constants';
import { MappedAttributes } from '../utils/functions';
import { getAuthToken } from './auth';

Axios.defaults.headers.common['Cache-Control'] = 'no-cache';
Axios.defaults.timeout = 500000;

export const uploadCsvClientContacts = async (filePath: string, mappedAttributes: MappedAttributes, asClientId?: string): Promise<void> => {
  const functionURL = cloudFunctionsURL.PARSE_CLIENT_CSV;
  const body = {
    filePath,
    mappedAttributes,
    asClientId,
  };

  const authToken = await getAuthToken();

  return Axios.post(functionURL, body, {
    headers: {
      Authorization: 'Bearer ' + authToken,
    },
    // We timeout after 20 seconds because we do not care about the response, errors will be handled
    // on the server by setting the syncStatus to ERROR
    timeout: 20000,
  });
};

export const approveCrmSync = async (clientIdsToSync: string[], clientId: string): Promise<void> => {
  const functionURL = cloudFunctionsURL.APPROVE_SELECTED_CRM_CHANGES;

  const body = {
    clientId: clientId,
    clientContactIds: clientIdsToSync,
  };

  const authToken = await getAuthToken();

  return Axios.post(functionURL, body, {
    headers: {
      Authorization: 'Bearer ' + authToken,
    },
  });
};

export const approveJobChangeSync = async (clientIdToApproveJobChange: string, clientId: string): Promise<void> => {
  const functionURL = cloudFunctionsURL.APPROVE_CRM_JOB_CHANGES;

  const body = {
    clientId: clientId,
    clientContactIds: [clientIdToApproveJobChange],
  };

  const authToken = await getAuthToken();

  return Axios.post(functionURL, body, {
    headers: {
      Authorization: 'Bearer ' + authToken,
    },
  });
};

export const dismissJobChange = async (clientIdToDismissJobChange: string, clientId: string): Promise<void> => {
  const functionURL = cloudFunctionsURL.DISMISS_CRM_JOB_CHANGES;

  const body = {
    clientId: clientId,
    clientContactIds: [clientIdToDismissJobChange],
  };

  const authToken = await getAuthToken();

  return Axios.post(functionURL, body, {
    headers: {
      Authorization: 'Bearer ' + authToken,
    },
  });
};

export const initiateSalesforceIntegration = async (): Promise<void> => {
  const functionURL = cloudFunctionsURL.SALESFORCE_AUTH;

  const authToken = await getAuthToken();

  const salesforceAuthURL = await Axios.get<string>(functionURL, {
    headers: {
      Authorization: 'Bearer ' + authToken,
    },
  });

  if (salesforceAuthURL.data) {
    window.location.assign(salesforceAuthURL.data);
  }
};

export interface SalesforceSetupFields {
  salesforceMapping: SalesforceMapping;
  jobChangeFieldLabel?: string;
}

export const initiateSalesforceSetup = async (body: SalesforceSetupFields): Promise<void> => {
  const functionURL = cloudFunctionsURL.SALESFORCE_SETUP_FIELDS;

  const authToken = await getAuthToken();

  return Axios.put(functionURL, body, {
    headers: {
      Authorization: 'Bearer ' + authToken,
    },
  });
};

export const initiateSalesforceSyncContacts = async (): Promise<void> => {
  const functionURL = cloudFunctionsURL.SALESFORCE_SYNC_CONTACTS;

  const authToken = await getAuthToken();

  return Axios.get(functionURL, {
    headers: {
      Authorization: 'Bearer ' + authToken,
    },
  });
};

export const enrichSalesforceContacts = async (clientContactIds: string[]) => {
  const functionURL = cloudFunctionsURL.SALESFORCE_ENRICH_CONTACTS;
  const body = { clientContactIds };

  const authToken = await getAuthToken();

  return Axios.put(functionURL, body, {
    headers: {
      Authorization: 'Bearer ' + authToken,
    },
  });
};

export const requestPasswordResetEmail = async (email: string) => {
  const functionURL = cloudFunctionsURL.RESET_PASSWORD;

  const authToken = await getAuthToken();

  return Axios.post(
    functionURL,
    { email },
    {
      headers: {
        Authorization: 'Bearer ' + authToken,
      },
    }
  );
};
