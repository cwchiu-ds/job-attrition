import firebase from 'firebase/app';

import { firebaseAuth } from '../config/firebase';
import { UserType } from '../utils/constants';
import { getCurrentTimestamp } from '../utils/functions';
import { createNewUser } from './firestore';

export const getAuthToken = () => {
  return firebaseAuth.currentUser?.getIdToken();
};

export const isSignInWithEmail = () => {
  return firebaseAuth.isSignInWithEmailLink(window.location.href);
};

export const signInWithEmailLink = (email: string, url: string) => {
  return firebaseAuth.signInWithEmailLink(email, url);
};

export const reauthenticateUser = (user: firebase.User, password: string) => {
  const cred = firebase.auth.EmailAuthProvider.credential(user.email!, password);

  return user.reauthenticateWithCredential(cred);
};

export const changePassword = (user: firebase.User, newPassword: string) => {
  return user.updatePassword(newPassword);
};

export interface OnboardNewUserData {
  newUser: firebase.User;
  firstName: string;
  lastName: string;
  phoneNumber?: string;
  password: string;
  clientId: string;
}

export const onboardNewUser = async ({
  newUser,
  firstName,
  lastName,
  phoneNumber,
  password,
  clientId,
}: OnboardNewUserData) => {
  const newUserData: NewUserData = {
    firstName,
    lastName,
    email: newUser.email!,
    userType: UserType.CLIENT,
    clientId,
    createdDate: getCurrentTimestamp(),
  };

  if (phoneNumber) {
    newUserData.phoneNumber = phoneNumber;
  }

  await changePassword(newUser, password)

  return createNewUser(newUserData, newUser.uid);
};
