import firebase from 'firebase/app';
import { chunk } from 'lodash';

import {
  ClientContactAttributeField,
  ClientField,
  ClientInternalField,
  COLLECTION,
  ContactDataField,
  CURRENT_ENVIRONMENT,
  Environment,
  MAX_CHUNK_SIZE,
  UserField,
} from '../utils/constants';
const db = firebase.firestore();

export const createNewClient = async (clientName: Client['name']): Promise<UserData['clientId']> => {
  const newClientRef = await db.collection(COLLECTION.CLIENTS).add({
    name: clientName,
    isTest: !(CURRENT_ENVIRONMENT === Environment.Production),
  });
  const newClientId = newClientRef.id;

  return newClientId;
};

export const createNewUser = (newUserData: NewUserData, authUserId: string): Promise<void> => {
  return db
    .collection(COLLECTION.USERS)
    .doc(authUserId)
    .set({
      ...newUserData,
    });
};

// Firebase's onSnapshot requires a separate callback to handle errors, we rethrow the error so it can be handled elsewhere
const onErrorRethrow = (err: Error) => {
  throw err;
};

// NOTE we should move all document writes to backend for security / safety
export const updateDocumentUsingMerge = <T>(collection: COLLECTION, documentData: WithId<Partial<T>>) => {
  const { id, ...updatedData } = documentData;
  return db.collection(collection).doc(id).set(updatedData, { merge: true });
};

export const updateUser = (userId: string, updatedUser: Partial<UserData>): Promise<void> => {
  return db
    .collection(COLLECTION.USERS)
    .doc(userId)
    .update({
      ...updatedUser,
    });
};

export const updateDocumentsUsingMerge = <T>(
  collection: COLLECTION,
  updated: WithId<Partial<T>>[]
): Promise<void[]> => {
  // We generally use chunk size of 400 to be safe
  const updatedChunks = chunk(updated, MAX_CHUNK_SIZE);

  return Promise.all(
    updatedChunks.map((updatedChunk) => {
      const batch = db.batch();

      updatedChunk.forEach((updatedData) => {
        const { id: docId, ...docData } = updatedData;
        batch.set(db.collection(collection).doc(docId), docData, {
          merge: true,
        });
      });

      return batch.commit();
    })
  );
};

// Generic get
interface GetDocumentsByField {
  collection: COLLECTION;
  field: (ClientField | ClientContactAttributeField | UserField | ClientInternalField | ContactDataField) & {
    id: never;
  };
  operation: firebase.firestore.WhereFilterOp;
  fieldValue: string | number | boolean | null | Timestamp;
}

export const getDocumentsByField = ({ collection, field, operation, fieldValue }: GetDocumentsByField) => {
  return db.collection(collection).where(field, operation, fieldValue).get();
};

export const getDocumentById = async <T extends { id: string }>(
  collection: COLLECTION,
  id: string
): Promise<WithId<T> | undefined> => {
  const doc = await db.collection(collection).doc(id).get();

  if (doc.exists) {
    return { ...(doc.data() as T), id: doc.id };
  } else {
    return;
  }
};

export const checkValueExistInDocumentArray = async <T extends { id: string }>(
  collection: COLLECTION,
  fieldName: string,
  fieldValue: string,
  id: string
): Promise<boolean> => {
  const doc = await db.collection(collection).doc(id).get();

  if (doc.exists) {
    const object = doc.data();
    if (object && object[fieldName]) {
      return object[fieldName].includes(fieldValue) ? true : false;
    }
    return false;
  } else {
    return false;
  }
};

export const getContactDataByIds = async (contactDataIds: ContactData['id'][]) => {
  // The IN operator for Firestore queries can only support up to 10 values at a time
  const idChunks = chunk(contactDataIds, 10);
  const contactDataCollection = db.collection(COLLECTION.CONTACT_DATA);

  const contactDataByIds: { [id: string]: ContactData } = {};

  for (const idChunk of idChunks) {
    const querySnapshot = await contactDataCollection
      .where(firebase.firestore.FieldPath.documentId(), 'in', idChunk)
      .get();

    if (!querySnapshot.empty) {
      const contactDataDocs = querySnapshot.docs;

      for (const contactDataDoc of contactDataDocs) {
        const contactData = contactDataDoc.data() as ContactData;
        contactDataByIds[contactDataDoc.id] = contactData;
      }
    }
  }

  return contactDataByIds;
};

export const getAllClientDataContactByClientId = async (clientId: UserData['clientId']): Promise<ClientContact[]> => {
  if (!clientId) {
    return [];
  } else {
    const clientContactQuery = await db
      .collection(COLLECTION.CLIENT_CONTACTS)
      .where(ClientContactAttributeField.CLIENT_ID, '==', clientId)
      .get();
    if (clientContactQuery.empty) {
      return [];
    } else {
      const clientContacts = clientContactQuery.docs.map((doc) => {
        return { id: doc.id, ...doc.data() } as ClientContact;
      });

      return clientContacts;
    }
  }
};

// Subscriptions - generic
export const subscribeDocument = (
  collection: COLLECTION,
  id: string,
  callback: (docSnapshot: firebase.firestore.DocumentSnapshot<firebase.firestore.DocumentData>) => void,
  onErrorCallback?: (err: Error) => void
) => {
  onErrorCallback = onErrorCallback ? onErrorCallback : onErrorRethrow;
  return db.collection(collection).doc(id).onSnapshot(callback, onErrorCallback);
};

export const subscribeCollection = (
  collection: COLLECTION,
  callback: (querySnapshot: firebase.firestore.QuerySnapshot<firebase.firestore.DocumentData>) => void,
  onErrorCallback?: (err: Error) => void
) => {
  onErrorCallback = onErrorCallback ? onErrorCallback : onErrorRethrow;

  return db.collection(collection).onSnapshot(callback, onErrorCallback);
};

interface SubscribeCollectionByField {
  collection: COLLECTION;
  field: ClientField | ClientContactAttributeField | UserField | ClientInternalField | ContactDataField;
  operation: firebase.firestore.WhereFilterOp;
  fieldValue: string | number | boolean | null | Timestamp;
  callback: (querySnapshot: firebase.firestore.QuerySnapshot<firebase.firestore.DocumentData>) => void;
  onErrorCallback?: (err: Error) => void;
  orderByField?: ClientField | ClientContactAttributeField | UserField | ClientInternalField | ContactDataField;
  orderByOrder?: 'desc' | 'asc' | undefined;
}

export const subscribeCollectionByField = ({
  collection,
  field,
  operation,
  fieldValue,
  callback,
  onErrorCallback = onErrorRethrow,
  orderByField,
  orderByOrder,
}: SubscribeCollectionByField) => {
  let query = db.collection(collection).where(field, operation, fieldValue);
  if (orderByField) {
    query = query.orderBy(orderByField, orderByOrder);
  }
  return query.onSnapshot(callback, onErrorCallback);
};

export const subscribeCollectionBlockByField = ({
  collection,
  field,
  operation,
  fieldValue,
  callback,
  onErrorCallback = onErrorRethrow,
  startAtId,
}: SubscribeCollectionByField & { startAtId: string }) => {
  // The limit should be the same as the max block size limit set in Cloud Functions
  const query = db
    .collection(collection)
    .where(field, operation, fieldValue)
    .orderBy(firebase.firestore.FieldPath.documentId())
    .startAt(startAtId)
    .limit(200);

  return query.onSnapshot(callback, onErrorCallback);
};
