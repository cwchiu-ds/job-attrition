import { createMuiTheme, ThemeProvider } from '@material-ui/core';
import CssBaseline from '@material-ui/core/CssBaseline';
import React, { useState } from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Route, Switch } from 'react-router-dom';

import AuthProvider from './components/auth/AuthProvider';
import PrivateRoute from './components/auth/PrivateRoute';
import { initializeLogging } from './modules/analytics';
import LoggedInRouter from './pages/LoggedInRouter';
import Login from './pages/Login';
import Onboard from './pages/Onboard';
import ResetPassword from './pages/ResetPassword';
import SignUp from './pages/SignUp';
import * as serviceWorker from './serviceWorker';
import { WarmlyColor } from './utils/constants';

const theme = createMuiTheme({
  palette: {
    primary: { main: WarmlyColor.DARK_BLUE, contrastText: WarmlyColor.WHITE },
    secondary: { main: WarmlyColor.SALMON, contrastText: WarmlyColor.WHITE },
    background: {
      default: WarmlyColor.LIGHT_BLUE,
    },
    tonalOffset: {
      light: 0.85,
      dark: 0.4,
    },
  },
  typography: {
    fontFamily: ['Roboto', '"Helvetica Neue"', 'sans-serif'].join(','),
    fontWeightRegular: 300,
    fontWeightMedium: 400,
    fontWeightBold: 500,
    fontSize: 13,
    h1: {
      fontFamily: 'Montserrat',
      fontSize: '2.25rem',
    },
    h2: {
      fontFamily: 'Montserrat',
      fontSize: '2rem',
    },
    h3: {
      fontFamily: 'Montserrat',
      fontSize: '1.75rem',
    },
    h4: {
      fontFamily: 'Montserrat',
      fontSize: '1.5rem',
    },
    h5: {
      fontFamily: 'Montserrat',
      fontSize: '1.25rem',
    },
    h6: {
      fontFamily: 'Montserrat',
      fontSize: '1rem',
    },
    subtitle1: {
      fontSize: '0.8rem',
    },
    subtitle2: {
      fontSize: '0.8rem',
      fontWeight: 500,
    },
    body1: {
      letterSpacing: '0.02em',
    },
    body2: {
      fontSize: '0.9rem',
      letterSpacing: '0.03em',
    },
  },
});

export const LoadingAndAlertContext = React.createContext<LoadingAndAlertContextData>({} as LoadingAndAlertContextData);

const Root: React.FC = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [snackbarAlertData, setSnackbarAlertData] = useState<AlertData | undefined>();

  return (
    <AuthProvider>
      <BrowserRouter>
        <LoadingAndAlertContext.Provider
          value={{
            isLoading,
            setIsLoading,
            snackbarAlertData,
            setSnackbarAlertData,
          }}
        >
          <ThemeProvider theme={theme}>
            <CssBaseline />
            <Switch>
              <Route exact={true} path="/sign-up" component={SignUp} />
              <Route exact={true} path="/login" component={Login} />
              <Route exact={true} path="/onboard" component={Onboard} />
              <Route exact={true} path="/reset-password" component={ResetPassword} />
              <PrivateRoute path="/" component={LoggedInRouter} />
            </Switch>
          </ThemeProvider>
        </LoadingAndAlertContext.Provider>
      </BrowserRouter>
    </AuthProvider>
  );
};

ReactDOM.render(<Root />, document.getElementById('root'));

initializeLogging();

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
