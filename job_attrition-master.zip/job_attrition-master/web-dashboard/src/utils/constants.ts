import CEO_AVATAR from '../assets/ceo_avatar.svg';
import CSV_LOGO from '../assets/csv-logo.png';
import CTO_AVATAR from '../assets/cto_avatar.svg';
import EMAIL_ICON from '../assets/gmail-logo.png';
import HUBSPOT_LOGO from '../assets/hubspot-logo.svg';
import LINKEDIN_ICON from '../assets/linkedin-icon.svg';
import WARMLY_LOGO_ICON from '../assets/logo-icon.svg';
import SALESFORCE_LOGO from '../assets/salesforce-logo.png';
import SECURE_ICON from '../assets/secure.svg';
import TWITTER_ICON from '../assets/twitter-icon.png';
import WARMLY_LOGO_HORIZONTAL_COLOR from '../assets/warmly-logo-horizontal-color.png';

export const CURRENT_ENVIRONMENT: Environment = process.env.REACT_APP_WARMLY_ENVIRONMENT as Environment;
export const REACT_APP_WARMLY_LOCAL_ENVIRONMENT: Environment = process.env
  .REACT_APP_WARMLY_LOCAL_ENVIRONMENT as Environment;

export const DEV_FIRESTORE: DevFirestore = process.env.REACT_APP_DEV_FIRESTORE as DevFirestore;

export const MTURK_ENVIRONMENT: Environment = process.env.REACT_APP_MTURK_ENVIRONMENT as Environment;

export enum WarmlyColor {
  DARK_BLUE = '#293767',
  SALMON = '#ff8769',
  WHITE = '#ffffff',
  BLACK = '#000000',
  LIGHT_BLUE = '#f4f8f9',
}

export enum NavigationPath {
  MAIN = '/',
  LOGIN = '/login',
  SIGN_UP = '/sign-up',
  JOB_CHANGES = '/job-changes',
  ENRICHED_CRM = '/enriched-crm',
  LOGOUT = '/logout',
  ADMIN = '/admin',
  UPLOAD = '/upload',
  CONTACT_US = '/contact',
  SETTINGS = '/settings',
  USERS_SETTINGS = '/settings/users',
  ACCOUNT_SETTINGS = '/settings/account',
  NOTIFICATION_SETTINGS = '/settings/notifications',
  INTEGRATION = '/integration',
  INTEGRATION_SALESFORCE = '/integration/salesforce',
  ADMIN_CLIENT_MANAGEMENT = '/admin/client-management',
  ADMIN_CLIENTS_MANAGEMENT = '/admin/clients-management',
  ADMIN_QA_USERS_MANAGEMENT = '/admin/qa-users-management',
  ADMIN_QA_CLIENTS_MANAGEMENT = '/admin/qa-clients-management',
  ADMIN_QA_DATA_REVIEW = '/admin/qa-review',
  ADMIN_QA_COLLECTOR_VIEW = '/admin/qa-collector-view',
  ADMIN_QA_APPROVER_VIEW = '/admin/qa-approver-view',
}

export enum IntegrationType {
  HUBSPOT = 'hubspot',
  SALESFORCE = 'salesforce',
}

export enum WARMLY_EMAIL {
  CEO = 'max@warmlycomma.com',
  CTO = 'carina@warmlycomma.com',
  SUPPORT_GENERAL = 'support@warmlycomma.com',
  SUPPORT_TECH = 'tech@warmlycomma.com',
}

export enum Environment {
  Development = 'development',
  Staging = 'staging',
  Production = 'production',
}

export enum DevFirestore {
  Staging = 'staging',
  Localhost = 'localhost',
}

export enum COLLECTION {
  CLIENTS = 'clients',
  CLIENT_INTERNAL = 'client_internal',
  CLIENT_CONTACTS = 'client_contacts',
  CONTACT_DATA = 'contact_data',
  USERS = 'users',
  COMPANIES = 'companies',
}

export enum ClientContactAttributeField {
  CLIENT_ID = 'clientId',
  FIRST_NAME = 'firstName',
  LAST_NAME = 'lastName',
  FULL_NAME = 'fullName',
  EMAIL = 'email',
  IS_VALID_EMAIL = 'isValidEmail',
  LINKEDIN_URL = 'linkedInURL',
  LINKEDIN_ID = 'linkedInId',
  CRM_DATA = 'crmData',
  POTENTIAL_SEARCHES = 'potentialSearches',
  JOB_CHANGED = 'jobChanged',

  ENRICHED_DATA_CHANGED = 'enrichedDataChanged',
  LAST_VERIFIED = 'lastVerified',
  CURRENT_JOB = 'currentJob',
  UNCERTAIN_URLS = 'uncertainURLs',
  CONTACT_DATA_ID = 'contactDataId',
  CONTACT_DATA = 'contactData',
  DATE_UPDATED = 'dateUpdated',
  PROFILE_PHOTO = 'profilePhoto',
  VERIFIED = 'verified',
  TITLE = 'title',
  COMPANY_NAME = 'companyName',

  JOB_CHANGED_STATUS = 'jobChangedStatus',
  CONTACT_DATA_LINKEDIN_URL = 'contactDataLinkedInURL',
  CONTACT_DATA_COMPANY_NAME = 'contactDataCompanyName',
  CONTACT_DATA_TITLE = 'contactDataTitle',
  CONTACT_DATA_START_DATE = 'contactDataStartDate',
  CONTACT_DATA_END_DATE = 'contactDataEndDate',
  CONTACT_DATA_DURATION = 'contactDataDuration',
  CONTACT_DATA_COMPANY_URL = 'contactDataCompanyURL',
  CONTACT_DATA_UPDATED_EMAIL = 'contactDataUpdatedEmail',
  QA_DATE = 'QADate',
  QA_FULL_NAME = 'QAFullName',
  QA_ASSESSMENT = 'QAAssessment',
  QA_USER_ID = 'QAUserId',
  QA_EMAIL = 'QAEmail',
  QA_LINKEDIN_URL = 'QALinkedInURL',
  QA_LINKEDIN_STATUS = 'QALinkedInStatus',
  QA_COMPANY_URL = 'QACompanyURL',
  QA_COMPANY_LINKEDIN_URL = 'QACompanyLinkedInURL',
  QA_JOB_CHANGE_STATUS = 'QAJobChangeStatus',
  QA_JOB_CHANGE_STATUS_DATE = 'QAJobChangeStatusDate',
  QA_NOTES = 'QANotes',
  QA_RESET_DATE = 'QAResetDate',
  SALESFORCE_ID = 'salesforceId',
  LAST_SALESFORCE_ENRICHMENT_DATE = 'lastSalesforceEnrichmentDate',
  LAST_SALESFORCE_ENRICHED_COMPANY_NAME = 'lastSalesforceEnrichedCompanyName',
  LAST_SALESFORCE_ENRICHED_TITLE = 'lastSalesforceEnrichedTitle',
  LAST_SALESFORCE_ENRICHED_LINKEDIN_URL = 'lastSalesforceEnrichedLinkedInURL',
}

export enum QAAssessment {
  CORRECT = 'Correct',
  INCORRECT_LINKEDIN = 'Incorrect LinkedIn URL',
  INCORRECT_JOB_CHANGE = 'Incorrect job change',
  INCORRECT_LINKEDIN_AND_JOB_CHANGE = 'Incorrect LinkedIn URL and job change',
}

export enum QALinkedInStatus {
  URL_FOUND = 'URL found',
  URL_CHANGED = 'URL changed',
  URL_FOUND_UNSURE = 'URL found but not sure',
  URL_NOT_FOUND = 'URL not found',
}

export enum QAJobChangeStatus {
  NO_JOB_CHANGE = 'No job change',
  LEFT_OLD_JOB_NO_NEW_JOB = 'Left old job but no new job',
  JOB_CHANGED = 'Job changed',
  JOB_CHANGED_SAME_COMPANY = 'Job changed but same company',
  EMAIL_INVALID = 'Email invalid',
}

export enum ClientContactAttribute {
  FULL_NAME = 'FULL_NAME',
  FIRST_NAME = 'FIRST_NAME',
  LAST_NAME = 'LAST_NAME',
  CURRENT_COMPANY = 'CURRENT_COMPANY',
  CURRENT_TITLE = 'CURRENT_TITLE',
  LINKEDIN_URL = 'LINKEDIN_URL',
  EMAIL = 'EMAIL',
  OTHER = 'OTHER',
}

export enum UserType {
  INTERNAL = 'INTERNAL',
  CLIENT = 'CLIENT',
  QA = 'QA',
}

export enum UserField {
  FIRST_NAME = 'firstName',
  LAST_NAME = 'lastName',
  EMAIL = 'email',
  PHONE_NUMBER = 'phoneNumber',
  CLIENT_ID = 'clientId',
  USER_TYPE = 'userType',
  CREATED_DATE = 'createdDate',
}

export enum ClientField {
  ID = 'id',
  NAME = 'name',
  CODE_NAME = 'codeName',
  ACCESS_TOKEN = 'accessToken',
  REFRESH_TOKEN = 'refreshToken',
  INTEGRATION_TYPE = 'integrationType',
  MAPPED_ATTRIBUTES = 'mappedAttributes',
  SALESFORCE_INTEGRATION = 'salesforceIntegration',
  SALESFORCE_CONTACTS_ENRICHED = 'salesforceContactsEnriched',
  SALESFORCE_JOB_CHANGES_APPROVED = 'salesforceJobChangesApproved',
  JOB_CHANGE_NOTIFICATION_EMAILS = 'jobChangeNotificationEmails',
  QA_STATUS = 'QAStatus',
  QA_STATUS_DATE = 'QAStatusDate',
  QA_USER_IDS = 'QAUserIds',
  STATUS = 'status',
  STATUS_DATE = 'statusDate',
  CONTACT_COUNT = 'contactCount',
  PAYMENT_STATUS = 'paymentStatus',
  CLIENT_CONTACT_BLOCKS = 'clientContactBlocks',
  CSV_UPLOAD = 'csvUpload',
}

export enum ClientInternalField {
  ID = 'id',
  NOTES = 'notes',
  CONTACTS_DENORMALIZATION_DATE = 'contactsDenormalizationDate',
  CONTACTS_CONTACT_DATA_ID_UPDATED = 'contactDataIdsUpdatedDate',
  CONTACTS_CONTACT_DATA_SCRAPED = 'contactDataScrapedDate',
  WEEKLY_REPORT_DATE = 'weeklyReportDate',
}

type ClientContactMetaData = {
  field: ClientContactAttributeField;
  displayText: string;
};

enum CloudFunctionEndpoint {
  PARSE_CLIENT_CSV = 'parseClientCsv',
  APPROVE_SELECTED_CRM_CHANGES = 'hubspot/sync-data-enrichment',
  APPROVE_CRM_JOB_CHANGES = 'hubspot/sync-job-changes',
  DISMISS_CRM_JOB_CHANGES = 'clientContact/dismiss-client-contact-job-change',
  INVITE_NEW_USER = 'user/invite-new-user',
  RESET_PASSWORD = 'user/reset-password',
  SALESFORCE_AUTH = 'sf/auth',
  SALESFORCE_SETUP_FIELDS = 'sf/setup-fields',
  SALESFORCE_SYNC_CONTACTS = 'sf/sync-contacts',
  SALESFORCE_ENRICH_CONTACTS = 'sf/enrich-contacts',
  CLIENT = 'client',
  HUBSPOT_INSTALL = 'hubSpotIntegration/install',
  ADMIN_GENERATE_JOB_CHANGES = 'admin/generate-job-changes',
  ADMIN_CREATE_NEW_USER = 'admin/create-new-user',
  ADMIN_DENORMALIZE_CONTACTS = 'admin/denormalize-contacts',
  ADMIN_APPEND_COMPANY_URL = 'admin/append-company-url',
  SCRAPE_CONTACTS = 'jobChange/send-contacts-to-proxycrawl',
  CREATE_CONTACT_DATA_ID = `jobChange/create-contact-data`,
  SEND_WEEKLY_JOB_CHANGE_REPORT = `sendClientReport/weekly-report`,
  EMAIL_VALIDATION_CHECK = `emailPing/the-checker`,
}

// need to change production URL to be actual Cloud Functions URLs
const CLOUD_FUNCTIONS_BASE_URL =
  CURRENT_ENVIRONMENT === Environment.Production
    ? 'https://us-central1-jobattrition.cloudfunctions.net/'
    : CURRENT_ENVIRONMENT === Environment.Staging
    ? 'https://us-central1-warmly-staging.cloudfunctions.net/'
    : REACT_APP_WARMLY_LOCAL_ENVIRONMENT === Environment.Production
    ? `http://localhost:5001/jobattrition/us-central1/`
    : `http://localhost:5001/warmly-staging/us-central1/`;

export const cloudFunctionsURL = {
  PARSE_CLIENT_CSV: CLOUD_FUNCTIONS_BASE_URL + CloudFunctionEndpoint.PARSE_CLIENT_CSV,
  APPROVE_SELECTED_CRM_CHANGES: CLOUD_FUNCTIONS_BASE_URL + CloudFunctionEndpoint.APPROVE_SELECTED_CRM_CHANGES,
  APPROVE_CRM_JOB_CHANGES: CLOUD_FUNCTIONS_BASE_URL + CloudFunctionEndpoint.APPROVE_CRM_JOB_CHANGES,
  DISMISS_CRM_JOB_CHANGES: CLOUD_FUNCTIONS_BASE_URL + CloudFunctionEndpoint.DISMISS_CRM_JOB_CHANGES,
  INVITE_NEW_USER: CLOUD_FUNCTIONS_BASE_URL + CloudFunctionEndpoint.INVITE_NEW_USER,
  RESET_PASSWORD: CLOUD_FUNCTIONS_BASE_URL + CloudFunctionEndpoint.RESET_PASSWORD,
  CLIENT_API: CLOUD_FUNCTIONS_BASE_URL + CloudFunctionEndpoint.CLIENT,
  SALESFORCE_AUTH: CLOUD_FUNCTIONS_BASE_URL + CloudFunctionEndpoint.SALESFORCE_AUTH,
  SALESFORCE_SETUP_FIELDS: CLOUD_FUNCTIONS_BASE_URL + CloudFunctionEndpoint.SALESFORCE_SETUP_FIELDS,
  SALESFORCE_SYNC_CONTACTS: CLOUD_FUNCTIONS_BASE_URL + CloudFunctionEndpoint.SALESFORCE_SYNC_CONTACTS,
  SALESFORCE_ENRICH_CONTACTS: CLOUD_FUNCTIONS_BASE_URL + CloudFunctionEndpoint.SALESFORCE_ENRICH_CONTACTS,
  HUBSPOT_INSTALL: CLOUD_FUNCTIONS_BASE_URL + CloudFunctionEndpoint.HUBSPOT_INSTALL,
  ADMIN_GENERATE_JOB_CHANGES: CLOUD_FUNCTIONS_BASE_URL + CloudFunctionEndpoint.ADMIN_GENERATE_JOB_CHANGES,
  ADMIN_CREATE_NEW_USER: CLOUD_FUNCTIONS_BASE_URL + CloudFunctionEndpoint.ADMIN_CREATE_NEW_USER,
  ADMIN_DENORMALIZE_CONTACTS: CLOUD_FUNCTIONS_BASE_URL + CloudFunctionEndpoint.ADMIN_DENORMALIZE_CONTACTS,
  ADMIN_APPEND_COMPANY_URL: CLOUD_FUNCTIONS_BASE_URL + CloudFunctionEndpoint.ADMIN_APPEND_COMPANY_URL,
  SCRAPE_CONTACTS: CLOUD_FUNCTIONS_BASE_URL + CloudFunctionEndpoint.SCRAPE_CONTACTS,
  EMAIL_VALIDATION_CHECK: CLOUD_FUNCTIONS_BASE_URL + CloudFunctionEndpoint.EMAIL_VALIDATION_CHECK,
  CREATE_CONTACT_DATA_ID: CLOUD_FUNCTIONS_BASE_URL + CloudFunctionEndpoint.CREATE_CONTACT_DATA_ID,
  SEND_WEEKLY_JOB_CHANGE_REPORT: CLOUD_FUNCTIONS_BASE_URL + CloudFunctionEndpoint.SEND_WEEKLY_JOB_CHANGE_REPORT,
};

export enum ContactDataField {
  EMAIL_DATA = 'emailData',
  EMAIL_ARRAY = 'emailArray',
  LINKEDIN_URL = 'linkedInURL',
  LINKEDIN_ID = 'linkedInId',
  LINKEDIN_DATA = 'linkedInData',
  CURRENT_JOB = 'currentJob',
  CLIENT_IDS = 'clientIds',
  PROFILE_PHOTO = 'profilePhoto',
  ALL_JOBS = 'allJobs',
  COMPANY_URL = 'companyURL',
}

// Field is the actual name of the field in Firebase
export const ClientContactAttributeMetaData: {
  [attribute in ClientContactAttribute]: ClientContactMetaData;
} = {
  [ClientContactAttribute.FULL_NAME]: {
    field: ClientContactAttributeField.FULL_NAME,
    displayText: 'Full Name',
  },
  [ClientContactAttribute.FIRST_NAME]: {
    field: ClientContactAttributeField.FIRST_NAME,
    displayText: 'First Name',
  },
  [ClientContactAttribute.LAST_NAME]: {
    field: ClientContactAttributeField.LAST_NAME,
    displayText: 'Last Name',
  },
  [ClientContactAttribute.CURRENT_COMPANY]: {
    field: ClientContactAttributeField.CURRENT_JOB,
    displayText: 'Company',
  },
  [ClientContactAttribute.CURRENT_TITLE]: {
    field: ClientContactAttributeField.CURRENT_JOB,
    displayText: 'Title',
  },
  [ClientContactAttribute.LINKEDIN_URL]: {
    field: ClientContactAttributeField.LINKEDIN_URL,
    displayText: 'LinkedIn',
  },
  [ClientContactAttribute.EMAIL]: {
    field: ClientContactAttributeField.EMAIL,
    displayText: 'Email',
  },
  [ClientContactAttribute.OTHER]: {
    field: ClientContactAttributeField.CRM_DATA,
    displayText: 'Other',
  },
};

export const ClientDownloadCSVHeaders = [
  {
    label: 'CRM_EMAIL',
    key: ClientContactAttributeField.EMAIL,
  },
  {
    label: 'CRM_FIRST_NAME',
    key: ClientContactAttributeField.FIRST_NAME,
  },
  {
    label: 'CRM_LAST_NAME',
    key: ClientContactAttributeField.LAST_NAME,
  },
  {
    label: 'CRM_FULL_NAME',
    key: ClientContactAttributeField.FULL_NAME,
  },
  {
    label: 'CRM_COMPANY_NAME',
    key: ClientContactAttributeField.COMPANY_NAME,
  },
  {
    label: 'CRM_TITLE',
    key: ClientContactAttributeField.TITLE,
  },
  {
    label: 'CRM_LINKEDIN',
    key: ClientContactAttributeField.LINKEDIN_URL,
  },
  {
    label: 'ENRICHED_COMPANY_NAME',
    key: ClientContactAttributeField.CONTACT_DATA_COMPANY_NAME,
  },
  {
    label: 'ENRICHED_TITLE',
    key: ClientContactAttributeField.CONTACT_DATA_TITLE,
  },
  {
    label: 'ENRICHED_LINKEDIN_URL',
    key: ClientContactAttributeField.CONTACT_DATA_LINKEDIN_URL,
  },
  {
    label: 'ENRICHED_START_DATE',
    key: ClientContactAttributeField.CONTACT_DATA_START_DATE,
  },
  {
    label: 'ENRICHED_END_DATE',
    key: ClientContactAttributeField.CONTACT_DATA_END_DATE,
  },
  {
    label: 'ENRICHED_DURATION',
    key: ClientContactAttributeField.CONTACT_DATA_DURATION,
  },
  {
    label: 'ENRICHED_COMPANY_URL',
    key: ClientContactAttributeField.CONTACT_DATA_COMPANY_URL,
  },
  {
    label: 'ENRICHED_EMAIL',
    key: ClientContactAttributeField.CONTACT_DATA_UPDATED_EMAIL,
  },
  {
    label: 'JOB_CHANGED_STATUS',
    key: ClientContactAttributeField.JOB_CHANGED_STATUS,
  },
  {
    label: 'JOB_CHANGE_FLAG',
    key: ClientContactAttributeField.JOB_CHANGED,
  },
  {
    label: 'VERIFIED_FLAG',
    key: ClientContactAttributeField.VERIFIED,
  },
];

export const QADownloadCSVHeaders = [
  {
    label: 'CRM_EMAIL',
    key: ClientContactAttributeField.EMAIL,
  },
  {
    label: 'CRM_FIRST_NAME',
    key: ClientContactAttributeField.FIRST_NAME,
  },
  {
    label: 'CRM_LAST_NAME',
    key: ClientContactAttributeField.LAST_NAME,
  },
  {
    label: 'CRM_FULL_NAME',
    key: ClientContactAttributeField.FULL_NAME,
  },
  {
    label: 'CRM_COMPANY_NAME',
    key: ClientContactAttributeField.COMPANY_NAME,
  },
  {
    label: 'CRM_TITLE',
    key: ClientContactAttributeField.TITLE,
  },
  {
    label: 'CRM_LINKEDIN',
    key: ClientContactAttributeField.LINKEDIN_URL,
  },
  {
    label: 'ENRICHED_COMPANY_NAME',
    key: ClientContactAttributeField.CONTACT_DATA_COMPANY_NAME,
  },
  {
    label: 'ENRICHED_TITLE',
    key: ClientContactAttributeField.CONTACT_DATA_TITLE,
  },
  {
    label: 'ENRICHED_LINKEDIN_URL',
    key: ClientContactAttributeField.CONTACT_DATA_LINKEDIN_URL,
  },
  {
    label: 'ENRICHED_START_DATE',
    key: ClientContactAttributeField.CONTACT_DATA_START_DATE,
  },
  {
    label: 'ENRICHED_END_DATE',
    key: ClientContactAttributeField.CONTACT_DATA_END_DATE,
  },
  {
    label: 'ENRICHED_DURATION',
    key: ClientContactAttributeField.CONTACT_DATA_DURATION,
  },
  {
    label: 'JOB_CHANGE_FLAG',
    key: ClientContactAttributeField.JOB_CHANGED,
  },
  {
    label: 'QA_JOB_CHANGE_STATUS',
    key: ClientContactAttributeField.QA_JOB_CHANGE_STATUS,
  },
  {
    label: 'QA_JOB_CHANGE_STATUS_DATE',
    key: ClientContactAttributeField.QA_JOB_CHANGE_STATUS_DATE,
  },
  {
    label: 'QA_LINKEDIN_URL',
    key: ClientContactAttributeField.QA_LINKEDIN_URL,
  },
  {
    label: 'QA_LINKEDIN_STATUS',
    key: ClientContactAttributeField.QA_LINKEDIN_STATUS,
  },
  {
    label: 'QA_NOTES',
    key: ClientContactAttributeField.QA_NOTES,
  },
  {
    label: 'QA_DATE',
    key: ClientContactAttributeField.QA_DATE,
  },
  {
    label: 'QA_ASSESSMENT',
    key: ClientContactAttributeField.QA_ASSESSMENT,
  },
  {
    label: 'QA_USER_ID',
    key: ClientContactAttributeField.QA_USER_ID,
  },
  {
    label: 'QA_EMAIL',
    key: ClientContactAttributeField.QA_EMAIL,
  },
  {
    label: 'QA_COMPANY_URL',
    key: ClientContactAttributeField.QA_COMPANY_URL,
  },
  {
    label: 'QA_COMPANY_LINKEDIN_URL',
    key: ClientContactAttributeField.QA_COMPANY_LINKEDIN_URL,
  },
];

export enum JobChangeStatus {
  NO_JOB_CHANGE = 'No job change',
  LEFT_OLD_JOB_BUT_NO_NEW_JOB = 'Left old job but no new job',
  JOB_CHANGED = 'Job changed',
  DATA_ENRICHED = 'Data enriched',
  JOB_CHANGED_BUT_SAME_COMPANY = 'Job changed but same company',
  EMAIL_INVALID = 'Email invalid',
}

export const JobChangeStatusMap = {
  [JobChangeStatus.LEFT_OLD_JOB_BUT_NO_NEW_JOB]: 'In between jobs',
  [JobChangeStatus.JOB_CHANGED]: 'New Company',
  [JobChangeStatus.JOB_CHANGED_BUT_SAME_COMPANY]: 'New job title',
  [JobChangeStatus.DATA_ENRICHED]: 'Data enriched',
  [JobChangeStatus.NO_JOB_CHANGE]: 'Data enriched',
  [JobChangeStatus.EMAIL_INVALID]: 'Email invalid',
};

export const JobChangeStatusIconMap = {
  [JobChangeStatus.LEFT_OLD_JOB_BUT_NO_NEW_JOB]: '💼',
  [JobChangeStatus.JOB_CHANGED]: '🏢',
  [JobChangeStatus.JOB_CHANGED_BUT_SAME_COMPANY]: '🙌',
  [JobChangeStatus.NO_JOB_CHANGE]: '',
  [JobChangeStatus.EMAIL_INVALID]: '📩',
};

export enum CompaniesField {
  COMPANY_URL = 'companyURL',
  COMPANY_LINKEDIN_URL = 'companyLinkedInURL',
  COMPANY_DOMAINS = 'companyDomains',
  COMPANY_NAMES = 'companyNames',
}

export enum DegreeType {
  Associate = 'ASSOCIATE',
  Bachelors = 'BACHELORS',
  Masters = 'MASTERS',
  MBA = 'MBA',
  PHD = 'PHD',
  JD = 'JD',
}

export enum EmailType {
  GENERIC = 'GENERIC',
  CONGRADULATE_NEW_JOB = 'CONGRADULATE_NEW_JOB',
}

export enum StorageFolder {
  CLIENT_UPLOAD = 'client_upload',
}

export {
  LINKEDIN_ICON,
  TWITTER_ICON,
  EMAIL_ICON,
  HUBSPOT_LOGO,
  CSV_LOGO,
  SECURE_ICON,
  WARMLY_LOGO_ICON,
  CEO_AVATAR,
  CTO_AVATAR,
  SALESFORCE_LOGO,
  WARMLY_LOGO_HORIZONTAL_COLOR,
};

export enum HTTP_RESPONSE {
  OK = 200,
  NO_CONTENT = 204,
  REDIRECT = 303,
  BAD_REQUEST = 400,
  UNAUTHORIZED = 401,
  FORBIDDEN = 403,
  NOT_FOUND = 404,
  CONFLICT = 409,
  INTERNAL_SERVER_ERROR = 500,
}

export enum AlertSeverity {
  ERROR = 'error',
  WARNING = 'warning',
  INFO = 'info',
  SUCCESS = 'success',
}

export enum SalesforceURL {
  EDITIONS_WITH_API_ACCESS = 'https://help.salesforce.com/articleView?type=1&mode=1&id=000326486',
  ADMIN_USER_DESCRIPTION = 'https://help.salesforce.com/articleView?id=basics_understanding_administrator.htm&type=5',
  ADD_ADMIN_USER = 'https://help.salesforce.com/articleView?id=000327017&type=1&mode=1',
  ADD_CUSTOM_FIELD = 'https://help.salesforce.com/articleView?id=adding_fields.htm&type=0',
}

export enum SyncStatus {
  SYNCING = 'SYNCING',
  COMPLETE = 'COMPLETE',
  ERROR = 'ERROR',
}

export enum ProjectId {
  Development = 'warmly-staging',
  Staging = 'warmly-staging',
  Production = 'jobattrition',
}

// We attempt to use recommended default events as much as possible
// https://support.google.com/analytics/answer/9267735?hl=en&authuser=1&ref_topic=9267641
export enum AnalyticsEvent {
  LOGIN = 'login',
  SIGN_UP = 'sign_up',
}

export enum AnalyticsParameter {
  FIRST_NAME = 'first_name',
  LAST_NAME = 'last_name',
  FULL_NAME = 'full_name',
  COMPANY_NAME_FULL_NAME = 'companyName_fullName',
  EMAIL = 'email',
  CLIENT_NAME = 'client_name',
  CLIENT_ID = 'client_id',
  USER_TYPE = 'user_type',
  PAYMENT_STATUS = 'payment_status',
  STATUS = 'status',
}

export enum QAStatus {
  QA_ASSIGNED = 'QA Assigned',
  QA_COMPLETED = 'QA Completed',
  QA_SUSPENDED = 'QA Suspended',
}

export enum ClientStatus {
  TRIAL = 'TRIAL',
  UNPAID = 'UNPAID',
  PAID = 'PAID',
  TRIAL_EXPIRED = 'TRIAL_EXPIRED',
  DISABLED = 'DISABLED',
  NOT_SET = 'NOT_SET',
}

export enum ClientPaymentStatus {
  PAID = 'paid',
  NOT_PAID = 'unpaid',
}

// To increase security, we do not use semantic words for the actual keys, since the local storage items are easily accessible
// by the users
export enum LocalStorageItem {
  LAST_SELECTED_CLIENT_ID = 'warmly_lsci',
}

export const MAX_CHUNK_SIZE = 400;

export const SENTRY_DSN = 'https://55efe3649813490ba0f2ca790ca0c8fb@o406756.ingest.sentry.io/5280634';
