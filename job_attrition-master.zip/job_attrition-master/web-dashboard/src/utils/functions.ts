import firebase from 'firebase/app';

import {
  ClientContactAttribute,
  ClientContactAttributeMetaData,
  CURRENT_ENVIRONMENT,
  EmailType,
  Environment,
  UserType,
} from './constants';

export const getCurrentTimestamp = () => {
  return firebase.firestore.Timestamp.fromDate(new Date());
};

export const extractLinkedInIdFromUrl = (url: string): string => {
  const match = url.match(/https?:\/\/.*\.?linkedin.com\/in\/([^?|/]*)/);
  if (!match) {
    return '';
  }

  const [, linkedInId] = match;

  return linkedInId;
};

export const addhttps = (url: string): string => {
  if (!/^(?:f|ht)tps?\:\/\//.test(url)) {
    url = 'https://' + url;
  }
  return url;
};

export const checkURLContainsLinkedInProfile = (url: string) => {
  if (url.toLowerCase().includes('linkedin.com/in') || url.toLowerCase().includes('linkedin.com/pub')) {
    return true;
  } else {
    return;
  }
};

export const getClientContactName = (clientContact: ClientContact, initials?: boolean): string => {
  const { firstName = '', lastName = '', fullName = '' } = clientContact;

  if (fullName) {
    if (initials) {
      return `${fullName.slice(0, 2)}`;
    } else {
      return fullName;
    }
  } else if (firstName || lastName) {
    if (initials) {
      return firstName === '' && lastName === ''
        ? ''
        : `${firstName !== '' ? firstName[0]?.toUpperCase() : ''} ${lastName !== '' ? lastName[0]?.toUpperCase() : ''}`;
    } else {
      return `${firstName} ${lastName}`;
    }
  } else {
    return '';
  }
};

export const getAttribute = (csvHeader: string): ClientContactAttribute => {
  // If the header text from the csv file includes an attribute's text, we use that attribute
  // e.g., if the CSV header is "Client LinkedIn URL", we assume that is the "linkedIn" attribute
  for (let attribute in ClientContactAttributeMetaData) {
    if (csvHeader.toLowerCase().includes(ClientContactAttributeMetaData[attribute].displayText.toLowerCase())) {
      return attribute as ClientContactAttribute;
    } else if (csvHeader.toLowerCase() === 'e-mail') {
      return ClientContactAttribute.EMAIL;
    } else if (csvHeader.toLowerCase() === 'name') {
      // If the header is just "name", assume that is the contact's full name
      return ClientContactAttribute.FULL_NAME;
    }
  }

  return ClientContactAttribute.OTHER;
};

export const allContactsHaveEmails = (contactDataArray: ClientContact[]) => {
  for (const contactData of contactDataArray) {
    const contactEmail = contactData.email;
    // Simple check: the contact's email must be a string and cannot be whitespace
    if (typeof contactEmail !== 'string' || !contactEmail.trim()) {
      return false;
    }
  }

  return true;
};

export const parseDomain = (url: string) => {
  return new URL(url);
};

export const isRealURL = (url: string) => {
  try {
    const urlObject = new URL(url);
    if (urlObject) {
      return true;
    } else {
      return false;
    }
  } catch (e) {
    console.log('error', e);
    return false;
  }
};

export const extractLinkedInCompanyIdFromUrl = (url: string): string => {
  const match = url.match(/https?:\/\/.*\.?linkedin.com\/company\/([^?|\/]*)/);
  if (!match) {
    return '';
  }

  const [, linkedInId] = match;

  return linkedInId;
};

export const getUserTypeByEmail = (email: string): UserType => {
  // TODO: Add email confirmation step before allowing user to access their account.
  //     We don't want random users signing up on TrackAdvocates saying their email is
  //     @warmlycomma.com when they don't actually have one, and then being able to
  //     access any client's data.
  if (email.toLowerCase().endsWith('@warmlycomma.com') && CURRENT_ENVIRONMENT !== Environment.Production) {
    return UserType.INTERNAL;
  } else {
    return UserType.CLIENT;
  }
};

export type MappedAttributes = {
  [headerName: string]: ClientContactAttribute;
};
