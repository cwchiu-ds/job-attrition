import { Box, Button, CircularProgress, Grid, Hidden, TextField, Typography } from '@material-ui/core';
import { Alert } from '@material-ui/lab';
import React, { useContext, useState } from 'react';
import { Redirect, useHistory } from 'react-router-dom';

import { AuthContext } from '../components/auth/AuthProvider';
import NavBar from '../components/NavBar';
import { useInitiateOnboarding } from '../hooks/auth';
import { logError } from '../modules/analytics';
import { onboardNewUser, OnboardNewUserData, signInWithEmailLink } from '../modules/auth';
import { AlertSeverity, NavigationPath, WarmlyColor } from '../utils/constants';
import { getAuthErrorMessage } from '../utils/errors';

const Onboard = () => {
  const { user } = useContext(AuthContext);
  const [inviteeUser, setInviteeUser] = useState<firebase.User>();
  const [isLoading, setIsLoading] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const { inviteeClientName, inviteeClientId, isEmailSignIn } = useInitiateOnboarding();
  const history = useHistory();

  if (user?.clientId) {
    return <Redirect to={NavigationPath.MAIN} />;
  }

  const onSubmitEmailConfirm = async (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
    e.preventDefault();

    if (!email.trim()) {
      setErrorMessage('Email is required');
      return;
    }

    try {
      const authUserCredential = await signInWithEmailLink(email, window.location.href);

      const authUser = authUserCredential.user;

      if (!authUser) {
        setErrorMessage('Your invite link was invalid, please contact the inviter for a new link');
        return;
      }

      setInviteeUser(authUser);
    } catch (err) {
      logError(err, 'Error onboarding user');
      const errorMessage = getAuthErrorMessage(err);
      setErrorMessage(errorMessage);
    }
  };

  const onSubmitOnboard = async (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
    e.preventDefault();

    let validationErrorMessage = '';
    if (!firstName.trim() || !lastName.trim() || !password.trim()) {
      validationErrorMessage = 'Required: ';
      let emptyFields = [];

      if (!firstName.trim()) {
        emptyFields.push('first name');
      }

      if (!lastName.trim()) {
        emptyFields.push('last name');
      }

      if (!password.trim()) {
        emptyFields.push('password');
      }

      validationErrorMessage += emptyFields.join(', ');
    }

    if (validationErrorMessage) {
      setErrorMessage(validationErrorMessage);
      return;
    }

    try {
      setIsLoading(true);
      const onboardNewUserData: OnboardNewUserData = {
        newUser: inviteeUser!,
        password,
        firstName,
        lastName,
        phoneNumber,
        clientId: inviteeClientId,
      };

      await onboardNewUser(onboardNewUserData);

      history.push(NavigationPath.MAIN);
    } catch (err) {
      logError(err, 'Error onboarding user');
      const errorMessage = getAuthErrorMessage(err);
      setErrorMessage(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <NavBar />
      <Grid container justify="center" style={{ backgroundColor: WarmlyColor.WHITE }}>
        <Hidden xsDown>
          <Grid item sm={3}>
            <img className="person-standing" alt="Person" src={require('../assets/person-standing.svg')} width="75%" />
          </Grid>
        </Hidden>

        <Grid item xs={8} sm={6} md={4}>
          {/* Step 1 - Ask for email confirmation */}
          {inviteeClientName && isEmailSignIn && !inviteeUser && (
            <form>
              <Box marginTop={4} marginLeft={-4}>
                <Box>
                  <Typography variant="h1" color="primary">
                    You have been invited to sign up as a member of {inviteeClientName}
                  </Typography>
                </Box>

                <Box marginTop={1}>
                  <Typography>
                    If that is correct, please begin the onboarding process by confirming your email below
                  </Typography>
                </Box>

                <Box marginTop={1}>
                  <Typography variant="subtitle2">
                    * Please note that onboarding must be completed in one session. In the event that you could not
                    complete the onboarding process, please ask the inviter for a new link.
                  </Typography>
                </Box>

                <Box marginTop={3}>
                  <TextField
                    label="Email*"
                    type="email"
                    value={email}
                    onChange={(event: React.ChangeEvent<HTMLInputElement>) => {
                      setEmail(event.target.value);
                    }}
                    fullWidth
                  />
                </Box>

                <Box marginTop={3} textAlign="right">
                  <Button variant="contained" color="primary" type="submit" onClick={onSubmitEmailConfirm}>
                    Confirm
                  </Button>
                </Box>

                <Box marginTop={3}>{errorMessage && <Alert severity={AlertSeverity.ERROR}>{errorMessage}</Alert>}</Box>
              </Box>
            </form>
          )}

          {/* Step 2 - once email confirmed, fill out rest of the information */}
          {inviteeUser && (
            <form>
              <Box marginTop={4} marginLeft={-4}>
                <Typography variant="h1" color="primary">
                  Please fill out the form to complete onboarding
                </Typography>

                <Box marginTop={3}>
                  <TextField
                    label="First Name*"
                    value={firstName}
                    onChange={(event: React.ChangeEvent<HTMLInputElement>) => {
                      setFirstName(event.target.value);
                    }}
                    fullWidth
                  />
                </Box>

                <Box marginTop={3}>
                  <TextField
                    label="Last Name*"
                    value={lastName}
                    onChange={(event: React.ChangeEvent<HTMLInputElement>) => {
                      setLastName(event.target.value);
                    }}
                    fullWidth
                  />
                </Box>

                <Box marginTop={3}>
                  <TextField
                    label="Phone number"
                    type="tel"
                    value={phoneNumber}
                    onChange={(event: React.ChangeEvent<HTMLInputElement>) => {
                      setPhoneNumber(event.target.value);
                    }}
                    fullWidth
                  />
                </Box>

                <Box marginTop={3}>
                  <TextField
                    label="Password*"
                    type="password"
                    value={password}
                    onChange={(event: React.ChangeEvent<HTMLInputElement>) => {
                      setPassword(event.target.value);
                    }}
                    fullWidth
                  />
                </Box>

                <Box marginTop={3}>
                  <Button
                    variant="contained"
                    color="primary"
                    type="submit"
                    onClick={onSubmitOnboard}
                    disabled={isLoading}
                  >
                    Complete Onboarding
                  </Button>
                  {isLoading && (
                    <Box marginTop={1} marginLeft={2}>
                      <CircularProgress />
                    </Box>
                  )}
                </Box>

                <Box marginTop={3}>{errorMessage && <Alert severity={AlertSeverity.ERROR}>{errorMessage}</Alert>}</Box>
              </Box>
            </form>
          )}
        </Grid>
      </Grid>
    </>
  );
};

export default Onboard;
