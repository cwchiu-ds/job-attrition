import { Box, createStyles, Grid, makeStyles, Step, StepLabel, Stepper, Typography } from '@material-ui/core';
import React, { useContext } from 'react';

import { AuthContext } from '../../components/auth/AuthProvider';
import CustomizeFields from './integrationSteps/CustomizeFields';
import IntegrationComplete from './integrationSteps/IntegrationComplete';
import SyncContacts from './integrationSteps/SyncContacts';

const useStyles = makeStyles(() =>
  createStyles({
    stepper: {
      backgroundColor: 'transparent',
    },
  })
);

enum IntegrationStep {
  CUSTOMIZE_FIELDS = 0,
  SYNC_CONTACTS = 1,
  INTEGRATION_COMPLETE = 2,
}

const getIntegrationStep = (client: Client): IntegrationStep => {
  if (!client.salesforceIntegration?.salesforceMapping) {
    return IntegrationStep.CUSTOMIZE_FIELDS;
  } else if (!client.salesforceIntegration.syncStatus) {
    return IntegrationStep.SYNC_CONTACTS;
  } else {
    return IntegrationStep.INTEGRATION_COMPLETE;
  }
};

const IntegrationSteps: React.FC = () => {
  const classes = useStyles();
  const { client } = useContext(AuthContext);

  const activeStep = getIntegrationStep(client!);

  return (
    <Grid container direction="row" justify="center" spacing={3}>
      <Grid container item xs={12}>
        <Typography variant="h1" color="primary">
          Salesforce Integration
        </Typography>
      </Grid>

      <Grid item xs={12}>
        <Box width="100%">
          <Stepper activeStep={activeStep} classes={{ root: classes.stepper }}>
            <Step>
              <StepLabel>Customize fields</StepLabel>
            </Step>
            <Step>
              <StepLabel>Sync contacts</StepLabel>
            </Step>
            <Step>
              <StepLabel>Integration complete</StepLabel>
            </Step>
          </Stepper>
        </Box>
      </Grid>

      {activeStep === IntegrationStep.CUSTOMIZE_FIELDS && <CustomizeFields />}
      {activeStep === IntegrationStep.SYNC_CONTACTS && <SyncContacts />}
      {activeStep === IntegrationStep.INTEGRATION_COMPLETE && <IntegrationComplete />}
    </Grid>
  );
};

export default IntegrationSteps;
