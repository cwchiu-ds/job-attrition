import { faTable } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { Box, Link, List, ListItem, ListItemIcon, ListItemText } from '@material-ui/core';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import React from 'react';

import { SalesforceURL, WARMLY_EMAIL, WarmlyColor } from '../../utils/constants';

interface Props {
  isOpen: boolean;
  setIsOpen: React.Dispatch<React.SetStateAction<boolean>>;
  onConfirm: () => void;
}
const SalesforceFirstTimeEnrichment: React.FC<Props> = ({ isOpen, setIsOpen, onConfirm }) => {
  const handleClose = () => {
    setIsOpen(false);
  };

  const onClickConfirm = () => {
    setIsOpen(false);
    onConfirm();
  };

  return (
    <Dialog open={isOpen} onClose={handleClose} aria-labelledby="reset-password-form">
      <DialogTitle>Sync to Salesforce</DialogTitle>
      <DialogContent>
        <Box>
          Hello!{' '}
          <span role="img" aria-label="wave-hello">
            👋
          </span>{' '}
          This appears to be the first time you are syncing data from Warmly back to Salesforce.
        </Box>
        <Box marginTop={2}>
          We are excited to enrich your data, but before proceeding, we would like to inform you on how this works! Specifically, we will:
        </Box>
        <List dense={true}>
          <ListItem>
            <ListItemIcon>
              <FontAwesomeIcon icon={faTable} color={WarmlyColor.DARK_BLUE} />
            </ListItemIcon>
            <ListItemText
              primary="Create 4 custom fields to store the enriched data: Job Changed, Latest Job Title, Latest Company Name, and Latest LinkedIn"
              secondary={
                <Link href={SalesforceURL.ADD_CUSTOM_FIELD} target="_blank" rel="noopener noreferrer">
                  What’s this? Open new tab for help page.
                </Link>
              }
            />
          </ListItem>
        </List>
        <Box>
          As always, if you have any questions, please contact us at{' '}
          <Link
            href={`https://mail.google.com/mail/?view=cm&fs=1&to=${WARMLY_EMAIL.SUPPORT_TECH}&su=[Warmly] Question about Salesforce Integration`}
            target="_blank"
            rel="noopener noreferrer"
          >
            tech@warmlycomma.com
          </Link>
        </Box>
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose} variant="outlined" color="primary">
          Cancel
        </Button>
        <Button onClick={onClickConfirm} variant="contained" color="primary">
          Proceed
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default SalesforceFirstTimeEnrichment;
