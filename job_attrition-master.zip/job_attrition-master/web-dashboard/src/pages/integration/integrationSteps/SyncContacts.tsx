import { faClock } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  Box,
  Button,
  CircularProgress,
  Grid,
  Link,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Paper,
  Typography,
} from '@material-ui/core';
import { Alert } from '@material-ui/lab';
import React, { useContext, useState } from 'react';

import { AuthContext } from '../../../components/auth/AuthProvider';
import { updateClient } from '../../../modules/client';
import { initiateSalesforceSyncContacts } from '../../../modules/cloudFunctions';
import { AlertSeverity, ClientContactAttribute, WARMLY_EMAIL } from '../../../utils/constants';
import { getApiErrorMessage } from '../../../utils/errors';

export const defaultSalesforceMapping: SalesforceMapping = {
  [ClientContactAttribute.FIRST_NAME]: 'FirstName',
  [ClientContactAttribute.LAST_NAME]: 'LastName',
  [ClientContactAttribute.CURRENT_TITLE]: 'Title',
  [ClientContactAttribute.EMAIL]: 'Email',
};

export const trackAdvocatesAttributes = [
  ClientContactAttribute.FIRST_NAME,
  ClientContactAttribute.LAST_NAME,
  ClientContactAttribute.CURRENT_TITLE,
  ClientContactAttribute.EMAIL,
  ClientContactAttribute.LINKEDIN_URL,
];

export const requiredTrackAdvocatesAttributes = [
  ClientContactAttribute.FIRST_NAME,
  ClientContactAttribute.LAST_NAME,
  ClientContactAttribute.EMAIL,
];

const estimateSyncTime = (contactCount: number) => {
  let estimateText = '';

  if (contactCount > 100000) {
    estimateText = `Due to the high number of Salesforce Contacts, we will require a more customized solution to provide the best experience for you. 
      If you have not discussed this with us, please contact us at ${WARMLY_EMAIL.SUPPORT_TECH} before continuing.`;
  } else if (contactCount > 50000) {
    estimateText = 'Several minutes to complete under normal conditions';
  } else if (contactCount > 5000) {
    estimateText = 'Up to a few minutes to complete under normal conditions';
  } else {
    estimateText = 'A few minutes.';
  }

  return estimateText;
};

// const estimateApiUse = (contactCount: number) => {
//   // https://developer.salesforce.com/docs/atlas.en-us.soql_sosl.meta/soql_sosl/sforce_api_calls_sosl_limit.htm
//   // The hard limit on records return per API query is 2000 (if you only query one field), but this is lower in practice
//   // because the more fields you query, the fewer records you can get per query
//   const ESTIMATED_AVERAGE_RECORDS_PER_QUERY = 500;
//   const estimatedApiUse = Math.ceil(contactCount / ESTIMATED_AVERAGE_RECORDS_PER_QUERY);

//   return `We batch all of our transactions whenever possible to minimize the number of Salesforce API calls used.
//     For this initial syncing process, we roughly estimate the number of API calls to be ${estimatedApiUse.toLocaleString()}.
//     The number of actual calls used may vary depending on the number of fields synced.`;
// };

const SyncContacts: React.FC = () => {
  const { client } = useContext(AuthContext);

  const [errorMessage, setErrorMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const contactCount = client?.salesforceIntegration?.contactCount || 0;
  // const contactCount = 1000000;

  const onClickConfirm = async () => {
    try {
      setIsLoading(true);
      await initiateSalesforceSyncContacts();
    } catch (err) {
      setErrorMessage(getApiErrorMessage(err));
      setIsLoading(false);
    }
  };

  const onClickBack = async () => {
    try {
      setIsLoading(true);
      await updateClient(client!.id, {
        salesforceIntegration: {
          salesforceMapping: null
        }
      });
    } catch (err) {
      setErrorMessage(getApiErrorMessage(err));
      setIsLoading(false);
    }
  }

  return (
    <>
      <Grid container item direction="column" xs={11} spacing={1}>
        <Grid item>
          <Typography variant="h5">Step 2 - Sync Contacts</Typography>
        </Grid>
        <Grid item>
          <Typography variant="subtitle2">
            <em>{contactCount.toLocaleString()}</em> contacts detected and ready to sync
          </Typography>
        </Grid>
      </Grid>

      <Grid item xs={11}>
        <Paper>
          <List>
            <ListItem>
              <ListItemIcon>
                <FontAwesomeIcon icon={faClock} size="2x" />
              </ListItemIcon>
              <ListItemText primary="Sync Time" secondary={estimateSyncTime(contactCount)} />
            </ListItem>
            {/* NOTE Remove API use estimates - maybe bring it back later if needed */}
            {/* <ListItem>
              <ListItemIcon>
                <FontAwesomeIcon icon={faMouse} size="2x" />
              </ListItemIcon>
              <ListItemText primary="API Use" secondary={estimateApiUse(contactCount)} />
            </ListItem> */}
          </List>

          <Box paddingLeft={2} paddingBottom={1} fontWeight="bold">
            Questions? We can help! We’re here for you anytime at{' '}
            <Link
              href={`https://mail.google.com/mail/?view=cm&fs=1&to=${WARMLY_EMAIL.SUPPORT_TECH}&su=[Warmly] Question about Salesforce Integration`}
              target="_blank"
              rel="noopener noreferrer"
            >
              tech@warmlycomma.com
            </Link>
          </Box>
        </Paper>
      </Grid>

      <Grid container item justify="space-between" alignItems="center" xs={11}>
        <Grid container item xs={3}>
          <Button variant="outlined" color="primary" onClick={onClickBack} disabled={isLoading}>
            Back (reset mapping)
          </Button>
        </Grid>

        <Grid container item xs>
          {errorMessage && (
            <Grid item xs>
              <Alert severity={AlertSeverity.ERROR}>{errorMessage}</Alert>
            </Grid>
          )}
          <Grid container item justify="flex-end" alignItems="center">
            {isLoading && (
              <Box marginRight={2}>
                <CircularProgress />
              </Box>
            )}
            <Button variant="contained" color="primary" onClick={onClickConfirm} disabled={isLoading}>
              Confirm & Sync
            </Button>
          </Grid>
        </Grid>
      </Grid>
    </>
  );
};

export default SyncContacts;
