import Paper from '@material-ui/core/Paper';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import { Field } from 'jsforce';
import React, { useContext } from 'react';

import { AuthContext } from '../../../../components/auth/AuthProvider';
import { ClientContactAttribute } from '../../../../utils/constants';
import { trackAdvocatesAttributes } from '../CustomizeFields';
import MapAttributesRow from './MapAttributesRow';

const columns = [
  { id: 'trackadvocates_attribute', label: 'Warmly Attribute (*required)', minWidth: 200 },
  {
    id: 'salesforce_field_name',
    label: 'Salesforce Field Name',
    minWidth: 200,
  },
  { id: 'salesforce_field_select', label: 'Select Field', minWidth: 200 },
];

interface Props {
  salesforceMapping: SalesforceMapping;
  setSalesforceMapping: React.Dispatch<React.SetStateAction<SalesforceMapping>>;
}

const invalidFieldTypes = ['date', 'datetime'];

const MapAttributesTable: React.FC<Props> = ({ salesforceMapping, setSalesforceMapping }) => {
  const { client } = useContext(AuthContext);
  const filteredFields = (client?.salesforceIntegration?.fields || []).filter((field: Field) => {
    return !invalidFieldTypes.includes(field.type);
  });

  return (
    <Paper>
      <TableContainer>
        <Table>
          <TableHead>
            <TableRow>
              {columns.map((column) => (
                <TableCell key={column.id} align="center" style={{ minWidth: column.minWidth }}>
                  {column.label}
                </TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {trackAdvocatesAttributes.map((attribute: ClientContactAttribute) => {
              const onChangeField = (field: string) => {
                setSalesforceMapping({ ...salesforceMapping, [attribute]: field });
              };

              return (
                <MapAttributesRow
                  key={attribute}
                  trackAdvocatesAttribute={attribute}
                  onChangeField={onChangeField}
                  salesforceFields={filteredFields}
                />
              );
            })}
          </TableBody>
        </Table>
      </TableContainer>
    </Paper>
  );
};

export default MapAttributesTable;
