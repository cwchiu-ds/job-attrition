import { Box, FormControl, MenuItem, Select, TableCell, TableRow } from '@material-ui/core';
import { Field } from 'jsforce';
import React, { useState } from 'react';

import { ClientContactAttribute, ClientContactAttributeMetaData } from '../../../../utils/constants';
import { defaultSalesforceMapping, requiredTrackAdvocatesAttributes } from '../CustomizeFields';

interface MapAttributesRowProps {
  trackAdvocatesAttribute: ClientContactAttribute;
  onChangeField: (field: string) => void;
  salesforceFields?: Field[];
}

const MapAttributesRow: React.FC<MapAttributesRowProps> = ({
  trackAdvocatesAttribute,
  salesforceFields = [],
  onChangeField,
}) => {
  const initialFieldSelected = defaultSalesforceMapping[trackAdvocatesAttribute] || '';
  const [selectedFieldName, setSelectedFieldName] = useState(initialFieldSelected);

  const selectedField = salesforceFields.find((field) => field.name === selectedFieldName);

  const handleChange = (event: React.ChangeEvent<{ value: unknown }>) => {
    const selectedField = event.target.value as string;
    setSelectedFieldName(selectedField);
    onChangeField(selectedField);
  };

  let attributeDisplayText = ClientContactAttributeMetaData[trackAdvocatesAttribute].displayText;
  if (requiredTrackAdvocatesAttributes.includes(trackAdvocatesAttribute)) {
    attributeDisplayText = attributeDisplayText + '*';
  }

  return (
    <TableRow hover>
      <TableCell>
        <Box textAlign="center">{attributeDisplayText}</Box>
      </TableCell>
      <TableCell>
        <Box textAlign="center">{selectedField?.name}</Box>
      </TableCell>
      <TableCell>
        <FormControl style={{ width: '100%' }}>
          <Select autoWidth value={selectedFieldName} onChange={handleChange}>
            <MenuItem value="">
              <em>None</em>
            </MenuItem>
            {salesforceFields.map((field) => {
              return (
                <MenuItem key={field.name} value={field.name}>
                  {field.label}
                </MenuItem>
              );
            })}
          </Select>
        </FormControl>
      </TableCell>
    </TableRow>
  );
};

export default MapAttributesRow;
