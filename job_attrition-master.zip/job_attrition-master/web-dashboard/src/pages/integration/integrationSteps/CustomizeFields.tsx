import { Box, Button, CircularProgress, Grid, Typography } from '@material-ui/core';
import { Alert } from '@material-ui/lab';
import React, { useState } from 'react';

import { initiateSalesforceSetup } from '../../../modules/cloudFunctions';
import {
  AlertSeverity,
  ClientContactAttribute,
  ClientContactAttributeMetaData,
} from '../../../utils/constants';
import { getApiErrorMessage } from '../../../utils/errors';
import MapAttributesTable from './mapAttributes/MapAttributesTable';

export const defaultSalesforceMapping: SalesforceMapping = {
  [ClientContactAttribute.FIRST_NAME]: 'FirstName',
  [ClientContactAttribute.LAST_NAME]: 'LastName',
  [ClientContactAttribute.CURRENT_TITLE]: 'Title',
  [ClientContactAttribute.EMAIL]: 'Email',
};

export const trackAdvocatesAttributes = [
  ClientContactAttribute.FIRST_NAME,
  ClientContactAttribute.LAST_NAME,
  ClientContactAttribute.CURRENT_TITLE,
  ClientContactAttribute.EMAIL,
  ClientContactAttribute.LINKEDIN_URL,
];

export const requiredTrackAdvocatesAttributes = [
  ClientContactAttribute.FIRST_NAME,
  ClientContactAttribute.LAST_NAME,
  ClientContactAttribute.EMAIL,
];

const CustomizeFields: React.FC = () => {
  const [errorMessage, setErrorMessage] = useState('');
  const [salesforceMapping, setSalesforceMapping] = useState<SalesforceMapping>(defaultSalesforceMapping);
  const [isLoading, setIsLoading] = useState(false);

  const onClickConfirm = async () => {
    try {
      setIsLoading(true);
      // Check for any missing required field mappings
      const missingAttributes = [];

      for (const requiredAttribute of requiredTrackAdvocatesAttributes) {
        const attributeDisplayText = ClientContactAttributeMetaData[requiredAttribute].displayText;

        if (!salesforceMapping[requiredAttribute]) {
          missingAttributes.push(attributeDisplayText);
        }
      }

      if (missingAttributes.length) {
        const errMsg = `Missing required fields: ${missingAttributes.join(', ')}`;
        setErrorMessage(errMsg);
        return;
      }

      await initiateSalesforceSetup({ salesforceMapping });

      // NOTE we do not need to setIsLoading(false) if this is successful, because
      // the Client would be updated and this component would be unmounted
    } catch (err) {
      setErrorMessage(getApiErrorMessage(err));
      setIsLoading(false);
    }
  };

  return (
    <>
      <Grid container item direction="column" xs={11} spacing={1}>
        <Grid item>
          <Typography variant="h5">Step 1 – Map Salesforce Data</Typography>
        </Grid>
        <Grid item>
          <Typography variant="subtitle2">
            To merge existing Salesforce data, please verify the column mapping below
          </Typography>
        </Grid>
      </Grid>

      <Grid item xs={11}>
        <MapAttributesTable salesforceMapping={salesforceMapping} setSalesforceMapping={setSalesforceMapping} />
      </Grid>

      <Grid container item justify="flex-end" alignItems="center" xs={11} spacing={3}>
        {errorMessage && (
          <Grid item xs>
            <Alert severity={AlertSeverity.ERROR}>{errorMessage}</Alert>
          </Grid>
        )}
        <Grid container item justify="flex-end" alignItems="center">
          {isLoading && (
            <Box marginRight={2}>
              <CircularProgress />
            </Box>
          )}
          <Button variant="contained" color="primary" onClick={onClickConfirm} disabled={isLoading}>
            Confirm & Next
          </Button>
        </Grid>
      </Grid>
    </>
  );
};

export default CustomizeFields;
