import { Box, Grid, LinearProgress, Link, Paper, Typography } from '@material-ui/core';
import React, { useContext, useEffect } from 'react';

import { LoadingAndAlertContext } from '../../..';
import { AuthContext } from '../../../components/auth/AuthProvider';
import { SyncStatus, WARMLY_EMAIL } from '../../../utils/constants';
import { ContactContext } from '../../Main';

const IntegrationComplete: React.FC = () => {
  const { client } = useContext(AuthContext);
  const { setIsLoading } = useContext(LoadingAndAlertContext);
  const clientId = client?.id;
  const syncStatus = client?.salesforceIntegration?.syncStatus;
  const { setSelectedClientId, selectedClientId } = useContext(ContactContext);

  useEffect(() => {
    // This useEffect is important because when syncing, we need to unsubscribe
    // from clientContacts (by setting the selectedClientId to undefined), otherwise the real-time updates
    // from the subscription will slow down the browser and potentially freeze the page

    // Here we indicate that, if we are syncing, we unsubscribe
    // from clientContacts
    if (syncStatus === SyncStatus.SYNCING) {
      setSelectedClientId(undefined);
    }
  }, [setSelectedClientId, syncStatus]);

  useEffect(() => {
    // Once the this component is unmounted (i.e., user has navigated to another page), we resubscribe
    // Unfortunately this does lead to a potential reloading, but that is better
    // than the page freezing

    return () => {
      if (selectedClientId === undefined) {
        setIsLoading(true);
        setSelectedClientId(clientId);
      }
    };
  }, [clientId, setIsLoading, setSelectedClientId, selectedClientId]);

  const totalContactCountToBeSynced = client?.salesforceIntegration?.contactCount;
  const syncedContactCount = client?.salesforceIntegration?.lastSyncUpdatedCount;
  const syncCompleteTime = client?.salesforceIntegration?.lastSyncDate;

  let titleMessage = 'Sync Status: ';
  let bodyMessage = '';

  if (syncStatus === SyncStatus.ERROR) {
    titleMessage += 'Error';
    bodyMessage =
      'An error occurred while attemping to sync your Salesforce data into our system. ' +
      'Our tech team has been notified and will attempt to remedy this issue as soon as possible. ' +
      'No action is required at this time. If you have any questions regarding the status of the error, ' +
      'please contact us at the link below.';
  } else if (syncStatus === SyncStatus.SYNCING) {
    titleMessage += 'In Progress';
    bodyMessage = `We are currently attempting to sync ${totalContactCountToBeSynced?.toLocaleString()} contacts from Salesforce. You may leave this page and return later to check the status`;
  } else if (syncStatus === SyncStatus.COMPLETE) {
    titleMessage += 'Complete';
    bodyMessage = `✅ ${syncedContactCount?.toLocaleString()} contacts successfully synced from Salesforce at ${syncCompleteTime
      ?.toDate()
      .toLocaleString()}. \n We are in process of enriching your data and will notify you of any detected job changes.`;
  }

  return (
    <>
      <Grid container item direction="column" xs={11} spacing={1}>
        <Grid item>
          <Typography variant="h5">Step 3 – Integration</Typography>
        </Grid>
        <Grid item>
          <Typography variant="subtitle2">{titleMessage}</Typography>
        </Grid>
      </Grid>

      <Grid item xs={11}>
        <Paper>
          <Box padding={2}>
            <Typography>{bodyMessage}</Typography>
          </Box>
          {syncStatus === SyncStatus.SYNCING && <LinearProgress variant="query" />}
          <Box padding={2} fontWeight="bold">
            Questions? We can help! We’re here for you anytime at{' '}
            <Link
              href={`https://mail.google.com/mail/?view=cm&fs=1&to=${WARMLY_EMAIL.SUPPORT_TECH}&su=[Warmly] Question about Salesforce Integration`}
              target="_blank"
              rel="noopener noreferrer"
            >
              tech@warmlycomma.com
            </Link>
          </Box>
        </Paper>
      </Grid>
    </>
  );
};

export default IntegrationComplete;
