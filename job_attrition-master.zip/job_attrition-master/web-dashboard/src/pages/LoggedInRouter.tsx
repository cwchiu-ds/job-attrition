import { Backdrop, CircularProgress, Snackbar } from '@material-ui/core';
import { Alert } from '@material-ui/lab';
import React, { useContext } from 'react';

import { LoadingAndAlertContext } from '..';
import { AuthContext } from '../components/auth/AuthProvider';
import { UserType } from '../utils/constants';
import Main from './Main';
import MainQA from './MainQA';

const LoggedInRouter: React.FC = () => {
  const { user } = useContext(AuthContext);
  const { isLoading, snackbarAlertData, setSnackbarAlertData } = useContext(LoadingAndAlertContext);

  return (
    <>
      <Backdrop open={isLoading} style={{ zIndex: 10000 }}>
        <CircularProgress color="primary" />
      </Backdrop>

      <Snackbar
        open={Boolean(snackbarAlertData?.message)}
        autoHideDuration={8000}
        onClose={() => setSnackbarAlertData(undefined)}
      >
        <Alert onClose={() => setSnackbarAlertData(undefined)} severity={snackbarAlertData?.severity}>
          {snackbarAlertData?.message}
        </Alert>
      </Snackbar>

      {user?.userType === UserType.QA && <MainQA />}

      {user?.userType !== UserType.QA && <Main />}
    </>
  );
};

export default LoggedInRouter;
