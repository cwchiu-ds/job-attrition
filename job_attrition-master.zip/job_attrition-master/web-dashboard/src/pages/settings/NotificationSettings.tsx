import { faEnvelope } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  Box,
  Button,
  CircularProgress,
  FormControl,
  Grid,
  Input,
  InputAdornment,
  InputLabel,
  Typography,
} from '@material-ui/core';
import { Alert } from '@material-ui/lab';
import React, { useContext, useState } from 'react';

import { AuthContext } from '../../components/auth/AuthProvider';
import { logError } from '../../modules/analytics';
import { updateClient } from '../../modules/client';
import { AlertSeverity } from '../../utils/constants';
import { getApiErrorMessage } from '../../utils/errors';
import NotificationEmail from './notification/NotificationEmail';

interface Props {
  client?: Client;
}

// We optionally allow a Client to be passed in as props, so internal users can "preview"
// what this looks like as that Client
const NotificationSettings: React.FC<Props> = ({ client }) => {
  const { client: contextClient } = useContext(AuthContext);

  client = client ? client : contextClient

  const currentNotificationEmails = client?.jobChangeNotificationEmails || [];

  const [newEmail, setNewEmail] = useState('');
  const [isUpdating, setIsUpdating] = useState(false);
  const [alert, setAlert] = useState<AlertData | undefined>();

  const handleEmailChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setNewEmail(event.target.value);
  };

  const onClickInvite = async () => {
    if (!newEmail || currentNotificationEmails.includes(newEmail)) {
      return;
    }

    try {
      setIsUpdating(true);

      const updatedJobChangeNotificationEmails = [...currentNotificationEmails, newEmail];

      const updatedClient = {
        jobChangeNotificationEmails: updatedJobChangeNotificationEmails,
      };

      await updateClient(client!.id, updatedClient);
    } catch (err) {
      const errMessage = getApiErrorMessage(err);
      logError(err, `Error inviting user to client ${client?.name} - ${errMessage}`);

      setAlert({
        severity: AlertSeverity.ERROR,
        message: errMessage,
      });
    } finally {
      setIsUpdating(false);
    }
  };

  return (
    <Grid container item direction="column" alignItems="flex-start" spacing={2}>
      <Grid item>
        <Typography variant="h5">Notification settings</Typography>
        <Typography variant="subtitle1">
          By default, we send job change reports to the email that first signed up for Warmly. However, you may
          update the preferred email to receive our reports.
        </Typography>
      </Grid>

      <Grid item>
        <Typography variant="subtitle1">Emails receiving job notifications</Typography>
        {currentNotificationEmails.map((email) => {
          const onConfirmDelete = () => {
            const filteredEmails = currentNotificationEmails.filter((notificationEmail) => notificationEmail !== email);

            const updatedClient = {
              jobChangeNotificationEmails: filteredEmails,
            };

            return updateClient(client!.id, updatedClient);
          };
          return <NotificationEmail key={email} email={email} onConfirmDelete={onConfirmDelete} />;
        })}
      </Grid>

      <Grid container item alignItems="flex-end" xs={8} spacing={3}>
        <Grid item xs={7} md={5}>
          <FormControl fullWidth>
            <InputLabel htmlFor="change-notification-email">Add email to job change notifications</InputLabel>
            <Input
              id="change-notification-email"
              value={newEmail}
              onChange={handleEmailChange}
              startAdornment={
                <InputAdornment position="start">
                  <FontAwesomeIcon size="lg" icon={faEnvelope} />
                </InputAdornment>
              }
            />
          </FormControl>
        </Grid>
        <Grid container item alignItems="center" xs>
          <Button variant="contained" color="primary" onClick={onClickInvite} disabled={isUpdating}>
            Confirm
          </Button>
          {isUpdating && (
            <Box marginLeft={2}>
              <CircularProgress />
            </Box>
          )}
        </Grid>
      </Grid>

      <Grid item xs={12}>
        {alert && <Alert severity={alert.severity}>{alert.message}</Alert>}
      </Grid>
    </Grid>
  );
};

export default NotificationSettings;
