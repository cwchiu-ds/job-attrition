import { faEnvelope } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  Box,
  Button,
  CircularProgress,
  FormControl,
  Grid,
  Input,
  InputAdornment,
  InputLabel,
  Typography,
} from '@material-ui/core';
import { Alert } from '@material-ui/lab';
import { AxiosError } from 'axios';
import React from 'react';

import { inviteNewUser } from '../../../modules/emails';
import { AlertSeverity,HTTP_RESPONSE } from '../../../utils/constants';

const InviteUser: React.FC = () => {
  const [inviteeEmail, setInviteeEmail] = React.useState('');
  const [sendingEmail, setSendingEmail] = React.useState(false);
  const [alert, setAlert] = React.useState<AlertData | undefined>();

  const handleInviteEmailChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setInviteeEmail(event.target.value);
  };

  const onClickInvite = async () => {
    setAlert(undefined);

    if (!inviteeEmail.trim()) {
      setAlert({
        severity: AlertSeverity.ERROR,
        message: 'Please enter a valid email address',
      });
    } else {
      try {
        setSendingEmail(true);
        const inviteResponse = await inviteNewUser(inviteeEmail);
        if (inviteResponse.status === HTTP_RESPONSE.OK) {
          setAlert({ severity: AlertSeverity.SUCCESS, message: 'Invite successfully sent!' });
        } else {
          throw new Error();
        }
      } catch (err) {
        const response = (err as AxiosError).response;

        if (response?.status === HTTP_RESPONSE.CONFLICT) {
          setAlert({
            severity: AlertSeverity.ERROR,
            message: `Invite could not be sent. A user with that email already exists.`,
          });
        } else {
          setAlert({
            severity: AlertSeverity.ERROR,
            message: `An error occurred while sending the invite. Please verify the email address is correct. \n 
              If you continue to encounter this error, please contact us at tech@warmlycomma.com`,
          });
        }
      } finally {
        setSendingEmail(false);
      }
    }
  };

  return (
    <Grid container item direction="column" alignItems="flex-start" spacing={2}>
      <Grid item>
        <Typography variant="h5">Invite another user from your organization</Typography>
        <Typography variant="subtitle1">Note: Users you invite will have access to the same data as you</Typography>
      </Grid>

      <Grid container item alignItems="flex-end" xs={8} spacing={3}>
        <Grid item xs={12} md={6}>
          <FormControl fullWidth>
            <InputLabel htmlFor="add-user-email-input">Email</InputLabel>
            <Input
              id="add-user-email-input"
              value={inviteeEmail}
              onChange={handleInviteEmailChange}
              startAdornment={
                <InputAdornment position="start">
                  <FontAwesomeIcon size="lg" icon={faEnvelope} />
                </InputAdornment>
              }
            />
          </FormControl>
        </Grid>
        <Grid container item alignItems="center" xs>
          <Button variant="contained" color="primary" onClick={onClickInvite} disabled={sendingEmail}>
            Send email invite
          </Button>
          {sendingEmail && (
            <Box marginLeft={2}>
              <CircularProgress />
            </Box>
          )}
        </Grid>
      </Grid>

      <Grid item xs={12}>
        {alert && <Alert severity={alert.severity}>{alert.message}</Alert>}
      </Grid>
    </Grid>
  );
};

export default InviteUser;
