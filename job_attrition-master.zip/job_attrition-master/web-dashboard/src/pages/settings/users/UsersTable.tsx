import { Grid, Typography } from '@material-ui/core';
import Paper from '@material-ui/core/Paper';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import React, { useContext } from 'react';

import { useSubscribeCollectionByField } from '../../../hooks/firebase';
import { COLLECTION, UserField } from '../../../utils/constants';
import { ContactContext } from '../../Main';

const UsersTable: React.FC = () => {
  const { selectedClientId } = useContext(ContactContext);

  const users = useSubscribeCollectionByField<UserData>({
    collection: COLLECTION.USERS,
    field: UserField.CLIENT_ID,
    operation: '==',
    fieldValue: selectedClientId,
  });

  return (
    <Grid container item direction="column" xs={11} lg={6} spacing={2}>
      <Grid item>
        <Typography variant="h5">Current users</Typography>
      </Grid>
      <Grid item>
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Name</TableCell>
                <TableCell align="left">Email</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {users.map((user) => (
                <TableRow key={user.id}>
                  <TableCell component="th" scope="row">
                    {`${user.firstName} ${user.lastName}`}
                  </TableCell>
                  <TableCell align="left">{user.email}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Grid>
    </Grid>
  );
};

export default UsersTable;
