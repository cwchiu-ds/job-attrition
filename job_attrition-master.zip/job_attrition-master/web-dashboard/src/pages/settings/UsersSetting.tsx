import { Grid } from '@material-ui/core';
import React from 'react';

import InviteUser from './users/InviteUser';
import UsersTable from './users/UsersTable';

const UsersSetting: React.FC = () => {
  return (
    <Grid container item direction="column" alignItems="flex-start" spacing={2}>
      <InviteUser />
      <UsersTable />
    </Grid>
  );
};

export default UsersSetting;
