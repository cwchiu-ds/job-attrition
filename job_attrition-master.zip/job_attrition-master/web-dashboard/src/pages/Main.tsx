import { Box } from '@material-ui/core';
import React, { useCallback, useContext, useEffect, useState } from 'react';
import { Route, Switch } from 'react-router-dom';

import { LoadingAndAlertContext } from '..';
import AdminRoute from '../components/auth/AdminRoute';
import { AuthContext } from '../components/auth/AuthProvider';
import Sidebar from '../components/Sidebar';
import { useSubscribeCollectionByField } from '../hooks/firebase';
import { getDocumentById, updateDocumentUsingMerge } from '../modules/firestore';
import { ClientContactAttributeField, ClientField, COLLECTION, NavigationPath } from '../utils/constants';
import AdminPanel from './dashboard/AdminPanel';
import ContactUs from './dashboard/ContactUs';
import EnrichedCrm from './dashboard/EnrichedCrm';
import JobChanges from './dashboard/JobChanges';
import UploadOrSync from './dashboard/UploadOrSync';
import Integration from './Integration';
import Settings from './Settings';

export const ContactContext = React.createContext<ContactContextData>({} as ContactContextData);

const Main: React.FC = () => {
  const { user, client } = useContext(AuthContext);
  const { setIsLoading } = useContext(LoadingAndAlertContext);
  const [selectedClientId, setSelectedClientId] = useState(user?.clientId);
  const [selectedClient, setSelectedClient] = useState<Client>();

  const onLoadComplete = useCallback(() => {
    setIsLoading(false);
  }, [setIsLoading]);

  const clientContacts = useSubscribeCollectionByField<ClientContact>({
    collection: COLLECTION.CLIENT_CONTACTS,
    field: ClientContactAttributeField.CLIENT_ID,
    operation: '==',
    fieldValue: selectedClientId,
    orderByField: ClientContactAttributeField.DATE_UPDATED,
    orderByOrder: 'desc',
    onLoadComplete,
  });

  // The below useEffects are used to update the contact count for clients
  useEffect(() => {
    if (selectedClientId && selectedClientId === client?.id) {
      setSelectedClient(client);
    } else if (selectedClientId) {
      getDocumentById<Client>(COLLECTION.CLIENTS, selectedClientId).then((client) => {
        setSelectedClient(client);
      });
    }
  }, [selectedClientId, client]);

  useEffect(() => {
    if (selectedClient && clientContacts.length && selectedClient.contactCount !== clientContacts.length) {
      updateDocumentUsingMerge(COLLECTION.CLIENTS, {
        id: selectedClient.id,
        [ClientField.CONTACT_COUNT]: clientContacts.length,
      });
    }
  }, [selectedClient, clientContacts]);

  return (
    <ContactContext.Provider
      value={{
        clientContacts,
        selectedClientId,
        setSelectedClientId,
        selectedClient,
      }}
    >
      <Box display="flex">
        <Sidebar />
        <Box maxWidth="85%" display="flex" flexGrow={1} marginLeft={5} marginTop={6}>
          <Switch>
            <Route exact={true} path={NavigationPath.JOB_CHANGES}>
              <JobChanges />
            </Route>
            <Route exact={true} path={NavigationPath.ENRICHED_CRM}>
              <EnrichedCrm />
            </Route>
            <Route exact={true} path={NavigationPath.UPLOAD}>
              <UploadOrSync />
            </Route>
            <Route exact={true} path={NavigationPath.CONTACT_US}>
              <ContactUs />
            </Route>
            <Route path={NavigationPath.SETTINGS}>
              <Settings />
            </Route>
            <Route path={NavigationPath.INTEGRATION}>
              <Integration />
            </Route>
            <AdminRoute path={NavigationPath.ADMIN}>
              <AdminPanel />
            </AdminRoute>
            <Route>
              <JobChanges />
            </Route>
          </Switch>
        </Box>
      </Box>
    </ContactContext.Provider>
  );
};

export default Main;
