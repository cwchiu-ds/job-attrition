import { Grid, Typography } from '@material-ui/core';
import React from 'react';
import { Redirect,Route, Switch } from 'react-router-dom';

import { NavigationPath } from '../utils/constants';
import AccountSettings from './settings/AccountSettings';
import NotificationSettings from './settings/NotificationSettings';
import UsersSetting from './settings/UsersSetting';

const Settings: React.FC = () => {
  return (
    <>
      <Grid container direction="column" justify="flex-start" alignItems="flex-start" spacing={3}>
        <Grid container item>
          <Typography variant="h1" color="primary">
            Settings
          </Typography>
        </Grid>

        <Switch>
          <Route exact={true} path={NavigationPath.ACCOUNT_SETTINGS}>
            <AccountSettings />
          </Route>
          <Route exact={true} path={NavigationPath.USERS_SETTINGS}>
            <UsersSetting />
          </Route>
          <Route exact={true} path={NavigationPath.NOTIFICATION_SETTINGS}>
            <NotificationSettings />
          </Route>
          <Route>
            <Redirect to={NavigationPath.ACCOUNT_SETTINGS} />
          </Route>
        </Switch>
      </Grid>
    </>
  );
};

export default Settings;
