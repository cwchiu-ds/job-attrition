import React, { useContext } from "react";
import { AuthContext } from "../components/auth/AuthProvider";

export default function LoggedOut() {
  const { user } = useContext(AuthContext);
  return user ? (
    <div />
  ) : (
    <div className="App">
      <header className="App-header">
        <div style={{ padding: "0px 100px" }}>
          <div className="dashboard-header">
            <h1>Login to view dashboard</h1>
          </div>
        </div>
      </header>
    </div>
  );
}
