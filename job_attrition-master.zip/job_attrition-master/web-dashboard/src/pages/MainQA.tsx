import { Box } from '@material-ui/core';
import React, { useCallback, useContext, useEffect, useState } from 'react';

import { LoadingAndAlertContext } from '..';
import { AuthContext } from '../components/auth/AuthProvider';
import { useSubscribeCollectionBlockByField } from '../hooks/firebase';
import { getDocumentById } from '../modules/firestore';
import { ClientContactAttributeField, COLLECTION } from '../utils/constants';
import QADashboard from './qa/QADashboard';
import QANavBar from './qa/QANavBar';

export const QAContactContext = React.createContext<QAContactContextData>({} as QAContactContextData);

const MainQA: React.FC = () => {
  const { user, client } = useContext(AuthContext);
  const { setIsLoading } = useContext(LoadingAndAlertContext);
  const [selectedClientId, setSelectedClientId] = useState(user?.clientId);
  const [selectedClient, setSelectedClient] = useState<Client>();
  const [startAtId, setStartAtId] = useState('');

  const onLoadComplete = useCallback(() => {
    setIsLoading(false);
  }, [setIsLoading]);

  const clientContacts = useSubscribeCollectionBlockByField<ClientContact>({
    collection: COLLECTION.CLIENT_CONTACTS,
    field: ClientContactAttributeField.CLIENT_ID,
    operation: '==',
    fieldValue: selectedClientId,
    orderByField: ClientContactAttributeField.DATE_UPDATED,
    orderByOrder: 'desc',
    onLoadComplete,
    startAtId,
  });

  useEffect(() => {
    if (selectedClientId && selectedClientId === client?.id) {
      setSelectedClient(client);
    } else if (selectedClientId) {
      getDocumentById<Client>(COLLECTION.CLIENTS, selectedClientId).then((client) => {
        setSelectedClient(client);
      });
    }
  }, [selectedClientId, client]);

  return (
    <QAContactContext.Provider
      value={{
        clientContacts,
        selectedClientId,
        setSelectedClientId,
        selectedClient,
        setStartAtId,
      }}
    >
      <Box>
        <QANavBar />
        <Box maxWidth="95%" display="flex" flexGrow={1} marginLeft={5} marginTop={6}>
          <QADashboard />
        </Box>
      </Box>
    </QAContactContext.Provider>
  );
};

export default MainQA;
