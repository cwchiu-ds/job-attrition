import { Box, Button, CircularProgress, Grid, Hidden, TextField, Typography } from '@material-ui/core';
import { Alert } from '@material-ui/lab';
import React, { useContext, useState } from 'react';
import { Redirect, useHistory } from 'react-router-dom';

import { AuthContext } from '../components/auth/AuthProvider';
import NavBar from '../components/NavBar';
import { firebaseAuth } from '../config/firebase';
import { analyticsSignUpEvent, logError } from '../modules/analytics';
import { createNewClient, createNewUser } from '../modules/firestore';
import { AlertSeverity, NavigationPath, WarmlyColor } from '../utils/constants';
import { getAuthErrorMessage } from '../utils/errors';
import { getCurrentTimestamp, getUserTypeByEmail } from '../utils/functions';

export default function SignUp() {
  const [isLoading, setIsLoading] = useState(false);

  const { user } = useContext(AuthContext);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const history = useHistory();

  if (user?.clientId) {
    return <Redirect to={NavigationPath.MAIN} />;
  }

  const onSubmit = async (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
    e.preventDefault();

    let validationErrorMessage = '';
    if (!email.trim() || !firstName.trim() || !lastName.trim() || !companyName.trim()) {
      validationErrorMessage = 'Required fields: ';
      let emptyFields = [];
      if (!email) {
        emptyFields.push('email');
      }
      if (!firstName) {
        emptyFields.push('first name');
      }
      if (!lastName) {
        emptyFields.push('last name');
      }
      if (!companyName) {
        emptyFields.push('company');
      }
      validationErrorMessage += emptyFields.join(', ');
      validationErrorMessage += '. ';
    }

    if (validationErrorMessage) {
      setErrorMessage(validationErrorMessage);
      return;
    }

    try {
      setIsLoading(true);
      const authUserCredential = await firebaseAuth.createUserWithEmailAndPassword(email, password);

      const authUser = authUserCredential.user;

      if (!authUser) {
        return;
      }

      // After creating authUser, first we create a new client
      const newClientId = await createNewClient(companyName);

      const newUserData: NewUserData = {
        firstName,
        lastName,
        email,
        userType: getUserTypeByEmail(email),
        clientId: newClientId,
        createdDate: getCurrentTimestamp(),
      };

      if (phoneNumber) {
        newUserData.phoneNumber = phoneNumber;
      }

      // Create new User with the corresponding clientId
      await createNewUser(newUserData, authUser.uid);
      analyticsSignUpEvent({
        firstName,
        lastName,
        clientName: companyName,
        email,
        companyName_fullName: `${companyName}_${firstName}_${lastName}`,
      });
      history.push(NavigationPath.UPLOAD);
    } catch (err) {
      logError(err, 'Error while creating new user');
      const errorMessage = getAuthErrorMessage(err);
      setErrorMessage(errorMessage);
      setIsLoading(false);
    }
  };

  return (
    <>
      <NavBar />
      <Grid container justify="center" style={{ backgroundColor: WarmlyColor.WHITE }}>
        <Hidden xsDown>
          <Grid item sm={3}>
            <img className="person-standing" alt="Person" src={require('../assets/person-standing.svg')} width="75%" />
          </Grid>
        </Hidden>

        <Grid item xs={8} sm={6} md={4}>
          <form>
            <Box marginTop={4} marginLeft={-4}>
              <Typography variant="h1" color="primary">
                Sign up for your account
              </Typography>

              <Box marginTop={3}>
                <TextField
                  label="First Name*"
                  value={firstName}
                  onChange={(event: React.ChangeEvent<HTMLInputElement>) => {
                    setFirstName(event.target.value);
                  }}
                  fullWidth
                />
              </Box>

              <Box marginTop={3}>
                <TextField
                  label="Last Name*"
                  value={lastName}
                  onChange={(event: React.ChangeEvent<HTMLInputElement>) => {
                    setLastName(event.target.value);
                  }}
                  fullWidth
                />
              </Box>

              <Box marginTop={3}>
                <TextField
                  label="Company name*"
                  value={companyName}
                  onChange={(event: React.ChangeEvent<HTMLInputElement>) => {
                    setCompanyName(event.target.value);
                  }}
                  fullWidth
                />
              </Box>

              <Box marginTop={3}>
                <TextField
                  label="Phone number"
                  type="tel"
                  value={phoneNumber}
                  onChange={(event: React.ChangeEvent<HTMLInputElement>) => {
                    setPhoneNumber(event.target.value);
                  }}
                  fullWidth
                />
              </Box>

              <Box marginTop={3}>
                <TextField
                  label="Email*"
                  type="email"
                  value={email}
                  onChange={(event: React.ChangeEvent<HTMLInputElement>) => {
                    setEmail(event.target.value);
                  }}
                  fullWidth
                />
              </Box>

              <Box marginTop={3}>
                <TextField
                  label="Password*"
                  type="password"
                  value={password}
                  onChange={(event: React.ChangeEvent<HTMLInputElement>) => {
                    setPassword(event.target.value);
                  }}
                  fullWidth
                />
              </Box>

              <Box marginTop={3}>
                {isLoading ? (
                  <Box marginLeft={2}>
                    <CircularProgress />
                  </Box>
                ) : (
                  <Button variant="contained" color="primary" type="submit" onClick={onSubmit} disabled={isLoading}>
                    Create Account
                  </Button>
                )}
              </Box>
              <Box marginTop={3}>
                <Typography variant="body2" color="textPrimary">
                  By clicking Create Account you are agreeing to our{' '}
                  <a target="_blank" rel="noopener noreferrer" href={`https://www.getwarmly.com/terms-of-service`}>
                    Terms of Service
                  </a>{' '}
                  and{' '}
                  <a target="_blank" rel="noopener noreferrer" href={`https://www.getwarmly.com/privacy-policy`}>
                    Privacy Policy
                  </a>
                  .
                </Typography>
              </Box>

              <Box marginTop={3}>{errorMessage && <Alert severity={AlertSeverity.ERROR}>{errorMessage}</Alert>}</Box>
            </Box>
          </form>
        </Grid>
      </Grid>
    </>
  );
}
