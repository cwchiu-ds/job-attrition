import React from 'react';
import { Grid } from '@material-ui/core';
import Skeleton from '@material-ui/lab/Skeleton';

interface Props {}

const LoadingPlaceholder = (props: Props) => {
  return (
    <Grid container direction="column" justify="flex-start" spacing={3} style={{ width: '80%' }}>
      <Grid item>
        <Skeleton variant="rect" height={150} />
      </Grid>
      <Grid item container direction="row" spacing={3}>
        <Grid item xs={2}>
          <Skeleton variant="rect" height={80} />
        </Grid>
        <Grid item xs={10}>
          <Skeleton variant="text" />
          <Skeleton variant="text" />
          <Skeleton variant="text" />
          <Skeleton variant="text" />
        </Grid>
      </Grid>
    </Grid>
  );
};

export default LoadingPlaceholder;
