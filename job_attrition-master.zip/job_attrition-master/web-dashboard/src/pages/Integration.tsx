import React from 'react';
import { Redirect, Route, Switch } from 'react-router-dom';

import { NavigationPath } from '../utils/constants';
import IntegrationSteps from './integration/IntegrationSteps';

const Integration: React.FC = () => {

  return (
    <Switch>
      <Route exact={true} path={NavigationPath.INTEGRATION_SALESFORCE}>
        <IntegrationSteps />
      </Route>
      <Route>
        <Redirect to={NavigationPath.MAIN} />
      </Route>
    </Switch>
  );
};

export default Integration;
