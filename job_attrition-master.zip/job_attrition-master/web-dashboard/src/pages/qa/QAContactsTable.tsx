import { faLinkedin } from '@fortawesome/free-brands-svg-icons';
import { faAddressBook } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { Box, Button, Grid, IconButton, Link } from '@material-ui/core';
import AddBox from '@material-ui/icons/AddBox';
import ArrowDownward from '@material-ui/icons/ArrowDownward';
import Check from '@material-ui/icons/Check';
import ChevronLeft from '@material-ui/icons/ChevronLeft';
import ChevronRight from '@material-ui/icons/ChevronRight';
import Clear from '@material-ui/icons/Clear';
import DeleteOutline from '@material-ui/icons/DeleteOutline';
import Edit from '@material-ui/icons/Edit';
import FilterList from '@material-ui/icons/FilterList';
import FirstPage from '@material-ui/icons/FirstPage';
import LastPage from '@material-ui/icons/LastPage';
import Remove from '@material-ui/icons/Remove';
import SaveAlt from '@material-ui/icons/SaveAlt';
import Search from '@material-ui/icons/Search';
import ViewColumn from '@material-ui/icons/ViewColumn';
import MaterialTable, { Column } from 'material-table';
import { Icons } from 'material-table';
import React, { forwardRef, useContext, useState } from 'react';

import { LoadingAndAlertContext } from '../..';
import { AuthContext } from '../../components/auth/AuthProvider';
import EditableText from '../../components/editable/EditableText';
import SelectDropdown from '../../components/SelectDropdown';
import { logError } from '../../modules/analytics';
import { updateDocumentUsingMerge } from '../../modules/firestore';
import {
  AlertSeverity,
  ClientContactAttributeField,
  COLLECTION,
  QAAssessment,
  QAJobChangeStatus,
  QALinkedInStatus,
  UserType,
} from '../../utils/constants';
import { extractLinkedInIdFromUrl, getClientContactName, getCurrentTimestamp } from '../../utils/functions';
import { ClientContactsById } from '../dashboard/adminPanel/QADataReview';

const tableIcons: Icons = {
  Add: forwardRef((props, ref) => <AddBox {...props} ref={ref} />),
  Check: forwardRef((props, ref) => <Check {...props} ref={ref} />),
  Clear: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
  Delete: forwardRef((props, ref) => <DeleteOutline {...props} ref={ref} />),
  DetailPanel: forwardRef((props, ref) => <ChevronRight {...props} ref={ref} />),
  Edit: forwardRef((props, ref) => <Edit {...props} ref={ref} />),
  Export: forwardRef((props, ref) => <SaveAlt {...props} ref={ref} />),
  Filter: forwardRef((props, ref) => <FilterList {...props} ref={ref} />),
  FirstPage: forwardRef((props, ref) => <FirstPage {...props} ref={ref} />),
  LastPage: forwardRef((props, ref) => <LastPage {...props} ref={ref} />),
  NextPage: forwardRef((props, ref) => <ChevronRight {...props} ref={ref} />),
  PreviousPage: forwardRef((props, ref) => <ChevronLeft {...props} ref={ref} />),
  ResetSearch: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
  Search: forwardRef((props, ref) => <Search {...props} ref={ref} />),
  SortArrow: forwardRef((props, ref) => <ArrowDownward {...props} ref={ref} />),
  ThirdStateCheck: forwardRef((props, ref) => <Remove {...props} ref={ref} />),
  ViewColumn: forwardRef((props, ref) => <ViewColumn {...props} ref={ref} />),
};

interface Props {
  clientName: string;
  clientContacts: ClientContact[];
  setSelectedClientContactsById?: React.Dispatch<React.SetStateAction<ClientContactsById>>;
  selectedClientContactsById?: ClientContactsById;
}

export interface QAContactRowData {
  clientContactId: string;
  row: number;
  name: string;
  companyNameForQA?: string;
  jobChanged?: boolean;
  titleForQA?: string;
  clientContact: ClientContact;
  clientContactLinkedInURL?: string;
  linkedInURL?: string;
  QAEmail?: string | null;
  QACompanyURL?: string | null;
  QACompanyLinkedInURL?: string | null;
  QAFullName?: string | null;
  QALinkedInStatus?: QALinkedInStatus | null;
  QAJobChangeStatus?: QAJobChangeStatus | null;
  QANotes?: string;
  QAPotentialJobChange?: boolean;
  QAAssessment?: QAAssessment | null;
  tableData?: Object;
}

export const QAAssessmentOptions: SelectOption[] = Object.values(QAAssessment).map((value) => {
  return { value, label: value };
});

const QAAssessmentFilters = Object.values(QAAssessment).reduce((acc, status) => {
  acc[status] = status;
  return acc;
}, {});

const linkedInStatusOptions: SelectOption[] = Object.values(QALinkedInStatus).map((value) => {
  return { value, label: value };
});

const jobChangeStatusOptions: SelectOption[] = Object.values(QAJobChangeStatus).map((value) => {
  return { value, label: value };
});

const linkedInStatusFilters = Object.values(QALinkedInStatus).reduce((acc, status) => {
  acc[status] = status;
  return acc;
}, {});

const jobChangeStatusFilters = Object.values(QAJobChangeStatus).reduce((acc, status) => {
  acc[status] = status;
  return acc;
}, {});

const QAContactsTable: React.FC<Props> = ({
  clientName,
  clientContacts,
  selectedClientContactsById,
  setSelectedClientContactsById,
}) => {
  const { setSnackbarAlertData } = useContext(LoadingAndAlertContext);
  const { user } = useContext(AuthContext);

  const onUpdateClientContactField = (field: ClientContactAttributeField) => {
    return async (clientContactId: string, updatedValue: string) => {
      try {
        const updatedData: WithId<Partial<ClientContact>> = {
          id: clientContactId,
          [field]: updatedValue,
        };

        if (field === ClientContactAttributeField.LINKEDIN_URL) {
          updatedData[ClientContactAttributeField.LINKEDIN_ID] = extractLinkedInIdFromUrl(updatedValue);
        } else if (field === ClientContactAttributeField.QA_JOB_CHANGE_STATUS) {
          updatedData[ClientContactAttributeField.QA_JOB_CHANGE_STATUS_DATE] = getCurrentTimestamp();
        }

        await updateDocumentUsingMerge<ClientContact>(COLLECTION.CLIENT_CONTACTS, updatedData);
        const alertData: AlertData = {
          severity: AlertSeverity.SUCCESS,
          message: `Successfully updated with the value ${updatedValue}`,
        };

        setSnackbarAlertData(alertData);
      } catch (err) {
        logError(
          err,
          `Error updating client contact (id: ${clientContactId}, field: ${field}, value: ${updatedValue})`
        );

        const alertData: AlertData = {
          severity: AlertSeverity.ERROR,
          message: `Error updating using the value ${updatedValue}, please try again`,
        };

        setSnackbarAlertData(alertData);
      }
    };
  };

  const contactRowData = clientContacts.map((clientContact, index) => {
    const linkedInURL = clientContact.QALinkedInURL ? clientContact.QALinkedInURL : clientContact.linkedInURL;

    let lastQACheckedJob = clientContact.currentJob;
    const mostRecentContactDataJob = clientContact.contactData?.currentJob?.[0];

    if (clientContact.contactData && clientContact.QAJobChangeStatusDate && mostRecentContactDataJob?.lastUpdated) {
      // If QA has already set the jobChangeStatus, that means they have already checked the original clientContact job data,
      // so we can just show then the last confirmed contactData job instead
      if (
        clientContact.QAJobChangeStatusDate.toDate() < mostRecentContactDataJob.lastUpdated.toDate() &&
        clientContact.contactData.allJobs &&
        clientContact.contactData.allJobs.length > 1
      ) {
        // If contact data has multiple jobs, we take the second to last one as the last confirmed job
        lastQACheckedJob = clientContact.contactData.allJobs[1];
      } else {
        lastQACheckedJob = clientContact.contactData.currentJob?.[0];
      }
    }

    const name = getClientContactName(clientContact);

    let QAPotentialJobChange = false;

    if (!clientContact.QAJobChangeStatusDate) {
      // If the clientContact is new (meaning QA has never set the job change status), then we always ask them to
      // check for job change
      QAPotentialJobChange = true;
    } else if (
      mostRecentContactDataJob?.lastUpdated &&
      clientContact.QAJobChangeStatusDate.toDate() < mostRecentContactDataJob?.lastUpdated.toDate()
    ) {
      QAPotentialJobChange = true;
    }

    const rowData: QAContactRowData = {
      row: index,
      name,
      QAFullName: clientContact.QAFullName,
      clientContactId: clientContact.id,
      companyNameForQA: lastQACheckedJob?.companyName,
      jobChanged: clientContact.jobChanged,
      titleForQA: lastQACheckedJob?.title,
      clientContact,
      linkedInURL: linkedInURL,
      clientContactLinkedInURL: clientContact.linkedInURL,
      QAEmail: clientContact.QAEmail,
      QALinkedInStatus: clientContact.QALinkedInStatus,
      QAJobChangeStatus: clientContact.QAJobChangeStatus,
      QACompanyURL: clientContact.QACompanyURL,
      QACompanyLinkedInURL: clientContact.QACompanyLinkedInURL,
      QAAssessment: clientContact.QAAssessment,
      QANotes: clientContact.QANotes,
      QAPotentialJobChange,
      tableData: {
        checked: Boolean(selectedClientContactsById?.[clientContact.id]),
      },
    };

    return rowData;
  });

  const allColumns: (Column<QAContactRowData> & { userTypes: UserType[] })[] = [
    {
      title: 'Row',
      field: 'row',
      type: 'numeric',
      cellStyle: { width: 75 },
      headerStyle: { width: 75 },
      userTypes: [UserType.QA],
    },
    {
      title: 'Live Job Change',
      field: 'jobChanged',
      cellStyle: { width: 75 },
      headerStyle: { width: 75 },
      render: (rowData) => {
        return (
          <Box style={{ overflowWrap: 'anywhere' }}>
            <Grid container direction="column">
              <Grid item>{`${rowData.jobChanged}` || 'hello s'}</Grid>
            </Grid>
          </Box>
        );
      },
      userTypes: [UserType.QA, UserType.INTERNAL],
    },
    {
      title: 'Name',
      field: 'name',
      cellStyle: { width: 180 },
      headerStyle: { width: 180 },
      render: (rowData) => {
        if (rowData.name === '') {
          return (
            <EditableText
              id={rowData.clientContactId}
              originalValue={rowData.name || rowData.QAFullName || ''}
              onUpdate={onUpdateClientContactField(ClientContactAttributeField.QA_FULL_NAME)}
              multiline={true}
            />
          );
        } else {
          return <Box>{rowData.name}</Box>;
        }
      },
      userTypes: [UserType.QA, UserType.INTERNAL],
    },
    {
      title: 'CRM Info',
      filtering: false,
      cellStyle: { width: 200, minWidth: 200, maxWidth: 200 },
      headerStyle: { width: 200, minWidth: 200, maxWidth: 200 },
      render: (rowData) => {
        return (
          <Box style={{ overflowWrap: 'anywhere' }}>
            <Grid container direction="column">
              <Grid item>
                <strong>Company</strong>: {rowData.clientContact.currentJob?.companyName || ''}
              </Grid>
              <Grid item>
                <strong>Title</strong>: {rowData.clientContact.currentJob?.title || ''}
              </Grid>
              <Grid item>
                <strong>Email</strong>: {rowData.clientContact.email || ''}
              </Grid>
            </Grid>
          </Box>
        );
      },
      userTypes: [UserType.INTERNAL, UserType.QA],
    },
    {
      title: 'Current Info',
      field: 'companyNameForQA',
      filtering: false,
      cellStyle: { width: 300, minWidth: 300, maxWidth: 300 },
      headerStyle: { width: 300, minWidth: 300, maxWidth: 300 },
      render: (rowData) => {
        const latestContactDataJob = rowData.clientContact.contactData?.currentJob?.[0];

        return (
          <Box style={{ overflowWrap: 'anywhere' }}>
            <Grid container direction="column">
              <Grid item>
                <strong>Company</strong>: {rowData.companyNameForQA || '?'}{' '}
                {rowData.QAPotentialJobChange && `➡️ ${latestContactDataJob?.companyName || '?'}`}
              </Grid>
              <Grid item>
                <strong>Title</strong>: {rowData.titleForQA || '?'}{' '}
                {rowData.QAPotentialJobChange && `➡️ ${latestContactDataJob?.title || '?'}`}
              </Grid>
              <Grid item>
                <strong>Email</strong>: {rowData.clientContact.email || '?'}
              </Grid>
            </Grid>
          </Box>
        );
      },
      userTypes: [UserType.QA],
    },

    {
      title: 'Contact Data',
      filtering: false,
      cellStyle: { width: 300, minWidth: 300, maxWidth: 300 },
      headerStyle: { width: 300, minWidth: 300, maxWidth: 300 },
      render: (rowData) => {
        if (!rowData.clientContact.contactData) {
          return (
            <Box>
              <span role="img" aria-label="alert">
                ⚠️
              </span>{' '}
              No contact data
            </Box>
          );
        }

        const contactData = rowData.clientContact.contactData;
        const currentJob = contactData.currentJob?.[0];

        // Previous job refers to if there was a previous job that we got from ProxyCrawl.
        // Meaning that we already ran ProxyCrawl multiple times, and this is a new detected
        // job change since a previous time we ran ProxyCrawl
        let previousContactDataJob;

        // If we only have only one ProxyCrawl job, or if we have never done a QA reset before,
        // then that means the job change we care about is clientContact.currentJob vs. contactData.currentJob
        // and we don't care about the previous contact data job
        if (contactData.allJobs && contactData.allJobs.length > 1) {
          if (
            rowData.clientContact.QAResetDate &&
            currentJob?.lastUpdated &&
            rowData.clientContact.QAResetDate.toDate() < currentJob.lastUpdated.toDate()
          ) {
            previousContactDataJob = contactData.allJobs[1];
          }
        }

        return (
          <Box style={{ overflowWrap: 'anywhere' }}>
            <Grid container direction="column">
              <Grid item>
                <strong>Company</strong>: {previousContactDataJob && `${previousContactDataJob.companyName || '?'} ➡️ `}
                {currentJob?.companyName || '?'}
              </Grid>
              <Grid item>
                <strong>Title</strong>: {previousContactDataJob && `${previousContactDataJob.title || '?'} ➡️ `}
                {currentJob?.title || '?'}
              </Grid>
              <Grid item>
                <strong>Date</strong>: {`${currentJob?.startDate || ''} - ${currentJob?.endDate || ''}`}
              </Grid>
            </Grid>
          </Box>
        );
      },
      userTypes: [UserType.INTERNAL],
    },
    {
      title: 'Job Change',
      field: ClientContactAttributeField.QA_JOB_CHANGE_STATUS,
      cellStyle: { width: 180, minWidth: 180, maxWidth: 180 },
      headerStyle: { width: 180, minWidth: 180, maxWidth: 180 },
      filterCellStyle: { width: 180, minWidth: 180, maxWidth: 180 },
      lookup: jobChangeStatusFilters,
      render: (rowData) => {
        const onSelect = (newStatus: string) => {
          onUpdateClientContactField(ClientContactAttributeField.QA_JOB_CHANGE_STATUS)(
            rowData.clientContactId,
            newStatus
          );
        };

        return (
          <>
            {rowData.QAPotentialJobChange && <Box>{`🚨 Check 🚨`}</Box>}
            <SelectDropdown
              options={jobChangeStatusOptions}
              selectedValue={rowData.QAJobChangeStatus || ''}
              onSelect={onSelect}
            />
          </>
        );
      },
      userTypes: [UserType.QA, UserType.INTERNAL],
    },
    {
      title: 'Check',
      field: 'QAPotentialJobChange',
      type: 'boolean',
      cellStyle: { width: 30, minWidth: 30 },
      headerStyle: { width: 30, minWidth: 30 },
      userTypes: [UserType.INTERNAL],
    },
    {
      title: 'Updated Email',
      field: ClientContactAttributeField.QA_EMAIL,
      cellStyle: { width: 180, minWidth: 180 },
      headerStyle: { width: 180, minWidth: 180 },
      render: (rowData) => (
        <EditableText
          id={rowData.clientContactId}
          originalValue={rowData.QAEmail || ''}
          onUpdate={onUpdateClientContactField(ClientContactAttributeField.QA_EMAIL)}
          multiline={true}
        />
      ),
      userTypes: [UserType.QA, UserType.INTERNAL],
    },
    {
      title: 'LinkedIn Status',
      field: ClientContactAttributeField.QA_LINKEDIN_STATUS,
      cellStyle: { width: 180, minWidth: 180, maxWidth: 180 },
      headerStyle: { width: 180, minWidth: 180, maxWidth: 180 },
      filterCellStyle: { width: 180, minWidth: 180, maxWidth: 180 },
      lookup: linkedInStatusFilters,
      render: (rowData) => {
        const onSelect = (newStatus: string) => {
          onUpdateClientContactField(ClientContactAttributeField.QA_LINKEDIN_STATUS)(
            rowData.clientContactId,
            newStatus
          );
        };

        return (
          <SelectDropdown
            options={linkedInStatusOptions}
            selectedValue={rowData.QALinkedInStatus || ''}
            onSelect={onSelect}
          />
        );
      },
      userTypes: [UserType.QA],
    },
    {
      title: 'Client Contact LinkedIn',
      field: 'clientContactLinkedInURL',
      cellStyle: { width: 300, minWidth: 300 },
      headerStyle: { width: 300, minWidth: 300 },
      render: (rowData) => {
        const iconDisabled = !Boolean(rowData.clientContact.linkedInURL);
        const onClick = () => {
          window.open(rowData.clientContact.linkedInURL || '', '_blank');
        };

        return (
          <Grid container direction="column">
            <EditableText
              id={rowData.clientContactId}
              originalValue={rowData.clientContact.linkedInURL || ''}
              iconButton={
                <IconButton
                  color="primary"
                  aria-label="linkedin"
                  onClick={onClick}
                  disabled={iconDisabled}
                  size="small"
                >
                  <FontAwesomeIcon icon={faLinkedin} size="lg" />
                </IconButton>
              }
              multiline={true}
              onUpdate={onUpdateClientContactField(ClientContactAttributeField.QA_LINKEDIN_URL)}
            />
            <Grid item>
              <strong>QA</strong>: {rowData.linkedInURL}
            </Grid>
          </Grid>
        );
      },
      userTypes: [UserType.INTERNAL],
    },
    {
      title: 'LinkedIn Profile URL',
      field: 'linkedInURL',
      cellStyle: { width: 300, minWidth: 300 },
      headerStyle: { width: 300, minWidth: 300 },
      render: (rowData) => {
        const iconDisabled = !Boolean(rowData.linkedInURL);
        const onClick = () => {
          window.open(rowData.linkedInURL || '', '_blank');
        };

        const subtext =
          rowData.linkedInURL !== rowData.clientContactLinkedInURL
            ? `original: ${rowData.clientContactLinkedInURL}`
            : '';

        return (
          <EditableText
            id={rowData.clientContactId}
            originalValue={rowData.linkedInURL || ''}
            iconButton={
              <IconButton color="primary" aria-label="linkedin" onClick={onClick} disabled={iconDisabled} size="small">
                <FontAwesomeIcon icon={faLinkedin} size="lg" />
              </IconButton>
            }
            multiline={true}
            onUpdate={onUpdateClientContactField(ClientContactAttributeField.QA_LINKEDIN_URL)}
            subtext={subtext}
          />
        );
      },
      userTypes: [UserType.QA],
    },
    {
      title: 'LinkedIn QA',
      field: ClientContactAttributeField.QA_LINKEDIN_STATUS,
      cellStyle: { width: 180, minWidth: 180, maxWidth: 180 },
      headerStyle: { width: 180, minWidth: 180, maxWidth: 180 },
      filterCellStyle: { width: 180, minWidth: 180, maxWidth: 180 },
      lookup: linkedInStatusFilters,
      render: (rowData) => {
        const onSelect = (newStatus: string) => {
          onUpdateClientContactField(ClientContactAttributeField.QA_LINKEDIN_STATUS)(
            rowData.clientContactId,
            newStatus
          );
        };

        // Confirm means QA found the right URL and we'll copy the QA URL as clientContact's "official" LinkedIn URL
        const onConfirm = () => {
          if (rowData.clientContact.QALinkedInURL) {
            onUpdateClientContactField(ClientContactAttributeField.LINKEDIN_URL)(
              rowData.clientContactId,
              rowData.clientContact.QALinkedInURL
            );
          }
        };

        return (
          <Box style={{ overflowWrap: 'anywhere' }}>
            <SelectDropdown
              options={linkedInStatusOptions}
              selectedValue={rowData.QALinkedInStatus || ''}
              onSelect={onSelect}
            />
            {rowData.clientContact.QALinkedInURL && (
              <Box fontSize={10}>
                <Link href={rowData.clientContact.QALinkedInURL} target="_blank" rel="noopener noreferrer">
                  {rowData.clientContact.QALinkedInURL}
                </Link>
                <Box marginTop={1}>
                  <Button variant="contained" color="primary" size="small" onClick={onConfirm}>
                    Confirm
                  </Button>
                </Box>
              </Box>
            )}
          </Box>
        );
      },
      userTypes: [UserType.INTERNAL],
    },

    {
      title: 'Company LinkedIn URL',
      field: ClientContactAttributeField.QA_COMPANY_LINKEDIN_URL,
      cellStyle: { width: 300, minWidth: 300 },
      headerStyle: { width: 300, minWidth: 300 },
      render: (rowData) => {
        const iconDisabled = !Boolean(rowData.QACompanyLinkedInURL);
        const onClick = () => {
          window.open(rowData.QACompanyLinkedInURL || '', '_blank');
        };

        return (
          <EditableText
            id={rowData.clientContactId}
            originalValue={rowData.QACompanyLinkedInURL || ''}
            iconButton={
              <IconButton color="primary" aria-label="linkedin" onClick={onClick} disabled={iconDisabled} size="small">
                <FontAwesomeIcon icon={faAddressBook} size="lg" />
              </IconButton>
            }
            multiline={true}
            onUpdate={onUpdateClientContactField(ClientContactAttributeField.QA_COMPANY_LINKEDIN_URL)}
          />
        );
      },
      userTypes: [UserType.INTERNAL, UserType.QA],
    },

    {
      title: 'Company URL',
      field: ClientContactAttributeField.QA_COMPANY_URL,
      cellStyle: { width: 300, minWidth: 300 },
      headerStyle: { width: 300, minWidth: 300 },
      render: (rowData) => {
        const iconDisabled = !Boolean(rowData.QACompanyURL);
        const onClick = () => {
          window.open(rowData.QACompanyURL || '', '_blank');
        };

        return (
          <EditableText
            id={rowData.clientContactId}
            originalValue={rowData.QACompanyURL || ''}
            iconButton={
              <IconButton color="primary" aria-label="linkedin" onClick={onClick} disabled={iconDisabled} size="small">
                <FontAwesomeIcon icon={faAddressBook} size="lg" />
              </IconButton>
            }
            multiline={true}
            onUpdate={onUpdateClientContactField(ClientContactAttributeField.QA_COMPANY_URL)}
          />
        );
      },
      userTypes: [UserType.INTERNAL, UserType.QA],
    },
    {
      title: 'QA Assessment',
      field: ClientContactAttributeField.QA_ASSESSMENT,
      cellStyle: { width: 180, minWidth: 180, maxWidth: 180 },
      headerStyle: { width: 180, minWidth: 180, maxWidth: 180 },
      filterCellStyle: { width: 180, minWidth: 180, maxWidth: 180 },
      lookup: QAAssessmentFilters,
      render: (rowData) => {
        const onSelect = (newStatus: string) => {
          onUpdateClientContactField(ClientContactAttributeField.QA_ASSESSMENT)(rowData.clientContactId, newStatus);
        };

        return (
          <SelectDropdown
            options={QAAssessmentOptions}
            selectedValue={rowData.QAAssessment || ''}
            onSelect={onSelect}
          />
        );
      },
      userTypes: [UserType.INTERNAL],
    },

    {
      title: 'Notes',
      field: ClientContactAttributeField.QA_NOTES,
      cellStyle: { width: 300, minWidth: 300 },
      headerStyle: { width: 300, minWidth: 300 },
      render: (rowData) => (
        <EditableText
          id={rowData.clientContactId}
          originalValue={rowData.QANotes || ''}
          onUpdate={onUpdateClientContactField(ClientContactAttributeField.QA_NOTES)}
          multiline={true}
        />
      ),
      userTypes: [UserType.QA, UserType.INTERNAL],
    },
  ];

  // We store columns in a state to avoid issue with Firestore updating removing filters
  // https://github.com/mbrn/material-table/issues/491
  const [columns] = useState(allColumns.filter((column) => column.userTypes.includes(user!.userType)));
  const currentDate = new Date().toLocaleString().split(',')[0];

  return (
    <MaterialTable
      icons={tableIcons}
      columns={columns}
      data={contactRowData}
      title="Data Verification"
      options={{
        draggable: false,
        filtering: true,
        selection: user?.userType === UserType.INTERNAL,
        search: false,
        pageSize: 20,
        exportButton: user?.userType === UserType.INTERNAL,
        exportFileName: `${clientName} - ${currentDate}_QA_DATA`,
      }}
      onSelectionChange={
        setSelectedClientContactsById
          ? (rows) => {
              const rowsByClientContactId = rows.reduce((acc, rowData) => {
                acc[rowData.clientContactId] = rowData.clientContact;
                return acc;
              }, {} as ClientContactsById);
              setSelectedClientContactsById(rowsByClientContactId);
            }
          : undefined
      }
    />
  );
};

export default QAContactsTable;
