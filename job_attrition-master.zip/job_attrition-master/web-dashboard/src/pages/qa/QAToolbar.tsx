import { Box, Button, CircularProgress, Dialog, DialogActions, DialogTitle, Grid } from '@material-ui/core';
import React, { useContext, useState } from 'react';

import { LoadingAndAlertContext } from '../..';
import { logError } from '../../modules/analytics';
import { updateClient } from '../../modules/client';
import { AlertSeverity, QAStatus } from '../../utils/constants';
import { QAContactContext } from '../MainQA';

// NOTE this component is current not used anywhere, but we are likely to add it pending QA feedback
const QAToolbar: React.FC = () => {
  const { selectedClient } = useContext(QAContactContext);
  const { isLoading, setIsLoading, setSnackbarAlertData } = useContext(LoadingAndAlertContext);
  const [showConfirmQACompleteModal, setShowConfirmQACompleteModal] = useState(false);

  const onCloseModal = () => {
    setShowConfirmQACompleteModal(false);
  };

  const onConfirmQAComplete = async () => {
    if (selectedClient) {
      try {
        setIsLoading(true);
        await updateClient(selectedClient.id, { QAStatus: QAStatus.QA_COMPLETED });

        const alertData: AlertData = {
          severity: AlertSeverity.SUCCESS,
          message: `Successfully marked client as QA completed`,
        };

        setSnackbarAlertData(alertData);
      } catch (err) {
        logError(err, `Error confirming QA complete for selected client (id: ${selectedClient.id})`);

        const alertData: AlertData = {
          severity: AlertSeverity.ERROR,
          message: `Error occurred while updating client to QA completed`,
        };

        setSnackbarAlertData(alertData);
      } finally {
        setIsLoading(false);
      }
    }
  };

  return (
    <Grid item>
      {selectedClient && (
        <Button variant="contained" color="primary">
          QA Completed for {selectedClient?.codeName}
        </Button>
      )}
      {/* Updates the client to be QA Completed status */}
      <Dialog open={showConfirmQACompleteModal} onClose={onCloseModal}>
        <DialogTitle>Once you have confirmed that QA is complete for this client,</DialogTitle>
        <DialogActions>
          {isLoading && (
            <Box marginRight={2}>
              <CircularProgress />
            </Box>
          )}
          <Button variant="outlined" color="primary" onClick={onCloseModal} disabled={isLoading}>
            No
          </Button>
          <Button variant="contained" color="primary" onClick={onConfirmQAComplete} disabled={isLoading}>
            Yes
          </Button>
        </DialogActions>
      </Dialog>
    </Grid>
  );
};

export default QAToolbar;
