import { Grid, MenuItem, Select } from '@material-ui/core';
import React from 'react';

import { updateClient } from '../../modules/client';
import { updateDocumentUsingMerge } from '../../modules/firestore';
import { COLLECTION,QALinkedInStatus } from '../../utils/constants';

interface Props {
  clientContact: ClientContact;
}

const LinkedInStatusSelect: React.FC<Props> = ({ clientContact }) => {
  const qaStatusOptions = Object.values(QALinkedInStatus);

  const handleChange = (event: React.ChangeEvent<{ value: unknown }>) => {
    const selectedStatus = event.target.value as QALinkedInStatus;

    if (!selectedStatus) {
      return;
    }

    updateDocumentUsingMerge<ClientContact>(COLLECTION.CLIENT_CONTACTS, {
      id: clientContact.id,
      QALinkedInStatus: selectedStatus,
    });
  };

  return (
    <Grid container>
      <Select value={clientContact.QALinkedInStatus || ''} onChange={handleChange} displayEmpty fullWidth>
        <MenuItem value="">
          <span role="img" aria-label="alert">
            ⚠️
          </span>{' '}
          Not set
        </MenuItem>
        {qaStatusOptions.map((status) => {
          return (
            <MenuItem key={status} value={status}>
              {status}
            </MenuItem>
          );
        })}
      </Select>
    </Grid>
  );
};

export default LinkedInStatusSelect;
