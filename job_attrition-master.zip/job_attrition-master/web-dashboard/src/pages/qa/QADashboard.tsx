import { Grid, Typography } from '@material-ui/core';
import React, { useContext, useEffect } from 'react';

import { AuthContext } from '../../components/auth/AuthProvider';
import { useSubscribeClientsForQAUserId } from '../../hooks/firebase';
import { LocalStorageItem } from '../../utils/constants';
import ClientSelect from '../dashboard/adminPanel/ClientSelect';
import { QAContactContext } from '../MainQA';
import QAClientContactBlockSelect from './QAClientContactBlockSelect';
import QAContactsTable from './QAContactsTable';

const QADashboard: React.FC = () => {
  const { user } = useContext(AuthContext);
  const { selectedClientId, clientContacts, setSelectedClientId, selectedClient } = useContext(QAContactContext);
  const { clients } = useSubscribeClientsForQAUserId(user!.id);

  useEffect(() => {
    // For QA, to improve user experience we save the last selected client id in LocalStorage,
    // so the next time they login or refresh, it'll automatically load that client
    const lastSelectedClientId = window.localStorage.getItem(LocalStorageItem.LAST_SELECTED_CLIENT_ID);

    if (lastSelectedClientId && clients.find((client) => client.id === lastSelectedClientId)) {
      setSelectedClientId(lastSelectedClientId);
    }
  }, [clients, setSelectedClientId]);

  return (
    <Grid container direction="row" spacing={3}>
      <Grid item xs={12}>
        <Typography variant="h5">Select Client</Typography>
      </Grid>

      <Grid container item xs={8} spacing={3}>
        <Grid item xs={12} md={8}>
          <ClientSelect
            clients={clients}
            selectedClientId={selectedClientId}
            setSelectedClientId={setSelectedClientId}
            useCodeNameOnly={true}
          />
        </Grid>
        <Grid item xs={6} md={2}>
          {selectedClientId && <QAClientContactBlockSelect />}
        </Grid>
      </Grid>

      <Grid item xs={12}>
        <QAContactsTable clientName={selectedClient?.name || ''} clientContacts={clientContacts} />
      </Grid>
    </Grid>
  );
};

export default QADashboard;
