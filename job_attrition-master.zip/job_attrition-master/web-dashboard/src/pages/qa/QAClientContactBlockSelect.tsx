import { FormControl, InputLabel, MenuItem, Select } from '@material-ui/core';
import React, { useContext, useEffect, useState } from 'react';

import { QAContactContext } from '../MainQA';

const QAClientContactBlockSelect: React.FC = () => {
  const { selectedClient, setStartAtId } = useContext(QAContactContext);
  const [selectedBlock, setSelectedBlock] = useState<string>('');

  const blocks: Block = selectedClient?.clientContactBlocks || {};

  const handleChange = (event: React.ChangeEvent<{ value: unknown }>) => {
    const selectedBlock = event.target.value;
    setStartAtId(blocks[selectedBlock as string]?.startAtId || '');
    setSelectedBlock(selectedBlock as string)
  };

  useEffect(() => {
    setSelectedBlock('');
  }, [selectedClient]);

  return (
    <FormControl variant="outlined" fullWidth>
      <InputLabel id="select-block-label">Block</InputLabel>
      <Select
        labelId="select-block-label"
        value={selectedBlock}
        onChange={handleChange}
        label="Block"
      >
        <MenuItem value="">
          <em>None</em>
        </MenuItem>
        {Object.keys(blocks).map((blockNumber) => {
          return (
            <MenuItem key={blockNumber} value={blockNumber}>
              {blockNumber}
            </MenuItem>
          );
        })}
      </Select>
    </FormControl>
  );
};

export default QAClientContactBlockSelect;
