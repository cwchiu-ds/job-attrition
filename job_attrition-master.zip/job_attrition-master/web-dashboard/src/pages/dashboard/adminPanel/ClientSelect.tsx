import { FormControl, InputLabel, MenuItem, Select } from '@material-ui/core';
import React from 'react';

import { LocalStorageItem } from '../../../utils/constants';

interface ClientSelectProps {
  clients: Client[];
  selectedClientId?: UserData['clientId'];
  setSelectedClientId: React.Dispatch<React.SetStateAction<string | undefined>>;
  useCodeNameOnly?: boolean;
}
const ClientSelect: React.FC<ClientSelectProps> = ({
  selectedClientId = '',
  setSelectedClientId,
  clients,
  useCodeNameOnly = false,
}) => {
  const handleChange = (event: React.ChangeEvent<{ value: unknown }>) => {
    const selectedId = event.target.value as string
    setSelectedClientId(selectedId);

    window.localStorage.setItem(LocalStorageItem.LAST_SELECTED_CLIENT_ID, selectedId)
  };

  if (!clients.find(client => client.id === selectedClientId)) {
    selectedClientId = ''
  }
  
  return (
    <FormControl variant="outlined" fullWidth>
      <InputLabel id="select-client-dropdown-label">Current Client</InputLabel>
      <Select
        labelId="select-client-dropdown-label"
        value={selectedClientId}
        onChange={handleChange}
        label="Current Client"
      >
        <MenuItem value="">
          <em>None</em>
        </MenuItem>
        {clients.map((client: Client) => {
          const codeName = client.codeName || 'Name unknown';
          return (
            <MenuItem key={client.id} value={client.id}>
              {useCodeNameOnly ? codeName : `${client.name} (${codeName})` || ''}
            </MenuItem>
          );
        })}
      </Select>
    </FormControl>
  );
};

export default ClientSelect;
