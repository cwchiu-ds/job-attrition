import { Box, Button, Grid, Typography } from '@material-ui/core';
import { Alert } from '@material-ui/lab';
import React, { useContext } from 'react';

import { LoadingAndAlertContext } from '../../..';
import HighlightText from '../../../components/HighlightText';
import { generateJobChanges } from '../../../modules/admin';
import { logError } from '../../../modules/analytics';
import { AlertSeverity, CURRENT_ENVIRONMENT, Environment } from '../../../utils/constants';
import { ContactContext } from '../../Main';
import NotificationSettings from '../../settings/NotificationSettings';
import UsersTable from '../../settings/users/UsersTable';
import ClientSelect from './ClientSelect';

interface ClientManagementProps {
  clients: Client[];
}
const ClientManagement: React.FC<ClientManagementProps> = ({ clients }) => {
  const { selectedClientId, setSelectedClientId } = useContext(ContactContext);
  const { setIsLoading, setSnackbarAlertData } = useContext(LoadingAndAlertContext);

  const selectedClient = clients.find((client) => client.id === selectedClientId);

  const onClickGenerateJobChanges = async () => {
    if (!selectedClient?.id) {
      return;
    }

    try {
      setIsLoading(true)
      await generateJobChanges(selectedClient.id);
      const alertData: AlertData = {
        severity: AlertSeverity.SUCCESS,
        message: `Job changes generated`,
      };

      setSnackbarAlertData(alertData);
    } catch (err) {
      const alertData: AlertData = {
        severity: AlertSeverity.ERROR,
        message: `Error while generating job changes`,
      };

      setSnackbarAlertData(alertData);
      logError(err, 'Error while generating job changes');
    } finally {
      setIsLoading(false)
    }
  };

  return (
    <>
      <Grid container item direction="row" justify="space-around" alignItems="center">
        <Grid container item direction="row" justify="flex-start" alignItems="center">
          <HighlightText>{clients.length}</HighlightText>
          <Box marginX={1}>total clients</Box>
        </Grid>
      </Grid>

      <Grid container item direction="column" alignItems="flex-start">
        <Box width="50%">
          <ClientSelect
            clients={clients}
            selectedClientId={selectedClientId}
            setSelectedClientId={setSelectedClientId}
          />
        </Box>
      </Grid>

      {CURRENT_ENVIRONMENT !== Environment.Production && (
        <Grid item>
          <Typography>For testing purposes only: generate job changes for 10 client contacts</Typography>
          <Button variant="contained" onClick={onClickGenerateJobChanges}>
            Generate Job Changes
          </Button>
        </Grid>
      )}

      <Grid item>
        <Alert severity={AlertSeverity.INFO}>
          Preview the selected Client's settings below - you may take action on their behalf but please be careful.
        </Alert>
      </Grid>

      <NotificationSettings client={selectedClient} />

      <Grid container item>
        <UsersTable />
      </Grid>
    </>
  );
};

export default ClientManagement;
