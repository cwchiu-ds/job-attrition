import { Grid } from '@material-ui/core';
import Bottleneck from 'bottleneck';
import React, { useContext, useEffect, useState } from 'react';

import { mTurkClient } from '../../../config/mTurk';
import { ContactContext } from '../../Main';
import ClientSelect from './ClientSelect';
import QAStatusSelect from './qaClientsManagement/QAStatusSelect';

interface Props {
  clients: Client[];
}

export interface ClientContactsById {
  [id: string]: ClientContact;
}

const QACollectorView: React.FC<Props> = ({ clients }) => {
  const { selectedClientId, clientContacts, setSelectedClientId, selectedClient } = useContext(ContactContext);
  const [template, setTemplate] = useState('');
  const [hits, setHits] = useState([]);

  // This refers to the selected QA Assessment in the modal (i.e., for bulk setting QA Assessment)

  mTurkClient.getAccountBalance((err: any, data: any) => {
    if (err) {
      console.warn('Error making the mTurk API call:', err);
    } else {
      // The call was a success
      const balance = `$${data.AvailableBalance}`;
      console.log('balance', balance);
    }
  });

  // @ts-ignore
  useEffect(() => {
    const limiter = new Bottleneck({
      minTime: 1000,
      maxConcurrent: 30,
    });

    // must go here to tes tout hits https://workersandbox.mturk.com

    // const getHits = (hitList = [], nextToken: string | undefined = undefined, count = 0) => {
    //   return limiter.schedule(
    //     async () =>
    //       new Promise((resolve, reject) => {
    //         mTurkClient.listHITs({ NextToken: nextToken, MaxResults: 20 }, (err, data) => {
    //           if (err) {
    //             console.warn('Error making the mTurk API call:', err);
    //           } else {
    //             // The call was a success
    //             const hits = data.HITs as [];
    //             const nextToken = data.NextToken as string | undefined;

    //             hitList = [...hits, ...hitList];

    //             if (data.NextToken) {
    //               count = count + 1;
    //               setHits(hitList);
    //               console.log('hitList', count, hitList);
    //               getHits(hitList, nextToken, count);
    //             } else {
    //               resolve(hitList);
    //             }
    //           }
    //         });
    //       })
    //   );
    // };

    const getReviewableHits = (hitList = [], nextToken: string | undefined = undefined, count = 0) => {
      return limiter.schedule(
        async () =>
          new Promise((resolve, reject) => {
            mTurkClient.listReviewableHITs({ NextToken: nextToken, MaxResults: 20 }, (err, data) => {
              if (err) {
                console.warn('Error making the mTurk API call:', err);
              } else {
                // The call was a success
                const hits = data.HITs as [];
                const nextToken = data.NextToken as string | undefined;

                hitList = [...hits, ...hitList];

                if (data.NextToken) {
                  count = count + 1;
                  setHits(hitList);
                  console.log('hitList', count, hitList);
                  getReviewableHits(hitList, nextToken, count);
                } else {
                  resolve(hitList);
                }
              }
            });
          })
      );
    };
    // const final = getHits([]);

    getReviewableHits([]);

    // console.log('should nly go once', final);
    return () => getReviewableHits([]);
  }, []);

  //   mTurkClient.getHIT({ HITId: '3PCPFX4U555CILF6PWYX644WXSWFQ8' }, (err, data) => {
  //     if (err) {
  //       console.warn('Error making the mTurk API call:', err);
  //     } else {
  //       // The call was a success
  //       const hits = data.HIT;
  //       console.log('hitt', hits);
  //     }
  //   });

  //   mTurkClient.listAssignmentsForHIT({ HITId: '3PCPFX4U555CILF6PWYX644WXSWFQ8' }, (err, data) => {
  //     if (err) {
  //       console.warn('Error making the mTurk API call:', err);
  //     } else {
  //       // The call was a success
  //       const hits = data;
  //       console.log('hitt', hits);
  //     }
  //   });

  //   mTurkClient.approveAssignment({ AssignmentId: '3PCPFX4U555CILF6PWYX644WXSWFQ8' }, (err, data) => {
  //     if (err) {
  //       console.warn('Error making the mTurk approved api call:', err);
  //     } else {
  //       // The call was a success
  //       const hits = data;
  //       console.log('approved', hits);
  //     }
  //   });

  // read xml file to create hits on backend. That sends to Mech Turk. Front end should just be approver

  return (
    <Grid container direction="row" spacing={3}>
      <Grid item xs={8} md={5}>
        <ClientSelect clients={clients} selectedClientId={selectedClientId} setSelectedClientId={setSelectedClientId} />
      </Grid>

      <Grid>{template}</Grid>

      <Grid container item xs={12} spacing={2}>
        <Grid container item xs={12}>
          <Grid item xs={12}>
            Set client QA status
          </Grid>
          {selectedClient && (
            <Grid item xs={3}>
              <QAStatusSelect client={selectedClient} />
            </Grid>
          )}
        </Grid>
      </Grid>
    </Grid>
  );
};

export default QACollectorView;
