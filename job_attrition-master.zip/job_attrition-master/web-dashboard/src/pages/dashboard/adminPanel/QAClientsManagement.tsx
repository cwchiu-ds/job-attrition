import { Grid, Typography } from '@material-ui/core';
import React from 'react';

import QAClientsTable from './qaClientsManagement/QAClientsTable';

interface Props {
  QAUsers: FullUser[];
  clients: Client[];
}
const QAClientsManagement: React.FC<Props> = ({ QAUsers, clients }) => {
  return (
    <>
      <Grid item>
        <Typography variant="h5">Manage QA Assignments for Clients</Typography>
      </Grid>

      <Grid container item>
        <QAClientsTable QAUsers={QAUsers} clients={clients} />
      </Grid>
    </>
  );
};

export default React.memo(QAClientsManagement);
