import { Button, Grid } from '@material-ui/core';
import React, { useContext, useState } from 'react';

import DownloadCSV from '../../../components/downloadCSV/DownloadCSV';
import { ContactContext } from '../../Main';
import QAContactsTable from '../../qa/QAContactsTable';
import ClientSelect from './ClientSelect';
import QAStatusSelect from './qaClientsManagement/QAStatusSelect';
import AppendCompanyURL from './qaDataReview/AppendCompanyURL';
import QAConfirmCompanyURL from './qaDataReview/QAConfirmCompanyURL';
import QAConfirmFullName from './qaDataReview/QAConfirmFullName';
import QAConfirmJobChangeFlag from './qaDataReview/QAConfirmJobChangeFlag';
import QAConfirmLinkedInURL from './qaDataReview/QAConfirmLinkedInURL';
import QAConfirmNewEmail from './qaDataReview/QAConfirmNewEmail';
import QAConfirmVerifiedFlag from './qaDataReview/QAConfirmVerifiedFlag';
import QAReset from './qaDataReview/QAReset';
import QASelectAssessment from './qaDataReview/QASelectAssessment';

interface Props {
  clients: Client[];
}

export interface ClientContactsById {
  [id: string]: ClientContact;
}

const QADataReview: React.FC<Props> = ({ clients }) => {
  const { selectedClientId, clientContacts, setSelectedClientId, selectedClient } = useContext(ContactContext);

  const [selectedClientContactsById, setSelectedClientContactsById] = useState<ClientContactsById>({});

  // This refers to the selected QA Assessment in the modal (i.e., for bulk setting QA Assessment)

  const selectedClientContacts = Object.values(selectedClientContactsById);

  return (
    <Grid container direction="row" spacing={3}>
      <Grid item xs={8} md={5}>
        <ClientSelect clients={clients} selectedClientId={selectedClientId} setSelectedClientId={setSelectedClientId} />
      </Grid>

      <Grid container item xs={12} spacing={2}>
        <Grid container item xs={12}>
          <Grid item xs={12}>
            Set client QA status
          </Grid>
          {selectedClient && (
            <Grid item xs={3}>
              <QAStatusSelect client={selectedClient} />
            </Grid>
          )}
        </Grid>

        <Grid item>
          <QAConfirmLinkedInURL selectedClientContacts={selectedClientContacts} />
        </Grid>

        <Grid item>
          <QAConfirmJobChangeFlag selectedClientContacts={selectedClientContacts} />
        </Grid>

        <Grid item>
          <QAConfirmNewEmail selectedClientContacts={selectedClientContacts} />
        </Grid>

        <Grid item>
          <QAConfirmVerifiedFlag selectedClientContacts={selectedClientContacts} />
        </Grid>

        <Grid item>
          <QAConfirmFullName selectedClientContacts={selectedClientContacts} />
        </Grid>

        <Grid item>
          <QASelectAssessment selectedClientContacts={selectedClientContacts} />
        </Grid>

        <Grid item>
          <QAConfirmCompanyURL selectedClientContacts={selectedClientContacts} />
        </Grid>

        <Grid item>
          <AppendCompanyURL selectedClientContacts={selectedClientContacts} />
        </Grid>

        <Grid item>
          <Button variant="outlined" color="primary">
            <DownloadCSV headerFlag={'QA'} />
          </Button>
        </Grid>

        <Grid item>
          <QAReset />
        </Grid>
      </Grid>

      <Grid item xs={12}>
        <QAContactsTable
          clientName={selectedClient?.name || ''}
          clientContacts={clientContacts}
          selectedClientContactsById={selectedClientContactsById}
          setSelectedClientContactsById={setSelectedClientContactsById}
        />
      </Grid>
    </Grid>
  );
};

export default QADataReview;
