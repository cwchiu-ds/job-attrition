import { Box, Button, Dialog, DialogActions, DialogContent, DialogTitle, Tooltip } from '@material-ui/core';
import React, { useContext, useState } from 'react';

import { LoadingAndAlertContext } from '../../../..';
import { logError } from '../../../../modules/analytics';
import { getDocumentById, updateDocumentsUsingMerge } from '../../../../modules/firestore';
import { AlertSeverity, COLLECTION } from '../../../../utils/constants';
import { getCurrentTimestamp } from '../../../../utils/functions';

interface Props {
  selectedClientContacts: ClientContact[];
}

const QAConfirmNewEmail: React.FC<Props> = ({ selectedClientContacts }) => {
  const { isLoading, setIsLoading, setSnackbarAlertData } = useContext(LoadingAndAlertContext);

  const [showConfirmSetNewEmailModal, setShowConfirmSetNewEmailModal] = useState(false);

  const onCloseModal = () => {
    setShowConfirmSetNewEmailModal(false);
  };

  const onConfirmAddNewEmail = async () => {
    try {
      setIsLoading(true);

      const filteredClientContacts = selectedClientContacts.filter(
        (clientContact) => clientContact.QAEmail && clientContact.contactDataId! && clientContact.contactDataId !== ''
      );

      const updatedContacts = await Promise.all(
        filteredClientContacts.map(async (clientContact) => {
          const contactData = await getDocumentById<ContactData>(COLLECTION.CONTACT_DATA, clientContact.contactDataId!);
          const newEmail = clientContact.QAEmail!;
          let emailArray = contactData?.emailArray;
          let emailData = contactData?.emailData;
          if (contactData && newEmail && newEmail !== '' && emailArray && emailData && !emailArray.includes(newEmail)) {
            emailArray.push(newEmail);
            emailData.push({
              dateCreated: getCurrentTimestamp(),
              email: newEmail,
              isValid: true,
              source: 'QA',
            });

            return {
              id: clientContact.contactDataId!,
              emailArray,
              emailData,
            };
          }
        })
      );

      const filteredUpdatedContacts = updatedContacts.filter((element) => {
        return element !== undefined;
      }) as ContactData[];

      await updateDocumentsUsingMerge<ContactData>(COLLECTION.CONTACT_DATA, filteredUpdatedContacts);

      const alertData: AlertData = {
        severity: AlertSeverity.SUCCESS,
        message: `New updated emails set, contact datas have been updated to reflect QA's new updated emails found`,
      };

      setSnackbarAlertData(alertData);
      onCloseModal();
    } catch (err) {
      logError(err, 'Error while updating QA assessment of updated emails for selected client contacts');

      const alertData: AlertData = {
        severity: AlertSeverity.ERROR,
        message: 'Error updated QA Assessments for updated emails',
      };

      setSnackbarAlertData(alertData);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <Tooltip title="Set all new emails that QA found to client contact">
        <Button
          variant="contained"
          color="primary"
          onClick={() => setShowConfirmSetNewEmailModal(true)}
          disabled={!selectedClientContacts.length}
        >
          Set New Email
        </Button>
      </Tooltip>

      {/* Modal handles adding new email */}
      <Dialog open={showConfirmSetNewEmailModal} onClose={onCloseModal}>
        <DialogTitle>
          Set new updated email for <strong>{selectedClientContacts.length}</strong> client contact(s)
        </DialogTitle>

        <DialogActions>
          <Button variant="outlined" color="primary" onClick={onCloseModal} disabled={isLoading}>
            Cancel
          </Button>
          <Button variant="contained" color="primary" onClick={onConfirmAddNewEmail} disabled={isLoading}>
            Confirm
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default QAConfirmNewEmail;
