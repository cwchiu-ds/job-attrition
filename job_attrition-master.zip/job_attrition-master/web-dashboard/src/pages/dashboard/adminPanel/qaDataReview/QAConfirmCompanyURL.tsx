import { Box, Button, Dialog, DialogActions, DialogContent, DialogTitle, Tooltip } from '@material-ui/core';
import React, { useContext, useState } from 'react';

import { LoadingAndAlertContext } from '../../../..';
import { logError } from '../../../../modules/analytics';
import { updateDocumentsUsingMerge } from '../../../../modules/firestore';
import { AlertSeverity, COLLECTION } from '../../../../utils/constants';
import {
  extractLinkedInCompanyIdFromUrl,
  getCurrentTimestamp,
  isRealURL,
  parseDomain,
} from '../../../../utils/functions';
import { ContactContext } from '../../../Main';

interface Props {
  selectedClientContacts: ClientContact[];
}

const QAConfirmCompanyURL: React.FC<Props> = ({ selectedClientContacts }) => {
  const { selectedClient, clientContacts } = useContext(ContactContext);
  const { isLoading, setIsLoading, setSnackbarAlertData } = useContext(LoadingAndAlertContext);

  const [showConfirmCompanyURLModal, setShowCompanyURLModal] = useState(false);

  const onCloseModal = () => {
    setShowCompanyURLModal(false);
  };

  const onConfirmCompanyURL = async () => {
    try {
      setIsLoading(true);

      const uniqueCompanies: (Partial<Company> & { id: string })[] = selectedClientContacts
        .filter(
          (clientContact) =>
            clientContact.QACompanyURL &&
            clientContact.QACompanyURL !== '' &&
            clientContact.QACompanyLinkedInURL &&
            clientContact.QACompanyLinkedInURL !== '' &&
            isRealURL(clientContact.QACompanyURL!) &&
            isRealURL(clientContact.QACompanyLinkedInURL!) &&
            parseDomain(clientContact.QACompanyURL!).host
        )
        .map((clientContact) => ({
          id: parseDomain(clientContact.QACompanyURL!).host,
          companyURL: clientContact.QACompanyURL,
          companyURLDomain: parseDomain(clientContact.QACompanyURL!).host,
          companyLinkedInURL: clientContact.QACompanyLinkedInURL,
          companyLinkedInId: extractLinkedInCompanyIdFromUrl(clientContact.QACompanyLinkedInURL!),
          dateUpdated: getCurrentTimestamp(),
        }))
        .reduce((unique, o) => {
          if (!unique.some((obj) => obj && obj.id && obj.id === o.id)) {
            unique.push(o);
          }
          return unique;
        }, [] as Partial<Company>[]) as (Company & { id: string })[];

      await updateDocumentsUsingMerge<Company>(COLLECTION.COMPANIES, uniqueCompanies);

      const alertData: AlertData = {
        severity: AlertSeverity.SUCCESS,
        message: `Synced new company and company LinkedIn URL from QA ${selectedClient?.name}`,
      };

      setSnackbarAlertData(alertData);
      onCloseModal();
    } catch (err) {
      logError(err, `Error while syncing QA Company URL and Company LinkedIn URL for ${selectedClient?.name}`);

      const alertData: AlertData = {
        severity: AlertSeverity.ERROR,
        message: `Error confirming company URLs`,
      };

      setSnackbarAlertData(alertData);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <Tooltip title="Save down QA Company URL and Company LinkedIn URL">
        <Button
          variant="contained"
          color="primary"
          onClick={() => setShowCompanyURLModal(true)}
          disabled={!selectedClientContacts.length}
        >
          Confirm Company URL
        </Button>
      </Tooltip>

      {/* Modal handles confirming full names */}
      <Dialog open={showConfirmCompanyURLModal} onClose={onCloseModal}>
        <DialogTitle>
          Confirm company URLs for <strong>{selectedClientContacts.length}</strong> client contact(s)
        </DialogTitle>

        <DialogActions>
          <Button variant="outlined" color="primary" onClick={onCloseModal} disabled={isLoading}>
            Cancel
          </Button>
          <Button variant="contained" color="primary" onClick={onConfirmCompanyURL} disabled={isLoading}>
            Confirm
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default QAConfirmCompanyURL;
