import { Button, Dialog, DialogActions, DialogContent, DialogTitle, Tooltip } from '@material-ui/core';
import React, { useContext, useState } from 'react';

import { LoadingAndAlertContext } from '../../../..';
import SelectDropdown from '../../../../components/SelectDropdown';
import { logError } from '../../../../modules/analytics';
import { updateDocumentsUsingMerge } from '../../../../modules/firestore';
import { AlertSeverity, COLLECTION, QAAssessment } from '../../../../utils/constants';
import { QAAssessmentOptions } from '../../../qa/QAContactsTable';

interface Props {
  selectedClientContacts: ClientContact[];
}

const QASelectAssessment: React.FC<Props> = ({ selectedClientContacts }) => {
  const { isLoading, setIsLoading, setSnackbarAlertData } = useContext(LoadingAndAlertContext);
  const [selectedQAAssessment, setSelectedQAAssessment] = useState<QAAssessment>(QAAssessment.CORRECT);

  const [showSetQAAssessmentModal, setShowSetQAAssessmentModal] = useState(false);

  const onCloseModal = () => {
    setShowSetQAAssessmentModal(false);
  };

  const onSetQAAssessment = async () => {
    try {
      setIsLoading(true);
      const updatedClientContacts: (Partial<ClientContact> & { id: string })[] = selectedClientContacts.map(
        (clientContact) => ({
          id: clientContact.id,
          QAAssessment: selectedQAAssessment,
        })
      );

      await updateDocumentsUsingMerge<ClientContact>(COLLECTION.CLIENT_CONTACTS, updatedClientContacts);

      const alertData: AlertData = {
        severity: AlertSeverity.SUCCESS,
        message: `QA Assessments updated`,
      };

      setSnackbarAlertData(alertData);
      onCloseModal();
    } catch (err) {
      logError(err, 'Error while updating QA asssessment for selected client contacts');

      const alertData: AlertData = {
        severity: AlertSeverity.ERROR,
        message: `Error updated QA Assessments`,
      };

      setSnackbarAlertData(alertData);
    } finally {
      setIsLoading(false);
    }
  };

  // This is used for the bulk QA Assessment setting modal
  const onSelectQAAssessment = (value: string) => {
    setSelectedQAAssessment(value as QAAssessment);
  };

  return (
    <>
      <Tooltip title="Set QA Assessment">
        <Button
          variant="contained"
          color="primary"
          onClick={() => setShowSetQAAssessmentModal(true)}
          disabled={!selectedClientContacts.length}
        >
          Set QA Assessment
        </Button>
      </Tooltip>

      {/* Modal handles setting QA assessments (i.e., if they're all correct/wrong/etc.) */}
      <Dialog open={showSetQAAssessmentModal} onClose={onCloseModal}>
        <DialogTitle>
          Set QA Assessment for <strong>{selectedClientContacts.length}</strong> client contact(s)
        </DialogTitle>
        <DialogContent>
          <SelectDropdown
            options={QAAssessmentOptions}
            selectedValue={selectedQAAssessment}
            onSelect={onSelectQAAssessment}
          />
        </DialogContent>
        <DialogActions>
          <Button variant="outlined" color="primary" onClick={onCloseModal} disabled={isLoading}>
            Cancel
          </Button>
          <Button variant="contained" color="primary" onClick={onSetQAAssessment} disabled={isLoading}>
            Confirm
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default QASelectAssessment;
