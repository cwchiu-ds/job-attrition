import { Box, Button, Dialog, DialogActions, DialogContent, DialogTitle, Tooltip } from '@material-ui/core';
import React, { useContext, useState } from 'react';

import { LoadingAndAlertContext } from '../../../..';
import { logError } from '../../../../modules/analytics';
import { updateDocumentsUsingMerge } from '../../../../modules/firestore';
import { AlertSeverity, COLLECTION, QAAssessment, QALinkedInStatus, QAStatus } from '../../../../utils/constants';
import { addhttps, checkURLContainsLinkedInProfile, extractLinkedInIdFromUrl } from '../../../../utils/functions';
import { ContactContext } from '../../../Main';

interface Props {
  selectedClientContacts: ClientContact[];
}

const QAConfirmLinkedInURL: React.FC<Props> = ({ selectedClientContacts }) => {
  const { isLoading, setIsLoading, setSnackbarAlertData } = useContext(LoadingAndAlertContext);

  const [showConfirmLinkedInModal, setShowConfirmLinkedInModal] = useState(false);

  const onCloseModal = () => {
    setShowConfirmLinkedInModal(false);
  };

  const onConfirmLinkedInURLs = async () => {
    try {
      setIsLoading(true);
      const updatedClientContacts: (Partial<ClientContact> & { id: string })[] = selectedClientContacts
        .filter(
          (clientContact) => clientContact.QALinkedInURL && checkURLContainsLinkedInProfile(clientContact.QALinkedInURL)
        )
        .map((clientContact) => ({
          id: clientContact.id,
          linkedInURL: addhttps(clientContact.QALinkedInURL!),
          linkedInId: extractLinkedInIdFromUrl(addhttps(clientContact.QALinkedInURL!)),
        }));

      await updateDocumentsUsingMerge<ClientContact>(COLLECTION.CLIENT_CONTACTS, updatedClientContacts);

      const wrongLinkedInClientContacts: (Partial<ClientContact> & { id: string })[] = selectedClientContacts
        .filter(
          (clientContact) =>
            clientContact.QALinkedInURL && !checkURLContainsLinkedInProfile(clientContact.QALinkedInURL)
        )
        .map((clientContact) => ({
          id: clientContact.id,
          QAAssessment: QAAssessment.INCORRECT_LINKEDIN,
        }));

      await updateDocumentsUsingMerge<ClientContact>(COLLECTION.CLIENT_CONTACTS, wrongLinkedInClientContacts);

      const alertData: AlertData = {
        severity: AlertSeverity.SUCCESS,
        message: `LinkedIn URLs confirmed, client contacts have been updated to reflect QA's LinkedIn URLs`,
      };

      setSnackbarAlertData(alertData);
      onCloseModal();
    } catch (err) {
      logError(err, 'Error while confirming LinkedIn URL for selected client contacts');

      const alertData: AlertData = {
        severity: AlertSeverity.ERROR,
        message: `Error confirming LinkedIn URLs`,
      };

      setSnackbarAlertData(alertData);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <Tooltip title="Set all LinkedIn URLs that QA filled to client contact">
        <Button
          variant="contained"
          color="primary"
          onClick={() => setShowConfirmLinkedInModal(true)}
          disabled={!selectedClientContacts.length}
        >
          Confirm LinkedIn URL
        </Button>
      </Tooltip>

      {/* Modal handles confirming all LinkedIn URLs (i.e., we think the QA's linkedIn URLs are correct) */}
      <Dialog open={showConfirmLinkedInModal} onClose={onCloseModal}>
        <DialogTitle>
          Confirm LinkedIn URLs for <strong>{selectedClientContacts.length}</strong> client contact(s)?
        </DialogTitle>
        <DialogActions>
          <Button variant="outlined" color="primary" onClick={onCloseModal} disabled={isLoading}>
            No
          </Button>
          <Button variant="contained" color="primary" onClick={onConfirmLinkedInURLs} disabled={isLoading}>
            Yes
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default QAConfirmLinkedInURL;
