import { Box, Button, Dialog, DialogActions, DialogContent, DialogTitle, Tooltip } from '@material-ui/core';
import React, { useContext, useState } from 'react';

import { LoadingAndAlertContext } from '../../../..';
import { logError } from '../../../../modules/analytics';
import { updateDocumentsUsingMerge } from '../../../../modules/firestore';
import { AlertSeverity, COLLECTION, QAJobChangeStatus } from '../../../../utils/constants';
import { getCurrentTimestamp } from '../../../../utils/functions';

interface Props {
  selectedClientContacts: ClientContact[];
}

const QAConfirmJobChangeFlag: React.FC<Props> = ({ selectedClientContacts }) => {
  const { isLoading, setIsLoading, setSnackbarAlertData } = useContext(LoadingAndAlertContext);

  const [showConfirmJobChangedModal, setShowConfirmJobChangedModal] = useState(false);

  const onCloseModal = () => {
    setShowConfirmJobChangedModal(false);
  };

  const onConfirmJobChangedFlags = async () => {
    try {
      setIsLoading(true);
      const validJobChangeStatus = [
        QAJobChangeStatus.LEFT_OLD_JOB_NO_NEW_JOB,
        QAJobChangeStatus.JOB_CHANGED,
        QAJobChangeStatus.JOB_CHANGED_SAME_COMPANY,
      ];
      const updatedClientContacts: (Partial<ClientContact> & { id: string })[] = selectedClientContacts
        .filter(
          (clientContact) =>
            clientContact.QAJobChangeStatus && validJobChangeStatus.includes(clientContact.QAJobChangeStatus)
        )
        .map((clientContact) => ({
          id: clientContact.id,
          jobChanged: true,
          jobChangedStatus: clientContact.QAJobChangeStatus,
          dateUpdated: getCurrentTimestamp(),
          // verified: false,
        }));

      await updateDocumentsUsingMerge<ClientContact>(COLLECTION.CLIENT_CONTACTS, updatedClientContacts);

      // For contacts not marked as job changed
      const jobChangedFalseContacts: (Partial<ClientContact> & { id: string })[] = selectedClientContacts
        .filter(
          (clientContact) =>
            clientContact.QAJobChangeStatus && clientContact.QAJobChangeStatus === QAJobChangeStatus.NO_JOB_CHANGE
        )
        .map((clientContact) => ({
          id: clientContact.id,
          jobChanged: false,
          jobChangedStatus: QAJobChangeStatus.NO_JOB_CHANGE,
          dateUpdated: getCurrentTimestamp(),
          // verified: false,
        }));

      await updateDocumentsUsingMerge<ClientContact>(COLLECTION.CLIENT_CONTACTS, jobChangedFalseContacts);

      const alertData: AlertData = {
        severity: AlertSeverity.SUCCESS,
        message: `Job Changed Flag confirmed, client contacts have been updated to reflect QA's Job Change Flags`,
      };

      setSnackbarAlertData(alertData);
      onCloseModal();
    } catch (err) {
      logError(err, 'Error while updating QA assessment of Job Changes for selected client contacts');

      const alertData: AlertData = {
        severity: AlertSeverity.ERROR,
        message: 'Error updated QA Assessments',
      };

      setSnackbarAlertData(alertData);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <Tooltip title="Set all Job Change Flags that QA filled to client contact">
        <Button
          variant="contained"
          color="primary"
          onClick={() => setShowConfirmJobChangedModal(true)}
          disabled={!selectedClientContacts.length}
        >
          Confirm Job Changed Flag
        </Button>
      </Tooltip>

      {/* Modal handles confirming all Job Changes (i.e., No job change, left old job but no new, job changed, job changed but same company */}
      <Dialog open={showConfirmJobChangedModal} onClose={onCloseModal}>
        <DialogTitle>
          Confirm Job Changed Flag for <strong>{selectedClientContacts.length}</strong> client contact(s)?
        </DialogTitle>
        <DialogActions>
          <Button variant="outlined" color="primary" onClick={onCloseModal} disabled={isLoading}>
            No
          </Button>
          <Button variant="contained" color="primary" onClick={onConfirmJobChangedFlags} disabled={isLoading}>
            Yes
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default QAConfirmJobChangeFlag;
