import { Box, Button, Dialog, DialogActions, DialogContent, DialogTitle, Tooltip } from '@material-ui/core';
import React, { useContext, useState } from 'react';

import { LoadingAndAlertContext } from '../../../..';
import { logError } from '../../../../modules/analytics';
import { getDocumentById, updateDocumentsUsingMerge } from '../../../../modules/firestore';
import { AlertSeverity, COLLECTION } from '../../../../utils/constants';
import { getCurrentTimestamp } from '../../../../utils/functions';

interface Props {
  selectedClientContacts: ClientContact[];
}

const QAConfirmFullName: React.FC<Props> = ({ selectedClientContacts }) => {
  const { isLoading, setIsLoading, setSnackbarAlertData } = useContext(LoadingAndAlertContext);

  const [showConfirmFullNamesModal, setshowConfirmFullNamesModal] = useState(false);

  const onCloseModal = () => {
    setshowConfirmFullNamesModal(false);
  };

  const onConfirmFullNames = async () => {
    try {
      setIsLoading(true);
      const updatedClientContacts: (Partial<ClientContact> & { id: string })[] = selectedClientContacts
        .filter((clientContact) => clientContact.QAFullName)
        .map((clientContact) => ({
          id: clientContact.id,
          fullName: clientContact.QAFullName!,
        }));

      await updateDocumentsUsingMerge<ClientContact>(COLLECTION.CLIENT_CONTACTS, updatedClientContacts);

      const alertData: AlertData = {
        severity: AlertSeverity.SUCCESS,
        message: `Full name confirmed, client contacts have been updated to reflect QA's full names`,
      };

      setSnackbarAlertData(alertData);
      onCloseModal();
    } catch (err) {
      logError(err, 'Error while confirming full name for selected client contacts');

      const alertData: AlertData = {
        severity: AlertSeverity.ERROR,
        message: `Error confirming full names`,
      };

      setSnackbarAlertData(alertData);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <Tooltip title="Set full name that QA found to client contact">
        <Button
          variant="contained"
          color="primary"
          onClick={() => setshowConfirmFullNamesModal(true)}
          disabled={!selectedClientContacts.length}
        >
          Confirm Full Name
        </Button>
      </Tooltip>

      {/* Modal handles confirming full names */}
      <Dialog open={showConfirmFullNamesModal} onClose={onCloseModal}>
        <DialogTitle>
          Confirm full names for <strong>{selectedClientContacts.length}</strong> client contact(s)
        </DialogTitle>

        <DialogActions>
          <Button variant="outlined" color="primary" onClick={onCloseModal} disabled={isLoading}>
            Cancel
          </Button>
          <Button variant="contained" color="primary" onClick={onConfirmFullNames} disabled={isLoading}>
            Confirm
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default QAConfirmFullName;
