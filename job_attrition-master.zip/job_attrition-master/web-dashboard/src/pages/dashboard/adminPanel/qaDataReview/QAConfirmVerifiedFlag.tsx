import { Box, Button, Dialog, DialogActions, DialogContent, DialogTitle, Tooltip } from '@material-ui/core';
import React, { useContext, useState } from 'react';

import { LoadingAndAlertContext } from '../../../..';
import { logError } from '../../../../modules/analytics';
import { getDocumentById, updateDocumentsUsingMerge } from '../../../../modules/firestore';
import { AlertSeverity, COLLECTION } from '../../../../utils/constants';
import { getCurrentTimestamp } from '../../../../utils/functions';

interface Props {
  selectedClientContacts: ClientContact[];
}

const QAConfirmVerifiedFlag: React.FC<Props> = ({ selectedClientContacts }) => {
  const { isLoading, setIsLoading, setSnackbarAlertData } = useContext(LoadingAndAlertContext);

  const [showConfirmVerifiedFlagModal, setshowConfirmVerifiedFlagModal] = useState(false);

  const onCloseModal = () => {
    setshowConfirmVerifiedFlagModal(false);
  };

  const onConfirmVerifiedFlag = async () => {
    try {
      setIsLoading(true);
      const updatedClientContacts: (Partial<ClientContact> & { id: string })[] = selectedClientContacts
        .filter((clientContact) => clientContact.QAAssessment === 'Correct')
        .map((clientContact) => ({
          id: clientContact.id,
          verified: true,
          lastVerified: getCurrentTimestamp(),
        }));

      await updateDocumentsUsingMerge<ClientContact>(COLLECTION.CLIENT_CONTACTS, updatedClientContacts);

      const alertData: AlertData = {
        severity: AlertSeverity.SUCCESS,
        message: `Verified flag confirmed, client contacts have been updated to reflect QA Assessment`,
      };

      setSnackbarAlertData(alertData);
      onCloseModal();
    } catch (err) {
      logError(err, 'Error while confirming verified flag for selected client contacts');

      const alertData: AlertData = {
        severity: AlertSeverity.ERROR,
        message: `Error confirming verified flag`,
      };

      setSnackbarAlertData(alertData);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <Tooltip title="Set Verified Flag to client contact">
        <Button
          variant="contained"
          color="primary"
          onClick={() => setshowConfirmVerifiedFlagModal(true)}
          disabled={!selectedClientContacts.length}
        >
          Confirm Verified Flag
        </Button>
      </Tooltip>

      {/* Modal handles confirming Verified Flag */}
      <Dialog open={showConfirmVerifiedFlagModal} onClose={onCloseModal}>
        <DialogTitle>
          Confirm QA assessment "correct" as Verified Flag for <strong>{selectedClientContacts.length}</strong> client
          contact(s)
        </DialogTitle>

        <DialogActions>
          <Button variant="outlined" color="primary" onClick={onCloseModal} disabled={isLoading}>
            Cancel
          </Button>
          <Button variant="contained" color="primary" onClick={onConfirmVerifiedFlag} disabled={isLoading}>
            Confirm
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default QAConfirmVerifiedFlag;
