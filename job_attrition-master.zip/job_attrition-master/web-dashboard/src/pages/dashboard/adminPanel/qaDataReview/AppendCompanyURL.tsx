import { Box, Button, Dialog, DialogActions, DialogContent, DialogTitle, Tooltip } from '@material-ui/core';
import React, { useContext, useState } from 'react';

import { LoadingAndAlertContext } from '../../../..';
import { appendCompanyURL } from '../../../../modules/admin';
import { logError } from '../../../../modules/analytics';
import { AlertSeverity, COLLECTION } from '../../../../utils/constants';
import { ContactContext } from '../../../Main';

interface Props {
  selectedClientContacts: ClientContact[];
}

const AppendCompanyURL: React.FC<Props> = ({ selectedClientContacts }) => {
  const { selectedClient, clientContacts } = useContext(ContactContext);
  const { isLoading, setIsLoading, setSnackbarAlertData } = useContext(LoadingAndAlertContext);

  const [showAppendCompanyURLModal, setShowAppendCompanyURLModal] = useState(false);

  const onCloseModal = () => {
    setShowAppendCompanyURLModal(false);
  };

  const onConfirmCompanyURL = async () => {
    try {
      setIsLoading(true);

      console.log('client id', selectedClient!.id);

      await appendCompanyURL(selectedClient!.id);

      const alertData: AlertData = {
        severity: AlertSeverity.SUCCESS,
        message: `Sent job to append company URL to contacts for ${selectedClient?.name}`,
      };

      setSnackbarAlertData(alertData);
      onCloseModal();
    } catch (err) {
      logError(err, `Error while sending job to append company URL to contacts for ${selectedClient?.name}`);

      const alertData: AlertData = {
        severity: AlertSeverity.ERROR,
        message: `Error confirming company URLs`,
      };

      setSnackbarAlertData(alertData);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <Tooltip title="Save down QA Company URL and Company LinkedIn URL">
        <Button variant="contained" color="primary" onClick={() => setShowAppendCompanyURLModal(true)}>
          Append Company URLs
        </Button>
      </Tooltip>

      {/* Modal handles confirming full names */}
      <Dialog open={showAppendCompanyURLModal} onClose={onCloseModal}>
        <DialogTitle>Append company URL for ALL client contacts</DialogTitle>

        <DialogActions>
          <Button variant="outlined" color="primary" onClick={onCloseModal} disabled={isLoading}>
            Cancel
          </Button>
          <Button variant="contained" color="primary" onClick={onConfirmCompanyURL} disabled={isLoading}>
            Confirm
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default AppendCompanyURL;
