import { Box, Button, Dialog, DialogActions, DialogContent, DialogTitle, Tooltip } from '@material-ui/core';
import React, { useContext, useState } from 'react';

import { LoadingAndAlertContext } from '../../../..';
import { logError } from '../../../../modules/analytics';
import { updateDocumentsUsingMerge } from '../../../../modules/firestore';
import { AlertSeverity, COLLECTION } from '../../../../utils/constants';
import { getCurrentTimestamp } from '../../../../utils/functions';
import { ContactContext } from '../../../Main';

const QAReset: React.FC = () => {
  const { selectedClient, clientContacts } = useContext(ContactContext);
  const { isLoading, setIsLoading, setSnackbarAlertData } = useContext(LoadingAndAlertContext);

  const [showQAResetModal, setShowQAResetModal] = useState(false);

  const onCloseModal = () => {
    setShowQAResetModal(false);
  };

  const onConfirmQAReset = async () => {
    try {
      setIsLoading(true);
      const QAResetDate = getCurrentTimestamp();
      const updatedClientContacts: (WithId<Partial<ClientContact>>)[] = clientContacts
        .map((clientContact) => ({
          id: clientContact.id,
          QAAssessment: null,
          QALinkedInStatus: null,
          QAJobChangeStatus: null,
          QACompanyURL: null,
          QAEmail: null,
          QACompanyLinkedInURL: null,
          QAResetDate,
        })
      );

      await updateDocumentsUsingMerge<ClientContact>(COLLECTION.CLIENT_CONTACTS, updatedClientContacts);

      const alertData: AlertData = {
        severity: AlertSeverity.SUCCESS,
        message: `QA reset complete for ${selectedClient?.name}`,
      };

      setSnackbarAlertData(alertData);
      onCloseModal();
    } catch (err) {
      logError(err, `Error while resetting QA status for ${selectedClient?.name}`);

      const alertData: AlertData = {
        severity: AlertSeverity.ERROR,
        message: `Error confirming LinkedIn URLs`,
      };

      setSnackbarAlertData(alertData);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <Tooltip title="Set all QA LinkedIn status (will not remove the QA LinkedIn URLs) and QA Assessment status to null">
        <Button variant="contained" color="primary" onClick={() => setShowQAResetModal(true)}>
          Reset QA
        </Button>
      </Tooltip>

      <Dialog open={showQAResetModal} onClose={onCloseModal}>
        <DialogTitle>Reset QA for {selectedClient?.name}?</DialogTitle>
        <DialogContent>
          <Box>
            Resetting QA should be done at the very end of a QA cycle (i.e. data is ready to be presented to the client)
          </Box>
          <Box marginY={2}>
            This will set three sets of status to null: 1) <em>Job change</em>, 2) <em>LinkedIn QA</em>, and 3){' '}
            <em>QA Assessment</em>
          </Box>
          <Box>It is recommended that you save down the QA data as csv before resetting</Box>
        </DialogContent>
        <DialogActions>
          <Button variant="outlined" color="primary" onClick={onCloseModal} disabled={isLoading}>
            Cancel
          </Button>
          <Button variant="contained" color="primary" onClick={onConfirmQAReset} disabled={isLoading}>
            Confirm
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default QAReset;
