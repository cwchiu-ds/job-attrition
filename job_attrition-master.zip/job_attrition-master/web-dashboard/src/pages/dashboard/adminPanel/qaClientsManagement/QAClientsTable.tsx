import {
  Box,
  Button,
  Chip,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogTitle,
  Grid,
  Typography,
} from '@material-ui/core';
import Paper from '@material-ui/core/Paper';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import React, { useState } from 'react';

import { logError } from '../../../../modules/analytics';
import { updateClient } from '../../../../modules/client';
import AddQAToClient from './AddQAToClient';
import ClientStatusSelect from './ClientStatusSelect';
import QAStatusSelect from './QAStatusSelect';

interface Props {
  QAUsers: FullUser[];
  clients: Client[];
}

const MIN_COLUMN_WIDTH = 150;

const QAClientsTable: React.FC<Props> = ({ QAUsers, clients }) => {
  clients = clients.sort((clientA, clientB) => {
    console.log('client a', clientA, clientB);
    return clientA.name.toLowerCase() > clientB.name.toLowerCase() ? 1 : -1;
  });

  const [removeClientId, setRemoveClientId] = useState('');
  const [removeUserId, setRemoveUserId] = useState('');
  const [showRemoveQAUserModal, setShowRemoveQAUserModal] = useState(false);
  const [showRemoveAllQAUsersModal, setShowRemoveAllQAUsersModal] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const clientToBeRemovedFrom = clients.find((client) => client.id === removeClientId);
  const QAUserToBeRemoved = QAUsers.find((user) => user.id === removeUserId);

  const onClose = () => {
    setShowRemoveQAUserModal(false);
    setShowRemoveAllQAUsersModal(false);
    setIsLoading(false);
  };

  const onClickRemove = (userId: string, clientId: string) => {
    setRemoveClientId(clientId);
    setRemoveUserId(userId);
    setShowRemoveQAUserModal(true);
  };

  const onClickRemoveAll = (clientId: string) => {
    setRemoveClientId(clientId);
    setShowRemoveAllQAUsersModal(true);
  };

  const onConfirmRemove = async () => {
    setIsLoading(true);

    try {
      const clientToRemove = clients.find((client) => client.id === removeClientId);

      const updatedQAUserIds = (clientToRemove?.QAUserIds || []).filter((userId) => userId !== removeUserId);

      await updateClient(removeClientId, { QAUserIds: updatedQAUserIds });
      onClose();
    } catch (err) {
      logError(err, `Error removing QA users from client (id: ${removeClientId})`);
    } finally {
      setIsLoading(false);
    }
  };

  const onConfirmRemoveAll = async () => {
    setIsLoading(true);

    try {
      await updateClient(removeClientId, { QAUserIds: [] });

      onClose();
    } catch (err) {
      logError(err, `Error removing all QA users from client (id: ${removeClientId})`);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Grid container item spacing={3}>
      <Grid item>
        <Typography variant="h5">Current Clients</Typography>
      </Grid>

      <Grid item xs={12}>
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell style={{ minWidth: MIN_COLUMN_WIDTH }}>Name</TableCell>
                <TableCell style={{ minWidth: MIN_COLUMN_WIDTH }}>Code Name</TableCell>
                <TableCell style={{ minWidth: MIN_COLUMN_WIDTH }} align="center">
                  Status
                </TableCell>
                <TableCell style={{ minWidth: MIN_COLUMN_WIDTH }} align="center">
                  QA Status
                </TableCell>
                <TableCell style={{ minWidth: MIN_COLUMN_WIDTH }} align="center">
                  QA Users
                </TableCell>
                <TableCell align="center">QA Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {clients.map((client) => {
                const QAUserIds = client.QAUserIds || [];
                const QAUsersForClient = QAUsers.filter((user) => QAUserIds.includes(user.id));

                return (
                  <TableRow key={client.id}>
                    <TableCell component="th" scope="row">
                      {client.name}
                      <Box>
                        {client.contactCount !== undefined
                          ? ` (${client.contactCount.toLocaleString()} contacts)`
                          : ` (unknown # contacts)`}
                      </Box>
                    </TableCell>
                    <TableCell component="th" scope="row">
                      {client.codeName || '⚠️ None'}
                    </TableCell>
                    <TableCell align="center">
                      <ClientStatusSelect client={client} />
                    </TableCell>
                    <TableCell align="center">
                      <QAStatusSelect client={client} />
                    </TableCell>
                    <TableCell align="center">
                      <Grid container spacing={1} justify="center">
                        {QAUsersForClient.map((user) => {
                          return (
                            <Grid item key={user.id}>
                              <Chip
                                variant="outlined"
                                size="small"
                                label={user.email}
                                onDelete={() => onClickRemove(user.id, client.id)}
                                color="primary"
                              />
                            </Grid>
                          );
                        })}
                      </Grid>
                    </TableCell>
                    <TableCell align="center">
                      <Grid container justify="center" spacing={2}>
                        <Grid item>
                          <AddQAToClient client={client} QAUsers={QAUsers} />
                        </Grid>
                        <Grid item>
                          <Button
                            variant="contained"
                            color="primary"
                            onClick={() => {
                              onClickRemoveAll(client.id);
                            }}
                          >
                            Remove All
                          </Button>
                        </Grid>
                      </Grid>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </TableContainer>
      </Grid>

      {/* Remove one user from a client's QA users list */}
      <Dialog open={showRemoveQAUserModal} onClose={onClose}>
        <DialogTitle>
          Remove <strong>{QAUserToBeRemoved?.email}</strong> from <i>{clientToBeRemovedFrom?.name}</i> QA list?
        </DialogTitle>
        <DialogActions>
          {isLoading && (
            <Box marginRight={2}>
              <CircularProgress />
            </Box>
          )}
          <Button variant="outlined" color="primary" onClick={onClose} disabled={isLoading}>
            No
          </Button>
          <Button variant="contained" color="primary" onClick={onConfirmRemove} disabled={isLoading}>
            Yes
          </Button>
        </DialogActions>
      </Dialog>

      {/* Remove all users from a client's QA users list */}
      <Dialog open={showRemoveAllQAUsersModal} onClose={onClose}>
        <DialogTitle>
          Remove <strong>all users</strong> from <i>{clientToBeRemovedFrom?.name}</i> QA list?
        </DialogTitle>
        <DialogActions>
          {isLoading && (
            <Box marginRight={2}>
              <CircularProgress />
            </Box>
          )}
          <Button variant="outlined" color="primary" onClick={onClose} disabled={isLoading}>
            No
          </Button>
          <Button variant="contained" color="primary" onClick={onConfirmRemoveAll} disabled={isLoading}>
            Yes
          </Button>
        </DialogActions>
      </Dialog>
    </Grid>
  );
};

export default QAClientsTable;
