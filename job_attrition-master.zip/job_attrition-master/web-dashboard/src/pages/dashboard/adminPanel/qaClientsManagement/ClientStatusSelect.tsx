import { FormHelperText, Grid, MenuItem, Select } from '@material-ui/core';
import React from 'react';

import { updateClient } from '../../../../modules/client';
import { ClientStatus } from '../../../../utils/constants';

interface Props {
  client: Client;
}

const ClientStatusSelect: React.FC<Props> = ({ client }) => {
  const clientStatusOptions = Object.values(ClientStatus);
  const qaStatusTimestampLabel = client.statusDate?.toDate()?.toLocaleString();

  const handleChange = (event: React.ChangeEvent<{ value: unknown }>) => {
    const selectedStatus = event.target.value as ClientStatus;

    if (!selectedStatus) {
      return;
    }

    updateClient(client.id, { status: selectedStatus });
  };
  return (
    <Grid container>
      <Select value={client.status || ''} onChange={handleChange} displayEmpty fullWidth>
        <MenuItem value="">
          <span role="img" aria-label="alert">
            ⚠️
          </span>{' '}
          Not set
        </MenuItem>
        {clientStatusOptions.map((status) => {
          return (
            <MenuItem key={status} value={status}>
              {status}
            </MenuItem>
          );
        })}
      </Select>
      <FormHelperText>{qaStatusTimestampLabel || ''}</FormHelperText>
    </Grid>
  );
};

export default ClientStatusSelect;
