import { FormHelperText, Grid, MenuItem, Select } from '@material-ui/core';
import React from 'react';

import { updateClient } from '../../../../modules/client';
import { QAStatus } from '../../../../utils/constants';

interface Props {
  client: Client;
}

const QAStatusSelect: React.FC<Props> = ({ client }) => {
  const qaStatusOptions = Object.values(QAStatus);
  const qaStatusTimestampLabel = client.QAStatusDate?.toDate()?.toLocaleString();

  const handleChange = (event: React.ChangeEvent<{ value: unknown }>) => {
    const selectedStatus = event.target.value as QAStatus;

    if (!selectedStatus) {
      return;
    }

    updateClient(client.id, { QAStatus: selectedStatus });
  };

  return (
    <Grid container>
      <Select value={client.QAStatus || ''} onChange={handleChange} displayEmpty fullWidth>
        <MenuItem value="">
          <span role="img" aria-label="alert">
            ⚠️
          </span>{' '}
          Not set
        </MenuItem>
        {qaStatusOptions.map((status) => {
          return (
            <MenuItem key={status} value={status}>
              {status}
            </MenuItem>
          );
        })}
      </Select>
      <FormHelperText>{qaStatusTimestampLabel || ''}</FormHelperText>
    </Grid>
  );
};

export default QAStatusSelect;
