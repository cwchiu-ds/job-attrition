import {
  Box,
  Button,
  CircularProgress,
  Dialog,
  DialogContent,
  DialogTitle,
  FormGroup,
  Grid,
  MenuItem,
  Select,
} from '@material-ui/core';
import { Alert } from '@material-ui/lab';
import React, { useState } from 'react';

import { updateClient } from '../../../../modules/client';
import { AlertSeverity } from '../../../../utils/constants';
import { getApiErrorMessage } from '../../../../utils/errors';

interface Props {
  QAUsers: FullUser[];
  client: Client;
}

const CreateQAUser: React.FC<Props> = ({ QAUsers, client }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [userId, setUserId] = useState('');

  // Filter out users that are already part of the client's QA users list
  const QAUsersNotYetAdded = client.QAUserIds?.length
    ? QAUsers.filter((user) => !client.QAUserIds?.includes(user.id))
    : QAUsers;

  const [errorMessage, setErrorMessage] = useState('');

  const onClose = () => {
    setShowModal(false);
    setIsLoading(false);

    setErrorMessage('');
  };

  const handleChange = (event: React.ChangeEvent<{ value: unknown }>) => {
    const selectedUserId = event.target.value as string;

    if (!selectedUserId) {
      return;
    }

    setUserId(selectedUserId);
  };

  const onSubmit = async (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
    e.preventDefault();

    if (!userId) {
      return;
    }

    try {
      setErrorMessage('');
      setIsLoading(true);

      const updatedQAUserIds = [...(client.QAUserIds || []), userId];
      await updateClient(client.id, { QAUserIds: updatedQAUserIds });
      onClose();
    } catch (err) {
      const errMessage = getApiErrorMessage(err);
      setErrorMessage(errMessage);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <Button variant="contained" color="primary" onClick={() => setShowModal(true)}>
        Add QA
      </Button>
      <Dialog open={showModal} onClose={onClose} fullWidth>
        <DialogTitle>Add user to {client.name}'s QA list</DialogTitle>
        <DialogContent>
          <FormGroup>
            <Select value={userId} onChange={handleChange} fullWidth>
              {QAUsersNotYetAdded.map((user) => {
                return (
                  <MenuItem key={user.id} value={user.id}>
                    {`${user.firstName} ${user.lastName} <${user.email}>`}
                  </MenuItem>
                );
              })}
            </Select>

            <Box marginTop={3}>
              <Grid container justify="flex-end">
                {isLoading && (
                  <Box marginRight={2}>
                    <CircularProgress />
                  </Box>
                )}
                <Box marginRight={2}>
                  <Button variant="outlined" color="primary" type="submit" onClick={onClose} disabled={isLoading}>
                    Cancel
                  </Button>
                </Box>
                <Button variant="contained" color="primary" type="submit" onClick={onSubmit} disabled={isLoading}>
                  Add
                </Button>
              </Grid>
            </Box>
          </FormGroup>

          <Box marginTop={3}>{errorMessage && <Alert severity={AlertSeverity.ERROR}>{errorMessage}</Alert>}</Box>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default CreateQAUser;
