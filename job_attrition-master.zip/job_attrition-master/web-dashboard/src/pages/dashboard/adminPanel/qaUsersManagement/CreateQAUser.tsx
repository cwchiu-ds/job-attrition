import {
  Box,
  Button,
  CircularProgress,
  Dialog,
  DialogContent,
  DialogTitle,
  FormGroup,
  Grid,
  TextField,
} from '@material-ui/core';
import { Alert } from '@material-ui/lab';
import React, { useState } from 'react';

import { adminCreateNewUser } from '../../../../modules/admin';
import { AlertSeverity, UserType } from '../../../../utils/constants';
import { getApiErrorMessage } from '../../../../utils/errors';

const CreateQAUser: React.FC = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [userCreated, setUserCreated] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  const onClose = () => {
    setShowModal(false);
    setIsLoading(false);
    setUserCreated(false);
    setEmail('');
    setPassword('');
    setCompanyName('');
    setFirstName('');
    setLastName('');
    setPhoneNumber('');
    setErrorMessage('');
  };

  const onSubmit = async (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
    e.preventDefault();

    let validationErrorMessage = '';
    if (!email.trim() || !firstName.trim() || !lastName.trim() || !companyName.trim()) {
      validationErrorMessage = 'Required fields: ';
      let emptyFields = [];
      if (!email) {
        emptyFields.push('email');
      }
      if (!firstName) {
        emptyFields.push('first name');
      }
      if (!lastName) {
        emptyFields.push('last name');
      }
      if (!companyName) {
        emptyFields.push('company');
      }
      validationErrorMessage += emptyFields.join(', ');
      validationErrorMessage += '. ';
    }

    if (validationErrorMessage) {
      setErrorMessage(validationErrorMessage);
      return;
    }

    try {
      setErrorMessage('');
      setIsLoading(true);

      const newUser = {
        firstName,
        lastName,
        email,
        password,
        phoneNumber,
        companyName,
        userType: UserType.QA,
      };

      await adminCreateNewUser(newUser);
      setUserCreated(true);
    } catch (err) {
      const errMessage = getApiErrorMessage(err)
      setErrorMessage(errMessage);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <Button variant="contained" color="primary" onClick={() => setShowModal(true)}>Create QA User</Button>
      <Dialog open={showModal} onClose={onClose} fullWidth>
        <DialogTitle>Create New QA User</DialogTitle>
        <DialogContent>
          {!userCreated && (
            <FormGroup>
              <Box marginTop={3}>
                <TextField
                  label="First Name*"
                  value={firstName}
                  onChange={(event: React.ChangeEvent<HTMLInputElement>) => {
                    setFirstName(event.target.value);
                  }}
                  fullWidth
                />
              </Box>

              <Box marginTop={3}>
                <TextField
                  label="Last Name*"
                  value={lastName}
                  onChange={(event: React.ChangeEvent<HTMLInputElement>) => {
                    setLastName(event.target.value);
                  }}
                  fullWidth
                />
              </Box>

              <Box marginTop={3}>
                <TextField
                  label="Company name*"
                  value={companyName}
                  onChange={(event: React.ChangeEvent<HTMLInputElement>) => {
                    setCompanyName(event.target.value);
                  }}
                  fullWidth
                />
              </Box>

              <Box marginTop={3}>
                <TextField
                  label="Phone number"
                  type="tel"
                  value={phoneNumber}
                  onChange={(event: React.ChangeEvent<HTMLInputElement>) => {
                    setPhoneNumber(event.target.value);
                  }}
                  fullWidth
                />
              </Box>

              <Box marginTop={3}>
                <TextField
                  label="Email*"
                  type="email"
                  value={email}
                  onChange={(event: React.ChangeEvent<HTMLInputElement>) => {
                    setEmail(event.target.value);
                  }}
                  fullWidth
                />
              </Box>

              <Box marginTop={3}>
                <TextField
                  label="Password*"
                  type="password"
                  value={password}
                  onChange={(event: React.ChangeEvent<HTMLInputElement>) => {
                    setPassword(event.target.value);
                  }}
                  fullWidth
                />
              </Box>

              <Box marginTop={3}>
                <Grid container justify="flex-end">
                  {isLoading && (
                    <Box marginRight={2}>
                      <CircularProgress />
                    </Box>
                  )}
                  <Button variant="contained" color="primary" type="submit" onClick={onSubmit} disabled={isLoading}>
                    Create Account
                  </Button>
                </Grid>
              </Box>
            </FormGroup>
          )}
          {userCreated && (
            <>
              <Alert severity={AlertSeverity.SUCCESS}>User successfully created</Alert>
              <Box marginY={1} textAlign="right">
                <Button variant="contained" color="primary" type="submit" onClick={onClose}>
                  Ok
                </Button>
              </Box>
            </>
          )}
          <Box marginTop={3}>{errorMessage && <Alert severity={AlertSeverity.ERROR}>{errorMessage}</Alert>}</Box>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default CreateQAUser;
