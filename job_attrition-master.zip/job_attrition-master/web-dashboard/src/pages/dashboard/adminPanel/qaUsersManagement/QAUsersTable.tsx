import {
  Box,
  Button,
  Chip,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogTitle,
  Grid,
  Typography,
} from '@material-ui/core';
import Paper from '@material-ui/core/Paper';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import React, { useState } from 'react';

import { logError } from '../../../../modules/analytics';
import { updateClient } from '../../../../modules/client';

interface Props {
  QAUsers: FullUser[];
  clients: Client[];
}

const MIN_COLUMN_WIDTH = 150;

const QAUsersTable: React.FC<Props> = ({ QAUsers, clients }) => {
  const [removeClientId, setRemoveClientId] = useState('');
  const [removeUserId, setRemoveUserId] = useState('');
  const [showRemoveClientModal, setShowRemoveClientModal] = useState(false);
  const [showRemoveAllClientsModal, setShowRemoveAllClientsModal] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const clientToBeRemoved = clients.find((client) => client.id === removeClientId);
  const userToBeRemovedFrom = QAUsers.find((user) => user.id === removeUserId);

  const onClose = () => {
    setShowRemoveClientModal(false);
    setShowRemoveAllClientsModal(false);
  };

  const onClickRemove = (userId: string, clientId: string) => {
    setRemoveUserId(userId);
    setRemoveClientId(clientId);
    setShowRemoveClientModal(true);
  };

  const onClickRemoveAll = (userId: string) => {
    setRemoveUserId(userId);
    setShowRemoveAllClientsModal(true);
  };

  const onConfirmRemove = async () => {
    setIsLoading(true);

    try {
      const clientToRemove = clients.find((client) => client.id === removeClientId);

      const updatedQAUserIds = (clientToRemove?.QAUserIds || []).filter((userId) => userId !== removeUserId);

      await updateClient(removeClientId, { QAUserIds: updatedQAUserIds });
      onClose();
    } catch (err) {
      logError(err);
    } finally {
      setIsLoading(false);
    }
  };

  const onConfirmRemoveAll = async () => {
    setIsLoading(true);

    try {
      const clientsToRemove = clients.filter((client) => client.QAUserIds && client.QAUserIds.includes(removeUserId));

      for (const clientToRemove of clientsToRemove) {
        const updatedQAUserIds = (clientToRemove?.QAUserIds || []).filter((userId) => userId !== removeUserId);

        await updateClient(clientToRemove.id, { QAUserIds: updatedQAUserIds });
      }

      onClose();
    } catch (err) {
      logError(err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Grid container item spacing={3}>
      <Grid item>
        <Typography variant="h5">Current QA users</Typography>
      </Grid>

      <Grid item xs={12}>
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell style={{ minWidth: MIN_COLUMN_WIDTH }}>Name</TableCell>
                <TableCell style={{ minWidth: MIN_COLUMN_WIDTH }} align="left">
                  Email
                </TableCell>
                <TableCell style={{ minWidth: MIN_COLUMN_WIDTH }} align="left">
                  Company
                </TableCell>
                <TableCell align="center">QA Clients</TableCell>
                <TableCell align="center">QA Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {QAUsers.map((user) => {
                const clientCompanyName = clients.find((client) => client.id === user.clientId)?.name || '';
                const QAUserClients = clients
                  .filter((client) => client.QAUserIds?.includes(user.id))
                  .sort((clientA, clientB) => (clientA.name.toLowerCase() > clientB.name.toLowerCase() ? 1 : -1));

                return (
                  <TableRow key={user.id}>
                    <TableCell component="th" scope="row">
                      {`${user.firstName} ${user.lastName}`}
                    </TableCell>
                    <TableCell align="left">{user.email}</TableCell>
                    <TableCell align="left">{clientCompanyName}</TableCell>
                    <TableCell align="center">
                      <Grid container spacing={1} justify="center">
                        {QAUserClients.map((client) => {
                          return (
                            <Grid item key={client.id}>
                              <Chip
                                variant="outlined"
                                size="small"
                                label={client.name}
                                onDelete={() => onClickRemove(user.id, client.id)}
                                color="primary"
                              />
                            </Grid>
                          );
                        })}
                      </Grid>
                    </TableCell>
                    <TableCell align="center">
                      <Button
                        variant="contained"
                        color="primary"
                        onClick={() => onClickRemoveAll(user.id)}
                        disabled={isLoading}
                      >
                        Remove all
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </TableContainer>
      </Grid>

      {/* Modal handles removing one client from a QA user's list */}
      <Dialog open={showRemoveClientModal} onClose={onClose}>
        <DialogTitle>
          Remove <strong>{clientToBeRemoved?.name}</strong> from <i>{userToBeRemovedFrom?.email}</i> QA list?
        </DialogTitle>
        <DialogActions>
          {isLoading && (
            <Box marginRight={2}>
              <CircularProgress />
            </Box>
          )}
          <Button variant="outlined" color="primary" onClick={onClose} disabled={isLoading}>
            No
          </Button>
          <Button variant="contained" color="primary" onClick={onConfirmRemove} disabled={isLoading}>
            Yes
          </Button>
        </DialogActions>
      </Dialog>

      {/* Modal handles removing all clients from a QA user's list */}
      <Dialog open={showRemoveAllClientsModal} onClose={onClose}>
        <DialogTitle>
          Remove <strong>all clients</strong> from <i>{userToBeRemovedFrom?.email}</i> QA list?
        </DialogTitle>
        <DialogActions>
          {isLoading && (
            <Box marginRight={2}>
              <CircularProgress />
            </Box>
          )}
          <Button variant="outlined" color="primary" onClick={onClose} disabled={isLoading}>
            No
          </Button>
          <Button variant="contained" color="primary" onClick={onConfirmRemoveAll} disabled={isLoading}>
            Yes
          </Button>
        </DialogActions>
      </Dialog>
    </Grid>
  );
};

export default QAUsersTable;
