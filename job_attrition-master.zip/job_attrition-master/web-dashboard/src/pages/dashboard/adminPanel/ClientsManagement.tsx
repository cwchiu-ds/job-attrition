import { Box, Grid } from '@material-ui/core';
import React from 'react';

import HighlightText from '../../../components/HighlightText';
import ClientsManagementTable from './clientsManagement/ClientsManagementTable';

interface Props {
  clients: Client[];
  clientInternalData: ClientInternal[];
}
const ClientsManagement: React.FC<Props> = ({ clients, clientInternalData }) => {
  return (
    <>
      <Grid container item direction="row" justify="space-around" alignItems="center">
        <Grid container item direction="row" justify="flex-start" alignItems="center">
          <HighlightText>{clients.length}</HighlightText>
          <Box marginX={1}>total clients</Box>
        </Grid>
      </Grid>

      <Grid container item>
        <Grid item xs={12}>
          <ClientsManagementTable clients={clients} clientInternalData={clientInternalData} />
        </Grid>
      </Grid>
    </>
  );
};

export default React.memo(ClientsManagement);
