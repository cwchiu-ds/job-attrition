import { Grid, Typography } from '@material-ui/core';
import React from 'react';

import CreateQAUser from './qaUsersManagement/CreateQAUser';
import QAUsersTable from './qaUsersManagement/QAUsersTable';

interface Props {
  QAUsers: FullUser[];
  clients: Client[];
}

const QAUsersManagement: React.FC<Props> = ({ QAUsers, clients }) => {
  return (
    <>
      <Grid item>
        <Typography variant="h5">Manage Client Assignments for QA Users</Typography>
      </Grid>

      <Grid container item>
        <CreateQAUser />
      </Grid>

      <Grid container item>
        <QAUsersTable QAUsers={QAUsers} clients={clients} />
      </Grid>
    </>
  );
};

export default QAUsersManagement;
