import { Grid } from '@material-ui/core';
import AddBox from '@material-ui/icons/AddBox';
import ArrowDownward from '@material-ui/icons/ArrowDownward';
import Check from '@material-ui/icons/Check';
import ChevronLeft from '@material-ui/icons/ChevronLeft';
import ChevronRight from '@material-ui/icons/ChevronRight';
import Clear from '@material-ui/icons/Clear';
import DeleteOutline from '@material-ui/icons/DeleteOutline';
import Edit from '@material-ui/icons/Edit';
import FilterList from '@material-ui/icons/FilterList';
import FirstPage from '@material-ui/icons/FirstPage';
import LastPage from '@material-ui/icons/LastPage';
import Remove from '@material-ui/icons/Remove';
import SaveAlt from '@material-ui/icons/SaveAlt';
import Search from '@material-ui/icons/Search';
import ViewColumn from '@material-ui/icons/ViewColumn';
import MaterialTable from 'material-table';
import { Icons } from 'material-table';
import React, { forwardRef } from 'react';

import { ClientField, ClientInternalField, IntegrationType } from '../../../../utils/constants';
import ClientManagementActions from './ClientManagementActions';

const tableIcons: Icons = {
  Add: forwardRef((props, ref) => <AddBox {...props} ref={ref} />),
  Check: forwardRef((props, ref) => <Check {...props} ref={ref} />),
  Clear: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
  Delete: forwardRef((props, ref) => <DeleteOutline {...props} ref={ref} />),
  DetailPanel: forwardRef((props, ref) => <ChevronRight {...props} ref={ref} />),
  Edit: forwardRef((props, ref) => <Edit {...props} ref={ref} />),
  Export: forwardRef((props, ref) => <SaveAlt {...props} ref={ref} />),
  Filter: forwardRef((props, ref) => <FilterList {...props} ref={ref} />),
  FirstPage: forwardRef((props, ref) => <FirstPage {...props} ref={ref} />),
  LastPage: forwardRef((props, ref) => <LastPage {...props} ref={ref} />),
  NextPage: forwardRef((props, ref) => <ChevronRight {...props} ref={ref} />),
  PreviousPage: forwardRef((props, ref) => <ChevronLeft {...props} ref={ref} />),
  ResetSearch: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
  Search: forwardRef((props, ref) => <Search {...props} ref={ref} />),
  SortArrow: forwardRef((props, ref) => <ArrowDownward {...props} ref={ref} />),
  ThirdStateCheck: forwardRef((props, ref) => <Remove {...props} ref={ref} />),
  ViewColumn: forwardRef((props, ref) => <ViewColumn {...props} ref={ref} />),
};

interface Props {
  clients: Client[];
  clientInternalData: ClientInternal[];
}

interface ClientsManagementRowData {
  [ClientField.NAME]: string;
  [ClientField.CODE_NAME]?: string;
  [ClientField.CONTACT_COUNT]?: number;
  [ClientField.INTEGRATION_TYPE]?: IntegrationType;
  [ClientInternalField.CONTACTS_DENORMALIZATION_DATE]?: string;
  [ClientInternalField.CONTACTS_CONTACT_DATA_ID_UPDATED]?: string;
  [ClientInternalField.NOTES]?: string;
  client: Client;
}

const ClientsManagementTable: React.FC<Props> = ({ clients, clientInternalData }) => {
  const rows: ClientsManagementRowData[] = clients.map((client) => {
    const rowData: ClientsManagementRowData = {
      client,
      [ClientField.NAME]: client.name,
      [ClientField.CODE_NAME]: client.codeName,
      [ClientField.CONTACT_COUNT]: client.contactCount,
      [ClientField.INTEGRATION_TYPE]: client.integrationType,
    };

    const internalData = clientInternalData.find((clientInternal) => clientInternal.id === client.id);
    if (internalData) {
      rowData[
        ClientInternalField.CONTACTS_DENORMALIZATION_DATE
      ] = internalData.contactsDenormalizationDate?.toDate().toLocaleString();
      rowData[ClientInternalField.NOTES] = internalData.notes;
      rowData[
        ClientInternalField.CONTACTS_CONTACT_DATA_ID_UPDATED
      ] = internalData.contactDataIdsUpdatedDate?.toDate().toLocaleString();
      rowData[
        ClientInternalField.CONTACTS_CONTACT_DATA_SCRAPED
      ] = internalData.contactDataScrapedDate?.toDate().toLocaleString();
    }

    return rowData;
  });

  return (
    <MaterialTable<ClientsManagementRowData>
      icons={tableIcons}
      columns={[
        { title: 'Name', field: ClientField.NAME, cellStyle: { width: 200 }, headerStyle: { width: 200 } },
        {
          title: 'Info',
          field: ClientField.NAME,
          cellStyle: { width: 200 },
          headerStyle: { width: 200 },
          render: (rowData) => {
            return (
              <Grid container direction="column">
                <Grid item>
                  <strong>Contact count</strong>: {rowData.contactCount?.toLocaleString() || ''}
                </Grid>
                <Grid item>
                  <strong>Integration</strong>: {rowData.integrationType || ''}
                </Grid>
              </Grid>
            );
          },
        },
        {
          title: 'Code Name',
          field: ClientField.CODE_NAME,
          cellStyle: { width: 200 },
          headerStyle: { width: 200 },
        },
        { title: 'Notes', field: ClientInternalField.NOTES },
        {
          title: 'Last Denormalized',
          field: ClientInternalField.CONTACTS_DENORMALIZATION_DATE,
          cellStyle: { width: 200 },
          headerStyle: { width: 200 },
        },
        {
          title: 'Last ContactDataId Updated',
          field: ClientInternalField.CONTACTS_CONTACT_DATA_ID_UPDATED,
          cellStyle: { width: 200 },
          headerStyle: { width: 200 },
        },
        {
          title: 'Last Scraped',
          field: ClientInternalField.CONTACTS_CONTACT_DATA_SCRAPED,
          cellStyle: { width: 200 },
          headerStyle: { width: 200 },
        },
        {
          title: 'Last Weekly Report',
          field: ClientInternalField.WEEKLY_REPORT_DATE,
          cellStyle: { width: 200 },
          headerStyle: { width: 200 },
        },
        {
          title: 'Actions',
          render: (rowData) => {
            return <ClientManagementActions client={rowData.client} />;
          },
          sorting: false,
          cellStyle: { width: 50 },
          headerStyle: { width: 50, textAlign: 'center' },
        },
      ]}
      data={rows}
      title="Clients Management"
    />
  );
};

export default ClientsManagementTable;
