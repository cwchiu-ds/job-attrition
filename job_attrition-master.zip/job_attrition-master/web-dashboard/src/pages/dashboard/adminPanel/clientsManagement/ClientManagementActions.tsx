import { faBars } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  Box,
  Button,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Grid,
  IconButton,
  Menu,
  MenuItem,
  TextField,
} from '@material-ui/core';
import { Alert } from '@material-ui/lab';
import React, { useState } from 'react';

import {
  deleteClient,
  denormalizeContacts,
  emailValidationCheck,
  scrapeAllContacts,
  sendWeeklyJobChangeReport,
  updateContactDataIdtoClientContact,
} from '../../../../modules/admin';
import { logError } from '../../../../modules/analytics';
import { AlertSeverity } from '../../../../utils/constants';
import { getApiErrorMessage } from '../../../../utils/errors';

interface Props {
  client: Client;
}

const ClientManagementActions: React.FC<Props> = ({ client }) => {
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const [showDeleteClientModal, setShowDeleteClientModal] = useState(false);
  const [showDenormalizeContactsModal, setShowDenormalizeContactsModal] = useState(false);
  const [showRunEnrichmentScraperModal, setShowRunEnrichmentScraperModal] = useState(false);
  const [showClickUpdateContactModal, setShowClickUpdateContactModal] = useState(false);
  const [showSendWeeklyReportModal, setShowWeeklyReportModal] = useState(false);
  const [showEmailValidationCheckModal, setShowEmailValidationCheckModal] = useState(false);
  const [minutes, setMinutes] = useState('1');
  const [testEmail, setTestEmail] = useState('alan@warmlycomma.com');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const handleActionMenuClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const onCloseMenu = () => {
    setAnchorEl(null);
  };

  const onCloseModals = () => {
    setErrorMessage('');
    setIsLoading(false);
    setShowDeleteClientModal(false);
    setShowDenormalizeContactsModal(false);
    setShowRunEnrichmentScraperModal(false);
    setShowClickUpdateContactModal(false);
    setShowWeeklyReportModal(false);
    setShowEmailValidationCheckModal(false);
  };

  const onClickDeleteClient = () => {
    setShowDeleteClientModal(true);
    setAnchorEl(null);
  };

  const onChangeMinutes = (event: React.ChangeEvent<HTMLInputElement>) => {
    setMinutes(event.target.value);
  };

  const onChangeTestEmail = (event: React.ChangeEvent<HTMLInputElement>) => {
    setTestEmail(event.target.value);
  };

  const onClickDenormalizeContacts = () => {
    setShowDenormalizeContactsModal(true);
    setAnchorEl(null);
  };

  const onClickUpdateContactDataIdToClientContacts = () => {
    setShowClickUpdateContactModal(true);
    setAnchorEl(null);
  };

  const onClickRunEnrichmentScraper = () => {
    setShowRunEnrichmentScraperModal(true);
    setAnchorEl(null);
  };

  const onClickEmailValidationCheck = () => {
    setShowEmailValidationCheckModal(true);
    setAnchorEl(null);
  };

  const onClickSendWeeklyReportModal = () => {
    setShowWeeklyReportModal(true);
    setAnchorEl(null);
  };

  const onConfirmDeleteClient = async () => {
    setIsLoading(true);

    try {
      await deleteClient(client.id);
      onCloseModals();
    } catch (err) {
      const errMessage = getApiErrorMessage(err);
      logError(err, `Error while deleting client - ${errMessage}`);
      setIsLoading(false);
    }
  };

  const onConfirmDenormalizeContacts = async () => {
    setIsLoading(true);

    try {
      await denormalizeContacts(client.id);
      onCloseModals();
    } catch (err) {
      const errMessage = getApiErrorMessage(err);
      logError(err, `Error while denormalizing contacts - ${errMessage}`);
      setIsLoading(false);
    }
  };

  const onConfirmContactDataIdToClientContacts = async () => {
    setIsLoading(true);

    try {
      await updateContactDataIdtoClientContact(client.id);
      console.log('finished');
      onCloseModals();
    } catch (err) {
      const errMessage = getApiErrorMessage(err);
      logError(err, `Error while updating contactDataId to client contacts - ${errMessage}`);
      setIsLoading(false);
    }
  };

  const onConfirmRunScraperOnAllContacts = async () => {
    setIsLoading(true);

    try {
      await scrapeAllContacts(client.id, minutes);
      onCloseModals();
    } catch (err) {
      const errMessage = getApiErrorMessage(err);
      logError(err, `Error while scraping all contacts - ${errMessage}`);
      setIsLoading(false);
    }
  };

  const onConfirmEmailValidationCheck = async () => {
    setIsLoading(true);

    try {
      await emailValidationCheck(client.id);
      onCloseModals();
    } catch (err) {
      const errMessage = getApiErrorMessage(err);
      logError(err, `Error while running email validation check - ${errMessage}`);
      setIsLoading(false);
    }
  };

  const onConfirmSendTestEmail = async () => {
    setIsLoading(true);

    try {
      await sendWeeklyJobChangeReport(client.id, testEmail);
      onCloseModals();
    } catch (err) {
      const errMessage = getApiErrorMessage(err);
      logError(err, `Error while scraping all contacts - ${errMessage}`);
      setIsLoading(false);
    }
  };

  const onConfirmSendEmail = async () => {
    setIsLoading(true);

    try {
      await sendWeeklyJobChangeReport(client.id);
      onCloseModals();
    } catch (err) {
      const errMessage = getApiErrorMessage(err);
      logError(err, `Error while scraping all contacts - ${errMessage}`);
      setIsLoading(false);
    }
  };

  return (
    <Grid container justify="center">
      <IconButton edge="start" color="inherit" aria-label="menu" onClick={handleActionMenuClick}>
        <FontAwesomeIcon icon={faBars} />
      </IconButton>
      <Menu
        anchorEl={anchorEl}
        keepMounted
        getContentAnchorEl={null}
        open={Boolean(anchorEl)}
        onClose={onCloseMenu}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'center',
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'center',
        }}
      >
        <MenuItem onClick={onClickDeleteClient}>Delete Client</MenuItem>
        <MenuItem onClick={onClickDenormalizeContacts}>Denormalize Contacts</MenuItem>
        <MenuItem onClick={onClickUpdateContactDataIdToClientContacts}>Update ContactDataID</MenuItem>
        <MenuItem onClick={onClickRunEnrichmentScraper}>Run Enrichment Scraper</MenuItem>
        <MenuItem onClick={onClickEmailValidationCheck}>Run Email Validation Check</MenuItem>
        <MenuItem onClick={onClickSendWeeklyReportModal}>Send Job Change Report</MenuItem>
      </Menu>

      {/* Deletes the client and all associated client contacts */}
      <Dialog open={showDeleteClientModal} onClose={onCloseModals}>
        <DialogTitle>
          <span role="img" aria-label="surprise">
            🙀
          </span>
          Deleting the client {client.name} will delete all their client contacts (the contact data will be unaffected),
          are you sure?
        </DialogTitle>
        <DialogContent>{errorMessage && <Alert severity={AlertSeverity.ERROR}>{errorMessage}</Alert>}</DialogContent>
        <DialogActions>
          {isLoading && (
            <Box marginRight={2}>
              <CircularProgress />
            </Box>
          )}
          <Button variant="outlined" color="primary" onClick={onCloseModals} disabled={isLoading}>
            No
          </Button>
          <Button variant="contained" color="primary" onClick={onConfirmDeleteClient} disabled={isLoading}>
            Yes
          </Button>
        </DialogActions>
      </Dialog>

      {/* Update ContactDataId for associated client contacts */}
      <Dialog open={showClickUpdateContactModal} onClose={onCloseModals}>
        <DialogTitle>
          <span role="img" aria-label="surprise">
            🟡
          </span>
          Create Contact Data for associated {client.name} client contacts if it doesn't exist. Append back associated
          contactDataId to Client Contact
        </DialogTitle>
        <DialogContent>{errorMessage && <Alert severity={AlertSeverity.ERROR}>{errorMessage}</Alert>}</DialogContent>
        <DialogActions>
          {isLoading && (
            <Box marginRight={2}>
              <CircularProgress />
            </Box>
          )}
          <Button variant="outlined" color="primary" onClick={onCloseModals} disabled={isLoading}>
            No
          </Button>
          <Button
            variant="contained"
            color="primary"
            onClick={onConfirmContactDataIdToClientContacts}
            disabled={isLoading}
          >
            Yes
          </Button>
        </DialogActions>
      </Dialog>

      {/* Updates the contactData for client contacts with the latest */}
      <Dialog open={showDenormalizeContactsModal} onClose={onCloseModals}>
        <DialogTitle>
          This will force an update across all of {client.name}'s client contacts to pull the latest contact data.
          Continue?
        </DialogTitle>
        <DialogContent>{errorMessage && <Alert severity={AlertSeverity.ERROR}>{errorMessage}</Alert>}</DialogContent>
        <DialogActions>
          {isLoading && (
            <Box marginRight={2}>
              <CircularProgress />
            </Box>
          )}
          <Button variant="outlined" color="primary" onClick={onCloseModals} disabled={isLoading}>
            No
          </Button>
          <Button variant="contained" color="primary" onClick={onConfirmDenormalizeContacts} disabled={isLoading}>
            Yes
          </Button>
        </DialogActions>
      </Dialog>

      {/* Runs Enrichment scraper on contactData for client */}
      <Dialog open={showRunEnrichmentScraperModal} onClose={onCloseModals}>
        <DialogTitle>
          Scrape latest job title, company name, start/end date across all {client.name}'s contacts
        </DialogTitle>
        <Box paddingRight={10} paddingLeft={10}>
          <TextField
            value={minutes}
            onChange={onChangeMinutes}
            disabled={isLoading}
            size="small"
            type="number"
            margin="dense"
            fullWidth
            label={'Minutes after which to scrape same client contact'}
          />
        </Box>
        <DialogContent>{errorMessage && <Alert severity={AlertSeverity.ERROR}>{errorMessage}</Alert>}</DialogContent>
        <DialogActions>
          {isLoading && (
            <Box marginRight={2}>
              <CircularProgress />
            </Box>
          )}
          <Button variant="outlined" color="primary" onClick={onCloseModals} disabled={isLoading}>
            Cancel
          </Button>
          <Button variant="contained" color="primary" onClick={onConfirmRunScraperOnAllContacts} disabled={isLoading}>
            Scrape All Contacts
          </Button>
        </DialogActions>
      </Dialog>

      {/* Run Email Validation Check  */}
      <Dialog open={showEmailValidationCheckModal} onClose={onCloseModals}>
        <DialogTitle>Run emailing pinging validation check on {client.name}'s client contacts. Continue?</DialogTitle>
        <DialogContent>{errorMessage && <Alert severity={AlertSeverity.ERROR}>{errorMessage}</Alert>}</DialogContent>
        <DialogActions>
          {isLoading && (
            <Box marginRight={2}>
              <CircularProgress />
            </Box>
          )}
          <Button variant="outlined" color="primary" onClick={onCloseModals} disabled={isLoading}>
            No
          </Button>
          <Button variant="contained" color="primary" onClick={onConfirmEmailValidationCheck} disabled={isLoading}>
            Yes
          </Button>
        </DialogActions>
      </Dialog>

      {/* Send weekly report email and test email */}
      <Dialog open={showSendWeeklyReportModal} onClose={onCloseModals}>
        <DialogTitle>
          <span role="img" aria-label="surprise">
            💌
          </span>
          Send weekly job change report email to {client.name}
        </DialogTitle>

        <DialogContent>{errorMessage && <Alert severity={AlertSeverity.ERROR}>{errorMessage}</Alert>}</DialogContent>
        <Box paddingRight={10} paddingLeft={10}>
          <TextField
            value={testEmail}
            onChange={onChangeTestEmail}
            disabled={isLoading}
            size="medium"
            margin="dense"
            fullWidth
            label={'Test Email'}
          />
        </Box>
        <DialogActions>
          {isLoading && (
            <Box marginRight={2}>
              <CircularProgress />
            </Box>
          )}
          <Button variant="outlined" color="primary" onClick={onCloseModals} disabled={isLoading}>
            Cancel
          </Button>
          <Button variant="contained" color="primary" onClick={onConfirmSendTestEmail} disabled={isLoading}>
            Send Test Email
          </Button>
          <Button variant="contained" color="secondary" onClick={onConfirmSendEmail} disabled={isLoading}>
            Send Email
          </Button>
        </DialogActions>
      </Dialog>
    </Grid>
  );
};

export default ClientManagementActions;
