import { faLinkedin } from '@fortawesome/free-brands-svg-icons';
import { faChevronDown } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { Avatar, Badge, Box, Checkbox, Divider, Grid, makeStyles, Paper, Tooltip } from '@material-ui/core';
import React, { useContext } from 'react';

import { WarmlyColor } from '../../utils/constants';
import { getClientContactName } from '../../utils/functions';
import { ContactContext } from '../Main';
import { ContactUpdatedById } from './EnrichedCrm';

const FIXED_HEIGHT = 56;
const FIXED_HEIGHT_EXPANDED = 100;

const HEIGHT_TRANSITION = 'height 0.2s ease-in';

const useStyles = makeStyles(() => ({
  paper: {
    width: '100%',
    height: FIXED_HEIGHT,
    transition: HEIGHT_TRANSITION,
  },
  paper_expanded: {
    width: '100%',
    height: FIXED_HEIGHT_EXPANDED,
    transition: HEIGHT_TRANSITION,
  },
  row: {
    height: '100%',
    transition: HEIGHT_TRANSITION,
  },
  avatar: {
    height: FIXED_HEIGHT,
    width: FIXED_HEIGHT,
  },
}));

interface ItemDataProps {
  onClick?: () => void;
  changed?: boolean;
  expanded?: boolean;
  currentDataValue?: string;
  previousDataValue?: string;
}

const ItemDataContainer: React.FC<ItemDataProps> = ({
  onClick = () => {},
  changed = false,
  expanded = false,

  currentDataValue,
  previousDataValue,
}) => {
  return (
    <Box
      style={{
        cursor: changed ? 'pointer' : undefined,
        transition: HEIGHT_TRANSITION,
      }}
      onClick={changed ? onClick : () => {}}
      display="flex"
      flexDirection="column"
      alignItems="center"
      justifyContent="center"
      bgcolor={changed ? 'secondary.light' : ''}
      width="100%"
      height={expanded ? FIXED_HEIGHT_EXPANDED - 2 : FIXED_HEIGHT - 2}
    >
      {expanded && changed && previousDataValue && (
        <>
          <Box textAlign="center" color="text.disabled">
            {previousDataValue}
          </Box>
          <Box marginY={1}>
            <FontAwesomeIcon size="lg" icon={faChevronDown} color={WarmlyColor.SALMON} />
          </Box>
        </>
      )}
      <Box textAlign="center" style={{ overflowWrap: 'anywhere' }}>
        {currentDataValue}
      </Box>
    </Box>
  );
};

interface EnrichedCrmProps {
  clientContact: ClientContact;
  expanded?: boolean;
  checked?: boolean;
  toggleExpanded: () => void;
  toggleChecked: () => void;
  contactUpdatedById: ContactUpdatedById;
}

const EnrichedCrmItem: React.FC<EnrichedCrmProps> = ({
  clientContact,
  expanded,
  checked = false,
  toggleExpanded,
  toggleChecked,
  contactUpdatedById,
}) => {
  const classes = useStyles();
  const { selectedClient: client } = useContext(ContactContext);

  const CategoryDivider = () => <Divider orientation="vertical" style={{ height: expanded ? '100%' : '70%' }} />;

  const onClickItemData = () => {
    toggleExpanded();
  };

  const onClickCheckBox = () => {
    toggleChecked();
  };

  let linkedInUpdated = false;
  let companyNameUpdated = false;
  let titleUpdated = false;

  // TODO we currently do not scrap email so this is always false
  let emailUpdated = false;

  const contactData = clientContact.contactData;

  if (contactData) {
    linkedInUpdated = contactUpdatedById.linkedInUpdated[clientContact.id];
    companyNameUpdated = contactUpdatedById.companyNameUpdated[clientContact.id];

    titleUpdated = contactUpdatedById.titleUpdated[clientContact.id];
  }

  if (!linkedInUpdated && !companyNameUpdated && !titleUpdated) {
    // If there are no detected changes, or if the data has already been synced back, we never expand the row
    expanded = false;
  }

  const onClickLinkedIn = () => {
    // contactData should always have a linkedInURL, but we use a fallback just in case
    const linkedInURL = contactData?.linkedInURL || clientContact.linkedInURL;

    if (linkedInURL) {
      window.open(linkedInURL, '_blank');
    }
  };

  const linkedInTooltipText = `Previous: ${clientContact.crmData?.crmLinkedInURL || 'na'} ➡️ Updated: ${
    clientContact?.linkedInURL || 'no current LinkedIn found'
  }`;

  return (
    <Grid container style={{ marginBottom: 3 }}>
      <Grid item xs>
        <Paper variant="outlined" className={expanded ? classes.paper_expanded : classes.paper}>
          <Grid container wrap="nowrap" direction="row" alignItems="center" className={classes.row}>
            <Grid container item alignItems="center" xs={3}>
              <Grid item style={{ width: FIXED_HEIGHT }}>
                <Avatar
                  variant="square"
                  className={classes.avatar}
                  src={contactData && contactData.profilePhoto ? contactData.profilePhoto : clientContact.profilePhoto}
                >
                  {getClientContactName(clientContact, true)}
                </Avatar>
              </Grid>
              <Grid item xs>
                <Box textAlign="center">
                  <Box fontWeight="bold">{getClientContactName(clientContact)}</Box>
                </Box>
              </Grid>
            </Grid>

            <CategoryDivider />

            <Grid container item direction="column" justify="center" alignItems="center" xs={3}>
              <ItemDataContainer
                onClick={onClickItemData}
                changed={false}
                expanded={expanded}
                currentDataValue={clientContact.email || ''}
              />
            </Grid>

            <CategoryDivider />

            <Grid container item direction="column" justify="center" alignItems="center" xs={2}>
              <ItemDataContainer
                onClick={onClickItemData}
                changed={companyNameUpdated}
                expanded={expanded}
                currentDataValue={
                  contactData?.currentJob?.[0].companyName
                    ? contactData?.currentJob?.[0].companyName
                    : clientContact.currentJob?.companyName || ''
                }
                previousDataValue={clientContact.currentJob?.companyName || 'na'}
              />
            </Grid>

            <CategoryDivider />

            <Grid container item direction="column" justify="center" alignItems="center" xs={4}>
              <ItemDataContainer
                onClick={onClickItemData}
                changed={titleUpdated}
                expanded={expanded}
                currentDataValue={
                  contactData?.currentJob?.[0].title
                    ? contactData?.currentJob?.[0].title
                    : clientContact.currentJob?.title || ''
                }
                previousDataValue={clientContact.currentJob?.title || 'na'}
              />
            </Grid>

            <CategoryDivider />

            <Grid item>
              <Box
                marginX={2}
                aria-label="linked-in"
                style={{ cursor: 'pointer' }}
                onClick={onClickLinkedIn}
                color={!clientContact.linkedInURL ? 'grey.300' : ''}
              >
                {linkedInUpdated ? (
                  <Tooltip title={linkedInTooltipText} aria-label="add">
                    <Badge variant="dot" color="secondary">
                      <FontAwesomeIcon icon={faLinkedin} size="2x" />
                    </Badge>
                  </Tooltip>
                ) : (
                  <FontAwesomeIcon icon={faLinkedin} size="2x" />
                )}
              </Box>
            </Grid>

            <Divider orientation="vertical" />

            <Grid item>
              <Box marginX={1}>
                {client?.integrationType && <Checkbox onClick={onClickCheckBox} checked={checked} />}
              </Box>
            </Grid>
          </Grid>
        </Paper>
      </Grid>
    </Grid>
  );
};

export default EnrichedCrmItem;
