import { faLinkedin } from '@fortawesome/free-brands-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { Box, Checkbox, Grid, makeStyles, Typography } from '@material-ui/core';
import React, { useContext } from 'react';

import { ContactContext } from '../Main';

const useStyles = makeStyles((theme) => ({
  headerRow: {
    fontWeight: 'bold',
    fontSize: theme.typography.h6.fontSize,
    marginBottom: 1,
  },
}));

interface Props {
  clientContacts: ClientContact[];
}

const EnrichedCrmHeaders: React.FC<Props> = ({ clientContacts }) => {
  const classes = useStyles();
  const { selectedClient: client } = useContext(ContactContext);
  return (
    <Grid container style={{ marginTop: 30 }}>
      <Grid item xs={12}>
        <Grid container wrap="nowrap" direction="row" alignItems="center" className={classes.headerRow}>
          <Grid item xs={3}>
            <Typography variant="body2">Total {clientContacts.length.toLocaleString()} contacts</Typography>
          </Grid>
          <Grid container item direction="column" justify="center" alignItems="center" xs={3}>
            <Box textAlign="center">Email</Box>
          </Grid>
          <Grid container item direction="column" justify="center" alignItems="center" xs={2}>
            <Box textAlign="center">Company</Box>
          </Grid>
          <Grid container item direction="column" justify="center" alignItems="center" xs={4}>
            <Box textAlign="center">Title</Box>
          </Grid>
          <Grid item style={{ visibility: 'hidden' }}>
            <Box marginX={2} aria-label="linked-in" style={{ cursor: 'pointer' }}>
              <FontAwesomeIcon icon={faLinkedin} size="2x" />
            </Box>
          </Grid>
          <Grid item style={{ visibility: 'hidden' }}>
            <Box marginX={1}>{client?.integrationType && <Checkbox />}</Box>
          </Grid>
        </Grid>
      </Grid>
    </Grid>
  );
};

export default EnrichedCrmHeaders;
