import { Box, Grid, makeStyles } from '@material-ui/core';
import React, { useContext } from 'react';

import { ContactContext } from '../Main';

const useStyles = makeStyles((theme) => ({
  headerRow: {
    fontWeight: 'bold',
    fontSize: theme.typography.h6.fontSize,
    marginBottom: 1,
  },
}));

const JobChangesHeaders = () => {
  const classes = useStyles();
  const { selectedClient: client } = useContext(ContactContext);

  return (
    <Grid container spacing={2} className={classes.headerRow}>
      <Grid container item xs={9}>
        <Grid container direction="row" alignItems="flex-end">
          <Grid container direction="row" item alignItems="center" xs={5}>
            <Grid container direction="row" item justify="center" alignItems="center" xs={3}>
              <Box textAlign="center">Detected</Box>
            </Grid>
            <Grid container item justify="center" alignItems="center" xs={4}></Grid>
            <Grid container item direction="column" justify="center" alignItems="center" xs={5}></Grid>
          </Grid>
          <Grid container item alignItems="center" xs={7}>
            <Grid container item direction="column" justify="center" alignItems="center" xs={3}>
              <Box textAlign="center">Email</Box>
            </Grid>
            <Grid item xs={3}>
              <Box textAlign="center">Company</Box>
            </Grid>
            <Grid item xs={3}>
              <Box textAlign="center">Title</Box>
            </Grid>
            <Grid item xs={3}>
              <Box textAlign="center">Note</Box>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
      <Grid container item xs={3} alignItems="flex-end">
        <Grid container item alignItems="center">
          <Grid item xs={4}>
            <Box textAlign="center">Contact</Box>
          </Grid>
          <Grid item xs={8}>
            {client?.integrationType && <Box textAlign="center">CRM Actions</Box>}
          </Grid>
        </Grid>
      </Grid>
    </Grid>
  );
};

export default JobChangesHeaders;
