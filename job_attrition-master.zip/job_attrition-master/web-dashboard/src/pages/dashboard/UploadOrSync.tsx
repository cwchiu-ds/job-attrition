import { Box, Grid, Typography } from '@material-ui/core';
import React, { useContext, useState } from 'react';

import { AuthContext } from '../../components/auth/AuthProvider';
import UploadCsvModal from '../../components/uploadCSV/UploadCSVModal';
import {
  cloudFunctionsURL,
  CSV_LOGO,
  HUBSPOT_LOGO,
  SALESFORCE_LOGO,
  SECURE_ICON,
} from '../../utils/constants';
import SalesforceInitializeModal from '../integration/SalesforceInitializeModal';

const UploadOrSync: React.FC = () => {
  const { user, client } = useContext(AuthContext);
  const [showUploadCsvModal, setShowUploadCsvModal] = useState(false);
  const [showSalesforceInitializeModal, setShowSalesforceInitializeModal] = useState(false);

  return (
    <Grid container direction="column" justify="flex-start" alignItems="flex-start" spacing={3}>
      <Grid item>
        <Typography variant="h1" color="primary">
          Get notified when your advocates change jobs
        </Typography>
      </Grid>

      <Grid item container justify="center">
        <Typography variant="h6" color="primary">
          Sync your existing CRM or upload a CSV:
        </Typography>
      </Grid>

      <Grid container item direction="column" justify="center" alignItems="center">
        <Grid item>
          <Box
            border={1}
            borderRadius={4}
            paddingY={2}
            marginY={2}
            width={250}
            height={100}
            borderColor="secondary.main"
            textAlign="center"
            style={{ cursor: 'pointer' }}
          >
            <a
              href={`${cloudFunctionsURL.HUBSPOT_INSTALL}?companyName=${client?.name}&companyEmail=${user?.email}&clid=${user?.clientId}`}
            >
              <img alt="hubspot-logo" src={HUBSPOT_LOGO} height="100%" />
            </a>
          </Box>
        </Grid>

        <Grid item>
          <Box
            border={1}
            borderRadius={4}
            paddingY={2}
            marginY={2}
            width={250}
            height={100}
            borderColor="secondary.main"
            textAlign="center"
            onClick={() => {
              setShowSalesforceInitializeModal(true);
            }}
            style={{ cursor: 'pointer' }}
          >
            <img alt="salesforce-logo" src={SALESFORCE_LOGO} height="100%" />
          </Box>
        </Grid>

        <Grid item>
          <Box
            border={1}
            borderRadius={4}
            paddingY={2}
            marginY={2}
            width={250}
            height={100}
            borderColor="black"
            textAlign="center"
            style={{ cursor: 'pointer' }}
            onClick={() => {
              setShowUploadCsvModal(true);
            }}
          >
            <img alt="csv-logo" src={CSV_LOGO} height="100%" />
          </Box>
        </Grid>

        <Grid item>
          <Box paddingY={2} marginY={2} width={300} height={100} borderColor="black">
            <Grid container spacing={2}>
              <Grid item>
                <img alt="secure-icon" src={SECURE_ICON} />
              </Grid>
              <Grid item xs>
                <Typography>
                  Your customer list will never be shared with anyone. Your customers will never know you use us to
                  track them.
                </Typography>
              </Grid>
            </Grid>
          </Box>
        </Grid>
      </Grid>
      <UploadCsvModal
        showUploadCsvModal={showUploadCsvModal}
        setShowUploadCsvModal={setShowUploadCsvModal}
      />
      <SalesforceInitializeModal
        showSalesforceInitializeModal={showSalesforceInitializeModal}
        setShowSalesforceInitializeModal={setShowSalesforceInitializeModal}
      />
    </Grid>
  );
};

export default UploadOrSync;
