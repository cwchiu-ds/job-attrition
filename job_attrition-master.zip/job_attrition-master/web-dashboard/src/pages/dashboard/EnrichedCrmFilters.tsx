import React from 'react';
import { Grid, Box, Paper, Typography, withStyles } from '@material-ui/core';
import { ContactUpdatedById } from './EnrichedCrm';

const FILTER_CONTAINER_HEIGHT = 80;

const FilterContainer = withStyles(() => ({
  root: {
    height: FILTER_CONTAINER_HEIGHT,
  },
}))(Paper);

const FilterTextbox = withStyles({
  root: {
    height: '100%',
  },
})((props) => (
  <Box
    {...props}
    display="flex"
    alignItems="center"
    marginX={2}
    fontWeight="bold"
    fontSize="h6.fontSize"
    color="primary.main"
  />
));

interface Props {
  contactUpdatedById: ContactUpdatedById;
}

const EnrichedCrmFilters: React.FC<Props> = ({ contactUpdatedById }) => {
  const linkedInUpdatedCount = Object.values(contactUpdatedById.linkedInUpdated).filter((value) => value).length;
  const companyNameUpdatedCount = Object.values(contactUpdatedById.companyNameUpdated).filter((value) => value).length;
  const titleUpdatedCount = Object.values(contactUpdatedById.companyNameUpdated).filter((value) => value).length;

  const totalUpdatedCount = Object.values(contactUpdatedById.anyUpdated).filter((value) => value).length

  return (
    <Grid container direction="row" spacing={4} style={{ marginBottom: 30 }}>
      <Grid item container xs={1} alignItems="center">
        <Typography variant="h6">Summary</Typography>
      </Grid>

      {Boolean(totalUpdatedCount) && <Grid item xs={2}>
        <FilterContainer>
          <FilterTextbox>{totalUpdatedCount} Enriched contacts</FilterTextbox>
        </FilterContainer>
      </Grid>}

      {Boolean(linkedInUpdatedCount) && (
        <Grid item xs={2}>
          <FilterContainer>
            <FilterTextbox>{linkedInUpdatedCount} LinkedIn updated</FilterTextbox>
          </FilterContainer>
        </Grid>
      )}

      {/* <Grid item xs={2}>
        <FilterContainer>
          <FilterTextbox>30 Emails updated</FilterTextbox>
        </FilterContainer>
      </Grid> */}

      {Boolean(companyNameUpdatedCount + titleUpdatedCount) && (
        <Grid item xs={2}>
          <FilterContainer>
            <FilterTextbox>{companyNameUpdatedCount + titleUpdatedCount} Company / Title data updated</FilterTextbox>
          </FilterContainer>
        </Grid>
      )}
    </Grid>
  );
};

export default EnrichedCrmFilters;
