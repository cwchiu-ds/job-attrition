import { Grid, Typography } from '@material-ui/core';
import React from 'react';
import { Redirect, Route, Switch } from 'react-router-dom';

import { useSubscribeCollection, useSubscribeCollectionByField } from '../../hooks/firebase';
import { COLLECTION, NavigationPath, UserField, UserType } from '../../utils/constants';
import ClientManagement from './adminPanel/ClientManagement';
import ClientsManagement from './adminPanel/ClientsManagement';
import QAClientsManagement from './adminPanel/QAClientsManagement';
import QACollectorView from './adminPanel/QACollectorView';
import QADataReview from './adminPanel/QADataReview';
import QAUsersManagement from './adminPanel/QAUsersManagement';

const AdminPanel: React.FC = () => {
  const clients = useSubscribeCollection<Client>(COLLECTION.CLIENTS);
  const clientInternalData = useSubscribeCollection<ClientInternal>(COLLECTION.CLIENT_INTERNAL);
  const QAUsers = useSubscribeCollectionByField<UserData>({
    collection: COLLECTION.USERS,
    field: UserField.USER_TYPE,
    operation: '==',
    fieldValue: UserType.QA,
  });

  return (
    <Grid container direction="column" justify="flex-start" alignItems="flex-start" spacing={3}>
      <Grid container item>
        <Typography variant="h1" color="primary">
          Admin Panel
        </Typography>
      </Grid>

      <Switch>
        <Route exact={true} path={NavigationPath.ADMIN_CLIENT_MANAGEMENT}>
          <ClientManagement clients={clients} />
        </Route>
        <Route exact={true} path={NavigationPath.ADMIN_CLIENTS_MANAGEMENT}>
          <ClientsManagement clients={clients} clientInternalData={clientInternalData} />
        </Route>
        <Route exact={true} path={NavigationPath.ADMIN_QA_USERS_MANAGEMENT}>
          <QAUsersManagement QAUsers={QAUsers} clients={clients} />
        </Route>
        <Route exact={true} path={NavigationPath.ADMIN_QA_CLIENTS_MANAGEMENT}>
          <QAClientsManagement QAUsers={QAUsers} clients={clients} />
        </Route>
        <Route exact={true} path={NavigationPath.ADMIN_QA_CLIENTS_MANAGEMENT}>
          <QAClientsManagement QAUsers={QAUsers} clients={clients} />
        </Route>
        <Route exact={true} path={NavigationPath.ADMIN_QA_DATA_REVIEW}>
          <QADataReview clients={clients} />
        </Route>
        <Route exact={true} path={NavigationPath.ADMIN_QA_COLLECTOR_VIEW}>
          <QACollectorView clients={clients} />
        </Route>
        <Route>
          <Redirect to={NavigationPath.ADMIN_CLIENT_MANAGEMENT} />
        </Route>
      </Switch>
    </Grid>
  );
};

export default AdminPanel;
