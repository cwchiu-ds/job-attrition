import { Box, Grid, Typography } from '@material-ui/core';
import Pagination from '@material-ui/lab/Pagination';
import React, { useContext, useEffect, useMemo, useState } from 'react';

import { LoadingAndAlertContext } from '../..';
import HighlightText from '../../components/HighlightText';
import { ContactContext } from '../Main';
// import EnrichedCrmFilters from './EnrichedCrmFilters';
import EnrichedCrmHeaders from './EnrichedCrmHeaders';
import EnrichedCrmItem from './EnrichedCrmItem';
import EnrichedCrmOptions from './EnrichedCrmOptions';

interface ExpandedClientContactsById {
  [id: string]: boolean;
}

export interface CheckedClientContactsById {
  [id: string]: boolean;
}

interface UpdatedById {
  [id: string]: boolean;
}

export interface ContactUpdatedById {
  linkedInUpdated: UpdatedById;
  emailUpdated: UpdatedById;
  companyNameUpdated: UpdatedById;
  titleUpdated: UpdatedById;
  anyUpdated: UpdatedById;
}

const getUpdatedById = (clientContacts: ClientContact[]): ContactUpdatedById => {
  const contactUpdatedById: ContactUpdatedById = {
    linkedInUpdated: {},
    emailUpdated: {},
    companyNameUpdated: {},
    titleUpdated: {},
    anyUpdated: {},
  };

  for (const clientContact of clientContacts) {
    let linkedInUpdated = false;
    let companyNameUpdated = false;
    let titleUpdated = false;
    const contactData = clientContact.contactData;

    // If the client has already synced data back to Salesforce, we check if the current data
    // is diff from the data they synced back
    if (contactData && clientContact.salesforceId && clientContact.lastSalesforceEnrichmentDate) {
      if (
        contactData.currentJob?.[0].companyName &&
        clientContact.lastSalesforceEnrichedCompanyName !== contactData.currentJob[0].companyName
      ) {
        companyNameUpdated = true;
      }

      if (
        contactData.currentJob?.[0].title &&
        clientContact.lastSalesforceEnrichedTitle !== contactData.currentJob[0].title
      ) {
        titleUpdated = true;
      }

      if (clientContact.linkedInURL && clientContact.lastSalesforceEnrichedLinkedInURL !== clientContact.linkedInURL) {
        linkedInUpdated = true;
      }
    } else if (contactData) {
      // If clientContact did not have a LinkedIn but our data does, or if the linkedIn are different
      // then we can say that LinkedIn has been updated
      linkedInUpdated = clientContact.linkedInURL !== clientContact.crmData?.crmLinkedInURL;

      if (contactData.currentJob?.[0].title || contactData.currentJob?.[0].companyName) {
        titleUpdated = clientContact.currentJob?.title !== contactData.currentJob?.[0].title;
        companyNameUpdated = clientContact.currentJob?.companyName !== contactData.currentJob?.[0].companyName;
      }
    }

    contactUpdatedById.linkedInUpdated[clientContact.id] = linkedInUpdated;
    contactUpdatedById.companyNameUpdated[clientContact.id] = companyNameUpdated;
    contactUpdatedById.titleUpdated[clientContact.id] = titleUpdated;

    contactUpdatedById.anyUpdated[clientContact.id] = linkedInUpdated || companyNameUpdated || titleUpdated;
  }

  return contactUpdatedById;
};

const EnrichedCrm = () => {
  const { clientContacts } = useContext(ContactContext);
  const { isLoading } = useContext(LoadingAndAlertContext);
  const [currentPage, setCurrentPage] = useState(1);
  // NOTE: sorting is currently not implemented. If adding sorting, we need to change the useEffect below
  const [sortedClientContacts, setSortedClientContacts] = useState(clientContacts);
  const [clientContactsShown, setClientContactsShown] = useState(sortedClientContacts.slice(0, 10));
  const [expandedClientContactsById, setExpandedClientContactsById] = useState<ExpandedClientContactsById>({});

  const [checkedClientContactsById, setCheckedClientContactsById] = useState<CheckedClientContactsById>({});

  const contactUpdatedById = useMemo(() => getUpdatedById(clientContacts), [clientContacts]);

  const numPages = Math.ceil(clientContacts.length / 10);

  const handleChange = (_e: React.ChangeEvent<unknown>, value: number) => {
    setCurrentPage(value);
  };

  const setAllRowsExpanded = (allExpanded: boolean) => {
    const updatedExpanded = sortedClientContacts.reduce((acc: ExpandedClientContactsById, clientContact) => {
      acc[clientContact.id] = allExpanded;
      return acc;
    }, {});

    setExpandedClientContactsById(updatedExpanded);
  };

  const checkAllClientContactIds = (allChecked: boolean) => {
    const updatedChecked = sortedClientContacts.reduce((acc: CheckedClientContactsById, clientContact) => {
      acc[clientContact.id] = allChecked;
      return acc;
    }, {});
    setCheckedClientContactsById(updatedChecked);
  };

  useEffect(() => {
    setSortedClientContacts(clientContacts);
  }, [clientContacts]);

  useEffect(() => {
    const firstContactIndex = (currentPage - 1) * 10;
    const lastContactIndex = firstContactIndex + 11;
    const updatedClientContactsShown = sortedClientContacts.slice(firstContactIndex, lastContactIndex);
    setClientContactsShown(updatedClientContactsShown);
  }, [currentPage, sortedClientContacts]);

  const enrichedCrmItems = useMemo(() => {
    return clientContactsShown.map((clientContact) => {
      const expanded = expandedClientContactsById[clientContact.id];
      const checked = checkedClientContactsById[clientContact.id];

      const toggleExpanded = () => {
        setExpandedClientContactsById({
          ...expandedClientContactsById,
          [clientContact.id]: !expanded,
        });
      };

      const toggleChecked = () => {
        setCheckedClientContactsById({
          ...checkedClientContactsById,
          [clientContact.id]: !checked,
        });
      };
      return (
        <EnrichedCrmItem
          key={clientContact.id}
          clientContact={clientContact}
          expanded={expanded}
          checked={checked}
          toggleExpanded={toggleExpanded}
          toggleChecked={toggleChecked}
          contactUpdatedById={contactUpdatedById}
        />
      );
    });
  }, [clientContactsShown, expandedClientContactsById, checkedClientContactsById, contactUpdatedById]);

  return (
    <>
      <Grid container direction="column" justify="flex-start" alignItems="flex-start" spacing={3}>
        <Grid container item>
          <Typography variant="h1" color="primary">
            Your Enriched CRM
          </Typography>
        </Grid>

        <Grid container item direction="row" justify="space-around" alignItems="center">
          <Grid container item direction="row" justify="flex-start" alignItems="center">
            <HighlightText>
              {Object.values(contactUpdatedById.anyUpdated)
                .filter((isUpdated) => isUpdated)
                .length.toLocaleString()}
            </HighlightText>
            <Box marginX={1}>contact enrichment(s)</Box>
          </Grid>
        </Grid>

        <Grid container item direction="column" alignItems="center">
          {Boolean(clientContacts.length) ? (
            <>
              {/* TODO: Need to fix this, calcs are off from internal google sheets counts */}
              {/* <EnrichedCrmFilters contactUpdatedById={contactUpdatedById} /> */}
              <EnrichedCrmOptions
                checkedClientContactsById={checkedClientContactsById}
                setAllRowsExpanded={setAllRowsExpanded}
                checkAllClientContactIds={checkAllClientContactIds}
              />
              <EnrichedCrmHeaders clientContacts={clientContacts} />
              {enrichedCrmItems}
              <Grid container direction="row" justify="flex-end">
                <Pagination
                  style={{
                    width: 'auto',
                    backgroundColor: 'transparent',
                    boxShadow: 'none',
                  }}
                  count={numPages}
                  page={currentPage}
                  onChange={handleChange}
                  variant="outlined"
                  shape="rounded"
                />
              </Grid>
            </>
          ) : !isLoading ? (
            <>
              <Typography variant="h6">
                You have not yet provided us with your contacts. Please use the Upload page to either upload a CSV file
                or sync in contacts from HubSpot or Salesforce.
              </Typography>
              <Box marginTop={2} fontWeight="bold" color="green" fontSize={20}>
                If you have recently uploaded contacts, please note that it may take a few minutes for the data to show
                up.
              </Box>
            </>
          ) : null}
        </Grid>
      </Grid>
    </>
  );
};

export default EnrichedCrm;
