import { faLinkedin } from '@fortawesome/free-brands-svg-icons';
import { faCheckCircle, faChevronDown, faEnvelope, faTimesCircle } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  Avatar,
  Box,
  Button,
  CircularProgress,
  Grid,
  makeStyles,
  Menu,
  MenuItem,
  Paper,
  Tooltip,
  Typography,
  withStyles,
} from '@material-ui/core';
import React, { useContext, useMemo, useState } from 'react';

import { LoadingAndAlertContext } from '../..';
import { logError } from '../../modules/analytics';
import { approveJobChangeSync, dismissJobChange, enrichSalesforceContacts } from '../../modules/cloudFunctions';
import {
  AlertSeverity,
  IntegrationType,
  JobChangeStatusIconMap,
  JobChangeStatusMap,
  WarmlyColor,
} from '../../utils/constants';
import { getClientContactName } from '../../utils/functions';
import SalesforceFirstTimeEnrichment from '../integration/SalesforceFirstTimeEnrichment';
import { ContactContext } from '../Main';

const FIXED_HEIGHT = 100;

const useStyles = makeStyles((theme) => ({
  paper: {
    width: '100%',
    height: FIXED_HEIGHT,
  },
  row: {
    height: '100%',
  },
  rowItem: {
    height: FIXED_HEIGHT,
    borderRight: 'solid 2px',
    borderRightColor: theme.palette.background.default,
  },
  avatar: {
    height: FIXED_HEIGHT,
    width: FIXED_HEIGHT,
  },
}));

const LightTooltip = withStyles((theme) => ({
  tooltip: {
    backgroundColor: theme.palette.common.white,
    color: 'rgba(0, 0, 0, 0.87)',
    boxShadow: theme.shadows[1],
    fontSize: 12,
  },
}))(Tooltip);

interface JobChangeItemDataProps {
  currentDataValue?: string;
  previousDataValue?: string;
}

const JobChangeItemData: React.FC<JobChangeItemDataProps> = ({ currentDataValue, previousDataValue }) => {
  return (
    <>
      {currentDataValue !== previousDataValue && (
        <>
          <Grid item xs={12}>
            <Box color="text.disabled" textAlign="center" style={{ overflowWrap: 'anywhere' }}>
              <Typography variant="subtitle1">{previousDataValue || 'na'}</Typography>
            </Box>
          </Grid>
          <Grid item xs={12}>
            <Box textAlign="center">
              <FontAwesomeIcon size="lg" icon={faChevronDown} color={WarmlyColor.SALMON} />
            </Box>
          </Grid>
        </>
      )}
      <Grid item xs={12}>
        <Box textAlign="center" style={{ overflowWrap: 'anywhere' }}>
          <Typography variant="subtitle1">{currentDataValue || 'na'}</Typography>
        </Box>
      </Grid>
    </>
  );
};

interface Props {
  clientContact: ClientContact;
}

const JobChangeItem: React.FC<Props> = ({ clientContact }) => {
  const contactData = clientContact.contactData;
  const { selectedClient } = useContext(ContactContext);
  const { setSnackbarAlertData } = useContext(LoadingAndAlertContext);
  const [selectedEmail, setSelectedEmail] = useState('');
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const [isLoadingApprove, setIsLoadingApprove] = useState(false);
  const [isLoadingDismiss, setIsLoadingDismiss] = useState(false);
  const [showSalesforceFirstTimeEnrichmentModal, setShowSalesforceFirstTimeEnrichmentModal] = useState(false);
  const isFirstTimeSalesforceEnrichment =
    selectedClient?.integrationType === IntegrationType.SALESFORCE &&
    (selectedClient.salesforceIntegration?.latestJobCompanyFieldName ||
      selectedClient.salesforceIntegration?.latestJobTitleFieldName ||
      selectedClient.salesforceIntegration?.latestLinkedInURLFieldName ||
      selectedClient.salesforceIntegration?.jobChangedFieldName);

  // We disable syncing back to CRM if the client does not have integration with Hubspot or Salesforce
  let disableCrmSync =
    selectedClient?.integrationType !== IntegrationType.HUBSPOT &&
    selectedClient?.integrationType !== IntegrationType.SALESFORCE;

  // If the Client is salesforce integrated but the client contact is missing Salesforce ID, we cannot sync back
  if (selectedClient?.integrationType === IntegrationType.SALESFORCE && !clientContact.salesforceId) {
    disableCrmSync = true;
  }

  const classes = useStyles();

  let hasLinkedIn = false;
  let hasEmail = false;

  if (contactData && clientContact.linkedInURL) {
    hasLinkedIn = Boolean(contactData.linkedInURL || clientContact.linkedInURL);
  }

  if (clientContact.email) {
    hasEmail = Boolean(clientContact.email);
  }

  const handleClose = (event: React.MouseEvent<HTMLLIElement, MouseEvent>) => {
    setSelectedEmail((event.target as HTMLInputElement).textContent as string);
    setAnchorEl(null);
  };

  const email =
    selectedEmail !== ''
      ? selectedEmail
      : clientContact.isValidEmail === false
      ? `${clientContact.email} 🛑` || 'na'
      : `${clientContact.email}` || 'na';

  const emails = useMemo(() => {
    if (contactData && contactData.emailData) {
      return contactData?.emailData.map((email) => {
        return (
          <MenuItem onClick={handleClose} value={email.email}>{`${email.email} ${
            email.isValid === false ? ' 🛑' : ' ✅'
          }`}</MenuItem>
        );
      });
    } else if (hasEmail) {
      setSelectedEmail(clientContact.email!);
      return (
        <MenuItem onClick={handleClose} value={clientContact.email}>{`${clientContact.email} ${
          clientContact.isValidEmail === false ? ' 🛑' : ' ✅'
        }`}</MenuItem>
      );
    } else {
      return '';
    }
  }, [clientContact.email, clientContact.isValidEmail, contactData, hasEmail]);

  const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const onClickLinkedIn = () => {
    const linkedInURL = contactData?.linkedInURL || clientContact.linkedInURL;

    if (linkedInURL) {
      window.open(linkedInURL, '_blank');
    }
  };

  const onClickEmail = () => {
    const email = clientContact.email;

    if (email) {
      window.open(`mailto:${email}`, '_blank');
    }
  };

  const onClickApproveSalesforceFirstTime = () => {
    setShowSalesforceFirstTimeEnrichmentModal(true);
  };

  const onClickApprove = async () => {
    try {
      setIsLoadingApprove(true);
      const clientContactId = clientContact.id;
      const clientId = clientContact.clientId;
      if (clientContactId && clientId) {
        if (selectedClient?.integrationType === IntegrationType.HUBSPOT) {
          if (!clientContact.crmData?.vid) {
            await dismissJobChange(clientContactId, clientId);
          } else {
            await approveJobChangeSync(clientContactId, clientId);
          }
        } else if (selectedClient?.integrationType === IntegrationType.SALESFORCE) {
          await enrichSalesforceContacts([clientContactId]);
        }
      }

      const alertData: AlertData = {
        severity: AlertSeverity.SUCCESS,
        message: `Contact successfully synced`,
      };

      setSnackbarAlertData(alertData);
    } catch (err) {
      logError(err, 'Error occurred while approving job change');

      const alertData: AlertData = {
        severity: AlertSeverity.ERROR,
        message: `Error occurred while syncing`,
      };

      setSnackbarAlertData(alertData);
      setIsLoadingApprove(false);
    }
  };

  const onClickDismiss = async () => {
    try {
      setIsLoadingDismiss(true);
      const clientContactId = clientContact.id;
      const clientId = clientContact.clientId;
      if (clientContactId && clientId) {
        await dismissJobChange(clientContactId, clientId);
      }

      const alertData: AlertData = {
        severity: AlertSeverity.INFO,
        message: `Job change notification dismissed`,
      };

      setSnackbarAlertData(alertData);
    } catch (err) {
      logError(err, 'Error occurred while dismissing job change');
      const alertData: AlertData = {
        severity: AlertSeverity.ERROR,
        message: `Error occurred while dismissing notification`,
      };

      setSnackbarAlertData(alertData);
      setIsLoadingDismiss(false);
    }
  };

  return (
    <Grid container spacing={2} style={{ marginBottom: 3, opacity: isLoadingApprove || isLoadingDismiss ? 0.5 : 1 }}>
      <Grid container item xs={9}>
        <Paper className={classes.paper}>
          <Grid container direction="row" alignItems="center" className={classes.row}>
            <Grid container direction="row" item alignItems="center" xs={5} className={classes.rowItem}>
              <Grid container direction="row" item justify="center" alignItems="center" xs={3}>
                {clientContact.dateUpdated?.toDate().toLocaleString().split(',')[0]}
              </Grid>
              <Grid container item justify="center" alignItems="center" xs={4}>
                <Avatar
                  variant="square"
                  className={classes.avatar}
                  src={contactData && contactData.profilePhoto ? contactData.profilePhoto : clientContact.profilePhoto}
                >
                  {getClientContactName(clientContact, true)}
                </Avatar>
              </Grid>
              <Grid container item direction="column" justify="center" alignItems="center" xs={5}>
                <Box textAlign="center">
                  <Grid container item direction="row" justify="center">
                    <Box marginRight={1} fontWeight="bold">
                      {getClientContactName(clientContact)}
                    </Box>
                    {/* {clientContact.verified === true ? (
                      <LightTooltip title="Verified job change">
                        <Box>
                          <FontAwesomeIcon icon={faCheckCircle} color={'green'} />
                        </Box>
                      </LightTooltip>
                    ) : null} */}
                  </Grid>
                </Box>
              </Grid>
            </Grid>
            <Grid container item alignItems="center" xs={7}>
              <Grid container item justify="center" alignItems="center" xs={3} className={classes.rowItem}>
                {/* NOTE we are not currently detecting email changes */}
                {/* <JobChangeItemData
                  previousDataValue={clientContact.email}
                  currentDataValue={
                    contactData?.emailArray?.[contactData?.emailArray?.length - 1] || clientContact.email
                  }
                /> */}

                <Grid container xs={12} direction="column" justify="center">
                  <Grid item>
                    <Box textAlign="center" style={{ overflowWrap: 'anywhere' }}>
                      <Box flexGrow={1}>
                        <Typography variant="subtitle1">{email}</Typography>
                      </Box>
                      <Box>
                        <Menu
                          id="simple-menu"
                          anchorEl={anchorEl}
                          keepMounted
                          open={Boolean(anchorEl)}
                          onClose={handleClose}
                        >
                          {emails}
                        </Menu>
                        {contactData && contactData.emailData && contactData.emailData.length > 1 ? (
                          <Button size="small" aria-controls="simple-menu" aria-haspopup="true" onClick={handleClick}>
                            <FontAwesomeIcon size="sm" icon={faChevronDown} color={WarmlyColor.DARK_BLUE} />
                          </Button>
                        ) : null}
                      </Box>
                    </Box>
                  </Grid>
                </Grid>
              </Grid>
              <Grid container item justify="center" alignItems="center" xs={3} className={classes.rowItem}>
                <JobChangeItemData
                  previousDataValue={clientContact.currentJob?.companyName}
                  currentDataValue={contactData?.currentJob?.[0]?.companyName || ''}
                />
              </Grid>
              <Grid container item justify="center" alignItems="center" xs={3} className={classes.rowItem}>
                <JobChangeItemData
                  previousDataValue={clientContact.currentJob?.title}
                  currentDataValue={contactData?.currentJob?.[0]?.title || ''}
                />
              </Grid>
              <Grid container item justify="center" alignItems="center" xs={3}>
                <Grid container item justify="center" alignItems="center" xs={12}>
                  {clientContact.jobChangedStatus ? JobChangeStatusIconMap[clientContact.jobChangedStatus] : ''}
                </Grid>
                <Grid container item justify="center" alignItems="center" xs={12}>
                  <Typography variant="subtitle1">
                    {clientContact.jobChangedStatus ? JobChangeStatusMap[clientContact.jobChangedStatus] : ''}
                  </Typography>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </Paper>
      </Grid>
      <Grid item xs={3}>
        <Paper className={classes.paper}>
          <Grid container alignItems="center" className={classes.row}>
            <Grid container item direction="column" justify="center" alignItems="center" xs={4}>
              <Box
                aria-label="linked-in"
                marginBottom={1}
                style={{ cursor: 'pointer' }}
                onClick={onClickLinkedIn}
                color={hasLinkedIn ? '' : 'grey.200'}
              >
                <FontAwesomeIcon icon={faLinkedin} size="2x" />
              </Box>
              <Box
                aria-label="email"
                style={{ cursor: 'pointer' }}
                onClick={onClickEmail}
                color={hasEmail ? '' : 'grey.200'}
              >
                <FontAwesomeIcon icon={faEnvelope} size="2x" />
              </Box>
            </Grid>

            <Grid container item direction="row" justify="center" alignItems="center" xs={8} spacing={1}>
              <Grid item xs={12}>
                <LightTooltip
                  title={
                    disableCrmSync
                      ? 'Contact must be synced from a CRM to enable sending back job change data'
                      : 'Sync new job data from Warmly back to your CRM'
                  }
                >
                  <Box>
                    <Button
                      variant="contained"
                      color="primary"
                      fullWidth
                      onClick={isFirstTimeSalesforceEnrichment ? onClickApproveSalesforceFirstTime : onClickApprove}
                      startIcon={<FontAwesomeIcon size="lg" icon={faCheckCircle} />}
                      disabled={disableCrmSync}
                    >
                      Approve
                      <Box ml={2}>{isLoadingApprove && <CircularProgress size={18} color="secondary" />}</Box>
                    </Button>
                  </Box>
                </LightTooltip>
              </Grid>
              <Grid item xs={12}>
                <LightTooltip title="Do not show this specific job change notification again. This person will remain in your CRM tab.">
                  <Button
                    variant="contained"
                    fullWidth
                    onClick={onClickDismiss}
                    startIcon={<FontAwesomeIcon size="lg" icon={faTimesCircle} />}
                  >
                    Dismiss
                    <Box ml={2}>{isLoadingDismiss && <CircularProgress size={18} />}</Box>
                  </Button>
                </LightTooltip>
              </Grid>
            </Grid>
          </Grid>
        </Paper>
      </Grid>

      {isFirstTimeSalesforceEnrichment && (
        <SalesforceFirstTimeEnrichment
          isOpen={showSalesforceFirstTimeEnrichmentModal}
          setIsOpen={setShowSalesforceFirstTimeEnrichmentModal}
          onConfirm={onClickApprove}
        />
      )}
    </Grid>
  );
};

export default JobChangeItem;
