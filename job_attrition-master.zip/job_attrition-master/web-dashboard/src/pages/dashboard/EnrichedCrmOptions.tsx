import { faArrowAltCircleDown } from '@fortawesome/free-regular-svg-icons';
import { faAngleDoubleDown, faAngleDoubleUp, faCheck } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { Box, Button, Grid, withStyles } from '@material-ui/core';
import React, { useContext, useState } from 'react';

import { LoadingAndAlertContext } from '../..';
import { ConfirmCRMApproveModal } from '../../components/crm/ConfirmCRMApproveModal';
import DownloadCSV from '../../components/downloadCSV/DownloadCSV';
import { logError } from '../../modules/analytics';
import { approveCrmSync, enrichSalesforceContacts } from '../../modules/cloudFunctions';
import { AlertSeverity, IntegrationType } from '../../utils/constants';
import SalesforceFirstTimeEnrichment from '../integration/SalesforceFirstTimeEnrichment';
import { ContactContext } from '../Main';
import { CheckedClientContactsById } from './EnrichedCrm';

const BUTTON_MARGIN = 30;

const EnrichedCrmOptionButton = withStyles((theme) => ({
  root: {
    paddingLeft: BUTTON_MARGIN,
    paddingRight: BUTTON_MARGIN,
    backgroundColor: theme.palette.common.white,
    textTransform: 'none',
    fontWeight: 300,
    borderColor: theme.palette.grey[300],
  },
}))(Button);

interface Props {
  setAllRowsExpanded: (allExpanded: boolean) => void;
  checkedClientContactsById: CheckedClientContactsById;
  checkAllClientContactIds: (allChecked: boolean) => void;
}

const EnrichedCrmOptions: React.FC<Props> = ({
  setAllRowsExpanded,
  checkedClientContactsById,
  checkAllClientContactIds,
}) => {
  const { selectedClient: client } = useContext(ContactContext);
  const { setIsLoading, setSnackbarAlertData } = useContext(LoadingAndAlertContext);
  const [allExpanded, setAllExpanded] = useState(false);
  const [allContactsChecked, setAllContactsChecked] = useState(false);
  const [showConfirmCRMApproveModal, setShowConfirmCRMApproveModal] = useState(false);
  const [showSalesforceFirstTimeEnrichmentModal, setShowSalesforceFirstTimeEnrichmentModal] = useState(false);
  const isFirstTimeSalesforceEnrichment =
    client?.integrationType === IntegrationType.SALESFORCE && !client?.salesforceContactsEnriched;

  const checkedClientContactIds = Object.keys(checkedClientContactsById).filter(
    (clientContactId) => checkedClientContactsById[clientContactId]
  );

  const checkedClientContactsCount = checkedClientContactIds.length;

  const approveSelectedChanges = async () => {
    try {
      setIsLoading(true);
      if (client?.integrationType === IntegrationType.HUBSPOT) {
        await approveCrmSync(checkedClientContactIds, client!.id);
      } else if (client?.integrationType === IntegrationType.SALESFORCE) {
        await enrichSalesforceContacts(checkedClientContactIds);
      }

      const alertData: AlertData = {
        severity: AlertSeverity.SUCCESS,
        message: `${checkedClientContactsCount} contact(s) successfully synced`,
      };

      setSnackbarAlertData(alertData);
    } catch (err) {
      logError(err, 'Error while syncing back CRM data');
      const alertData: AlertData = {
        severity: AlertSeverity.ERROR,
        message: `Error occurred while syncing back CRM data, our team has been notified of the issue`,
      };

      setSnackbarAlertData(alertData);
    } finally {
      setIsLoading(false);
      setShowConfirmCRMApproveModal(false);
    }
  };

  const onClickExpandAll = () => {
    const currentExpandedStatus = allExpanded;

    setAllExpanded(!currentExpandedStatus);
    setAllRowsExpanded(!currentExpandedStatus);
  };

  const handleSelectAllClick = (_event: React.MouseEvent<HTMLButtonElement>) => {
    const currentCheckedStatus = allContactsChecked;

    setAllContactsChecked(!currentCheckedStatus);
    checkAllClientContactIds(!currentCheckedStatus);
  };

  return (
    <Grid container direction="row" justify="flex-end" spacing={3}>
      <Grid item>
        <EnrichedCrmOptionButton
          size="small"
          variant="outlined"
          startIcon={<FontAwesomeIcon icon={faArrowAltCircleDown} />}
        >
          <DownloadCSV headerFlag={'CLIENT'} />
        </EnrichedCrmOptionButton>
      </Grid>
      <Grid item>
        <EnrichedCrmOptionButton
          size="small"
          variant="outlined"
          startIcon={<FontAwesomeIcon icon={allExpanded ? faAngleDoubleUp : faAngleDoubleDown} />}
          onClick={onClickExpandAll}
        >
          {allExpanded ? 'Contract all' : 'Expand and show all updates'}
        </EnrichedCrmOptionButton>
      </Grid>
      <Grid item>
        {Boolean(checkedClientContactsCount) && (
          <EnrichedCrmOptionButton
            size="small"
            variant="outlined"
            onClick={() => {
              if (isFirstTimeSalesforceEnrichment) {
                setShowSalesforceFirstTimeEnrichmentModal(true);
              } else {
                setShowConfirmCRMApproveModal(true);
              }
            }}
          >
            <Box marginRight={1}>Sync to CRM</Box>
            <FontAwesomeIcon icon={faCheck} />
          </EnrichedCrmOptionButton>
        )}
      </Grid>

      {client?.integrationType && (
        <>
          <Grid item>
            <EnrichedCrmOptionButton size="small" variant="outlined" onClick={handleSelectAllClick}>
              {allContactsChecked ? 'Deselect All' : 'Check All'}
            </EnrichedCrmOptionButton>
          </Grid>
          <ConfirmCRMApproveModal
            checkedClientContactsCount={checkedClientContactsCount}
            showConfirmCRMApproveModal={showConfirmCRMApproveModal}
            setShowConfirmCRMApproveModal={setShowConfirmCRMApproveModal}
            approveSelectedChanges={approveSelectedChanges}
          />
        </>
      )}

      {isFirstTimeSalesforceEnrichment && (
        <SalesforceFirstTimeEnrichment
          isOpen={showSalesforceFirstTimeEnrichmentModal}
          setIsOpen={setShowSalesforceFirstTimeEnrichmentModal}
          onConfirm={() => {
            setShowSalesforceFirstTimeEnrichmentModal(false);
            setShowConfirmCRMApproveModal(true);
          }}
        />
      )}
    </Grid>
  );
};

export default EnrichedCrmOptions;
