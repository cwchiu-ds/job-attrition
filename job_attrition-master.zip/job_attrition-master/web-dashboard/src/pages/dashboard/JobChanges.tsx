import { Box, Grid, Typography } from '@material-ui/core';
import Pagination from '@material-ui/lab/Pagination';
import React, { useContext, useEffect, useMemo, useState } from 'react';

import { LoadingAndAlertContext } from '../..';
import HighlightText from '../../components/HighlightText';
import { ContactContext } from '../Main';
import JobChangeItem from './JobChangeItem';
import JobChangesHeaders from './JobChangesHeaders';

const JobChanges = () => {
  const { clientContacts } = useContext(ContactContext);
  const { isLoading } = useContext(LoadingAndAlertContext);
  const [jobChangedClientContacts, setJobChangedClientContacts] = useState<ClientContact[]>([]);

  const numPages = Math.ceil(jobChangedClientContacts.length / 10);

  const [currentPage, setCurrentPage] = useState(1);
  const [clientContactsShown, setClientContactsShown] = useState<ClientContact[]>([]);

  const handleChange = (_e: React.ChangeEvent<unknown>, value: number) => {
    setCurrentPage(value);
  };

  const jobChangeItems = useMemo(() => {
    return clientContactsShown.map((clientContact) => {
      return <JobChangeItem key={clientContact.id} clientContact={clientContact} />;
    });
  }, [clientContactsShown]);

  useEffect(() => {
    const jobChangedClientContacts = clientContacts.filter((contact) => contact.jobChanged);

    setJobChangedClientContacts(jobChangedClientContacts);
  }, [clientContacts]);

  useEffect(() => {
    const firstContactIndex = (currentPage - 1) * 10;
    const lastContactIndex = firstContactIndex + 11;

    const updatedClientContactsShown = jobChangedClientContacts.slice(firstContactIndex, lastContactIndex);

    setClientContactsShown(updatedClientContactsShown);
  }, [jobChangedClientContacts, currentPage]);

  return (
    <Grid container direction="column" justify="flex-start" alignItems="flex-start" spacing={3}>
      <Grid container item>
        <Typography variant="h1" color="primary">
          Job Change Notifications
        </Typography>
      </Grid>
      <Grid container item direction="row" justify="space-around" alignItems="center">
        <Grid container item direction="row" justify="flex-start" alignItems="center">
          <HighlightText>{jobChangedClientContacts.length}</HighlightText>
          <Box marginX={1}> detected </Box>
        </Grid>
      </Grid>
      <Grid container item direction="column" alignItems="center">
        {Boolean(jobChangedClientContacts.length) && (
          <>
            <JobChangesHeaders />
            {jobChangeItems}
            <Grid container direction="row" justify="flex-end">
              <Pagination
                style={{ width: 'auto', backgroundColor: 'transparent', boxShadow: 'none' }}
                count={numPages}
                page={currentPage}
                onChange={handleChange}
                variant="outlined"
                shape="rounded"
              />
            </Grid>
          </>
        )}

        {!Boolean(clientContacts.length) && !isLoading ? (
          <Typography variant="h6">
            You have not yet provided us with your contacts. Please use the Upload page to either upload a CSV file or
            sync in contacts from HubSpot or Salesforce.
          </Typography>
        ) : !Boolean(jobChangedClientContacts.length) && !isLoading ? (
          <Typography variant="h6">
            No new job changes have been detected yet. Our systems are constantly working to provide you with the latest
            data on your contacts. You will receive an email with updates once the process is complete.
          </Typography>
        ) : null}
      </Grid>
    </Grid>
  );
};

export default JobChanges;
