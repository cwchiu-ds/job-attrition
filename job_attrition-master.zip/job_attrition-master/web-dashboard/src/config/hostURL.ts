import { CURRENT_ENVIRONMENT, Environment } from '../utils/constants';

export const HOST_FIREBASE =
  CURRENT_ENVIRONMENT === Environment.Development
    ? 'http://localhost:5001/jobattrition/us-central1'
    : CURRENT_ENVIRONMENT === Environment.Staging
    ? 'https://us-central1-warmly-staging.cloudfunctions.net'
    : 'https://us-central1-jobattrition.cloudfunctions.net';

export const HUBSPOT_URL =
  CURRENT_ENVIRONMENT === Environment.Development
    ? 'http://localhost:5001/jobattrition/us-central1/hubSpotIntegration'
    : CURRENT_ENVIRONMENT === Environment.Staging
    ? 'https://us-central1-warmly-staging.cloudfunctions.net/hubSpotIntegration'
    : 'https://us-central1-jobattrition.cloudfunctions.net/hubSpotIntegration';
