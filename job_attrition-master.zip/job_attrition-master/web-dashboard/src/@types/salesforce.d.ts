import { ClientContactAttribute } from '../utils/constants';

declare global {
  type SalesforceMapping = {
    [key in ClientContactAttribute]?: string;
  };
}
