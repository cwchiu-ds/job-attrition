declare module 'react-papaparse' {
  import React from 'react';
  import { ParseConfig, ParseResult } from 'papaparse';

  interface CSVReaderProps {
    onDrop?: (data: ParseResult[]) => void;
    onError?: Function;
    onFileLoad?: (data: ParseResult[]) => void;
    config?: ParseConfig;
  }

  export class CSVReader extends React.Component<CSVReaderProps> {
    inputFileRef: React.RefObject<HTMLInputElement | undefined>;
    dropAreaRef: React.RefObject<HTMLDivElement | undefined>;
    fileSizeInfoRef: React.RefObject<HTMLSpanElement | undefined>;
    fileNameInfoRef: React.RefObject<HTMLSpanElement>;
  }
}
