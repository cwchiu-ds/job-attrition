import { Field } from 'jsforce';

import {
  AlertSeverity,
  ClientContactAttributeField,
  ClientField,
  ClientInternalField,
  ClientStatus,
  CompaniesField,
  ContactDataField,
  IntegrationType,
  QAAssessment,
  QAJobChangeStatus,
  QALinkedInStatus,
  QAStatus,
  SyncStatus,
  UserField,
  UserType,
} from '../utils/constants';
declare global {
  type Timestamp = firebase.firestore.Timestamp;

  type WithId<T> = T & { id: string };

  type SelectOption = {
    label: string;
    value: string;
  };

  type CrmData = {
    [key: string]: string;
  } & {
    crmLinkedInURL?: string;
  };

  type Block = {
    [block: number]: { startAtId: string; blockSize: number };
  };

  // ContactData may be from a CSV, our database, or a third-party source,
  // so the key could be anything
  type CsvContactData = {
    [key: string]: string;
  };

  interface UserData {
    [UserField.FIRST_NAME]: string;
    [UserField.LAST_NAME]: string;
    [UserField.EMAIL]: string;
    [UserField.PHONE_NUMBER]?: string;
    [UserField.CLIENT_ID]: string;
    [UserField.USER_TYPE]: UserType;
    [UserField.CREATED_DATE]?: Timestamp;
  }

  type NewUserData = UserData;

  type FullUser = UserData & {
    id: string;
  };

  interface AuthContextData {
    authUser?: firebase.User;
    user?: FullUser;
    client?: Client;
    errorMessage: string;
    signOut: () => void;
  }

  interface ContactDataById {
    [id: string]: ContactData;
  }

  interface ContactContextData {
    clientContacts: ClientContact[];
    selectedClientId: string | undefined;
    setSelectedClientId: React.Dispatch<React.SetStateAction<string | undefined>>;
    selectedClient?: Client;
  }

  interface QAContactContextData extends ContactContextData {
    setStartAtId: React.Dispatch<React.SetStateAction<string>>;
  }

  interface LoadingAndAlertContextData {
    isLoading: boolean;
    setIsLoading: React.Dispatch<React.SetStateAction<boolean>>;
    snackbarAlertData?: AlertData;
    setSnackbarAlertData: React.Dispatch<React.SetStateAction<AlertData | undefined>>;
  }

  interface SalesforceIntegration {
    accessToken?: string | null;
    refreshToken?: string | null;
    instanceUrl?: string | null;
    lastSyncDate?: Timestamp;
    lastSyncUpdatedCount?: number;
    contactCount?: number;
    fields?: Field[];
    salesforceMapping?: SalesforceMapping | null;
    jobChangedFieldName?: string;
    latestJobTitleFieldName?: string;
    latestJobCompanyFieldName?: string;
    latestLinkedInURLFieldName?: string;
    jobChangeFieldLabel?: string | null;
    jobChangeFieldName?: string | null;
    syncStatus?: SyncStatus;
  }

  interface CSVUpload {
    lastSyncDate?: Timestamp;
    syncStatus?: SyncStatus;
    lastSyncUpdatedCount?: number;
  }

  interface Client {
    [ClientField.ID]: string;
    [ClientField.NAME]: string;
    [ClientField.CODE_NAME]?: string;
    [ClientField.ACCESS_TOKEN]?: string;
    [ClientField.REFRESH_TOKEN]?: string;
    [ClientField.INTEGRATION_TYPE]?: IntegrationType;
    [ClientField.SALESFORCE_INTEGRATION]?: SalesforceIntegration;
    [ClientField.SALESFORCE_CONTACTS_ENRICHED]?: number;
    [ClientField.SALESFORCE_JOB_CHANGES_APPROVED]?: number;
    [ClientField.JOB_CHANGE_NOTIFICATION_EMAILS]?: string[];
    [ClientField.QA_STATUS]?: QAStatus;
    [ClientField.QA_STATUS_DATE]?: Timestamp;
    [ClientField.QA_USER_IDS]?: string[];
    [ClientField.STATUS]?: ClientStatus;
    [ClientField.STATUS_DATE]?: Timestamp;
    [ClientField.CONTACT_COUNT]?: number;
    [ClientField.PAYMENT_STATUS]?: string;
    [ClientField.CLIENT_CONTACT_BLOCKS]?: Block;
    [ClientField.CSV_UPLOAD]?: CSVUpload;
  }

  interface ClientInternal {
    [ClientInternalField.ID]: string; // Should be same as the Client's ID
    [ClientInternalField.NOTES]?: string;
    [ClientInternalField.CONTACTS_DENORMALIZATION_DATE]?: Timestamp;
    [ClientInternalField.CONTACTS_CONTACT_DATA_ID_UPDATED]?: Timestamp;
    [ClientInternalField.CONTACTS_CONTACT_DATA_SCRAPED]?: Timestamp;
  }

  interface CurrentJob {
    companyName?: string;
    title?: string;
    startDate?: string;
    endDate?: string;
    duration?: string;
    companyLink?: string;
    companyId?: string;
    companyURL?: string;
    lastUpdated?: Timestamp;
  }

  interface PotentialSearch {
    fuzzyScore: string;
    searchResultTitle: string;
    searchTime: Timestamp;
    linkedInURL: string;
  }

  interface Company {
    id: string;
    [CompaniesField.COMPANY_DOMAINS]?: string[] | null;
    [CompaniesField.COMPANY_LINKEDIN_URL]?: string | null;
    [CompaniesField.COMPANY_NAMES]?: string[] | null;
    [CompaniesField.COMPANY_URL]?: string | null;
  }

  interface ClientContact {
    id: string;
    [ClientContactAttributeField.CLIENT_ID]: string;
    [ClientContactAttributeField.FIRST_NAME]?: string;
    [ClientContactAttributeField.LAST_NAME]?: string;
    [ClientContactAttributeField.FULL_NAME]?: string;
    [ClientContactAttributeField.EMAIL]?: string;
    [ClientContactAttributeField.IS_VALID_EMAIL]?: boolean | null;
    [ClientContactAttributeField.CURRENT_JOB]?: CurrentJob;
    [ClientContactAttributeField.LINKEDIN_URL]?: string;
    [ClientContactAttributeField.LINKEDIN_ID]?: string;
    [ClientContactAttributeField.CRM_DATA]?: CrmData;
    [ClientContactAttributeField.CONTACT_DATA_ID]?: string;
    [ClientContactAttributeField.VERIFIED]?: boolean | null;
    [ClientContactAttributeField.CONTACT_DATA]?: ContactData | null;
    [ClientContactAttributeField.ENRICHED_DATA_CHANGED]?: boolean;
    [ClientContactAttributeField.JOB_CHANGED]?: boolean;
    [ClientContactAttributeField.JOB_CHANGED_STATUS]?: QAJobChangeStatus | null;
    [ClientContactAttributeField.POTENTIAL_SEARCHES]?: PotentialSearch[];
    [ClientContactAttributeField.PROFILE_PHOTO]?: string;
    [ClientContactAttributeField.LAST_VERIFIED]?: Timestamp;
    [ClientContactAttributeField.DATE_UPDATED]?: Timestamp;
    [ClientContactAttributeField.QA_ASSESSMENT]?: QAAssessment | null;
    [ClientContactAttributeField.QA_USER_ID]?: string;
    [ClientContactAttributeField.QA_FULL_NAME]?: string | null;
    [ClientContactAttributeField.QA_EMAIL]?: string | null;
    [ClientContactAttributeField.QA_COMPANY_URL]?: string | null;
    [ClientContactAttributeField.QA_LINKEDIN_URL]?: string;
    [ClientContactAttributeField.QA_COMPANY_LINKEDIN_URL]?: string | null;
    [ClientContactAttributeField.QA_LINKEDIN_STATUS]?: QALinkedInStatus | null;
    [ClientContactAttributeField.QA_JOB_CHANGE_STATUS]?: QAJobChangeStatus | null;
    [ClientContactAttributeField.QA_JOB_CHANGE_STATUS_DATE]?: Timestamp;
    [ClientContactAttributeField.QA_NOTES]?: string;
    [ClientContactAttributeField.QA_RESET_DATE]?: Timestamp;
    [ClientContactAttributeField.SALESFORCE_ID]: string | null;
    [ClientContactAttributeField.LAST_SALESFORCE_ENRICHMENT_DATE]: Timestamp | null;
    [ClientContactAttributeField.LAST_SALESFORCE_ENRICHMENT_DATE]: Timestamp | null;
    [ClientContactAttributeField.LAST_SALESFORCE_ENRICHED_COMPANY_NAME]: string | null;
    [ClientContactAttributeField.LAST_SALESFORCE_ENRICHED_TITLE]: string | null;
    [ClientContactAttributeField.LAST_SALESFORCE_ENRICHED_LINKEDIN_URL]: string | null;
  }

  type EmailData = {
    email?: string;
    dateCreated?: Timestamp;
    source?: string;
    isValid?: boolean;
  };

  interface LinkedInData {
    firstName: string;
    lastName: string;
    dateCreated: Timestamp;
    email?: string;
  }
  interface ContactData {
    id: string;
    [ContactDataField.EMAIL_DATA]?: EmailData[];
    [ContactDataField.EMAIL_ARRAY]?: string[];
    [ContactDataField.LINKEDIN_URL]: string;
    [ContactDataField.LINKEDIN_ID]: string;
    [ContactDataField.LINKEDIN_DATA]?: LinkedInData[];
    [ContactDataField.CURRENT_JOB]?: CurrentJob[];
    [ContactDataField.ALL_JOBS]?: CurrentJob[];
    [ContactDataField.PROFILE_PHOTO]?: string;
  }

  interface AlertData {
    severity: AlertSeverity;
    message: string;
  }
}
