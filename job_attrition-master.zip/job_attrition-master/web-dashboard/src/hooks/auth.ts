import { useEffect,useState } from 'react';
import { useLocation } from 'react-router-dom';

import { logError } from '../modules/analytics';
import { isSignInWithEmail } from '../modules/auth';

export const useInitiateOnboarding = () => {
  const [inviteeClientName, setInviteeClientName] = useState('');
  const [inviteeClientId, setInviteeClientId] = useState('');
  const [isEmailSignIn, setIsEmailSignIn] = useState(false);
  const query = new URLSearchParams(useLocation().search);

  useEffect(() => {
    const initiateOnboardInvitedUser = async () => {
      const isEmailSignIn = isSignInWithEmail();
      const clientId = query.get('clientId');
      const clientName = query.get('clientName');

      if (isEmailSignIn && clientId && clientName) {
        try {
          setIsEmailSignIn(true);
          setInviteeClientName(decodeURIComponent(clientName));
          setInviteeClientId(decodeURIComponent(clientId));
        } catch (err) {
          logError(err, `Error while trying to setup onboarding data for invited user for client ${clientName} (id: ${clientId})`);
        }
      }
    };

    initiateOnboardInvitedUser();
  }, [query]);

  return { inviteeClientName, inviteeClientId, isEmailSignIn };
};
