import { useCallback, useEffect, useState } from 'react';

import { logError } from '../modules/analytics';
import { subscribeCollection, subscribeCollectionBlockByField, subscribeCollectionByField } from '../modules/firestore';
import {
  ClientContactAttributeField,
  ClientField,
  ClientInternalField,
  COLLECTION,
  ContactDataField,
  CURRENT_ENVIRONMENT,
  Environment,
  UserField,
} from '../utils/constants';

// Generic use subscribe collection
export const useSubscribeCollection = <T extends {}>(collection: COLLECTION) => {
  const [collectionData, setCollectionData] = useState<WithId<T>[]>([]);

  const onSnapshotCallback = (querySnapshot: firebase.firestore.QuerySnapshot<firebase.firestore.DocumentData>) => {
    if (!querySnapshot.empty) {
      const dataFromQuery = querySnapshot.docs.map((doc) => {
        return { ...(doc.data() as T), id: doc.id };
      });

      setCollectionData(dataFromQuery);
    }
  };

  useEffect(() => {
    const unsubscribe = subscribeCollection(collection, onSnapshotCallback);

    return unsubscribe;
  }, [collection]);

  return collectionData;
};

interface UseSubscribeCollectionByField {
  collection: COLLECTION;
  field: ClientField | ClientContactAttributeField | UserField | ClientInternalField | ContactDataField;
  operation: firebase.firestore.WhereFilterOp;
  fieldValue: string | number | boolean | null | Timestamp | undefined;
  orderByField?: ClientField | ClientContactAttributeField | UserField | ClientInternalField | ContactDataField;
  orderByOrder?: 'desc' | 'asc' | undefined;
  onLoadComplete?: () => void;
}

export const useSubscribeCollectionByField = <T extends {}>({
  collection,
  field,
  operation,
  fieldValue,
  orderByField,
  orderByOrder,
  onLoadComplete,
}: UseSubscribeCollectionByField) => {
  const [collectionData, setCollectionData] = useState<WithId<T>[]>([]);

  const onSnapshotCallback = useCallback(
    (querySnapshot: firebase.firestore.QuerySnapshot<firebase.firestore.DocumentData>) => {
      const dataFromQuery = querySnapshot.docs.map((doc) => {
        return { ...(doc.data() as T), id: doc.id };
      });

      setCollectionData(dataFromQuery);

      onLoadComplete && onLoadComplete();
    },
    [onLoadComplete]
  );

  useEffect(() => {
    let unsubscribe = () => {};

    if (fieldValue !== undefined) {
      unsubscribe = subscribeCollectionByField({
        collection,
        field,
        operation,
        fieldValue,
        callback: onSnapshotCallback,
        orderByField,
        orderByOrder,
      });
    } else {
      onLoadComplete && onLoadComplete();
    }

    return () => {
      unsubscribe();

      if (CURRENT_ENVIRONMENT !== Environment.Production) {
        console.log(`Unsubscribing from ${collection} where ${field} ${operation} ${fieldValue}`)
      }
    };
  }, [collection, field, operation, fieldValue, orderByField, orderByOrder, onSnapshotCallback, onLoadComplete]);

  return collectionData;
};

export const useSubscribeCollectionBlockByField = <T extends {}>({
  collection,
  field,
  operation,
  fieldValue,
  orderByField,
  orderByOrder,
  onLoadComplete,
  startAtId,
}: UseSubscribeCollectionByField & { startAtId: string }) => {
  const [collectionData, setCollectionData] = useState<(T & { id: string })[]>([]);

  const onSnapshotCallback = useCallback(
    (querySnapshot: firebase.firestore.QuerySnapshot<firebase.firestore.DocumentData>) => {
      const dataFromQuery = querySnapshot.docs.map((doc) => {
        return { ...(doc.data() as T), id: doc.id };
      });

      setCollectionData(dataFromQuery);

      onLoadComplete && onLoadComplete();
    },
    [onLoadComplete]
  );

  useEffect(() => {
    let unsubscribe = () => {};

    if (startAtId && fieldValue !== undefined) {
      const onErrorCallback = (err: Error) => {
        logError(err, `Error retrieving block of data: ${collection} where ${field} ${operation} ${fieldValue}`);
      };

      unsubscribe = subscribeCollectionBlockByField({
        collection,
        field,
        operation,
        fieldValue,
        callback: onSnapshotCallback,
        orderByField,
        orderByOrder,
        startAtId,
        onErrorCallback,
      });
    } else {
      onLoadComplete && onLoadComplete();
    }

    return unsubscribe;
  }, [
    collection,
    field,
    operation,
    fieldValue,
    orderByField,
    orderByOrder,
    startAtId,
    onSnapshotCallback,
    onLoadComplete,
  ]);

  return collectionData;
};

// Specific use subscribes
export const useSubscribeClientsForQAUserId = (QAUserId: string) => {
  const [clients, setClients] = useState<Client[]>([]);

  const onSnapshotCallback = (querySnapshot: firebase.firestore.QuerySnapshot<firebase.firestore.DocumentData>) => {
    if (!querySnapshot.empty) {
      const clientsFromQuery = querySnapshot.docs.map((doc) => {
        // We explicitly strip out client name here just to be safe (QA users should never see clients' true names)
        return { ...(doc.data() as Client), name: '', id: doc.id };
      });

      setClients(clientsFromQuery);
    }
  };

  useEffect(() => {
    const unsubscribe = subscribeCollectionByField({
      collection: COLLECTION.CLIENTS,
      field: ClientField.QA_USER_IDS,
      operation: 'array-contains',
      fieldValue: QAUserId,
      callback: onSnapshotCallback,
    });

    return unsubscribe;
  }, [QAUserId]);

  return { clients };
};
