# TrackAdvocates by Warmly

## App Links

Warmly landing page: https://getwarmly.com/

Web app - production: https://dashboard.getwarmly.com/

Web app - staging: https://warmly-staging.firebaseapp.com/

Confluence Wiki - https://warmly.atlassian.net/wiki/home

[🔥Firebase DB](https://console.firebase.google.com/u/1/project/jobattrition/database/firestore/data~2Fcompanies~2FWarmly)

[📁Eng Google Drive](https://drive.google.com/drive/u/1/folders/1AtSvApthM7uygVmq83rvwu-tWmVh-Vgf)

[💻Eng Design](https://docs.google.com/document/d/11yj6BF74oSDGRrYwAf89fSQU30VtNjeulRmXKjzXRiU/edit)

[🎨UX Mocks](https://app.zeplin.io/project/5e62d5a11df0781127d42c3c/dashboard)

## One-time Initial Firebase Setup

Install firebase tools

```shell
$ npm install firebase-tools -g
```

Log into firebase. Should open up a browser window and have you verify account information

```shell
$ firebase login
```

**Select Firebase Project**

Before starting development, make sure you understand every setting within `.firebaserc` and `firebase.json`

*Important*: Do not run `firebase init` unless instructed by a team member, it will overwrite our custom `firebase.json`

There are two Firebase projects: `jobattrition` and `warmly-staging`
- `jobattrition` is the `default` project as per `.firebaserc`
- `warmly-staging` is the `staging` project as per `.firebaserc`

To being development, you should use `staging`

```shell
$ firebase use staging
```

If you need to make modifications to production (this should not happen except in emergencies), make sure you run
```shell
$ firebase use default
```

## Initialize Development Environment

Pre-requisite:

- Read the Git workflow / development guide in our wiki: https://warmly.atlassian.net/wiki/spaces/ENG/pages/80445444/Devops+Development
- Google Cloud SDK (`gcloud`) must be installed if not already (`brew cask install google-cloud-sdk`)
- If installing `gcloud` for the first time, follow the steps provided by `brew` to enable to `gcloud` command

**All steps must be executed from the root project folder**

Ensure that the initialization script is executable

```shell
$ chmod +x devops/init_dev_env.sh
```

**The initialization script should be run during initial setup as well as whenever `.env` (environment variables) files have changed**

Execute initialization script, which asks you to login to `gcloud` (if not already logged in). You should use your `@warmlycomma.com` account, same as one used for `firebase` console. Once logged in, it automatically downloads the appropriate `.env` files

```shell
$ devops/init_dev_env.sh
```
## Start Local Development 
Ensure you're on the `staging` Firebase project (unless you need to test production, in which case use `default` instead):
```shell
$ firebase use staging
```

### 🏁  Web Apps
To serve the TrackAdvocates dashboard locally:
```shell
$ cd web-dashboard
$ npm install # only if first time or dependencies changed
$ npm run start
```

### 🏁  Functions

To start firebase functions / backend server:

In general, while developing it is preferred to use `npm run dev` to automatically watch and recompile as you make changes.

```shell
$ npm run dev
```

Then

```shell
$ firebase emulators:start --only functions
```

Or:

```shell
$ firebase serve --only functions
```

If you get a timeout error, you might need to authenticate once with `sudo` (esp if you've messed with localhost on [/etc/hosts](https://stackoverflow.com/questions/48029583/firebase-functions-error-from-emulator-error-timeout-waiting-for-emulator-st)):

```shell
sudo firebase emulators:start --only functions
```

## Deploy to Staging

🚨 Deploying to staging from your local machine is **highly not recommended**. Unless it is absolutely necessary (e.g., to test an emergency fix that cannot wait), please follow the [deployment process guide](https://warmly.atlassian.net/wiki/spaces/ENG/pages/116195329/Deployment+Process) in Confluence. 🚨

**Note**: Our custom `firebase.json` has a pre-deploy script setup that automatically invoke the respective build commands in each app, so no need to manually build each app before deploying

First, **ensure** that the `.env` variables are correctly set. By default, the environment is set to `development`. Note that the `.env-staging` and `.env-production` files are *not* automatically used when deploying locally, even if you are deploying to staging or production (they are only used in the CI/CD process).

Ensure you're on the `staging` Firebase project:
```shell
$ firebase use staging
```

To deploy TrackAdvocates' web dashboard:
```shell
$ firebase deploy --only hosting
```

To deploy Cloud Functions:

**Note**: Certain functions are currently run only locally, but for sake of convenience we deploy them anyway.
```shell
$ firebase deploy --only functions
```

To deploy a specific function:

```shell
$ firebase deploy --only functions:FunctionName
```

## Deploy to Production

🚨🚨 Deploying to production from your local machine is **extremely, highly not recommended**. Unless it is absolutely necessary (e.g., to implement an emergency fix that cannot wait), please follow the [deployment process guide](https://warmly.atlassian.net/wiki/spaces/ENG/pages/116195329/Deployment+Process) in Confluence. 🚨🚨


First, **ensure** that the `.env` variables are correctly set, same as deploying to staging.

Ensure you're on the `default` (production) Firebase project:

```shell
$ firebase use default
```

Otherwise the deployment steps are the same as for staging

## Error Tracking and Analytics

We use a number of tools to track errors and analytics data:
- [Google Cloud services](https://console.cloud.google.com/)
  - Logging: view all logs
  - Cloud Trace: trace performance for Cloud Functions
  - Cloud Error Reporting: error reporting for Cloud Functions
  - Google Analytics: analytics data
- [Sentry.io](https://sentry.io/) - error reporting for frontend (web-dashboard)