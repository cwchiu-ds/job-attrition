import functions, { EventContext, Change } from 'firebase-functions';

import {
  getDocumentsByField,
  updateDocumentsUsingMerge,
  getDocumentById,
  getContactDataByContactDataId,
} from '../controllers/firestore';
import { sendToEngineeringErrorsSlack, sendToClientNotificationsSlack } from '../controllers/slack';
import { ClientContactField, COLLECTION } from '../utils/constants';
import { extractLinkedInIdFromUrl } from '../utils/functions';
import { QueryDocumentSnapshot, DocumentSnapshot } from 'firebase-functions/lib/providers/firestore';
import { appendCompanyURL } from '../modules/triggers';

const updateContactDataForClientContacts = async ({
  contactData,
  useLinkedInId,
}: {
  contactData: ContactData;
  useLinkedInId: boolean;
}): Promise<FirebaseFirestore.WriteResult[][] | void> => {
  const clientContacts = useLinkedInId
    ? await getDocumentsByField<ClientContact>({
        collection: COLLECTION.CLIENT_CONTACTS,
        field: ClientContactField.LINKEDIN_ID,
        operation: '==',
        fieldValue: contactData.linkedInId!,
      })
    : await getDocumentsByField<ClientContact>({
        collection: COLLECTION.CLIENT_CONTACTS,
        field: ClientContactField.CONTACT_DATA_ID,
        operation: '==',
        fieldValue: contactData.id,
      });

  if (clientContacts.length) {
    const updatedClientContacts = clientContacts.map((clientContact) => {
      if (useLinkedInId && clientContact.contactDataId && clientContact.contactDataId !== contactData.id) {
        sendToEngineeringErrorsSlack(
          `🚨 Client contact (id: ${clientContact.id}) was found to have an existing contact data (id: ${clientContact.contactDataId}) 
        that is different from a new contact data (id: ${contactData.id}) that has the same LinkedInId. The client contact data has been 
        updated to using the new contact data`
        );
      }

      return {
        id: clientContact.id,
        [ClientContactField.CONTACT_DATA]: contactData,
        [ClientContactField.CONTACT_DATA_ID]: contactData.id,
      };
    });
    return updateDocumentsUsingMerge<ClientContact>(COLLECTION.CLIENT_CONTACTS, updatedClientContacts);
  } else {
    return;
  }
};

const deleteContactDataFromClientData = async (
  contactDataId: string
): Promise<FirebaseFirestore.WriteResult[][] | void> => {
  const clientContacts = await getDocumentsByField<ClientContact>({
    collection: COLLECTION.CLIENT_CONTACTS,
    field: ClientContactField.CONTACT_DATA_ID,
    operation: '==',
    fieldValue: contactDataId,
  });

  if (clientContacts.length) {
    const updatedClientContacts = clientContacts.map((clientContact) => {
      return {
        id: clientContact.id,
        [ClientContactField.CONTACT_DATA]: null,
        [ClientContactField.CONTACT_DATA_ID]: null,
      };
    });

    return updateDocumentsUsingMerge<ClientContact>(COLLECTION.CLIENT_CONTACTS, updatedClientContacts);
  } else {
    return;
  }
};

/* 
  The primary purpose of this function is to ensure that each client contact always includes the latest
  version of contact data (i.e., denormalization). It also ensures that contact data always has a LinkedInId
*/
export const onWriteContactData = async (
  change: functions.Change<functions.firestore.DocumentSnapshot>
): Promise<void> => {
  // If contact data is being deleted, remove it from all client contacts that are tied to this contact data
  try {
    if (!change.after.exists) {
      await deleteContactDataFromClientData(change.before.id);
      return;
    }

    const contactDataId = change.after.id;

    const contactData = { ...change.after.data(), id: contactDataId } as ContactData;

    // If contact data does not have LinkedIn URL, that's not correct and we should be notified
    if (!contactData.linkedInURL) {
      await sendToEngineeringErrorsSlack(
        `🚨 Contact data id ${contactDataId} was created / updated without a LinkedIn URL!`
      );
      return;
    }

    if (!contactData.linkedInId) {
      const linkedInId = extractLinkedInIdFromUrl(contactData.linkedInURL);

      if (!linkedInId) {
        await sendToEngineeringErrorsSlack(
          `🚨 Unable to extract LinkedIn id for Contact Data id ${contactData.id} with URL of ${contactData.linkedInURL}`
        );
        return;
      } else {
        // Don't await for this - proceed to updating client contacts
        updateDocumentsUsingMerge<ContactData>(COLLECTION.CONTACT_DATA, [{ id: contactData.id, linkedInId }]);
        contactData.linkedInId = linkedInId;
      }
    }

    // If this is a new contact data, we use LinkedIn Id to update client contacts
    const useLinkedInId = !change.before.exists;

    await updateContactDataForClientContacts({ contactData, useLinkedInId });
  } catch (err) {
    console.error(new Error(err.toString()));
  } finally {
    return;
  }
};

/* 
  This function serves to notify us when a new user is created
  The notification is only sent in prod and only if the user is not internal
*/
export const onCreateUser = async (snapshot: QueryDocumentSnapshot): Promise<void> => {
  try {
    const newUser = snapshot.data() as UserData;

    if (!newUser.email.toLowerCase().includes('warmlycomma')) {
      const newUserClient = await getDocumentById<Client>(COLLECTION.CLIENTS, newUser.clientId);

      await sendToClientNotificationsSlack(
        `👼 New user alert: ${newUser.firstName} ${newUser.lastName} (${newUser.email}) of ${newUserClient?.name}`
      );
    }
  } catch (err) {
    console.error(new Error(err.toString()));
  } finally {
    return;
  }
};
// tutorial on trigger functions https://medium.com/@moki298/test-your-firebase-cloud-functions-locally-using-cloud-functions-shell-32c821f8a5ce
// to test locally run firebase functions:shell
export const onWriteClientData = async (change: Change<DocumentSnapshot>, context: EventContext): Promise<void> => {
  try {
    const clientContactId = context.params.clientContactId;
    const clientContact = { ...change.after.data(), id: clientContactId } as ClientContact;

    const contactDataId = clientContact.contactDataId;
    if (contactDataId) {
      const contactData = await getContactDataByContactDataId(contactDataId);
      if (contactData?.allJobs && contactData.currentJob) {
        const currentJob = contactData.currentJob;
        const allJobs = contactData.allJobs;

        // appending Company URL to each current job of contactData
        const currentJobPromises = currentJob.map(async (currentJob) => {
          return appendCompanyURL(currentJob);
        });
        const newCurrentJob = await Promise.all(currentJobPromises);

        // appending Company URL to each all job of contactData
        const allJobsPromises = allJobs.map(async (currentJob) => {
          return appendCompanyURL(currentJob);
        });
        const newAllJobs = await Promise.all(allJobsPromises);

        const updatedContactData: Partial<ContactData> = {
          currentJob: newCurrentJob,
          allJobs: newAllJobs,
        };

        await updateDocumentsUsingMerge<ContactData>(COLLECTION.CONTACT_DATA, [
          { ...updatedContactData, id: contactDataId },
        ]);
      }
    }
  } catch (err) {
    console.error(new Error(err.toString()));
  } finally {
    return;
  }
};
