import { Message } from 'firebase-functions/lib/providers/pubsub';

import {
  sendWebErrorToEngineeringErrorsSlack,
  sendToEngineeringErrorsSlack,
  sendCloudFunctionsErrorToEngineeringErrorsSlack,
} from '../controllers/slack';
import { WEB_SERVICE_NAME } from '../utils/constants';

interface BaseErrorReportingBody {
  insertId?: string;
  logName?: string;
  receiveTimestamp?: string;
  severity?: string;
  timestamp?: string;
}

export interface WebErrorReportingBody extends BaseErrorReportingBody {
  httpRequest?: {
    requestUrl?: string;
    userAgent?: string;
  };
  jsonPayload?: {
    '@type'?: string;
    context?: {
      httpRequest?: {
        url?: string;
        userAgent?: string;
      };
      user?: string;
    };
    message?: string;
    serviceContext?: {
      service?: string;
    };
  };
  resource?: {
    labels?: {
      project_id?: string;
    };
    type?: string;
  };
}

export interface CloudFunctionsErrorReportingBody extends BaseErrorReportingBody {
  labels?: {
    execution_id?: string;
  };
  resource?: {
    labels?: {
      function_name?: string;
      project_id?: string;
      region?: string;
    };
    type?: string;
  };
  textPayload?: string;
  trace?: string;
}

export const errorReportingToSlack = async (message: Message): Promise<void> => {
  try {
    const messageBody = message.data ? Buffer.from(message.data, 'base64').toString() : '';

    const jsonBody = JSON.parse(messageBody);

    const service = jsonBody?.jsonPayload?.serviceContext?.service;

    // Errors reported from the web-dashboard follows a specific structure
    if (service === WEB_SERVICE_NAME) {
      // If the service name is same as the the web-dashboard, then we assume it's an error
      // reported by the Stackdriver Error Reporting from the web-dashboard
      await sendWebErrorToEngineeringErrorsSlack(jsonBody as WebErrorReportingBody);
    } else {
      // Otherwise,  we assume it is a cloud functions error
      await sendCloudFunctionsErrorToEngineeringErrorsSlack(jsonBody);
    }
  } catch (err) {
    sendToEngineeringErrorsSlack('Error while forwarding Error Reports to Slack', (err as Error).toString()).catch();
  } finally {
    return;
  }
};
