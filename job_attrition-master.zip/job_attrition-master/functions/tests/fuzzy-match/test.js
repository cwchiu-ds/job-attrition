// import fuse from 'fuse';
const Fuse = require('fuse.js');

const fuseTitleOptions = {
  includeScore: true,
  keys: ['title'],
};
const fuseCompanyOptions = {
  includeScore: true,
  keys: ['companyName'],
};

// todo pull in testing library like mocha
function runTests() {
  runMatchTest({
    crmCompany: 'facebook',
    crmTitle: 'product manager',
    proxyCrawlCompany: 'facebook',
    proxyCrawlTitle: 'product manager',
  });
  runMatchTest({
    crmCompany: 'facebook',
    crmTitle: 'PM',
    proxyCrawlCompany: 'facebook',
    proxyCrawlTitle: 'product manager',
  });
  runMatchTest({
    crmCompany: 'cisco.com',
    crmTitle: 'product manager',
    proxyCrawlCompany: 'cisco',
    proxyCrawlTitle: 'product man',
  });
  runMatchTest({
    crmCompany: 'cisco',
    crmTitle: 'svp engineering',
    proxyCrawlCompany: 'cisco.com',
    proxyCrawlTitle: 'senior vp eng',
  });
  runMatchTest({
    crmCompany: 'cisco',
    crmTitle: 'svp engineering',
    proxyCrawlCompany: 'cisco.com',
    proxyCrawlTitle: 'senior vp of engineering',
  });
  runMatchTest({
    crmCompany: 'kindred.ai',
    crmTitle: 'vp people',
    proxyCrawlCompany: 'Kindred.ai',
    proxyCrawlTitle: 'VP, Operations',
  });
  runMatchTest({
    crmCompany: 'lyft',
    crmTitle: 'head of self driving',
    proxyCrawlCompany: 'iconiq capital',
    proxyCrawlTitle: 'technical advisory board',
  });
}
function runMatchTest({
  crmTitle,
  crmCompany,
  proxyCrawlTitle,
  proxyCrawlCompany,
}) {
  runFuseMatchTest({
    crmTitle,
    crmCompany,
    proxyCrawlTitle,
    proxyCrawlCompany,
  });
}

function runFuseMatchTest({
  crmTitle,
  crmCompany,
  proxyCrawlTitle,
  proxyCrawlCompany,
}) {
  const currentJobs = createCurrentJobs(proxyCrawlCompany, proxyCrawlTitle);
  const fuseTitle = new Fuse(currentJobs, fuseTitleOptions);
  const fuseCompany = new Fuse(currentJobs, fuseCompanyOptions);
  const titleResult = fuseTitle.search(crmTitle);
  const companyResult = fuseCompany.search(crmCompany);
  // 0 is perfect match, 1 is complete mis match
  let titleScore = 0;
  if (titleResult[0]) {
    titleScore = 100 - Math.round(titleResult[0].score * 100);
  }
  let companyScore = 0;
  if (companyResult[0]) {
    companyScore = 100 - Math.round(companyResult[0].score * 100);
  }
  const combinedScore = (titleScore + 2 * companyScore) / 3;
  console.log('\n');
  console.log(
    `${crmCompany}, ${crmTitle} -> ${proxyCrawlCompany}, ${proxyCrawlTitle} `
  );
  console.log(`${titleScore} % title score`);
  console.log(`${companyScore} % company score`);
  console.log(`${combinedScore} % combined score`);
  // final output, weight the company name 2x as much as the title
}

function createCurrentJobs(companyName, title) {
  return [{ companyName, title }];
}
runTests();
