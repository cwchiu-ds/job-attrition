import path from 'path';

/* eslint-disable import/first */
// We need to allow dotenv to config first before all other imports are resolved
import dotenv from 'dotenv';

dotenv.config({
  path: path.resolve(__dirname, '.env'),
});

import cloudTrace from './config/cloudTrace';
// The Cloud Functions for Firebase SDK to create Cloud Functions and setup triggers.
import * as functions from 'firebase-functions';

import { proxyCrawlLinkedIn } from './api/webhooks/proxyCrawlLinkedIn';
import { hubSpotIntegration as hubSpotIntegrationApi } from './api/hubspot/auth';
import { parseClientCsv as parseClientCsvApi } from './api/parseClientCsv';
import { userApi } from './api/user';
import { salesforceIntegrationApi } from './api/salesforce';
import { clientApi } from './api/client';
import { mTurkApi } from './api/mTurk';
import { adminApi } from './api/admin';
import { jobChangeApi } from './api/jobChange';
import { hubspotApi } from './api/hubspot';
import { clientContactApi } from './api/clientContact';
import { errorReportingToSlack } from './triggers/logging';
import { emailReportsApi } from './api/emailReports';
import { emailPingApi } from './api/emailPing';
import { theCheckerWebhook } from './api/webhooks/theChecker';
import {
  onWriteContactData as onWriteContactDataTrigger,
  onCreateUser as onCreateUserTrigger,
} from './triggers/firestore';

if (cloudTrace) {
  console.log('🗺   Cloud tracing initiated');
}
// set a longer timeout because takes a while for proxyCrawl to send through larger batches of contacts
const runtimeOpts: functions.RuntimeOptions = {
  timeoutSeconds: 540,
  memory: '1GB',
};

// set a longer timeout because takes a while for proxyCrawl to send through larger batches of contacts
const increasedMemoryOpt: functions.RuntimeOptions = {
  memory: '1GB',
};

export const jobChange = functions.runWith(runtimeOpts).https.onRequest(jobChangeApi);

export const hubspot = functions.https.onRequest(hubspotApi);

export const hubSpotIntegration = functions.runWith(runtimeOpts).https.onRequest(hubSpotIntegrationApi);

export const sendClientReport = functions.runWith(increasedMemoryOpt).https.onRequest(emailReportsApi);

export const user = functions.https.onRequest(userApi);

export const sf = functions.runWith(increasedMemoryOpt).https.onRequest(salesforceIntegrationApi);

export const clientContact = functions.https.onRequest(clientContactApi);

export const client = functions.https.onRequest(clientApi);

export const admin = functions.runWith(runtimeOpts).https.onRequest(adminApi);

export const emailPing = functions.runWith(runtimeOpts).https.onRequest(emailPingApi);

// The Checker email pinging webhook
export const theChecker = functions.https.onRequest(theCheckerWebhook);

// Mechanical turk
export const taskManagement = functions.runWith(runtimeOpts).https.onRequest(mTurkApi);

// proxyCrawl Webhook
export const proxyCrawl = functions.https.onRequest(proxyCrawlLinkedIn);

// Get uploaded csv's and create new client contacts from the csv data
export const parseClientCsv = functions.runWith(runtimeOpts).https.onRequest(parseClientCsvApi);

// Pub/sub triggers
export const googleCloudLoggingErrors = functions.pubsub.topic('error_reporting').onPublish(errorReportingToSlack);

// Firestore triggers
export const onWriteContactData = functions.firestore
  .document('contact_data/{contactDataId}')
  .onWrite(onWriteContactDataTrigger);
export const onCreateUser = functions.firestore.document('users/{userId}').onCreate(onCreateUserTrigger);
