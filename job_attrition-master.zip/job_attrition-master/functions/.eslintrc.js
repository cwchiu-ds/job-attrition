module.exports = {
  parserOptions: {
    ecmaVersion: 2017,
  },
  env: {
    node: true,
  },
  overrides: [
    {
      files: ['**/*.ts'],
      extends: ['plugin:@typescript-eslint/recommended'],
      parser: '@typescript-eslint/parser',
      plugins: ['@typescript-eslint', 'import'],
      rules: {
        '@typescript-eslint/no-non-null-assertion': 'off',
        '@typescript-eslint/ban-ts-ignore': 'off',
        '@typescript-eslint/no-unused-vars': ['warn', { varsIgnorePattern: '^_' }],
        'import/first': 'error',
        'import/newline-after-import': 'error',
        'import/no-duplicates': 'error',
        '@typescript-eslint/camelcase': 'warn',
      },
    },
    {
      files: ['**/*.js'],
      extends: ['eslint:recommended'],
      rules: {
        'import/order': ['error', { 'newlines-between': 'always' }],
        'no-unused-vars': ['warn', { varsIgnorePattern: '^_' }],
      },
    },
  ],
};
