import { getDocumentsByField, updateDocumentsUsingMerge } from '../controllers/firestore';
import { COLLECTION, CompaniesField } from '../utils/constants';

const appendCompanyNamesToCompany = async (company: Company, currentJob: CurrentJob): Promise<void> => {
  const companyNames = company.companyNames;

  if (companyNames) {
    if (currentJob.companyName && !companyNames.includes(currentJob.companyName)) {
      companyNames.push(currentJob.companyName);
      await updateDocumentsUsingMerge<Company>(COLLECTION.COMPANIES, [{ companyNames, id: company.id }]);
    }
  } else {
    if (currentJob.companyName) {
      await updateDocumentsUsingMerge<Company>(COLLECTION.COMPANIES, [
        { companyNames: [currentJob.companyName], id: company.id },
      ]);
    }
  }
};

export const appendCompanyURL = async (currentJob: CurrentJob): Promise<CurrentJob> => {
  if (currentJob.companyId) {
    const company = (
      await getDocumentsByField<Company>({
        collection: COLLECTION.COMPANIES,
        field: CompaniesField.COMPANY_LINKEDIN_ID,
        operation: '==',
        fieldValue: currentJob.companyId,
      })
    )[0] as Company;

    if (company) {
      if (company && company.companyURL && company.companyURLDomain) {
        currentJob[CompaniesField.COMPANY_URL] = company.companyURL;
        currentJob[CompaniesField.COMPANY_URL_DOMAIN] = company.companyURLDomain;
      }
      await appendCompanyNamesToCompany(company, currentJob);
    }
  } else if (currentJob.companyName) {
    const company = (
      await getDocumentsByField<Company>({
        collection: COLLECTION.COMPANIES,
        field: CompaniesField.COMPANY_NAMES,
        operation: 'array-contains',
        fieldValue: currentJob.companyName,
      })
    )[0] as Company;

    if (company) {
      if (company && company.companyURL && company.companyURLDomain) {
        currentJob[CompaniesField.COMPANY_URL] = company.companyURL;
        currentJob[CompaniesField.COMPANY_URL_DOMAIN] = company.companyURLDomain;
      }
      await appendCompanyNamesToCompany(company, currentJob);
    }
  }
  return currentJob;
};
