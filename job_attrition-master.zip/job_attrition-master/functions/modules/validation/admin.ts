import { Joi, validate } from 'express-validation';

import { UserField, UserType } from '../../utils/constants';

export interface CreateNewUser {
  [UserField.EMAIL]: string;
  [UserField.FIRST_NAME]: string;
  [UserField.LAST_NAME]: string;
  [UserField.USER_TYPE]: UserType;
  [UserField.PHONE_NUMBER]?: string;
  [UserField.CLIENT_ID]?: string;
  companyName: string;
  password: string;
}

const createNewUser = {
  body: Joi.object<CreateNewUser>({
    [UserField.EMAIL]: Joi.string().required(),
    [UserField.FIRST_NAME]: Joi.string().required(),
    [UserField.LAST_NAME]: Joi.string().required(),
    [UserField.USER_TYPE]: Joi.string().valid(...Object.values(UserType)).required(),
    [UserField.PHONE_NUMBER]: Joi.string().allow('').optional(),
    [UserField.CLIENT_ID]: Joi.string().allow('').optional(),
    companyName: Joi.string().when(UserField.CLIENT_ID, {
      not: Joi.string(),
      then: Joi.required(),
      otherwise: Joi.optional(),
    }),
    password: Joi.string().required(),
  }),
};

export const adminValidationMiddleware = {
  createNewUser: validate(createNewUser, {}, {}),
};
