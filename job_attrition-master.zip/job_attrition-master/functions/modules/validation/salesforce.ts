import { Joi, validate } from 'express-validation';

import { ClientContactAttribute } from '../../utils/constants';

export interface SalesforceSetupFields {
  salesforceMapping: SalesforceMapping;
}

const setupFields = {
  body: Joi.object<SalesforceSetupFields>({
    salesforceMapping: Joi.object({
      [ClientContactAttribute.FIRST_NAME]: Joi.string().required(),
      [ClientContactAttribute.LAST_NAME]: Joi.string().required(),
      [ClientContactAttribute.EMAIL]: Joi.string().required(),
      [ClientContactAttribute.CURRENT_TITLE]: Joi.string(),
      [ClientContactAttribute.LINKEDIN_URL]: Joi.string(),
    }),
  }),
};

export interface SalesforceEnrichContacts {
  clientContactIds: string[];
}

const enrichContacts = {
  body: Joi.object<SalesforceEnrichContacts>({
    clientContactIds: Joi.array().items(Joi.string()),
  }),
};

export const salesforceValidationMiddleware = {
  setupFields: validate(setupFields, { keyByField: true }, {}),
  enrichContacts: validate(enrichContacts, { keyByField: true }, {}),
};
