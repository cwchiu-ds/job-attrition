import { firestore } from 'firebase-admin';
import { getDocumentsByField } from '../controllers/firestore';
import { ClientContactField, COLLECTION } from '../utils/constants';
import { createHit } from '../controllers/mTurk';
import { getClientContactName } from '../utils/functions';
import { CreateHITRequest } from 'aws-sdk/clients/mturk';
import Bottleneck from 'bottleneck';

const limiter = new Bottleneck({
  minTime: 1000,
  maxConcurrent: 2,
});

export const createHits = async (clientId: string): Promise<void> => {
  try {
    // Generate job changes for up to 10 client contacts
    const clientContacts = await getDocumentsByField<ClientContact>({
      collection: COLLECTION.CLIENT_CONTACTS,
      field: ClientContactField.CLIENT_ID,
      operation: '==',
      fieldValue: clientId,
    });

    clientContacts.map(async (clientContact) => {
      return limiter.schedule(async () => {
        const name = getClientContactName(clientContact);
        const title = clientContact.currentJob?.title;
        const company = clientContact.currentJob?.companyName;
        const email = clientContact.email;

        const hitInputObject = {
          Title: 'Detect Job Change LinkedIn',
          Description: 'Another description',
          MaxAssignments: 2,
          LifetimeInSeconds: 432000,
          AssignmentDurationInSeconds: 1000,
          Reward: '0.01',
          // Question: myQuestion,
          HITLayoutId: '3J08K2YXGCG90QUS1EK7CYY44AIGGH',
          HITLayoutParameters: [
            { Name: 'name', Value: name },
            { Name: 'title', Value: title },
            { Name: 'company', Value: company },
            { Name: 'email', Value: email },
          ],
          Keywords: 'Linkedin, LinkedIn URL, data entry, website',
          // Add a qualification requirement that the Worker must be either in Canada or the US
          QualificationRequirements: [
            {
              QualificationTypeId: '00000000000000000071',
              Comparator: 'In',
              LocaleValues: [{ Country: 'US' }, { Country: 'CA' }],
            },
          ],
        } as CreateHITRequest;

        await createHit(hitInputObject);
      });
    });
  } catch (err) {
    console.error(err);
  }
};
