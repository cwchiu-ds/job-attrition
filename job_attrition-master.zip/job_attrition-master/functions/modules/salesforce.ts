import { Record } from 'jsforce';
import { get } from 'lodash';

import {
  updateDocumentsUsingMerge,
  addOrUpdateClientContactsFromSalesforce,
  getDocumentById,
} from '../controllers/firestore';
import { getSfConnection, UpdateSalesforceObjectData, updateSalesforceObjects } from '../controllers/salesforce';
import { sendToEngineeringErrorsSlack } from '../controllers/slack';
import {
  ClientContactAttribute,
  ClientContactAttributeField,
  ClientContactField,
  COLLECTION,
  IntegrationType,
  SalesforceObject,
  SyncStatus,
  UserType,
  SalesforceCustomFieldName,
} from '../utils/constants';
import { getCurrentTimestamp } from '../utils/functions';
import { sendNewSalesforceIntegrationUploadAlert } from './slack';

const SALESFORCE_COMPANY_NAME_FIELD = 'Account.Name';
const SALESFORCE_CONTACT_ID_FIELD = 'Id';

// Currently, we limit the number of records fetched at 100k. If a Client
// has more than 100k contacts we ask them to contact us first and we
// may need to adjust some settings to make this work better
const SALESFORCE_MAX_FETCH = 100000;

const getConformedClientContacts = (
  records: Record[],
  clientId: string,
  salesforceMapping: SalesforceMapping
): NewClientContact[] => {
  const conformedClientContacts = records.map((record) => {
    const salesforceId = get(record, SALESFORCE_CONTACT_ID_FIELD);
    // We use lodash get here because the saleforce field is nested in dot notation
    const companyName = get(record, SALESFORCE_COMPANY_NAME_FIELD) || null;

    const clientContact = {
      [ClientContactField.SALESFORCE_ID]: salesforceId,
      [ClientContactField.CLIENT_ID]: clientId,
      [ClientContactField.CURRENT_JOB]: { companyName },
    } as NewClientContact;

    for (const attribute in salesforceMapping) {
      const salesforceField = salesforceMapping[attribute as keyof SalesforceMapping];
      if (salesforceField) {
        const trackAdvocatesField = ClientContactAttributeField[attribute as ClientContactAttribute];

        // NOTE At the moment we do not let Clients choose the field that we get companyName from, since we
        // assume that for all Salesforce Contacts we would use their AccountName as the companyName
        // However, we do let them choose the field for job title
        if (attribute === ClientContactAttribute.CURRENT_TITLE) {
          clientContact.currentJob!.title = record[salesforceField];
        } else {
          clientContact[trackAdvocatesField] = record[salesforceField];
        }
      }
    }

    return clientContact;
  });

  return conformedClientContacts;
};

// This function retrieves Salesforce tokens as well as contact counts and all Contact fields from salesforce
export const getSalesforceTokens = async (user: UserData, code: string): Promise<void> => {
  const sfConnection = getSfConnection();
  await sfConnection.authorize(code);

  const { accessToken, refreshToken, instanceUrl } = sfConnection;

  const queryContactCount = `SELECT COUNT() from ${SalesforceObject.CONTACT}`;

  const contactCountQueryResult = await sfConnection.query(queryContactCount);
  const contactCount = contactCountQueryResult.totalSize;

  const describeContactResult = await sfConnection.sobject(SalesforceObject.CONTACT).describe();
  const fields = describeContactResult.fields;

  const salesforceIntegration = { accessToken, refreshToken, instanceUrl, contactCount, fields };

  // Get a total count of contacts and store it in Client data
  return updateDocumentsUsingMerge<Client>(COLLECTION.CLIENTS, [
    { id: user.clientId, salesforceIntegration, integrationType: IntegrationType.SALESFORCE },
  ]);
};

export const syncSalesforceContacts = async (client: Client, user: UserData): Promise<void> => {
  try {
    const sfConnection = getSfConnection(client);

    const salesforceMapping = client.salesforceIntegration!.salesforceMapping!;

    const salesforceFieldsToBeSynced = Object.values(salesforceMapping).filter((field) => field);

    // First we retrieve again the number of contacts so we have the most up to date information
    const queryContactCount = `SELECT COUNT() from ${SalesforceObject.CONTACT}`;

    const contactCountQueryResult = await sfConnection.query(queryContactCount);
    const contactCount = contactCountQueryResult.totalSize;

    await updateDocumentsUsingMerge<Client>(COLLECTION.CLIENTS, [
      { id: client.id, salesforceIntegration: { syncStatus: SyncStatus.SYNCING, contactCount } },
    ]);

    const queryContacts = `SELECT ${SALESFORCE_CONTACT_ID_FIELD}, ${SALESFORCE_COMPANY_NAME_FIELD}, ${salesforceFieldsToBeSynced.join(
      ' , '
    )} from Contact`;

    const queryResult = await sfConnection
      .query(queryContacts)
      .run({ autoFetch: true, maxFetch: SALESFORCE_MAX_FETCH });

    const queryResultRecords = queryResult.records;

    const newClientContacts = getConformedClientContacts(queryResultRecords, client.id, salesforceMapping);

    await addOrUpdateClientContactsFromSalesforce({
      newClientContacts,
      clientId: client.id,
      clientName: client.name,
      userId: user.id,
    });

    await updateDocumentsUsingMerge<Client>(COLLECTION.CLIENTS, [
      {
        id: client.id,
        salesforceIntegration: {
          syncStatus: SyncStatus.COMPLETE,
          lastSyncDate: getCurrentTimestamp(),
          lastSyncUpdatedCount: queryResultRecords.length,
        },
      },
    ]);

    await sendNewSalesforceIntegrationUploadAlert(client.name, queryResult.records.length);
  } catch (err) {
    await updateDocumentsUsingMerge<Client>(COLLECTION.CLIENTS, [
      {
        id: client.id,
        salesforceIntegration: { syncStatus: SyncStatus.ERROR },
      },
    ]);
    const slackMessage = `⛔️ Error occurred while getting/uploading Salesforce contacts for client ${client.name} / clientId ${client.id}`;
    await sendToEngineeringErrorsSlack(slackMessage, (err as Error).toString());
    throw err;
  }
};

export const enrichSalesforceContacts = async (
  clientContactIds: string[],
  authUser: UserData,
  client: Client
): Promise<void> => {
  const clientContacts: ClientContact[] = [];
  const updatedClientContacts: WithId<Partial<ClientContact>>[] = [];
  let numOfSalesforceContactsEnriched = client.salesforceContactsEnriched || 0;
  let numOfSalesforceJobChangesApproved = client.salesforceJobChangesApproved || 0;

  // First we retrieve all the client contacts that we are trying to sync back
  // We check to ensure that it is a client contact that can be synced back to Salesforce
  await Promise.all(
    clientContactIds.map((clientContactId) => {
      return getDocumentById<ClientContact>(COLLECTION.CLIENT_CONTACTS, clientContactId).then((clientContact) => {
        if (clientContact?.clientId !== client.id && authUser.userType !== UserType.INTERNAL) {
          throw new Error(
            `Permission denied for syncing back contacts for client ${client.name}. ${authUser.email} is not allowed to perform this action`
          );
        } else if (!clientContact?.salesforceId) {
          throw new Error(
            `Error syncing back contacts. Client contact (id: ${clientContact?.id}) does not have a Salesforce Id`
          );
        }

        if (clientContact) {
          clientContacts.push(clientContact);
        }

        return;
      });
    })
  );

  // Get the updated contact data to be synced back into Salesforce
  const updatedSalesforceContacts: UpdateSalesforceObjectData[] = clientContacts.map((clientContact) => {
    const updatedSalesforceContactObject: UpdateSalesforceObjectData = {
      Id: clientContact.salesforceId!,
    };

    // We only count a contact as enriched if the data we synced back is different from what
    // the client already had
    let contactEnriched = false;

    const updatedClientContact: WithId<Partial<ClientContact>> = {
      id: clientContact.id,
      lastSalesforceEnrichmentDate: getCurrentTimestamp(),
    };

    if (clientContact.jobChanged) {
      updatedSalesforceContactObject[SalesforceCustomFieldName.JOB_CHANGED] = true;
      contactEnriched = true;
      numOfSalesforceJobChangesApproved++;
      // Once we finish sync back the data, we update jobChanged to be false so the client won't be notified again
      updatedClientContact.jobChanged = false;
    }

    const latestJob = clientContact.contactData?.currentJob[0];

    if (latestJob?.companyName) {
      updatedSalesforceContactObject[SalesforceCustomFieldName.LATEST_JOB_COMPANY] = latestJob.companyName;

      if (latestJob.companyName !== clientContact.lastSalesforceEnrichedCompanyName) {
        contactEnriched = true;
        updatedClientContact.lastSalesforceEnrichedCompanyName = latestJob.companyName;
      }
    }

    if (latestJob?.title) {
      updatedSalesforceContactObject[SalesforceCustomFieldName.LATEST_JOB_TITLE] = latestJob.title;

      if (latestJob.title !== clientContact.lastSalesforceEnrichedTitle) {
        contactEnriched = true;
        updatedClientContact.lastSalesforceEnrichedTitle = latestJob.title;
      }
    }

    if (clientContact?.linkedInURL) {
      updatedSalesforceContactObject[SalesforceCustomFieldName.LATEST_LINKEDIN] = clientContact.linkedInURL;

      if (clientContact.linkedInURL !== clientContact.lastSalesforceEnrichedLinkedInURL) {
        contactEnriched = true;
        updatedClientContact.lastSalesforceEnrichedLinkedInURL = clientContact.linkedInURL;
      }
    }

    if (contactEnriched) {
      numOfSalesforceContactsEnriched++;
    }

    updatedClientContacts.push(updatedClientContact);

    return updatedSalesforceContactObject;
  });

  await updateSalesforceObjects(client, SalesforceObject.CONTACT, updatedSalesforceContacts)
    .then((res) => {
      for (const updateResult of res) {
        if (!updateResult.success) {
          throw updateResult;
        }
      }
    })
    .catch((err) => {
      throw err;
    });

  await updateDocumentsUsingMerge(COLLECTION.CLIENT_CONTACTS, updatedClientContacts);

  // If we have enriched data for the client, we add that to our tally to keep track
  if (
    client.salesforceContactsEnriched !== numOfSalesforceContactsEnriched ||
    client.salesforceJobChangesApproved !== numOfSalesforceJobChangesApproved
  ) {
    await updateDocumentsUsingMerge(COLLECTION.CLIENTS, [
      {
        id: client.id,
        salesforceContactsEnriched: numOfSalesforceContactsEnriched,
        salesforceJobChangesApproved: numOfSalesforceJobChangesApproved,
      },
    ]);
  }

  return;
};
