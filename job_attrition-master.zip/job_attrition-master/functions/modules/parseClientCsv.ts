import Papa from 'papaparse';
import { Readable } from 'stream';

import { getFileAsReadable } from '../controllers/cloudStorage';
import { updateDocumentsUsingMerge, addOrUpdateClientContactsFromCSV } from '../controllers/firestore';
import {
  ClientContactAttribute,
  ClientContactAttributeField,
  ClientContactField,
  COLLECTION,
  SyncStatus,
} from '../utils/constants';
import { sendNewCSVUploadAlert } from './slack';
import { getCurrentTimestamp } from '../utils/functions';

// Adopted from https://github.com/mholt/PapaParse/issues/752
const papaParsePromise = (readable: Readable, config?: Papa.ParseConfig): Promise<Papa.ParseResult> =>
  new Promise((resolve, reject) => {
    Papa.parse(readable, {
      ...config,
      complete: function (results) {
        resolve(results);
      },
      error: function (error) {
        reject(error);
      },
    });
  });

export const conformCsvData = (
  csvContactDataArray: CsvContactData[],
  mappedAttributes: MappedAttributes
): NewClientContact[] => {
  const allContactDataConformed: NewClientContact[] = [];
  const existingEmails: { [email: string]: boolean } = {};

  for (const contactData of csvContactDataArray) {
    const clientContactConformed = {} as NewClientContact;
    const crmData: ClientContact['crmData'] = {};

    for (const header in contactData) {
      const csvData = contactData[header].trim();
      const attributeName = mappedAttributes[header];
      const attributeField = ClientContactAttributeField[attributeName];

      if (attributeName === ClientContactAttribute.OTHER) {
        // If the attribute is not one of the existing attributes in our database,
        // we include its data inside the crmData "catch-all" attribute
        crmData[header] = csvData;
      } else if (attributeName === ClientContactAttribute.CURRENT_COMPANY) {
        let tempCurrentJob = clientContactConformed[ClientContactField.CURRENT_JOB] || {};
        tempCurrentJob = { ...tempCurrentJob, companyName: csvData };
        clientContactConformed[attributeField as ClientContactField.CURRENT_JOB] = tempCurrentJob;
      } else if (attributeName === ClientContactAttribute.CURRENT_TITLE) {
        let tempCurrentJob = clientContactConformed[ClientContactField.CURRENT_JOB] || {};
        tempCurrentJob = { ...tempCurrentJob, title: csvData };
        clientContactConformed[attributeField as ClientContactField.CURRENT_JOB] = tempCurrentJob;
      } else {
        const attributeField = ClientContactField[attributeName];
        clientContactConformed[attributeField] = csvData;
      }
    }

    clientContactConformed[ClientContactField.CRM_DATA] = crmData;

    const email = clientContactConformed[ClientContactField.EMAIL];

    if (email && existingEmails[email]) {
      // We deduplicate contacts that have the same emails (in this case, we only keep the first contact that has that email)
    } else {
      if (email) {
        existingEmails[email] = true;
      }

      allContactDataConformed.push(clientContactConformed);
    }
  }

  return allContactDataConformed;
};

export const parseCsvFileAndAddClientContacts = async (
  filePath: string,
  mappedAttributes: MappedAttributes,
  userId: string,
  client: Client
): Promise<void> => {
  const readable = getFileAsReadable(filePath);
  const config = {};

  const clientId = client.id;

  if (readable && clientId && client?.name) {
    const parseResult = await papaParsePromise(readable, config);
    const csvHeaders: string[] = parseResult.data[0].map((header: string) => header.trim());
    const parseResultExcludingHeaders = parseResult.data.slice(1);

    const contactDataFromCsv: CsvContactData[] = [];
    for (const contact of parseResultExcludingHeaders) {
      // Maps each row from CSV into an object with headers as keys
      // and CSV data as values
      const contactData = contact.reduce((acc: CsvContactData, value: string, i: number) => {
        const headerName = csvHeaders[i];
        acc[headerName] = value;
        return acc;
      }, {});
      contactDataFromCsv.push(contactData);
    }

    const newClientContacts = conformCsvData(contactDataFromCsv, mappedAttributes);

    try {
      await updateDocumentsUsingMerge<Client>(COLLECTION.CLIENTS, [
        { id: clientId, csvUpload: { syncStatus: SyncStatus.SYNCING } },
      ]);

      await addOrUpdateClientContactsFromCSV({ newClientContacts, clientId, userId, clientName: client.name });

      await updateDocumentsUsingMerge<Client>(COLLECTION.CLIENTS, [
        {
          id: clientId,
          mappedAttributes,
          csvUpload: {
            syncStatus: SyncStatus.COMPLETE,
            lastSyncDate: getCurrentTimestamp(),
            lastSyncUpdatedCount: newClientContacts.length,
          },
        },
      ]);

      await sendNewCSVUploadAlert(client.name, newClientContacts.length);
    } catch (err) {
      await updateDocumentsUsingMerge<Client>(COLLECTION.CLIENTS, [
        {
          id: clientId,
          csvUpload: {
            syncStatus: SyncStatus.ERROR,
            lastSyncDate: getCurrentTimestamp(),
          },
        },
      ]);

      throw err;
    }

    return;
  } else {
    throw new Error(`Error while parsing CSV for client ${client?.name} (clientId: ${clientId})`);
  }
};
