import { sendToClientNotificationsSlack } from '../controllers/slack';

export const sendNewUserSlackAlert = (
  firstName: string,
  lastName: string,
  clientName: string,
  email: string
): Promise<void> => {
  const message = `🆕 New User Alert: ${firstName} ${lastName} at ${clientName} has signed up (📧: ${email})`;

  return sendToClientNotificationsSlack(message);
};

export const sendNewCSVUploadAlert = (clientName: string, numberContacts?: number): Promise<void> => {
  let message = `📄 New CSV Alert: Client ${clientName} has uploaded a \`.csv\` file)`;

  if (typeof numberContacts === 'number') {
    message = message + ` with ${numberContacts} contacts`;
  }

  return sendToClientNotificationsSlack(message);
};

export const sendNewHubspotIntegrationUploadAlert = (clientName: string, numberContacts?: number): Promise<void> => {
  let message = `📄 New Hubspot Integration Alert: Client ${clientName} has successfully integrated`;

  if (typeof numberContacts === 'number') {
    message = message + ` with ${numberContacts.toLocaleString()} contacts`;
  }

  return sendToClientNotificationsSlack(message);
};

export const sendNewSalesforceIntegrationUploadAlert = (clientName: string, numberContacts: number): Promise<void> => {
  let message = `📄 New Salesforce Integration Alert: Client ${clientName} has successfully integrated`;

  if (typeof numberContacts === 'number') {
    message = message + ` with ${numberContacts.toLocaleString()} contacts`;
  }

  return sendToClientNotificationsSlack(message);
};

export const sendJobChangeNotificationEmailsChangedAlert = (
  clientName: string,
  originalEmails: string[],
  updatedEmails: string[]
): Promise<void> => {
  const message = `🚨📬 ${clientName} updated their job change notification email preference: \n
    previous emails: ${originalEmails.join(', ')} \n
    updated emails: ${updatedEmails.join(', ')}
    `;

  return sendToClientNotificationsSlack(message);
};
