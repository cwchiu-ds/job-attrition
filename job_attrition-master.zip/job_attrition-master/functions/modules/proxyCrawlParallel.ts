import https from 'https';
import Axios from 'axios';
import { db, getClientDataContactsByContactDataId, updateClientContactById } from '../controllers/firestore';
import { scraperControlPanel } from '../config/scraperControlPanel';
import { getCurrentTimestamp } from '../utils/functions';
import { JobChangeStatus } from '../utils/constants';

const keepAliveAgent = new https.Agent({ keepAlive: true });

const linkedInToken = process.env.PROXYCRAWL_NORMAL_TOKEN;

const contactsDataCollection = db.collection('contact_data');

const count = 0;

export const changeJobChangedFlagTrueFromContactData = async (
  contactId: string,
  jobChangedStatus: string
): Promise<void> => {
  const clientContacts = await getClientDataContactsByContactDataId(contactId);
  clientContacts.map(async (clientContact) => {
    if (clientContact.id) {
      await updateClientContactById(clientContact.id, {
        jobChanged: true,
        verified: false,
        jobChangedStatus,
        dateUpdated: getCurrentTimestamp(),
      });
      console.log('🟢🚶‍♂️ JobChanged Marked True', contactId);
    }
  });

  return;
};

export const proxyCrawlLinkedIn = async (url: string, ID: string, tryCount = 0): Promise<void> => {
  try {
    const response = await Axios({
      method: 'GET',
      url:
        `https://api.proxycrawl.com/?token=${linkedInToken}&callback=true&crawler=${scraperControlPanel.proxyCrawlerName}&scraper=linkedin-profile&url=` +
        url,
      // responseType: 'stream',
      httpsAgent: keepAliveAgent,
    });

    const { rid } = response.data;

    const contactRef = contactsDataCollection.doc(ID);
    await contactRef.set(
      {
        rid,
        proxyCrawlCompletedFlag: false,
        lastUpdatedProxyCrawl: getCurrentTimestamp(),
      },
      { merge: true }
    );
    console.log('🥳 Successfully saved RID ', rid, ' for proxyCrawl LinkedIn Scraper request==>>', ID, count);
  } catch (err) {
    console.log('🛑 an error occuredd==>>>', ID, err);
  }
};

export const jobChangeStatusMap = (currentJob: CurrentJob, previousJob: CurrentJob): string => {
  if (currentJob.companyName !== previousJob.companyName) {
    return JobChangeStatus.JOB_CHANGED;
  }
  if (currentJob.title !== previousJob.title) {
    return JobChangeStatus.JOB_CHANGED_SAME_COMPANY;
  }
  return JobChangeStatus.NO_JOB_CHANGE;
};
