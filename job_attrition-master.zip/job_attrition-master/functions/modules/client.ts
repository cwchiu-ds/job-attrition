import faker from 'faker';
import { isEqual } from 'lodash';

import {
  deleteDocumentsFromCollection,
  getDocumentById,
  getDocumentsByField,
  updateDocumentsUsingMerge,
} from '../controllers/firestore';
import { sendJobChangeNotificationEmailsChangedAlert } from '../modules/slack';
import { getRandomAnimal } from '../utils/animals';
import { ClientContactField, ClientField, COLLECTION } from '../utils/constants';
import { getCurrentTimestamp } from '../utils/functions';
import { deleteAuthUsers } from './admin';

export const handleNotificationEmailChanges = (clientOriginal: Client, clientUpdated: Partial<Client>): void => {
  // This helper function detects whether a client's notification emails have changed, if so it sends
  // a Slack message to notify the team the change

  if (!clientUpdated.jobChangeNotificationEmails) {
    return;
  }

  // We use .slice() to duplicate the array, because we need to call .sort() on them later, which mutates the arrays
  const originalEmails = (clientOriginal?.jobChangeNotificationEmails || []).slice();
  const updatedEmails = clientUpdated.jobChangeNotificationEmails.slice();

  if (!isEqual(originalEmails.sort(), updatedEmails.sort())) {
    sendJobChangeNotificationEmailsChangedAlert(clientOriginal.name, originalEmails, updatedEmails);
  }
};

export const addCodeNameIfNotSet = async (
  clientOriginal: Client,
  clientUpdated: Partial<Client>
): Promise<Partial<Client>> => {
  if (!clientOriginal.codeName && !clientUpdated.codeName) {
    let codeName = `${faker.commerce.color()} ${getRandomAnimal()}`.toLowerCase();

    let existingClientSameCodeName = (
      await getDocumentsByField<Client>({
        collection: COLLECTION.CLIENTS,
        field: ClientField.CODE_NAME,
        operation: '==',
        fieldValue: codeName,
      })
    )[0];

    // If the initial randomly generated codename is taken, add an adjective and try again
    if (existingClientSameCodeName) {
      codeName = `${faker.commerce.productAdjective()} ${faker.commerce.color()} ${getRandomAnimal()}`.toLowerCase();
    }

    existingClientSameCodeName = (
      await getDocumentsByField<Client>({
        collection: COLLECTION.CLIENTS,
        field: ClientField.CODE_NAME,
        operation: '==',
        fieldValue: codeName,
      })
    )[0];

    // If still taken (extremely unlikely), we use UUID as codename
    if (existingClientSameCodeName) {
      codeName = faker.random.uuid();
    }

    return { ...clientUpdated, codeName };
  } else {
    return clientUpdated;
  }
};

export const updateQAStatusDate = (clientOriginal: Client, clientUpdated: Partial<Client>): Partial<Client> => {
  if (clientOriginal.QAStatus !== clientUpdated.QAStatus) {
    return { ...clientUpdated, QAStatusDate: getCurrentTimestamp() };
  } else {
    return clientUpdated;
  }
};

export const updateStatusDate = (clientOriginal: Client, clientUpdated: Partial<Client>): Partial<Client> => {
  if (clientOriginal.status !== clientUpdated.status) {
    return { ...clientUpdated, statusDate: getCurrentTimestamp() };
  } else {
    return clientUpdated;
  }
};

const removeUserIdsFromClientQAUserIds = async (userIds: string[]): Promise<void> => {
  for (const uid of userIds) {
    const clients = await getDocumentsByField<Client>({
      collection: COLLECTION.CLIENTS,
      field: ClientField.QA_USER_IDS,
      operation: 'array-contains',
      fieldValue: uid,
    });

    const updatedClients = clients.map((client) => {
      const QAUserIds = client.QAUserIds || [];

      const updatedQAUserIds = QAUserIds.filter((qaUid) => qaUid !== uid);

      return { id: client.id, [ClientField.QA_USER_IDS]: updatedQAUserIds };
    });

    await updateDocumentsUsingMerge(COLLECTION.CLIENTS, updatedClients);
    console.log('clients qa list updated', updatedClients.length);
    return;
  }
};

export const deleteClientAndRelatedData = async (client: Client): Promise<void> => {
  // First we delete the client contacts
  const clientContacts = await getDocumentsByField<ClientContact>({
    collection: COLLECTION.CLIENT_CONTACTS,
    field: ClientContactField.CLIENT_ID,
    operation: '==',
    fieldValue: client.id,
  });

  if (clientContacts.length) {
    const clientContactIds = clientContacts.map((clientContact) => clientContact.id);
    await deleteDocumentsFromCollection(COLLECTION.CLIENT_CONTACTS, clientContactIds);
    console.log('clientContactIds DELETED!!!', clientContactIds.length);
  }

  // Then we delete the client internal data
  const clientInternalData = await getDocumentById<ClientInternal>(COLLECTION.CLIENT_INTERNAL, client.id);

  if (clientInternalData) {
    await deleteDocumentsFromCollection(COLLECTION.CLIENT_INTERNAL, [clientInternalData.id]);
    console.log('Client internal data deleted!');
  }

  // Then we get all users associated with that client, remove them from QA lists, delete the auth accounts, and finally the user data
  const users = await getDocumentsByField<UserData>({
    collection: COLLECTION.USERS,
    field: ClientContactField.CLIENT_ID,
    operation: '==',
    fieldValue: client.id,
  });

  if (users.length) {
    const userIds = users.map((user) => user.id);
    await removeUserIdsFromClientQAUserIds(userIds);
    await deleteAuthUsers(userIds);
    console.log('Auth users deleted!', userIds.length);
    await deleteDocumentsFromCollection(COLLECTION.CLIENT_INTERNAL, userIds);
    console.log('User data deleted!', userIds.length);
    await deleteDocumentsFromCollection(COLLECTION.USERS, userIds);
    console.log('Users deleted!', userIds.length);
  }

  // Finally we delete the Client record
  await deleteDocumentsFromCollection(COLLECTION.CLIENTS, [client.id]);
  console.log(`${client.name} deleted!`);

  return;
};
