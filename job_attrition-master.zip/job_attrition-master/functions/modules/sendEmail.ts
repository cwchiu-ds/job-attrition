import mailjet from 'node-mailjet';
import sgMail from '@sendgrid/mail';
import url from 'url';
import {
  MJ_PRIVATE_API_KEY,
  MJ_PUBLIC_API_KEY,
  SENDGRID_API_KEY,
  WARMLY_EMAIL,
  MailJetEmaiTemplate,
  DashboardURL,
} from '../utils/constants';
import { firebaseAuth } from '../controllers/authentication';
import { admin } from 'firebase-admin/lib/auth';
import { generateEmailSignInLink } from './authentication';

const mailjetClient = mailjet.connect(MJ_PUBLIC_API_KEY, MJ_PRIVATE_API_KEY);

sgMail.setApiKey(SENDGRID_API_KEY);

interface SendNewUserInviteConfig {
  inviteeEmail: string;
  inviterUser: UserData;
  inviterClient: Client;
}

export const sendNewUserInvite = async ({
  inviteeEmail,
  inviterUser,
  inviterClient,
}: SendNewUserInviteConfig): Promise<mailjet.Email.PostResponse> => {
  const actionCodeSettings = {
    url: `${DashboardURL.Onboard}?clientId=${encodeURIComponent(inviterUser.clientId)}&clientName=${encodeURIComponent(
      inviterClient.name
    )}`,
    // This must be true for email link sign-in.
    handleCodeInApp: true,
  };

  const signUpURL = await generateEmailSignInLink(inviteeEmail, actionCodeSettings);

  return mailjetClient.post('send', { version: 'v3.1' }).request({
    Messages: [
      {
        From: {
          Email: WARMLY_EMAIL.SUPPORT_TECH,
          Name: 'Warmly Support Team',
        },
        To: [
          {
            Email: inviteeEmail,
            Name: 'New Warmly User',
          },
        ],
        TemplateID: MailJetEmaiTemplate.INVITE_NEW_USER,
        TemplateLanguage: true,
        Subject: 'Welcome to Warmly',
        Variables: {
          inviterName: inviterUser.firstName,
          inviterClientName: inviterClient.name,
          signUpURL,
        },
      },
    ],
  });
};

export const sendWeeklyEmail = async (
  receiver: string[] | undefined,
  receiverName: string,
  template: string,
  totaljobChangesString: string,
  jobChangesNewString: string,
  jobChangesPreviousString: string,
  peopleChangedJobsNew: any,
  testEmailFlag: boolean
): Promise<number | undefined> => {
  let emailStatus;
  if (!receiver) {
    return;
  }

  try {
    const msg = {
      to: receiver,
      from: WARMLY_EMAIL.CTO,
      cc: testEmailFlag ? '' : WARMLY_EMAIL.CSM,
      templateId: template,
      substitutionWrappers: ['{{', '}}'],
      dynamic_template_data: {
        receiverName: receiverName,
        totalJobChanges: totaljobChangesString,
        jobChangesNew: jobChangesNewString,
        jobChangesPrevious: jobChangesPreviousString,
        peopleChangedJobsNew,
      },
    };

    await sgMail
      .send(msg)
      .then((result) => {
        console.log('email sent');
        emailStatus = result[0].statusCode;
      })
      .catch((err) => {
        console.log('err', err);
      });
  } catch (err) {
    console.error(err);
  } finally {
    return emailStatus;
  }
};

export const sendPasswordResetEmail = async (email: string): Promise<mailjet.Email.PostResponse> => {
  const actionCodeSettings: admin.auth.ActionCodeSettings = {
    url: DashboardURL.ResetPassword,
    handleCodeInApp: false,
  };

  const generatedUrl = await firebaseAuth.generatePasswordResetLink(email, actionCodeSettings);
  const urlObject = new URL(generatedUrl);
  const urlSearchParams = urlObject.searchParams;
  const oobCode = urlSearchParams.get('oobCode') || '';

  const passwordResetUrl = `${DashboardURL.ResetPassword}?oobCode=${encodeURIComponent(oobCode)}`;

  return mailjetClient.post('send', { version: 'v3.1' }).request({
    Messages: [
      {
        From: {
          Email: WARMLY_EMAIL.SUPPORT_TECH,
          Name: 'Warmly Support Team',
        },
        To: [
          {
            Email: email,
            Name: 'Warmly User',
          },
        ],
        TemplateID: MailJetEmaiTemplate.RESET_PASSWORD,
        TemplateLanguage: true,
        Subject: 'Reset your Warmly account password',
        Variables: {
          passwordResetUrl,
        },
      },
    ],
  });
};
