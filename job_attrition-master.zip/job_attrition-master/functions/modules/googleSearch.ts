import { firestore } from 'firebase-admin';
import { customsearch_v1 as googleCustomSearch } from 'googleapis';
import short from 'short-uuid';

import {
  updateBulkContactsData,
  updateContactDataGoogleSearchOngoingFlagTrue,
  updateDocumentsUsingMerge,
} from '../controllers/firestore';
import { COLLECTION, GOOGLE_SEARCH_API_KEY, GOOGLE_SEARCH_CSE_KEY } from '../utils/constants';
import { extractLinkedInIdFromUrl } from '../utils/functions';

const customSearch = new googleCustomSearch.Customsearch({
  auth: GOOGLE_SEARCH_API_KEY,
});

export const executeCustomSearch = async (searchTerm: string): Promise<googleCustomSearch.Schema$Result[]> => {
  console.log('google query search term', searchTerm);
  try {
    const searchQuery = await customSearch.cse.siterestrict.list({
      q: searchTerm,
      cx: GOOGLE_SEARCH_CSE_KEY,
      quotaUser: short().new(),
    });
    const searchResults = searchQuery.data.items;

    if (searchResults === undefined) {
      console.log('search results undefined');
    }
    // console.log("search result is", searchResults);

    // console.log("Google customer search query results", searchResults);
    return searchResults || [];
  } catch (err) {
    console.log('ERROR DETAILS BELOW------------------------');
    console.error(err);
    return [];
  }
};

export const generatedSearchQueryString = (contact: ClientContact): [string, string] => {
  if (contact.currentJob?.title !== '' && contact.currentJob?.companyName !== '' && contact.fullName !== '') {
    console.log(
      '👁 Querying Name/Company/Title ',
      contact.fullName,
      contact.currentJob?.companyName,
      contact.currentJob?.title
    );
    return [
      `${contact.fullName} ${contact.currentJob?.companyName} ${contact.currentJob?.title}`,
      'name_company_title',
    ];
  } else if (contact.currentJob?.companyName !== '' && contact.fullName !== '') {
    console.log('👁 Querying Name/Company ', contact.fullName, contact.currentJob?.companyName);
    return [`${contact.fullName} ${contact.currentJob?.companyName}`, 'name_company'];
  } else if (contact.currentJob?.title !== '' && contact.fullName !== '') {
    console.log('👁 Querying Name/Title ', contact.fullName, contact.currentJob?.title);
    return [`${contact.fullName} ${contact.currentJob?.title}`, 'name_title'];
  } else {
    console.log('👁 Querying Name ', contact.fullName, contact.currentJob?.companyName);
    return [`site:linkedin.com/in ${contact.fullName}`, 'name'];
  }
};

const checkIfValidLinkedInProfileURL = (url: string): boolean => {
  const match = url.match(/https?:\/\/.*\.?linkedin.com\/in\/([^?|\/]*)/);
  if (!match) {
    return false;
  }
  return true;
};

const SEARCH_RESULT_LINKEDIN_APPENDIX = ' | LinkedIn';
const SEARCH_RESULT_LINKEDIN_TITLE_DELIMITER = ' - ';

const parseJobFromSearchResultTitle = (searchResultTitle: string): JobObject => {
  const parsedJob: JobObject = {};
  const titleExcludingAppendix = searchResultTitle.replace(SEARCH_RESULT_LINKEDIN_APPENDIX, '');

  const titlePhraseArray = titleExcludingAppendix
    .split(SEARCH_RESULT_LINKEDIN_TITLE_DELIMITER)
    .map((word) => word.trim());

  // The first phrase of the title is almost guaranteed to be the person's name, so we need
  // at least two phrases to extract useful job data
  if (titlePhraseArray.length === 2) {
    // If the title has two phrases, we assume that the second one is the job title
    parsedJob.title = titlePhraseArray[1];
  } else if (titlePhraseArray.length >= 3) {
    // If the title has three or more phrases, we assume that the second phrase is job title
    // and third phrase is company name
    parsedJob.title = titlePhraseArray[1];
    parsedJob.company = titlePhraseArray[2];
  }

  return parsedJob;
};

const parseJobsCount = (searchResult: googleCustomSearch.Schema$Result): GoogleSearchResult['jobCount'] => {
  // We search all possible text descriptions to see if one of them includes the job count
  const potentialText: string[] = [
    searchResult.pagemap?.metatags?.[0]?.['og:description'],
    searchResult.pagemap?.metatags?.[0]?.['twitter:description'],
    searchResult.snippet,
  ];

  for (const text of potentialText) {
    if (text) {
      const match = text.match(/has (\d+) jobs listed on their profile/i);
      if (match) {
        const [, jobsCount] = match;
        return +jobsCount; // NOTE consider a better way to convert to number than type coercion
      }
    }
  }

  return 0;
};

const extractPhotoURL = (searchResult: googleCustomSearch.Schema$Result): GoogleSearchResult['photoURL'] => {
  const photoURL: string =
    searchResult.pagemap?.cse_image?.[0]?.src ||
    searchResult.pagemap?.cse_thumbnail?.[0]?.src ||
    searchResult.pagemap?.metatags?.[0]?.['og:image'] ||
    searchResult.pagemap?.metatags?.[0]?.['twitter:image'];

  return photoURL;
};

type AdditionalGoogleData = Omit<GoogleSearchResult, 'currentJob'>;

const getAdditionalDataFromSearchResult = (searchResult: googleCustomSearch.Schema$Result): AdditionalGoogleData => {
  // the og:description and twitter:description tend to be longer and more comprehensive than the snippet
  const searchResultDescription: string =
    searchResult.pagemap?.metatags?.[0]?.['og:description'] ||
    searchResult.pagemap?.metatags?.[0]?.['twitter:description'] ||
    searchResult.snippet;

  const additionalData: AdditionalGoogleData = {
    searchResultTitle: searchResult.title || '',
    searchResultDescription: searchResultDescription || '',
    searchTime: firestore.Timestamp.fromDate(new Date()),
    jobCount: parseJobsCount(searchResult),
    photoURL: extractPhotoURL(searchResult),
  };

  return additionalData;
};

export const parseGoogleSearchResults = (
  linkedInUrl: string,
  searchResults: googleCustomSearch.Schema$Result[]
): GoogleSearchResult | undefined => {
  const linkedInId = extractLinkedInIdFromUrl(linkedInUrl);

  if (!linkedInId) {
    return;
  }

  for (const item of searchResults) {
    const searchResultLinkedInId = extractLinkedInIdFromUrl(item.link || '');
    if (searchResultLinkedInId === linkedInId && item.title) {
      const parsedJob = parseJobFromSearchResultTitle(item.title);
      const additionalData = getAdditionalDataFromSearchResult(item);
      return {
        currentJob: parsedJob,
        ...additionalData,
      };
    }
  }

  return;
};

const checkLinkedInSame = (
  existingContact: ContactData,
  contactSearchResults: googleCustomSearch.Schema$Result[]
): googleCustomSearch.Schema$Result => {
  let sameLinkedInResult: googleCustomSearch.Schema$Result = {};

  contactSearchResults.forEach((result) => {
    // google searhc array result item could be empty
    if (contactSearchResults.length > 0) {
      const id1 = extractLinkedInIdFromUrl(result.link!);
      const id2 = extractLinkedInIdFromUrl(existingContact.linkedInURL!);

      if (id1 === id2) {
        sameLinkedInResult = result;
      }
    } else {
      console.log('empty 2', result);
    }
  });

  return sameLinkedInResult;
};

const checkGoogleSearchQueryJobChangeAndReturnSavedObject = async (
  existingContact: ContactData,
  sameLinkedInResult: googleCustomSearch.Schema$Result
): Promise<GoogleSearchResults> => {
  const sameLinkedInResultParsedJobCount = parseJobsCount(sameLinkedInResult);

  // let uploadedPhotoURL = "";

  // if (sameLinkedInResult.link) {
  //   // Use the email to ensure each profile photo has a unique name
  //   const photoFileName = existingContact.ID + ".jpg";
  //   uploadedPhotoURL = await uploadPhoto(
  //     sameLinkedInResult.link,
  //     photoFileName
  //   );
  // }

  const obj: GoogleSearchResults = {
    searchResultTitle: sameLinkedInResult.title! || '',
    searchResultDescription: sameLinkedInResult.snippet! || '',
    searchTime: firestore.Timestamp.fromDate(new Date()),
    jobsCount: sameLinkedInResultParsedJobCount || 0,
    // photoURL: uploadedPhotoURL,
    googleSearchResultChanges: [
      {
        searchResultTitle: sameLinkedInResult.title! || '',
        searchResultDescription: sameLinkedInResult.snippet! || '',
        searchTime: firestore.Timestamp.fromDate(new Date()),
        jobsCount: sameLinkedInResultParsedJobCount || 0,
        // photoURL: uploadedPhotoURL,
      },
    ],
    googleScrapeFailed: false,
  };

  if (Object.keys(sameLinkedInResult).length === 0 || !sameLinkedInResult.title) {
    console.log('🛑 Scrape failed, 0 job count or no search results');
    obj.googleScrapeFailed = true;
  } else {
    // check if googleSearchResult exists on existing contact object
    if (existingContact.googleSearchResults) {
      if (
        sameLinkedInResult.title !== existingContact.googleSearchResults.searchResultTitle ||
        sameLinkedInResultParsedJobCount !== existingContact.googleSearchResults.jobsCount
      ) {
        // check if Google search title is different or if job count on google search query is different. Flag it if so!
        obj.googleSearchResultChanges = [
          ...existingContact.googleSearchResults.googleSearchResultChanges,
          ...obj.googleSearchResultChanges,
        ];
        console.log('⭐️ Detected a job change at ContactData ID', existingContact.ID);

        // set jobChanged flag to True on Client Data
        // await updateClientDataJobChangedFlagToTrue(existingContact.ID);
        await updateContactDataGoogleSearchOngoingFlagTrue(existingContact.ID);
      } else {
        console.log('No change to google search title, return existing googleSearchResults', existingContact.ID);
        return existingContact.googleSearchResults;
      }
    }
  }
  return obj;
};

export const processSearchResults = async (
  contacts: ContactData[],
  searchResultsArray: googleCustomSearch.Schema$Result[][]
): Promise<FirebaseFirestore.WriteResult[]> => {
  const updatedContactsData = [];
  for (const contactIndex in contacts) {
    const existingContact = contacts[contactIndex];

    // const existingGoogleSearchData = await getContactDataSubCollectionForGoogleByContactId(
    //   existingContact.ID,
    //   "googleSearchResults"
    // );

    const contactSearchResults = searchResultsArray[contactIndex];

    const sameLinkedInResult = checkLinkedInSame(existingContact, contactSearchResults);

    const obj = await checkGoogleSearchQueryJobChangeAndReturnSavedObject(existingContact, sameLinkedInResult);

    if (Object.keys(obj).length === 0) {
      obj.googleScrapeFailed = true;
    }

    // const parsedSearchData = parseGoogleSearchResults(
    //   existingContact.linkedInURL!,
    //   contactSearchResults
    // );

    if (existingContact && Object.keys(obj).length > 0 && obj.searchResultTitle !== '') {
      updatedContactsData.push({ googleSearchResults: obj } as Partial<ContactData>);
    } else {
      // If unable to find and parse a valid google search result, push an empty update
      updatedContactsData.push({});
    }
  }

  // console.log("updated contacts", updatedContactsData);

  return updateBulkContactsData(contacts, updatedContactsData);
};

export const processSearchResultsGetLinkedInURL = async (
  contacts: ClientContact[],
  searchResultsArray: googleCustomSearch.Schema$Result[][],
  queryStringList: [string, string][]
): Promise<void> => {
  const potentialSearch = [];

  for (const contactIndex in contacts) {
    const topThreeSearchResults = [];
    const firstResultLinkedInURL = searchResultsArray[contactIndex][0]?.link;
    const linkedInURL: string = firstResultLinkedInURL || '';

    let fillError = false;
    if (linkedInURL == '') {
      fillError = true;
      console.log('Google Search Query Didnt Fill LinkedInURL, check fillError');
    }

    for (let i = 0; i < 3; i++) {
      const firstResultLinkedInURL = searchResultsArray[contactIndex][i]?.link;
      const linkedInURL: string = firstResultLinkedInURL || '';
      const firstResultTitle = searchResultsArray[contactIndex][i]?.title;
      const title: string = firstResultTitle || '';
      const firstSnippet = searchResultsArray[contactIndex][i]?.snippet;
      const snippet: string = firstSnippet || '';

      const searchQueryResult = {
        linkedInURL: linkedInURL,
        title: title,
        snippet: snippet,
      };

      if (linkedInURL && checkIfValidLinkedInProfileURL(linkedInURL)) {
        topThreeSearchResults.push(searchQueryResult);
      }
    }

    console.log('Saving Linked url', linkedInURL, queryStringList[contactIndex][0]);

    if (linkedInURL) {
      potentialSearch.push({
        id: contacts[contactIndex].id,
        initialGoogleSearch: {
          topThreeSearchResults,
          queryString: queryStringList[contactIndex][0],
          queryParams: queryStringList[contactIndex][1],
          searchTime: firestore.Timestamp.fromDate(new Date()),
          fillError,
        },
      });
    } else {
      // If unable to find and parse a valid google search result, push an empty update
      potentialSearch.push({ id: contacts[contactIndex].id });
    }
  }

  return updateDocumentsUsingMerge<ClientContact>(COLLECTION.CLIENT_CONTACTS, potentialSearch);
};
