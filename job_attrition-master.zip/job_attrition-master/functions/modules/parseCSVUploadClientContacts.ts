// CSV parser
// const fs = require('fs');
// const Papa = require('papaparse');
// var path = require('path');
// const { firestore } = require('firebase-admin');
// const { chunk } = require('lodash');

// const admin = require('../config/firebaseConfig.js');

import { firestore } from 'firebase-admin';
import fs from 'fs';
import { chunk } from 'lodash';
import Papa from 'papaparse';
import path from 'path';

import { extractLinkedInIdFromUrl } from '../utils/functions';
import { areJobsEqual } from '../utils/helperFunctions/checkJobChangesHelperFunctions';
import { db, addDocumentsToCollection } from '../controllers/firestore';
import { COLLECTION } from '../utils/constants';

const clientContactCollection = db.collection('client_contacts');
const contactDataCollection = db.collection('contact_data');
const clientsCollection = db.collection('clients');

/**
 * Parses CSV file from crm_data/ that's in the following format, and saves fields into DB 'companies' and 'contacts' collection.
 * @param companyName Company (our customer). E.g. 'Fitco'.
 * @param companyEmail Email we should send our job attrition email notifications to. E.g. 'andrea@fitcolatam.com'.
 * @param csvFileName Name of the CSV file. E.g. 'fitco.csv'.
 *
 * CSV required format:
 *   | Name | Title | Account | Email |
 *
 *   - Name: contact's first and last name
 *   - Title: contact's job title
 *   - Account: contact's company
 *   - Email: contact's email
 *   - LinkedInURL: contact's linkedin URL
 **/
export async function parseCSVUploadClientContacts(
  companyName: string,
  csvFileName: string,
  upload = false
): Promise<void> {
  // let csvFilePath = "functions/utils/crm_data/" + csvFileName;
  const csvFilePath = path.join(__dirname, 'crm_data/') + csvFileName + '.csv';
  console.log('Path:', path.join(__dirname, 'crm_data/'));

  // Documentation: https://www.papaparse.com/docs#local-files
  const config = {
    delimiter: '', // auto-detect ","
    newline: '', // auto-detect "\r\n"
    // quoteChar: '"',
    // escapeChar: '"',
    // header: false,
    // transformHeader: undefined,
    // dynamicTyping: false,
    // preview: 0,
    // encoding: "",
    // worker: false,
    // comments: false,
    // step: undefined,
    complete: async (results: any): Promise<void> => {
      console.log('Number of Rows:', results.data.length);
      console.log('Columns:', results.data[0]);

      console.log('results data length', results.data.length);

      if (results.data.length < 2) {
        // No data in CSV besides header row.
        return;
      }
      const columnCount = results.data[0].length;
      const columnNames = results.data[0];

      // check to make sure client exists or not.
      const clientSnapshot = await clientsCollection.where('name', '==', companyName).get();

      let clientRef: any;

      const updateArray: any[] = [];
      const newUploadArray: any[] = [];

      console.log('clientSnapshot', clientSnapshot.empty);

      // if client exists keep the clientRef for the ID. Else make a new client
      if (clientSnapshot.empty) {
        clientsCollection
          // @ts-ignore
          .add({
            name: companyName,
            createdDate: firestore.Timestamp.fromDate(new Date()),
          })
          .then(() => {
            console.log('🥳 Successfully saved new client to DB:', companyName);
          });
      } else {
        clientSnapshot.forEach((doc) => {
          if (doc.exists) {
            clientRef = doc.ref;
            console.log('Company', companyName, 'already exists in client DB, clientRef is', clientRef.id);
          }
        });
      }
      // for (var i = 1; i < 5; i++) {
      for (let i = 1; i < results.data.length; i++) {
        // Start at 1 to skip the CSV title row "'Name', 'Title', 'Account', 'Email'"
        const contact = results.data[i];

        let name = '';
        let title = '';
        let account = '';
        let email = '';
        let linkedInURL = '';
        let firstName = '';
        let lastName = '';
        let jobChanged = false;
        const crmData: any = {}; // Extra columns from their CRM that isn't mapped to one of our default parsed fields.

        // Check if these fields exist because they might be blank or the column might not exist

        if (columnCount > 0) {
          name = contact[0];
        }
        if (columnCount > 1) {
          firstName = contact[1];
        }
        if (columnCount > 2) {
          lastName = contact[2];
        }
        if (columnCount > 3) {
          title = contact[3];
        }
        if (columnCount > 4) {
          account = contact[4];
        }
        if (columnCount > 5) {
          email = contact[5];
        }
        if (columnCount > 6) {
          linkedInURL = contact[6];
          console.log('linkedIn URL is', linkedInURL);
        }

        for (let c = 7; c < columnCount; c++) {
          if (columnNames[c] == 'jobChanged') {
            jobChanged = contact[c] === 'TRUE' ? true : false;
          } else {
            crmData[columnNames[c]] = contact[c];
          }
        }

        crmData.crmLinkedInURL = linkedInURL;

        if (upload) {
          const newData = {
            clientId: clientRef.id,
            clientName: companyName,
            firstName,
            lastName,
            fullName: name,
            currentJob: {
              companyName: account,
              title: title,
            },
            dateUpdated: firestore.Timestamp.fromDate(new Date()),
            dateCreated: firestore.Timestamp.fromDate(new Date()),
            email: email,
            linkedInURL: linkedInURL,
            crmData,
            jobChanged,
          };
          console.log('upload', email);
          newUploadArray.push(newData);
        } else {
          const clientContactRef = await clientContactCollection
            // .where('email', '==', email)
            .where('email', '==', email)
            .where('clientId', '==', clientRef.id)
            .get();

          if (clientContactRef.empty) {
            const obj = {
              clientId: clientRef.id,
              clientName: companyName,
              firstName,
              lastName,
              fullName: name,
              currentJob: {
                companyName: account,
                title: title,
              },
              dateUpdated: firestore.Timestamp.fromDate(new Date()),
              dateCreated: firestore.Timestamp.fromDate(new Date()),
              email: email,
              linkedInURL: linkedInURL,
              crmData,
              jobChanged,
            };
            console.log('uploading', email);
            newUploadArray.push(obj);
          } else {
            clientContactRef.forEach((doc) => {
              if (doc.exists) {
                const obj = {
                  clientId: clientRef.id,
                  clientName: companyName,
                  firstName,
                  lastName,
                  fullName: name,
                  currentJob: {
                    companyName: account,
                    title: title,
                  },
                  dateUpdated: firestore.Timestamp.fromDate(new Date()),
                  email: email,
                  linkedInURL: linkedInURL,
                  crmData,
                  jobChanged,
                };
                // console.log('updating', email);
                updateArray.push({ obj, id: doc.id });
              }
            });
          }
        }
      }

      // upload without updating
      if (upload) {
        await addDocumentsToCollection(COLLECTION.CLIENT_CONTACTS, newUploadArray);
        console.log('✅ Parallel upload completed');
      } else {
        // Update batch
        if (updateArray.length > 0) {
          // @ts-ignore
          const updateArrayChunks = chunk(updateArray, 400);
          updateArrayChunks.forEach((subArray) => {
            const updateBatch = db.batch();
            subArray.forEach((element) => {
              updateBatch.set(clientContactCollection.doc(element.id), element.obj, {
                merge: true,
              });
            });
            updateBatch.commit();
          });
          console.log('🟢 Update data upload complete');
        }

        // upload new data batch
        // @ts-ignore
        const newUploadArrayChunks = chunk(newUploadArray, 400);
        newUploadArrayChunks.forEach((subArray) => {
          const newUploadBatch = db.batch();
          // // new data upload array

          subArray.forEach((obj) => {
            console.log('new upload', obj);
            newUploadBatch.set(clientContactCollection.doc(), obj);
          });
          newUploadBatch.commit();
        });

        console.log('🟢 New data upload complete');
      }
    },
  };

  // Read via fs:
  const file = await fs.createReadStream(csvFilePath);
  await Papa.parse(file, config);

  // Not working to read CSV directly even with "download: true"
  // https://stackoverflow.com/questions/49752889/how-can-i-read-a-local-file-with-papa-parse
  // Papa.parse('crm_data/carina_test_1.csv', config);
}

const addAllJobsUpdateCurrentJobInContactData = async (
  contactDataCollection: firestore.CollectionReference<firestore.DocumentData>,
  contactDataId: string,
  companyName: string,
  title: string
): Promise<void> => {
  await contactDataCollection.doc(contactDataId).set(
    {
      allJobs: [
        {
          companyName,
          title,
          lastUpdated: firestore.Timestamp.fromDate(new Date()),
        },
      ],
      currentJob: [
        {
          companyName,
          title,
          lastUpdated: firestore.Timestamp.fromDate(new Date()),
        },
      ],
    },
    { merge: true }
  );
};

const checkUpdateJobChangeEnrichedDataFlag = async (
  clientContactRef: firestore.DocumentReference<firestore.DocumentData>,
  jobChangedFlag: string,
  enrichedDataFlag: string
): Promise<void> => {
  if (jobChangedFlag === 'TRUE') {
    await clientContactRef.set(
      {
        jobChanged: true,
      },
      { merge: true }
    );
  } else {
    await clientContactRef.set(
      {
        jobChanged: false,
      },
      { merge: true }
    );
  }

  if (enrichedDataFlag === 'TRUE') {
    await clientContactRef.set(
      {
        enrichedDataChanged: true,
      },
      { merge: true }
    );
  } else {
    await clientContactRef.set(
      {
        enrichedDataChanged: false,
      },
      { merge: true }
    );
  }
};

export async function postQAFinalUpdatete(companyName: string, csvFileName: string): Promise<void> {
  console.log('companyName', companyName);
  console.log('csvFileName', csvFileName);

  // let csvFilePath = "functions/utils/crm_data/" + csvFileName;
  const csvFilePath = path.join(__dirname, 'crm_data/') + csvFileName + '.csv';
  console.log('Path:', path.join(__dirname, 'crm_data/'));

  // Documentation: https://www.papaparse.com/docs#local-files
  const config = {
    delimiter: '', // auto-detect ","
    newline: '', // auto-detect "\r\n"

    complete: async (results: any): Promise<void> => {
      console.log('Number of Rows:', results.data.length);

      if (results.data.length < 2) {
        // No data in CSV besides header row.
        return;
      }
      const columnCount = results.data[0].length;

      // check to make sure client exists or not.
      const clientSnapshot = await clientsCollection.where('name', '==', companyName).get();

      // const updateArray: any[] = [];
      // const newUploadArray: any[] = [];

      // if client exists keep the clientRef for the ID. Else make a new client
      if (clientSnapshot.empty) {
        console.log('Company', companyName, 'does not exist');
      } else {
        clientSnapshot.forEach((doc) => {
          if (doc.exists) {
            console.log('Company', companyName, 'already exists in client DB');
          }
        });
      }
      // for (var i = 1; i < 5; i++) {
      for (let i = 1; i < results.data.length; i++) {
        // Start at 1 to skip the CSV title row "'Name', 'Title', 'Account', 'Email'"
        const contact = results.data[i];

        let clientContactID = '';
        let contactDataId = '';
        let email = '';
        let title = '';
        let firstName = '';
        let lastName = '';
        let name = '';
        let companyName = '';
        let jobChangedFlag = '';
        let enrichedDataFlag = '';
        let wrongURLFlag = '';
        let linkedInURL = '';
        let crmLinkedInURL = '';
        console.log(crmLinkedInURL, name, lastName, firstName);

        // Check if these fields exist because they might be blank or the column might not exist

        if (columnCount > 0) {
          console.log('contact 0', contact[0]);
          clientContactID = contact[0];
        }
        if (columnCount > 1) {
          contactDataId = contact[1];
        }
        if (columnCount > 2) {
          email = contact[2];
        }
        if (columnCount > 3) {
          name = contact[3];
        }
        if (columnCount > 4) {
          firstName = contact[4];
        }
        if (columnCount > 5) {
          lastName = contact[5];
        }
        if (columnCount > 10) {
          title = contact[10];
        }
        if (columnCount > 14) {
          companyName = contact[14];
        }
        if (columnCount > 16) {
          jobChangedFlag = contact[16];
        }
        if (columnCount > 17) {
          enrichedDataFlag = contact[17];
        }
        if (columnCount > 18) {
          wrongURLFlag = contact[18];
        }
        if (columnCount > 20) {
          linkedInURL = contact[20];
        }
        if (columnCount > 21) {
          crmLinkedInURL = contact[21];
        }

        // for (let c = 5; c < columnCount; c++) {
        //   crmData[columnNames[c]] = contact[c];
        // }

        console.log('company name', companyName);
        console.log(
          'row',
          clientContactID,
          contactDataId,
          title,
          companyName,
          email,
          jobChangedFlag,
          enrichedDataFlag,
          wrongURLFlag,
          linkedInURL
        );

        const clientContactRef = await clientContactCollection.doc(clientContactID);

        const clientContactExists = (await clientContactRef.get()).exists;

        const currentJob = { companyName, title };

        // if (leadLifeCycleStage !== '') {
        //   await clientContactRef.set(
        //     {
        //       leadLifeCycleStage: leadLifeCycleStage,
        //     },
        //     { merge: true }
        //   );
        // }

        if (clientContactExists) {
          // linkedin url doesnt exist and cant find
          if (linkedInURL === '' && wrongURLFlag == 'FALSE') {
            await clientContactRef.set({ linkedInURLNotFound: true, contactDataId: '' }, { merge: true });
            continue;
          }

          if (wrongURLFlag === 'TRUE') {
            const contact = (await clientContactRef.get()).data();
            if (linkedInURL === '') {
              await clientContactRef.set(
                {
                  linkedInURL: linkedInURL,
                  linkedInURLNotFound: true,
                  contactDataId: '',
                  crmData: {
                    crmLinkedInURL: crmLinkedInURL || '',
                  },
                },
                { merge: true }
              );
              continue;
            }

            await checkUpdateJobChangeEnrichedDataFlag(clientContactRef, jobChangedFlag, enrichedDataFlag);

            // save correct linkedin url current contact URL must be diff from upload csv URL so you can show diff
            if (contact?.linkedInURL !== linkedInURL) {
              await clientContactRef.set(
                {
                  linkedInURL: linkedInURL,
                  crmData: {
                    crmLinkedInURL: crmLinkedInURL || '',
                  },
                },
                { merge: true }
              );

              const linkedInId = extractLinkedInIdFromUrl(linkedInURL);
              const contactsQuerySnapshot = await contactDataCollection.where('linkedInId', '==', linkedInId).get();

              console.log('got here', contactsQuerySnapshot.size);

              if (contactsQuerySnapshot.size === 0) {
                // save new contactId if no linkedinId exists, append contactDataId to client data
                const obj = {
                  emailData: [
                    {
                      email: email,
                      dateCreated: firestore.Timestamp.fromDate(new Date()),
                      source: 'CRM',
                    },
                  ],

                  emailArray: [email],
                  firstName: firstName || '',
                  lastName: lastName || '',
                  name: name || '',
                  linkedInURL: linkedInURL,
                  linkedInId,
                  currentJob: [
                    {
                      companyName: companyName,
                      title: title,
                      lastUpdated: firestore.Timestamp.fromDate(new Date()),
                    },
                  ],
                  allJobs: [
                    {
                      companyName: companyName,
                      title: title,
                      lastUpdated: firestore.Timestamp.fromDate(new Date()),
                    },
                  ],
                };
                await contactDataCollection.add(obj).then(async (ref) => {
                  await clientContactRef.set(
                    {
                      contactDataId: ref.id,
                    },
                    { merge: true }
                  );
                });
              }
              // check if linkedInId exists in contactdata
              contactsQuerySnapshot.forEach(async (doc) => {
                if (doc.exists) {
                  console.log('doc exists', doc.id, doc.exists);
                  await clientContactRef.set(
                    {
                      contactDataId: doc.id,
                    },
                    { merge: true }
                  );
                  const contact = (await contactDataCollection.doc(doc.id).get()).data();
                  if (contact?.allJobs) {
                    const updatedJobsArray = contact.allJobs;
                    if (!areJobsEqual(currentJob, contact.allJobs[contact.allJobs.length - 1])) {
                      // If new job detected, append the new job to the contact and flag the contact.
                      updatedJobsArray.push({
                        companyName,
                        title,
                        lastUpdated: firestore.Timestamp.fromDate(new Date()),
                      });
                    }

                    await contactDataCollection.doc(doc.id).set(
                      {
                        allJobs: updatedJobsArray,
                        currentJob: [
                          {
                            companyName,
                            title,
                            lastUpdated: firestore.Timestamp.fromDate(new Date()),
                          },
                        ],
                      },
                      { merge: true }
                    );
                  } else {
                    console.log('shouldve got here', doc.id);
                    // if there is no allJobs field present
                    await addAllJobsUpdateCurrentJobInContactData(
                      contactDataCollection,
                      contactDataId,
                      companyName,
                      title
                    );
                  }
                }
              });
            }
          } else {
            console.log('write url flag');
            // vanilla if linkedInURL is not wrong just update current job companyName and title in contacdata, and jobchange flag and enriched flag in clientdata
            const contact = (await contactDataCollection.doc(contactDataId).get()).data();
            if (contact?.allJobs) {
              const updatedJobsArray = contact.allJobs;
              if (!areJobsEqual(currentJob, contact.allJobs[contact.allJobs.length - 1])) {
                // If new job detected, append the new job to the contact and flag the contact.
                updatedJobsArray.push({
                  companyName,
                  title,
                  lastUpdated: firestore.Timestamp.fromDate(new Date()),
                });
              }

              await contactDataCollection.doc(contactDataId).set(
                {
                  allJobs: updatedJobsArray,
                  currentJob: [
                    {
                      companyName,
                      title,
                      lastUpdated: firestore.Timestamp.fromDate(new Date()),
                    },
                  ],
                },
                { merge: true }
              );
            } else {
              // if there is no allJobs field present
              await addAllJobsUpdateCurrentJobInContactData(contactDataCollection, contactDataId, companyName, title);
            }

            if (linkedInURL !== '') {
              await clientContactRef.set(
                {
                  linkedInURL: linkedInURL,

                  crmData: {
                    crmLinkedInURL: crmLinkedInURL || '',
                  },
                  linkedInURLNotFound: false,
                },
                { merge: true }
              );
            }

            await checkUpdateJobChangeEnrichedDataFlag(clientContactRef, jobChangedFlag, enrichedDataFlag);
          }
        }
      }
      console.log('🟢 New data upload complete');
    },
  };

  // Read via fs:
  const file = await fs.createReadStream(csvFilePath);
  await Papa.parse(file, config);
}

export async function markTrackFlagClientData(companyName: string, csvFileName: string): Promise<void> {
  // let csvFilePath = "functions/utils/crm_data/" + csvFileName;
  const csvFilePath = path.join(__dirname, 'crm_data/') + csvFileName + '.csv';
  console.log('Path:', path.join(__dirname, 'crm_data/'));

  // Documentation: https://www.papaparse.com/docs#local-files
  const config = {
    delimiter: '', // auto-detect ","
    newline: '', // auto-detect "\r\n"

    complete: async (results: any): Promise<void> => {
      console.log('Number of Rows:', results.data.length);
      console.log('Columns:', results.data[0]);

      if (results.data.length < 2) {
        // No data in CSV besides header row.
        return;
      }
      const columnCount = results.data[0].length;

      const updateArray: any[] = [];

      let totalContactsUpdated = 0;
      // for (var i = 1; i < 5; i++) {
      for (let i = 1; i < results.data.length; i++) {
        // Start at 1 to skip the CSV title row "'Name', 'Title', 'Account', 'Email'"
        const contact = results.data[i];

        let email = ''; // email is first column

        if (columnCount > 0) {
          email = contact[0];
        }

        const clientContactRef = await clientContactCollection
          .where('email', '==', email)
          .where('clientName', '==', companyName)
          .get();

        clientContactRef.forEach((doc) => {
          if (doc.exists) {
            const obj = {
              trackFlag: true,
              dateUpdated: firestore.Timestamp.fromDate(new Date()),
            };
            console.log('updating', email);
            totalContactsUpdated = totalContactsUpdated + 1;
            updateArray.push({ obj, id: doc.id });
          }
        });
      }

      // Update batch
      // @ts-ignore
      const updateArrayChunks = chunk(updateArray, 400);
      updateArrayChunks.forEach((subArray) => {
        const updateBatch = db.batch();
        subArray.forEach((element) => {
          updateBatch.set(clientContactCollection.doc(element.id), element.obj, {
            merge: true,
          });
        });
        updateBatch.commit();
      });

      console.log(`🟢 Update data upload complete, ${totalContactsUpdated} contacts updated`);
    },
  };

  // Read via fs:
  const file = await fs.createReadStream(csvFilePath);
  await Papa.parse(file, config);
}

export async function addClientIdsToContactData(companyName: string, csvFileName: string): Promise<void> {
  // let csvFilePath = "functions/utils/crm_data/" + csvFileName;
  const csvFilePath = path.join(__dirname, 'crm_data/') + csvFileName + '.csv';
  console.log('Path:', path.join(__dirname, 'crm_data/'));

  // Documentation: https://www.papaparse.com/docs#local-files
  const config = {
    delimiter: '', // auto-detect ","
    newline: '', // auto-detect "\r\n"

    complete: async (results: any): Promise<void> => {
      console.log('Number of Rows:', results.data.length);
      console.log('Columns:', results.data[0]);

      if (results.data.length < 2) {
        // No data in CSV besides header row.
        return;
      }
      const columnCount = results.data[0].length;
      let totalCount = 0;
      // for (var i = 1; i < 5; i++) {
      for (let i = 1; i < results.data.length; i++) {
        // Start at 1 to skip the CSV title row "'Name', 'Title', 'Account', 'Email'"
        const contact = results.data[i];

        let contactDataId = ''; // email is first column

        if (columnCount > 0) {
          contactDataId = contact[0];
        }

        const contactDataRef = await contactDataCollection.doc(contactDataId);

        const contactDataContactExists = (await contactDataRef.get()).exists;

        if (contactDataContactExists) {
          await contactDataRef.set({ clientIds: ['43Y2TeoiSfW5snv5VcG6'] }, { merge: true });
          console.log('updating contact data contact', contactDataId);
          totalCount = totalCount + 1;
          continue;
        }
      }

      console.log(`🟢 Update clientIds upload complete for ${companyName}, ${totalCount} rows updated`);
    },
  };

  // Read via fs:
  const file = await fs.createReadStream(csvFilePath);
  await Papa.parse(file, config);
}

export async function addLinkedInURLsToClientData(companyName: string, csvFileName: string): Promise<void> {
  // let csvFilePath = "functions/utils/crm_data/" + csvFileName;
  const csvFilePath = path.join(__dirname, 'crm_data/') + csvFileName + '.csv';
  console.log('Path:', path.join(__dirname, 'crm_data/'));

  // Documentation: https://www.papaparse.com/docs#local-files
  const config = {
    delimiter: '', // auto-detect ","
    newline: '', // auto-detect "\r\n"

    complete: async (results: any): Promise<void> => {
      console.log('Number of Rows:', results.data.length);
      console.log('Columns:', results.data[0]);

      if (results.data.length < 2) {
        // No data in CSV besides header row.
        return;
      }
      const columnCount = results.data[0].length;

      const updateArray: any[] = [];

      let totalContactsUpdated = 0;
      // for (var i = 1; i < 5; i++) {
      for (let i = 1; i < results.data.length; i++) {
        // Start at 1 to skip the CSV title row "'Name', 'Title', 'Account', 'Email'"
        const contact = results.data[i];

        let email = ''; // email is first column
        let linkedInURL = "'";

        if (columnCount > 0) {
          email = contact[0];
        }

        if (columnCount > 1) {
          linkedInURL = contact[1];
        }

        const clientContactRef = await clientContactCollection
          .where('email', '==', email)
          .where('clientName', '==', companyName)
          .get();

        clientContactRef.forEach((doc) => {
          if (doc.exists) {
            const obj = {
              linkedInURL: linkedInURL,
              crmData: {
                crmLinkedInURL: linkedInURL,
              },
              dateUpdated: firestore.Timestamp.fromDate(new Date()),
            };
            console.log('updating', email);
            totalContactsUpdated = totalContactsUpdated + 1;
            updateArray.push({ obj, id: doc.id });
          }
        });
      }

      // Update batch
      // @ts-ignore
      const updateArrayChunks = chunk(updateArray, 400);
      updateArrayChunks.forEach((subArray) => {
        const updateBatch = db.batch();
        subArray.forEach((element) => {
          updateBatch.set(clientContactCollection.doc(element.id), element.obj, {
            merge: true,
          });
        });
        updateBatch.commit();
      });

      console.log(`🟢 Update data upload complete, ${totalContactsUpdated} contacts updated`);
    },
  };

  // Read via fs:
  const file = await fs.createReadStream(csvFilePath);
  await Papa.parse(file, config);
}

export async function addHubspotVidsToClientData(companyName: string, csvFileName: string): Promise<void> {
  // let csvFilePath = "functions/utils/crm_data/" + csvFileName;
  const csvFilePath = path.join(__dirname, 'crm_data/') + csvFileName + '.csv';
  console.log('Path:', path.join(__dirname, 'crm_data/'));

  // Documentation: https://www.papaparse.com/docs#local-files
  const config = {
    delimiter: '', // auto-detect ","
    newline: '', // auto-detect "\r\n"

    complete: async (results: any): Promise<void> => {
      console.log('Number of Rows:', results.data.length);
      console.log('Columns:', results.data[0]);

      if (results.data.length < 2) {
        // No data in CSV besides header row.
        return;
      }
      const columnCount = results.data[0].length;

      const updateArray: any[] = [];

      let totalContactsUpdated = 0;
      // for (var i = 1; i < 5; i++) {
      for (let i = 1; i < results.data.length; i++) {
        // Start at 1 to skip the CSV title row "'Name', 'Title', 'Account', 'Email'"
        const contact = results.data[i];

        let email = ''; // email is first column
        let hubspotVid = '';

        if (columnCount > 0) {
          email = contact[0];
        }

        if (columnCount > 1) {
          hubspotVid = contact[1];
        }

        const clientContactRef = await clientContactCollection
          .where('email', '==', email)
          .where('clientName', '==', companyName)
          .get();

        clientContactRef.forEach((doc) => {
          if (doc.exists) {
            const obj = {
              crmData: {
                vid: hubspotVid,
              },
              dateUpdated: firestore.Timestamp.fromDate(new Date()),
            };
            console.log('updating', email);
            totalContactsUpdated = totalContactsUpdated + 1;
            updateArray.push({ obj, id: doc.id });
          }
        });
      }

      // Update batch
      // @ts-ignore
      const updateArrayChunks = chunk(updateArray, 400);
      updateArrayChunks.forEach((subArray) => {
        const updateBatch = db.batch();
        subArray.forEach((element) => {
          updateBatch.set(clientContactCollection.doc(element.id), element.obj, {
            merge: true,
          });
        });
        updateBatch.commit();
      });

      console.log(`🟢 Update data upload complete, ${totalContactsUpdated} contacts updated`);
    },
  };

  // Read via fs:
  const file = await fs.createReadStream(csvFilePath);
  await Papa.parse(file, config);
}

export async function addCRMLinkedInURLsOnlyToClientData(companyName: string, csvFileName: string): Promise<void> {
  // let csvFilePath = "functions/utils/crm_data/" + csvFileName;
  const csvFilePath = path.join(__dirname, 'crm_data/') + csvFileName + '.csv';
  console.log('Path:', path.join(__dirname, 'crm_data/'));

  // Documentation: https://www.papaparse.com/docs#local-files
  const config = {
    delimiter: '', // auto-detect ","
    newline: '', // auto-detect "\r\n"

    complete: async (results: any): Promise<void> => {
      console.log('Number of Rows:', results.data.length);
      console.log('Columns:', results.data[0]);

      if (results.data.length < 2) {
        // No data in CSV besides header row.
        return;
      }
      const columnCount = results.data[0].length;

      const updateArray: any[] = [];

      let totalContactsUpdated = 0;
      // for (var i = 1; i < 5; i++) {
      for (let i = 1; i < results.data.length; i++) {
        // Start at 1 to skip the CSV title row "'Name', 'Title', 'Account', 'Email'"
        const contact = results.data[i];

        let email = ''; // email is first column
        let crmLinkedInURL = '';

        if (columnCount > 0) {
          email = contact[0];
        }

        if (columnCount > 1) {
          crmLinkedInURL = contact[1];
        }

        const clientContactRef = await clientContactCollection
          .where('email', '==', email)
          .where('clientName', '==', companyName)
          .get();

        clientContactRef.forEach((doc) => {
          if (doc.exists) {
            const obj = {
              crmData: {
                crmLinkedInURL: crmLinkedInURL,
              },
              dateUpdated: firestore.Timestamp.fromDate(new Date()),
            };
            console.log('updating', email);
            totalContactsUpdated = totalContactsUpdated + 1;
            updateArray.push({ obj, id: doc.id });
          }
        });
      }

      // Update batch
      // @ts-ignore
      const updateArrayChunks = chunk(updateArray, 400);
      updateArrayChunks.forEach((subArray) => {
        const updateBatch = db.batch();
        subArray.forEach((element) => {
          updateBatch.set(clientContactCollection.doc(element.id), element.obj, {
            merge: true,
          });
        });
        updateBatch.commit();
      });

      console.log(`🟢 Update data upload complete, ${totalContactsUpdated} contacts updated`);
    },
  };

  // Read via fs:
  const file = await fs.createReadStream(csvFilePath);
  await Papa.parse(file, config);
}

export async function addCurrentJobToClientData(companyName: string, csvFileName: string): Promise<void> {
  // let csvFilePath = "functions/utils/crm_data/" + csvFileName;
  const csvFilePath = path.join(__dirname, 'crm_data/') + csvFileName + '.csv';
  console.log('Path:', path.join(__dirname, 'crm_data/'));

  // Documentation: https://www.papaparse.com/docs#local-files
  const config = {
    delimiter: '', // auto-detect ","
    newline: '', // auto-detect "\r\n"
    // quoteChar: '"',
    // escapeChar: '"',
    // header: false,
    // transformHeader: undefined,
    // dynamicTyping: false,
    // preview: 0,
    // encoding: "",
    // worker: false,
    // comments: false,
    // step: undefined,
    complete: async (results: any): Promise<void> => {
      console.log('Number of Rows:', results.data.length);
      console.log('Columns:', results.data[0]);

      if (results.data.length < 2) {
        // No data in CSV besides header row.
        return;
      }
      const columnCount = results.data[0].length;

      // check to make sure client exists or not.
      const clientSnapshot = await clientsCollection.where('name', '==', companyName).get();

      let clientRef: any;

      const updateArray: any[] = [];
      const newUploadArray: any[] = [];

      console.log('clientSnapshot', clientSnapshot.empty);

      // if client exists keep the clientRef for the ID. Else make a new client
      if (clientSnapshot.empty) {
        clientsCollection
          // @ts-ignore
          .add({
            name: companyName,
            createdDate: firestore.Timestamp.fromDate(new Date()),
          })
          .then(() => {
            console.log('🥳 Successfully saved new client to DB:', companyName);
          });
      } else {
        clientSnapshot.forEach((doc) => {
          if (doc.exists) {
            clientRef = doc.ref;
            console.log('Company', companyName, 'already exists in client DB');
          }
        });
      }
      // for (var i = 1; i < 5; i++) {
      for (let i = 1; i < results.data.length; i++) {
        // Start at 1 to skip the CSV title row "'Name', 'Title', 'Account', 'Email'"
        const contact = results.data[i];

        let title = '';
        let account = '';
        let email = '';

        // Check if these fields exist because they might be blank or the column might not exist

        if (columnCount > 0) {
          email = contact[0];
        }
        if (columnCount > 1) {
          title = contact[1];
        }
        if (columnCount > 2) {
          account = contact[2];
        }

        // Save contact to DB
        // TODO(carina): Improve to use batching instead of single row creations:
        // https://stackoverflow.com/questions/46618601/how-to-create-update-multiple-documents-at-once-in-firestore

        const clientContactRef = await clientContactCollection
          .where('email', '==', email)
          .where('clientId', '==', clientRef.id)
          .get();

        if (clientContactRef.empty) {
          const obj = {
            currentJob: {
              companyName: account,
              title: title,
            },
            dateUpdated: firestore.Timestamp.fromDate(new Date()),
            dateCreated: firestore.Timestamp.fromDate(new Date()),
          };
          console.log('uploading', email);
          newUploadArray.push(obj);
        } else {
          clientContactRef.forEach((doc) => {
            if (doc.exists) {
              const obj = {
                currentJob: {
                  companyName: account,
                  title: title,
                },
                dateUpdated: firestore.Timestamp.fromDate(new Date()),
              };
              console.log('updating', email);
              updateArray.push({ obj, id: doc.id });

              // doc.ref
              //   .set(obj, { merge: true })
              //   .then((result) => {
              //     console.log(
              //       "🤡 Successfully updated contact_data for:",
              //       email
              //     );
              //   })
              //   .catch(function (error) {
              //     console.log("🛑 Error getting document:", error);
              //   });
            }
          });
        }
      }

      // Update batch
      if (updateArray.length > 0) {
        // @ts-ignore
        const updateArrayChunks = chunk(updateArray, 400);
        updateArrayChunks.forEach((subArray) => {
          const updateBatch = db.batch();
          subArray.forEach((element) => {
            updateBatch.set(clientContactCollection.doc(element.id), element.obj, {
              merge: true,
            });
          });
          updateBatch.commit();
        });
        console.log('🟢 Update data upload complete');
      }

      // upload new data batch
      // @ts-ignore
      const newUploadArrayChunks = chunk(newUploadArray, 400);
      newUploadArrayChunks.forEach((subArray) => {
        const newUploadBatch = db.batch();
        // // new data upload array

        subArray.forEach((obj) => {
          console.log('new upload', obj);
          newUploadBatch.set(clientContactCollection.doc(), obj);
        });
        newUploadBatch.commit();
      });

      console.log('🟢 New data upload complete');
    },
  };

  // Read via fs:
  const file = await fs.createReadStream(csvFilePath);
  await Papa.parse(file, config);

  // Not working to read CSV directly even with "download: true"
  // https://stackoverflow.com/questions/49752889/how-can-i-read-a-local-file-with-papa-parse
  // Papa.parse('crm_data/carina_test_1.csv', config);
}

export async function addCurrentJobToContactData(companyName: string, csvFileName: string): Promise<void> {
  // let csvFilePath = "functions/utils/crm_data/" + csvFileName;
  const csvFilePath = path.join(__dirname, 'crm_data/') + csvFileName + '.csv';
  console.log('Path:', path.join(__dirname, 'crm_data/'));

  // Documentation: https://www.papaparse.com/docs#local-files
  const config = {
    delimiter: '', // auto-detect ","
    newline: '', // auto-detect "\r\n"

    complete: async (results: any): Promise<void> => {
      console.log('Number of Rows:', results.data.length);
      console.log('Columns:', results.data[0]);

      if (results.data.length < 2) {
        // No data in CSV besides header row.
        return;
      }
      const columnCount = results.data[0].length;
      let totalCount = 0;
      // for (var i = 1; i < 5; i++) {
      for (let i = 1; i < results.data.length; i++) {
        // Start at 1 to skip the CSV title row "'Name', 'Title', 'Account', 'Email'"
        const contact = results.data[i];

        let contactDataId = ''; // email is first column
        let title = '';
        let account = '';

        if (columnCount > 0) {
          contactDataId = contact[0];
        }

        if (columnCount > 1) {
          title = contact[1];
        }
        if (columnCount > 2) {
          account = contact[2];
        }

        const contactDataRef = await contactDataCollection.doc(contactDataId);

        const contactDataContactExists = (await contactDataRef.get()).exists;

        if (contactDataContactExists) {
          await contactDataRef.set(
            {
              currentJob: {
                companyName: account,
                title: title,
              },
            },
            { merge: true }
          );
          console.log('updating contact data contact', contactDataId);
          totalCount = totalCount + 1;
          continue;
        }
      }

      console.log(`🟢 Update clientIds upload complete for ${companyName}, ${totalCount} rows updated`);
    },
  };

  // Read via fs:
  const file = await fs.createReadStream(csvFilePath);
  await Papa.parse(file, config);
}

export async function changeJobChangedFlagToTrue(companyName: string): Promise<void> {
  // use this formula ="'"&A1&"'"&","
  const emails = [
    'kai@earlybird.com',
    'tyu@venrock.com',
    'vince@initialized.com',
    'paola@hardwareclub.co',
    'kalee@trinityventures.com',
    'brandon@detroit.vc',
    'jana@brv.com',
    'polina@aqpsearch.com',
    'janice.louie@cshs.org',
    'juan@ret.vc',
    'dan@tpycapital.com',
    'olivia@joinef.com',
    'kim@forgoodventures.com',
    'sebastien@axavp.com',
    'ally@acme.vc',
    'dedina@omersventures.com',
    'kailin@polychain.capital',
    'nicole@compound.vc',
    'helen.gibney@humanventures.co',
  ];
  let totalCount = 0;

  console.log('company name', companyName);

  for (let i = 0; i < emails.length; i++) {
    console.log('email', emails[i], companyName);
    const clientContactDataQuery = await clientContactCollection
      .where('clientName', '==', companyName)
      .where('email', '==', emails[i])
      .get();

    if (clientContactDataQuery.size === 0) {
      console.log('could not find ', emails[i], ' in ', companyName);
    } else {
      clientContactDataQuery.forEach(async (doc) => {
        if (doc.exists) {
          await doc.ref
            .set(
              {
                jobChanged: true,
                dateUpdated: firestore.Timestamp.fromDate(new Date()),
              },
              { merge: true }
            )
            .then(() => {
              console.log('updating client contact data contact', emails[i]);
              totalCount = totalCount + 1;
            });
        } else {
          console.log('doc not found');
        }
      });
    }
  }

  console.log(`🟢 Update clientIds upload complete for ${companyName}, ${totalCount} rows updated`);
}

export async function moveLinkedInTitleAndCompanyToCurrentJob(
  companyName: string,
  allContacts: boolean
): Promise<void> {
  // use this formula ="'"&L42&"'"&","
  const contactDataIds = ['qnoO0KDgeGsCzUHRDkrh', 'uuq7R2Sa9who22K8ZDWa'];
  let totalCount = 0;

  console.log('company name', companyName);

  if (!allContacts) {
    for (let i = 0; i < contactDataIds.length; i++) {
      const contact = (await contactDataCollection.doc(contactDataIds[i]).get()).data();

      if (contact && contact.lastLinkedInData && contact.lastLinkedInData.currentJob && companyName !== '') {
        const title = contact.lastLinkedInData.currentJob.title;
        const companyName = contact.lastLinkedInData.currentJob.companyName;
        const currentJob = {
          title,
          companyName,
        };
        if (contact?.allJobs) {
          const updatedJobsArray = contact.allJobs;
          if (!areJobsEqual(currentJob, contact.allJobs[contact.allJobs.length - 1])) {
            // If new job detected, append the new job to the contact and flag the contact.
            updatedJobsArray.push({
              companyName,
              title,
              lastUpdated: firestore.Timestamp.fromDate(new Date()),
            });
          }

          await contactDataCollection
            .doc(contactDataIds[i])
            .set(
              {
                allJobs: updatedJobsArray,
                currentJob: [
                  {
                    companyName,
                    title,
                    lastUpdated: firestore.Timestamp.fromDate(new Date()),
                  },
                ],
              },
              { merge: true }
            )
            .then(() => {
              console.log('🟢 Updated CurrentJob', contactDataIds[i]);
              totalCount = totalCount + 1;
            });
        } else {
          // if there is no allJobs field present
          console.log('🟢 Created CurrentJob', contactDataIds[i]);
          await addAllJobsUpdateCurrentJobInContactData(contactDataCollection, contactDataIds[i], companyName, title);
        }
      } else {
        console.log('🛑 No contact or lastLinkedInData');
      }
    }
  } else {
    console.log('get here');
    const contactDataQuery = await contactDataCollection
      .where('clientNames', 'array-contains-any', [companyName])
      .get();

    if (contactDataQuery.size === 0) {
      console.log('🛑 could not find ', companyName);
    } else {
      contactDataQuery.forEach(async (doc) => {
        if (doc.exists) {
          const contact = doc.data();
          console.log('conttt', contact);

          if (contact && contact.lastLinkedInData && contact.lastLinkedInData.currentJob && companyName !== '') {
            const title = contact.lastLinkedInData.currentJob.title;
            const companyName = contact.lastLinkedInData.currentJob.companyName;
            const currentJob = {
              title,
              companyName,
            };
            if (contact?.allJobs) {
              const updatedJobsArray = contact.allJobs;
              if (!areJobsEqual(currentJob, contact.allJobs[contact.allJobs.length - 1])) {
                // If new job detected, append the new job to the contact and flag the contact.
                updatedJobsArray.push({
                  companyName,
                  title,
                  lastUpdated: firestore.Timestamp.fromDate(new Date()),
                });
              }

              await contactDataCollection.doc(doc.id).set(
                {
                  allJobs: updatedJobsArray,
                  currentJob: [
                    {
                      companyName,
                      title,
                      lastUpdated: firestore.Timestamp.fromDate(new Date()),
                    },
                  ],
                },
                { merge: true }
              );
              console.log('🟢 Updated CurrentJob');
              totalCount = totalCount + 1;
            } else {
              // if there is no allJobs field present
              console.log('🟢 Created CurrentJob');
              await addAllJobsUpdateCurrentJobInContactData(contactDataCollection, doc.id, companyName, title);
            }
          } else {
            console.log('🛑 No contact or lastLinkedInData', doc.id);
          }
        } else {
          console.log('doc not found');
        }
      });
    }
  }
  console.log(`🟢 Update clientIds upload complete for ${companyName}, ${totalCount} rows updated`);
}
