import https from 'https';
import { firestore } from 'firebase-admin';
import {
  createContactDataContactFromClientData,
  peopleDataLabsError,
  updateClientContactById,
} from '../controllers/firestore';
import { extractLinkedInIdFromUrl, getCurrentTimestamp, addhttps } from '../utils/functions';

const keepAliveAgent = new https.Agent({ keepAlive: true });
const peopleDataLabsToken = process.env.PEOPLEDATALABS_API;

const peopleDataLabsRetryLimit = 2;

function sleep(milliseconds: number): void {
  const date = Date.now();
  let currentDate = null;
  do {
    currentDate = Date.now();
  } while (currentDate - date < milliseconds);
}

export const createContactData = async (contact: ClientContact, tryCount = 0): Promise<undefined> => {
  if (tryCount >= peopleDataLabsRetryLimit) {
    console.log(
      '🛑 Exit People Data Labs - Tried hitting People Data Labs more than 10 times',
      contact.id,
      contact.email
    );

    // Store for manual QA. Likely bad LinkedIn URL or rate limit exceeded error leading to retries
    peopleDataLabsError(contact.id, `People Data Labs retry limit ${peopleDataLabsRetryLimit} exceeded`);

    return;
  }
  console.log('👁 Sending People Data Labs Request for ', contact.id, contact.email);
  console.log('try Count', tryCount);

  console.log('email of', contact.email);

  const options = {
    hostname: 'api.peopledatalabs.com',
    path: `/v4/person?pretty=true&api_key=${peopleDataLabsToken}&email=${encodeURIComponent(
      contact.email || ''
    )}&profile=${encodeURIComponent(contact.crmData?.crmLinkedIn || '')}&company=${encodeURIComponent(
      contact.currentJob?.companyName || ''
    )}&first_name=${encodeURIComponent(contact.firstName || '')}&last_name=${encodeURIComponent(
      contact.lastName || ''
    )}&required=${encodeURIComponent('profiles.network:linkedin AND experience')}`,
    agent: keepAliveAgent,
  };

  sleep(100);

  try {
    https
      .request(options, (response) => {
        let body = '';
        console.log('response status code', response.statusCode, typeof response.statusCode);

        if (response.statusCode === 404) {
          console.log('🛑 response code 404 received, couldnt pull profile', response.statusCode);
          peopleDataLabsError(contact.id, `404 Error - People Data Labs couldnt pull profile`);
        }

        if (response.statusCode === 502) {
          console.log('🛑 response code 502 received, couldnt pull profile', response.statusCode);
          peopleDataLabsError(contact.id, `502 Error - People Data Labs couldnt pull profile`);
        }

        // ran into rate limit exceeded, retry request
        if (response.statusCode === 429) {
          console.log('🛑 response code 429 received', response.statusCode);
          createContactData(contact, tryCount + 1);
          return;
        }

        // handle error our DNS tiems out when we try to ping it. So run up against proxycrawl API dnot found. Handle this error on alert or exception
        // or retry the request like a 429.

        response
          .on('data', (chunk) => (body += chunk))
          .on('end', async () => {
            const result = JSON.parse(body);

            const data = result.data;
            const primary = data.primary;

            const linkedInURL = addhttps(data.primary.linkedin || '');

            let companyName = '';
            let title = '';
            let companySize = '';
            let titleLevel = '';
            let startDate = '';
            let endDate = '';
            const emails: any = [];

            if (contact.email) {
              emails.push(contact.email);
            }

            if (primary.job && primary.job.company) {
              companyName = primary.job.company?.name || '';
              companySize = primary.job.company.size || '';
              startDate = primary.job.company.start_date || '';
              endDate = primary.job.company.end_date || '';
              title = primary.job.title?.name || '';
              titleLevel = primary.job.title?.levels || '';
            }

            if (data.emails) {
              emails.concat(data.emails);
            }

            if (linkedInURL) {
              if (linkedInURL && linkedInURL !== '') {
                // verified LinkedIn URL already exists so just create contact and return

                const linkedInId = extractLinkedInIdFromUrl(linkedInURL);
                const newContactDataObj = {
                  ...(contact.email && {
                    emailData: [
                      {
                        email: contact.email,
                        dateCreated: getCurrentTimestamp(),
                        source: 'CRM',
                      },
                    ],
                  }),
                  clientId: contact.clientId,
                  clientName: contact.clientName,
                  email: emails,
                  firstName: contact.firstName || '',
                  lastName: contact.lastName || '',
                  linkedInURL: linkedInURL || contact.linkedInURL,
                  linkedInId,
                  peopleDataLabsData: {
                    dateCreated: getCurrentTimestamp(),
                    currentJob: {
                      companyName,
                      lastUpdated: getCurrentTimestamp(),
                      title,
                      companySize,
                      titleLevel,
                      startDate,
                      endDate,
                    },
                    workExperience: [
                      {
                        companyName,
                        title,
                        lastUpdated: firestore.Timestamp.fromDate(new Date()),
                        companySize,
                        titleLevel,
                        startDate,
                        endDate,
                      },
                    ],
                  },
                };
                console.log('People Data Labs upload object', newContactDataObj);
                await createContactDataContactFromClientData(contact.id, newContactDataObj);

                await updateClientContactById(contact.id, { linkedInURL });
                return;
              }
            }
          });
      })
      .end();
  } catch (e) {
    console.log('Https Request Error for People Data labs', e);
    createContactData(contact, tryCount + 1);
  }
  return;
};
