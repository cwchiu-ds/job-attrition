import { areJobsEqual } from '../utils/helperFunctions/checkJobChangesHelperFunctions';
import {
  updateClientContactById,
  getClientDataContactsByContactDataId,
} from '../controllers/firestore';

export const updateEnrichedDataChangedFlagIfCurrentJobDiffBetweenClientAndContactData = async (
  contactDataId: string,
  lastLinkedInData: LastLinkedInData
): Promise<undefined> => {
  // get client contacts and compare against recently scraped jobObject
  const clientContacts = await getClientDataContactsByContactDataId(
    contactDataId
  );

  clientContacts.forEach((clientContact) => {
    if (!areJobsEqual(clientContact.currentJob, lastLinkedInData.currentJob)) {
      console.log(
        '⭐️ Found Client_Data and Contact_Data Diff',
        clientContact.currentJob,
        lastLinkedInData.currentJob
      );
      // @ts-ignore
      updateClientContactById(clientContact.id!, { enrichedDataChanged: true });
    }
  });

  return;
};
