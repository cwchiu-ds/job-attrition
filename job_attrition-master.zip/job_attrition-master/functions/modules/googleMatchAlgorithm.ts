import fuzz from 'fuzzball';
import { firestore } from 'firebase-admin';
import {
  createContactDataContactFromClientData,

  // updateClientContactById
} from '../controllers/firestore';
import { extractLinkedInIdFromUrl } from '../utils/functions';

export const exactMatch = (
  name: string,
  detectedName: string,
  companyName: string,
  detectedCompanyName: string,
  title: string,
  detectedTitle: string
): boolean => {
  if (
    name === detectedName &&
    companyName === detectedCompanyName &&
    title === detectedTitle &&
    title !== '' &&
    companyName !== ''
  ) {
    return true;
  } else {
    return false;
  }
};

// name and company hard match, title soft match
export const nameCompanyTitleSoftMatch = (
  name: string,
  detectedName: string,
  companyName: string,
  detectedCompanyName: string,
  title: string,
  detectedTitle: string
): [boolean, number] => {
  // check name and company exact match
  if (name == detectedName && companyName == detectedCompanyName && companyName != '') {
    const ratio = fuzz.token_set_ratio(title, detectedTitle);
    return [true, ratio];
  } else {
    return [false, 0];
  }
};

export const nameCompanySoftMatchTitleSoftMatch = (
  name: string,
  detectedName: string,
  companyName: string,
  detectedCompanyName: string,
  title: string,
  detectedTitle: string
): [boolean, number, number] => {
  // check name exact match

  if (name == detectedName) {
    const ratioTitle = fuzz.token_set_ratio(title, detectedTitle);
    const ratioCompany = fuzz.token_set_ratio(companyName, detectedCompanyName);

    return [true, ratioCompany, ratioTitle];
  }
  return [false, 0, 0];
};

export const nameSoftMatchCompanySoftMatchTitleSoftMatch = (
  name: string,
  detectedName: string,
  companyName: string,
  detectedCompanyName: string,
  title: string,
  detectedTitle: string
): [boolean, number, number, number] => {
  // check soft match name, company, title

  const ratioName = fuzz.token_set_ratio(JSON.stringify(name), JSON.stringify(detectedName));
  const ratioTitle = fuzz.token_set_ratio(title, detectedTitle);
  const ratioCompany = fuzz.token_set_ratio(companyName, detectedCompanyName);

  return [true, ratioName, ratioCompany, ratioTitle];
};

export const matchAlgorithm = (
  name: string,
  detectedName: string,
  companyName: string,
  detectedCompanyName: string,
  title: string,
  detectedTitle: string
): string => {
  name = name.toLowerCase().trim();
  detectedName = detectedName.toLowerCase().trim();
  companyName = companyName.toLowerCase().trim();
  detectedCompanyName = detectedCompanyName.toLowerCase().trim();
  title = title.toLowerCase().trim();
  detectedTitle = detectedTitle.toLowerCase().trim();

  // return if 1 else end function
  let notReturned = 1;

  // Run Match Algorithm
  if (exactMatch(name, detectedName, companyName, detectedCompanyName, title, detectedTitle)) {
    notReturned = 0;
    return 'A1';
  }

  const nameCompanyTitleSoftMatchResult = nameCompanyTitleSoftMatch(
    name,
    detectedName,
    companyName,
    detectedCompanyName,
    title,
    detectedTitle
  );
  if (nameCompanyTitleSoftMatchResult[0] && notReturned == 1) {
    notReturned = 0;
    const ratio = nameCompanyTitleSoftMatchResult[1];
    if (ratio > 80) return 'A2';
    if (ratio > 60) return 'A3';
    if (ratio > 30) return 'B1';
    if (ratio >= 0) return 'B2';
  }

  const nameCompanySoftMatchTitleSoftMatchResult = nameCompanySoftMatchTitleSoftMatch(
    name,
    detectedName,
    companyName,
    detectedCompanyName,
    title,
    detectedTitle
  );
  if (nameCompanySoftMatchTitleSoftMatchResult[0] && notReturned == 1) {
    const ratioCompany = nameCompanySoftMatchTitleSoftMatchResult[1];
    const ratioTitle = nameCompanySoftMatchTitleSoftMatchResult[2];
    notReturned = 0;
    if (ratioCompany > 80) {
      if (ratioTitle > 80) return 'A2';
      if (ratioTitle > 60) return 'A3';
      if (ratioTitle > 20) return 'B1';
      if (ratioTitle >= 0) return 'B2';
    }
    if (ratioCompany > 60) {
      if (ratioTitle > 80) return 'A3';
      if (ratioTitle > 60) return 'B1';
      if (ratioTitle > 20) return 'B2';
      if (ratioTitle >= 0) return 'B3';
    }
    if (ratioCompany > 30) {
      if (ratioTitle > 80) return 'B1';
      if (ratioTitle > 60) return 'B2';
      if (ratioTitle > 20) return 'B3';
      if (ratioTitle >= 0) return 'C1';
    }
    if (ratioCompany >= 0) {
      if (ratioTitle > 80) return 'C1';
      if (ratioTitle > 60) return 'C2';
      if (ratioTitle > 20) return 'C3';
      if (ratioTitle >= 0) return 'D1';
    } else return 'F';
  }

  const nameSoftMatchCompanySoftMatchTitleSoftMatchResult = nameSoftMatchCompanySoftMatchTitleSoftMatch(
    name,
    detectedName,
    companyName,
    detectedCompanyName,
    title,
    detectedTitle
  );
  if (nameSoftMatchCompanySoftMatchTitleSoftMatchResult[0] && notReturned == 1) {
    const ratioName = nameSoftMatchCompanySoftMatchTitleSoftMatchResult[1];
    const ratioCompany = nameSoftMatchCompanySoftMatchTitleSoftMatchResult[2];
    const ratioTitle = nameSoftMatchCompanySoftMatchTitleSoftMatchResult[3];

    notReturned = 0;

    if (ratioName > 80) {
      if (ratioCompany > 80) {
        if (ratioTitle > 80) return 'A2';
        if (ratioTitle > 60) return 'B1';
        if (ratioTitle > 20) return 'B2';
        if (ratioTitle >= 0) return 'B3';
      }
      if (ratioCompany > 60) {
        if (ratioTitle > 80) return 'A3';
        if (ratioTitle > 60) return 'B1';
        if (ratioTitle > 20) return 'B2';
        if (ratioTitle >= 0) return 'B3';
      }
      if (ratioCompany > 30) {
        if (ratioTitle > 80) return 'B1';
        if (ratioTitle > 60) return 'B2';
        if (ratioTitle > 20) return 'B3';
        if (ratioTitle >= 0) return 'C1';
      }
      if (ratioCompany >= 0) {
        if (ratioTitle > 80) return 'B2';
        if (ratioTitle > 60) return 'B3';
        if (ratioTitle > 20) return 'C1';
        if (ratioTitle >= 0) return 'C2';
      }
    }
    if (ratioName > 60) {
      if (ratioCompany > 80) {
        if (ratioTitle > 80) return 'A3';
        if (ratioTitle > 60) return 'B1';
        if (ratioTitle > 20) return 'B2';
        if (ratioTitle >= 0) return 'B3';
      }
      if (ratioCompany > 60) {
        if (ratioTitle > 80) return 'B1';
        if (ratioTitle > 60) return 'B2';
        if (ratioTitle > 20) return 'B3';
        if (ratioTitle >= 0) return 'C1';
      }
      if (ratioCompany > 30) {
        if (ratioTitle > 80) return 'B2';
        if (ratioTitle > 60) return 'B3';
        if (ratioTitle > 20) return 'C1';
        if (ratioTitle >= 0) return 'C2';
      }
      if (ratioCompany >= 0) {
        if (ratioTitle > 80) return 'B3';
        if (ratioTitle > 60) return 'C1';
        if (ratioTitle > 20) return 'C2';
        if (ratioTitle >= 0) return 'C3';
      }
    } else {
      return 'F';
    }
  } else {
    return 'F';
  }
  return 'F';
};

export const parseGoogleSearchTitle = (title: string): GoogleTitleParsedObject => {
  let titleSplit = [];
  let jobTitle = '';
  let companyName = '';
  let location = '';
  const titleArray = title.split('-');
  const titleArrayTwo = title.split('–');
  if (titleArray.length > titleArrayTwo.length) {
    titleSplit = titleArray;
  } else {
    titleSplit = titleArrayTwo;
  }

  const titleLength = titleSplit.length;

  if (titleLength === 2) {
    jobTitle = titleSplit[1];
    location = titleSplit[1];
  } else if (titleLength === 3) {
    jobTitle = titleSplit[1];
    companyName = titleSplit[2];
  } else if (titleLength === 4) {
    jobTitle = titleSplit[1] + '-' + titleSplit[2];
    companyName = titleSplit[3];
  } else if (titleLength >= 4) {
    companyName = titleSplit[titleLength - 1];
  } else {
    console.log('🛑 No dashes in Google Title');
  }

  const obj = {
    name: titleSplit[0].trim(),
    jobTitle: jobTitle.trim(),
    companyName: companyName.trim(),
    titleLength: titleLength,
    location: location.trim(),
  };

  return obj;
};

export const calculateMatchScoreGoogleSearchResults = (contacts: ClientContact[]): undefined => {
  contacts.map((contact) => {
    // Start at "F" for highest score, should only go up

    if (contact.linkedInURL && contact.linkedInURL !== '') {
      // verified LinkedIn URL already exists so just create contact and return
      const linkedInId = extractLinkedInIdFromUrl(contact.linkedInURL);
      const newContactDataObj = {
        ...(contact.email && {
          emailData: [
            {
              email: contact.email,
              dateCreated: firestore.Timestamp.fromDate(new Date()),
              source: 'CRM',
            },
          ],
        }),
        clientId: contact.clientId,
        clientName: contact.clientName,
        email: contact.email,
        firstName: contact.firstName || '',
        lastName: contact.lastName || '',
        linkedInURL: contact.linkedInURL,
        linkedInId,
        currentJob: {
          companyName: contact.currentJob?.companyName || '',
          title: contact.currentJob?.title || '',
        },
      };
      createContactDataContactFromClientData(contact.id, newContactDataObj);
      return;
    } else {
      console.log('🛑 No LinkedIn URL so skip for now, later you can use Google Search Algo to proxy LI URL');
      return;
    }

    // let highestScore = 'F';

    // const crmName = contact.fullName || '';
    // const crmCompanyName = contact.currentJob?.companyName || '';
    // const crmJobTitle = contact.currentJob?.title || '';

    // console.log(crmName, crmCompanyName, crmJobTitle);

    // let highestScoreObject: HighestScoreObject = {};
    // let highestLinkedInURL = '';

    // if ('initialGoogleSearch' in contact) {
    //   const googleResults = contact.initialGoogleSearch?.topThreeSearchResults;

    //   googleResults?.map((result) => {
    //     const googleTitle = result.title
    //       .replace('...', '')
    //       .replace('Professional', '')
    //       .replace('|', '')
    //       .replace('Profile', '')
    //       .replace('LinkedIn', '')
    //       .replace("- We're Hiring -", '')
    //       .replace("- We're hiring -", '')
    //       .replace("We're hiring", '')
    //       .replace("We're Hiring", '')
    //       .trim();
    //     const titleParseResults = parseGoogleSearchTitle(googleTitle);
    //     const parsedTitleLength = titleParseResults.titleLength;
    //     const parsedName = titleParseResults.name;
    //     const parsedJobTitle = titleParseResults.jobTitle;
    //     const parsedCompanyName = titleParseResults.companyName;
    //     const parsedLocation = titleParseResults.location;
    //     const linkedInURL = result.linkedInURL;

    //     console.log(
    //       'results',
    //       parsedTitleLength,
    //       parsedName,
    //       parsedJobTitle,
    //       parsedCompanyName,
    //       parsedLocation,
    //       linkedInURL
    //     );

    //     const weightedScore = matchAlgorithm(
    //       crmName,
    //       parsedName,
    //       crmCompanyName,
    //       parsedCompanyName,
    //       crmJobTitle,
    //       parsedJobTitle
    //     );

    //     console.log(
    //       'weighted score',
    //       weightedScore,
    //       crmName,
    //       parsedName,
    //       crmCompanyName,
    //       parsedCompanyName,
    //       crmJobTitle,
    //       parsedJobTitle,
    //       weightedScore,
    //       highestScore,
    //       weightedScore < highestScore
    //     );

    //     result.score = weightedScore;

    //     if (weightedScore < highestScore) {
    //       highestScore = weightedScore;
    //       highestLinkedInURL = linkedInURL;
    //       highestScoreObject = {
    //         highestScore,
    //         googleSearchResult: result,
    //         parsedName: parsedName.replace('|', '').trim(),
    //         parsedTitle: parsedJobTitle.replace('|', '').trim(),
    //         parsedCompanyName: parsedCompanyName.replace('|', '').trim(),
    //         parsedLocation: parsedLocation.replace('|', '').trim(),
    //       } as HighestScoreObject;
    //     }
    //   });
    //   console.log('final score', highestScoreObject);
    //   console.log('google search result', googleResults);

    //   // check if highest score google search query meets threshold
    //   const checkThreshold =
    //     highestLinkedInURL !== '' && highestScoreObject.highestScore && highestScoreObject.highestScore < 'B1';

    //   const linkedInId = extractLinkedInIdFromUrl(highestLinkedInURL);

    //   // Only write back LinkedInURL if the score is A or above

    //   const obj = {
    //     ...contact,
    //     ...(checkThreshold && {
    //       linkedInURL: highestLinkedInURL,
    //     }),
    //     initialGoogleSearch: {
    //       ...contact.initialGoogleSearch,
    //       topThreeSearchResults: googleResults,
    //       highestScoreObject,
    //     },
    //   };

    //   updateClientContactById(contact.id, obj as ClientContact);

    //   // if google search score meets threshold, and contactData not created, create a new contactId
    //   if (!contact.contactDataId) {
    //     const newContactDataObj = {
    //       ...(contact.email && {
    //         emailData: [
    //           {
    //             email: contact.email,
    //             dateCreated: firestore.Timestamp.fromDate(new Date()),
    //             source: 'CRM',
    //           },
    //         ],
    //       }),
    //       clientId: contact.clientId,
    //       clientName: contact.clientName,
    //       email: contact.email,
    //       firstName: contact.firstName || '',
    //       lastName: contact.lastName || '',
    //       fullName: contact.fullName || '',
    //       linkedInURL: highestLinkedInURL,
    //       linkedInId,
    //       currentJob: {
    //         companyName: contact.currentJob?.companyName,
    //         title: contact.currentJob?.title,
    //       },
    //     };
    //     console.log('new contact data obj', newContactDataObj);

    //     // you need to check if contact data for this client data contact exists arleady. If so then just append the right contactId to client data contact
    //     createContactDataContactFromClientData(contact.id, newContactDataObj);
    //   }
    // }
    // console.log('LinkedIn URL exists and contactDataId appended', contact.linkedInURL, contact.email);
  });

  console.log('🟢 Google Match Algorithm Completed');

  return;
};
