import { NextFunction } from 'express';
import { ValidationError } from 'express-validation';
import { Request, Response } from 'firebase-functions';

import { HTTP_RESPONSE } from '../utils/constants';
import { getAuthenticatedUID } from './authentication';

export const firebaseAuthMiddleware = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  const authUID = await getAuthenticatedUID(req);

  if (!authUID) {
    console.log('Unauthenticated request', req.headers);
    res.sendStatus(HTTP_RESPONSE.FORBIDDEN);
    return;
  }

  (req as Request<AuthenticatedParams>).params.authUID = authUID;

  return next();
};

export const validationErrorMiddleware = (err: Error, req: Request, res: Response, next: NextFunction): void => {
  if (err instanceof ValidationError) {
    res.status(err.statusCode).json(err);
    return;
  }

  return next();
};
