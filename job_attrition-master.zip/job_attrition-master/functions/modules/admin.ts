import faker from 'faker';
import admin from 'firebase-admin';
import { chunk } from 'lodash';
import {
  addContactData,
  getContactDataByContactDataId,
  getDocumentById,
  getDocumentsByField,
  updateDocumentsUsingMerge,
  updateDocumentsWithoutMerge,
} from '../controllers/firestore';
import { sendToEngineeringErrorsSlack } from '../controllers/slack';
import { ClientContactField, ClientInternalField, COLLECTION } from '../utils/constants';
import { extractLinkedInIdFromUrl, getCurrentTimestamp } from '../utils/functions';

export const generateJobChangesForRandomContacts = async (client: Client): Promise<void> => {
  // Generate job changes for up to 10 client contacts
  const clientContacts = await getDocumentsByField<ClientContact>({
    collection: COLLECTION.CLIENT_CONTACTS,
    field: ClientContactField.CLIENT_ID,
    operation: '==',
    fieldValue: client.id,
    limit: 10,
  });

  const updatedClientContacts: WithId<Partial<ClientContact>>[] = [];

  await Promise.all(clientContacts.map(async (clientContact) => {
    const randomNewCompany = `${faker.company.companyName()}`;
    const randomNewJobTitle = `${faker.name.jobTitle()}`;
    let linkedInURL = '';
    let linkedInId = '';
    let contactDataId = clientContact.contactDataId;
    let contactData = clientContact.contactData;

    if (contactDataId) {
      const existingContactData = await getContactDataByContactDataId(contactDataId);

      if (!existingContactData) {
        throw new Error('No contact data found for contactDataId ' + contactDataId);
      }

      linkedInURL = existingContactData.linkedInURL
        ? existingContactData.linkedInURL
        : `https://www.linkedin.com/in/${faker.random.uuid()}/`;

      linkedInId = extractLinkedInIdFromUrl(linkedInURL);

      const updatedContactData: Partial<ContactData> = {
        linkedInURL,
        linkedInId,
        currentJob: [
          {
            companyName: randomNewCompany,
            title: randomNewJobTitle,
            lastUpdated: getCurrentTimestamp(),
          },
        ],
        allJobs: [
          {
            companyName: randomNewCompany,
            title: randomNewJobTitle,
            lastUpdated: getCurrentTimestamp(),
          },
          ...(existingContactData.allJobs || []),
        ],
      };

      await updateDocumentsUsingMerge<ContactData>(COLLECTION.CONTACT_DATA, [
        { ...updatedContactData, id: existingContactData.id },
      ]);
    } else {
      linkedInURL = clientContact.linkedInURL
        ? clientContact.linkedInURL
        : `https://www.linkedin.com/in/${faker.random.uuid()}_NEW/`;

      linkedInId = extractLinkedInIdFromUrl(linkedInURL);

      const newContactData = {
        firstName: clientContact.firstName || faker.name.firstName(),
        lastName: clientContact.lastName || faker.name.lastName(),
        clientIds: [client.id],
        clientNames: [client.name],
        linkedInURL,
        linkedInId,
        currentJob: [
          {
            companyName: randomNewCompany,
            title: randomNewJobTitle,
            lastUpdated: getCurrentTimestamp(),
          },
        ],
        allJobs: [
          {
            companyName: randomNewCompany,
            title: randomNewJobTitle,
            lastUpdated: getCurrentTimestamp(),
          },
        ],
      } as Partial<ContactData>;
      const newlyCreatedContactData = await addContactData(newContactData);
      contactDataId = newlyCreatedContactData.id;
      contactData = newContactData as ContactData;
    }

    updatedClientContacts.push({ id: clientContact.id, jobChanged: true, linkedInURL, linkedInId, contactDataId, contactData });
  }))

  await updateDocumentsUsingMerge<ClientContact>(COLLECTION.CLIENT_CONTACTS, updatedClientContacts);

  return;
};

export const denormalizeContactData = async (client: Client): Promise<void> => {
  // NOTE: Important - do not use a custom orderBy for this query, we rely on the default order (which is by id, ascending)
  // to set up QA blocks
  const clientContacts = await getDocumentsByField<ClientContact>({
    collection: COLLECTION.CLIENT_CONTACTS,
    field: ClientContactField.CLIENT_ID,
    operation: '==',
    fieldValue: client.id,
  });

  // We only update client contacts that already have contact data
  const clientContactsToBeUpdated = clientContacts.filter((contact) => contact.contactDataId);

  // We get all the contactData at the same time
  const updatedClientContacts: Partial<ClientContact> & { id: string }[] = await Promise.all(
    clientContactsToBeUpdated.map((clientContact) => {
      return getDocumentById<ContactData>(COLLECTION.CONTACT_DATA, clientContact.contactDataId!).then((contactData) => {
        if (!contactData) {
          sendToEngineeringErrorsSlack(
            `🚨 Error: unable to find contactData (id: ${clientContact.id}) for client contact (id: ${clientContact.id})`
          );

          return { id: clientContact.id, contactData: null };
        } else {
          return { id: clientContact.id, contactData };
        }
      });
    })
  );

  // Update client contacts with the latest contact data
  await updateDocumentsWithoutMerge<ClientContact>(COLLECTION.CLIENT_CONTACTS, updatedClientContacts);

  const clientContactBlocks: Block = {};

  // To enable QA in Bangladesh to load data in a reasonable time, we divide client contacts into blocks of 200
  const clientContactChunks = chunk(clientContacts, 200);

  for (let block = 0; block < clientContactChunks.length; block++) {
    const currentBlock = clientContactChunks[block];
    const firstClientContactForThisBlock = currentBlock[0];

    // For ease of communication with QA, we start the block count from 1 instead of zero
    clientContactBlocks[block + 1] = {
      startAtId: firstClientContactForThisBlock.id,
      blockSize: currentBlock.length,
    };
  }

  // We also update the client internal data to reflect the denormalization date
  await updateDocumentsUsingMerge<ClientInternal>(COLLECTION.CLIENT_INTERNAL, [
    { id: client.id, [ClientInternalField.CONTACTS_DENORMALIZATION_DATE]: getCurrentTimestamp() },
  ]);

  // We also update the client internal data to reflect the denormalization date
  // We do NOT use merge, because we want to override the clientContactBlocks field completely
  await updateDocumentsWithoutMerge<Client>(COLLECTION.CLIENTS, [{ id: client.id, clientContactBlocks }]);

  return;
};

export const deleteAuthUsers = (authUserIds: string[]): Promise<void[]> => {
  return Promise.all(
    authUserIds.map((uid) => {
      return admin
        .auth()
        .deleteUser(uid)
        .catch((err) => console.error(err));
    })
  );
};
