import { Request } from 'firebase-functions';
import { firebaseAuth } from '../controllers/authentication';
import admin from '../config/firebaseConfig';

export const getAuthenticatedUID = async (req: Request): Promise<string | undefined> => {
  let authUID;

  try {
    if (req.headers.authorization && req.headers.authorization.startsWith('Bearer ')) {
      const authToken = req.headers.authorization.split('Bearer ')[1];

      if (authToken) {
        authUID = await firebaseAuth
          .verifyIdToken(authToken)
          .then((decodedToken) => decodedToken.uid);
      }
    }
  } catch (err) {
    console.error(err);
  } finally {
    return authUID;
  }
};

export const generateEmailSignInLink = (email: string, actionCodeSettings: admin.auth.ActionCodeSettings): Promise<string> => {
  return firebaseAuth.generateSignInWithEmailLink(email, actionCodeSettings)
}