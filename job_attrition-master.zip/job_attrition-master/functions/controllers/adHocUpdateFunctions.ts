import { db } from '../controllers/firestore';

const clientContactsCollection = db.collection('client_contacts');

export const updateAllClientData = async (): Promise<void> => {
  const clientContactsQuerySnapshot = await clientContactsCollection.get();

  clientContactsQuerySnapshot.forEach(async (doc) => {
    const contact: Partial<ClientContact> = doc.data();

    if (contact.dateUpdated) {
      console.log('already has contact dateUpdated');
    } else {
      const batch = db.batch();
      batch.set(
        clientContactsCollection.doc(doc.id),
        { dateUpdated: new Date() },
        {
          merge: true,
        }
      );

      batch.commit();
      console.log('fixed date for ', contact.email);
    }
  });
};
