const path = require('path');

const admin = require('firebase-admin');

const SECRETS = path.resolve(__dirname, '../secrets');

const pathToKey = {
  ['production']: SECRETS + '/jobattrition-firebase-adminsdk-gc6d2-861d6e2361.json',
};

// @typescript/eslint prohibits the use of require but we need it to dynamically import the json
const serviceAccount = require(pathToKey['production']); // eslint-disable-line

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

const db = admin.firestore();
const collection = db.collection('contact_data');

const countDocuments = async () => {
  console.log('running');

  let count = 0;

  db.collection('contact_data')
    .select()
    .stream()
    .on('data', (snap) => {
      ++count;
    })
    .on('end', () => {
      console.log(`Total count is ${count}`);
    });
};

countDocuments();
