import jsforce, { MetadataInfo } from 'jsforce';

import { salesforceOAuth2 } from '../config/salesforce';
import { SalesforceObject, SalesforceCustomFieldName, SalesforceCustomFieldType } from '../utils/constants';
import { updateSalesforceAccessToken } from './firestore';

interface ProfileFieldLevelSecurity {
  editable: boolean;
  field: string;
  hidden?: boolean;
  readable: boolean;
}

interface SalesforceProfileMetadata extends jsforce.MetadataInfo {
  fieldPermissions: ProfileFieldLevelSecurity[];
}

export const getSfConnection = (client?: Client): jsforce.Connection => {
  const accessToken = client?.salesforceIntegration?.accessToken;
  const refreshToken = client?.salesforceIntegration?.refreshToken;
  const instanceUrl = client?.salesforceIntegration?.instanceUrl;

  const sfConnection = new jsforce.Connection({ oauth2: salesforceOAuth2, instanceUrl, accessToken, refreshToken });

  // Set callback for if accessToken is refreshed
  if (client) {
    sfConnection.on('refresh', (accessToken: string) => {
      // Refresh event will be fired when accessToken is renewed, in which case we'll replace
      // the old accessToken
      if (accessToken) {
        updateSalesforceAccessToken(client.id, accessToken);
      }
    });
  }

  return sfConnection;
};

// Salesforce types: https://help.salesforce.com/articleView?id=custom_field_types.htm&type=5
export const createCustomSalesforceContactField = async (
  client: Client,
  customField: SalesforceCustomFieldData
): Promise<void> => {
  const sfConnection = getSfConnection(client);

  const fullName = `${SalesforceObject.CONTACT}.${customField.name}`;

  const metadata: MetadataInfo & { [key: string]: string | number | boolean } = {
    fullName,
    label: customField.label,
    type: customField.fieldType,
    description: customField.description,
  };

  if (customField.length !== undefined) {
    metadata['length'] = customField.length;
  }

  if (customField.defaultValue !== undefined) {
    metadata['defaultValue'] = customField.defaultValue;
  }

  // https://developer.salesforce.com/docs/atlas.en-us.api_meta.meta/api_meta/customfield.htm
  await sfConnection.metadata
    .create('CustomField', metadata)
    .then((res) => {
      // If creating the custom field failed, we throw an error to stop the entire process
      if (!(res as jsforce.SaveResult).success) {
        throw res;
      }
    })
    .catch((err) => {
      // If this errors out because there's an existing field with that name, we ignore the error
      // and just continue with using that field. Otherwise, we throw that error
      if (err.errors.statusCode !== 'DUPLICATE_DEVELOPER_NAME') {
        throw err;
      }
    });

  // Once custom field is created, we need to set it to be readable for all profiles
  // so they can show up in Salesforce's web UI

  // This gets a list of references to all Profiles (not the actual Profiles themselves)
  const allProfilesList = await sfConnection.metadata.list([{ type: SalesforceObject.PROFILE }]);

  const updateProfilesPromises = [];

  // First we get the full Profile for each profile reference, then for each Profile we create
  // a Promise in which we update the field permission for the just created custom field
  for (const profileRef of allProfilesList) {
    updateProfilesPromises.push(
      sfConnection.metadata.read(SalesforceObject.PROFILE, [profileRef.fullName]).then((profile) => {
        const fieldPermissions = (profile as SalesforceProfileMetadata).fieldPermissions;

        const customFieldPermissions = fieldPermissions.find((fieldPermission) => {
          return fieldPermission.field == fullName;
        });

        if (customFieldPermissions) {
          customFieldPermissions.readable = true;
          customFieldPermissions.editable = true;
          customFieldPermissions.hidden = false;
        } else if (!customFieldPermissions) {
          fieldPermissions.push({
            editable: true,
            field: fullName,
            readable: true,
            hidden: false,
          });
        }

        return sfConnection.metadata
          .update(SalesforceObject.PROFILE, {
            fullName: (profile as SalesforceProfileMetadata).fullName,
            fieldPermissions,
          } as jsforce.MetadataInfo)
          .then((res) => {
            if (!(res as jsforce.SaveResult).success) {
              throw res;
            }
          });
      })
    );
  }

  await Promise.all(updateProfilesPromises);

  return;
};

export type UpdateSalesforceObjectData = {
  Id: string;
  [SalesforceCustomFieldName.JOB_CHANGED]?: boolean;
  [SalesforceCustomFieldName.LATEST_JOB_TITLE]?: string;
  [SalesforceCustomFieldName.LATEST_JOB_COMPANY]?: string;
  [SalesforceCustomFieldName.LATEST_LINKEDIN]?: string;
};

export const updateSalesforceObjects = (
  client: Client,
  sObject: SalesforceObject,
  updatedContacts: UpdateSalesforceObjectData[]
): Promise<jsforce.RecordResult[]> => {
  const sfConnection = getSfConnection(client);

  // Need to use recursive in case we are updating more than 200 records at a time
  // https://jsforce.github.io/document/#:~:text=There%20is%20a%20limit%20of,the%20request%20to%20process%20them.
  // @ts-ignore The @types/jsforce package is missing the allowRecursive option
  return sfConnection.sobject(sObject).update(updatedContacts, { allowRecursive: true });
};

// NOTE: we do not modify our clients' Layouts for them, but code is kept here for reference in case there's a use case
// export const updateLayouts = async (client: Client): Promise<void> => {
//   const sfConnection = getSfConnection(client);

//   // This gets a list of references to all Profiles (not the actual Profiles themselves)
//   // const allProfilesList = await sfConnection.metadata.list([{ type: 'Layout' }]);

//   sfConnection.metadata.read('Layout', ['Contact-Contact Layout']).then((profile) => {
//     // @ts-ignore
//     console.log('profile', profile.layoutSections[0].layoutColumns[0].layoutItems[0]);
//     console.log('profile', profile.layoutSections[0].layoutColumns[0].layoutItems[1]);
//     console.log('profile', profile.layoutSections[0].layoutColumns[0].layoutItems[2]);
//     console.log('profile', profile.layoutSections[0].layoutColumns[0].layoutItems[3]);
//     console.log('profile', profile.layoutSections[0].layoutColumns[0].layoutItems[4]);
//     console.log('profile', profile.layoutSections[0].layoutColumns[0].layoutItems[5]);
//     console.log('profile', profile.layoutSections[0].layoutColumns[0].layoutItems[6]);
//     console.log('profile', profile.layoutSections[0].layoutColumns[0].layoutItems[7]);
//     console.log('profile', profile.layoutSections[0].layoutColumns[0].layoutItems[8]);
//     console.log('part 2')
//     console.log('profile', profile.layoutSections[0].layoutColumns[1].layoutItems[0]);
//     console.log('profile', profile.layoutSections[0].layoutColumns[1].layoutItems[1]);
//     console.log('profile', profile.layoutSections[0].layoutColumns[1].layoutItems[2]);
//     console.log('profile', profile.layoutSections[0].layoutColumns[1].layoutItems[3]);
//   });
// };
