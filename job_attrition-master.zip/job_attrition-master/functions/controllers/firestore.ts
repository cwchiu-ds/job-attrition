import { chunk } from 'lodash';

import admin from '../config/firebaseConfig';
import {
  ClientContactField,
  ClientField,
  CompaniesField,
  COLLECTION,
  ContactDataField,
  MAX_CHUNK_SIZE,
  UserField,
} from '../utils/constants';
import { extractLinkedInIdFromUrl, getCurrentTimestamp, updateLatestEmails, addhttps } from '../utils/functions';
import Bottleneck from 'bottleneck';

export const db = admin.firestore();

const clientContactsCollection = db.collection(COLLECTION.CLIENT_CONTACTS);
const usersCollection = db.collection(COLLECTION.USERS);
const clientsCollection = db.collection(COLLECTION.CLIENTS);
const contactDataCollection = db.collection(COLLECTION.CONTACT_DATA);

export const getHubSpotVidsByClientContactId = async (clientContactId: string): Promise<string> => {
  const clientContactRef = await clientContactsCollection.doc(clientContactId).get();
  const clientContact = clientContactRef.data();

  if (clientContact && clientContact.crmData && clientContact.crmData.vid) {
    return clientContact.crmData.vid;
  } else {
    return '';
  }
};

export const getContactDataByContactDataId = async (contactDataId: string): Promise<ContactData | undefined> => {
  let contactDataContact;
  try {
    const contactDataRef = await contactDataCollection.doc(contactDataId).get();
    if (contactDataRef.exists) {
      contactDataContact = { ...(contactDataRef.data() as ContactData), id: contactDataRef.id };
    }
  } catch (e) {
    console.log(e);
  }

  return contactDataContact;
};

export const getHubSpotVidsAndContactDataTitleAndCompanyByClientContactId = async (
  clientContactId: string
): Promise<HubSpotEnrichment | object> => {
  const obj: any = {};
  obj.id = clientContactId;
  try {
    const clientContactRef = await clientContactsCollection.doc(clientContactId).get();
    const clientContact = clientContactRef.data() as ClientContact;

    if (clientContact && clientContact.crmData && clientContact.crmData.vid) {
      obj.crmData = clientContact.crmData;

      if (clientContact.contactDataId) {
        const contactData = await getContactDataByContactDataId(clientContact!.contactDataId);

        if (contactData && (contactData.currentJob[0].title || contactData.currentJob[0].companyName)) {
          obj.currentJob = contactData.currentJob;
        }
      }
    }
  } catch (e) {
    console.log(e);
  }
  if ((obj.currentJob && obj.currentJob.companyName !== '') || (obj.currentJob && obj.currentJob.title !== '')) {
    return obj;
  }
  return obj;
};

export const updateClientContactsByHubSpotVid = async (
  clientId: string,
  vid: string,
  hubSpotUpdateObject: Partial<ClientContact>
): Promise<void> => {
  const clientContactDataQuery = await clientContactsCollection
    .where('clientId', '==', clientId)
    .where('crmData.vid', '==', vid)
    .get();

  const newHubSpotClientContact = {
    ...hubSpotUpdateObject,
    clientId: clientId,
    crmType: 'hubspot',
  };

  if (clientContactDataQuery.size === 0) {
    const clientName = (await clientsCollection.doc(clientId).get()).data()!.name;

    const clientContactRef = clientContactsCollection.doc();

    clientContactRef.set({ ...newHubSpotClientContact, clientName: clientName || '' }, { merge: true }).then(() => {
      console.log('🟢 Saved new hubspot contacts in client contact', clientContactRef.id);
    });
  } else {
    clientContactDataQuery.forEach(async (doc) => {
      if (doc.exists) {
        const contact = doc.data();
        const finalUpdate = {
          ...hubSpotUpdateObject,
          crmData: {
            ...contact.crmData,
            ...(hubSpotUpdateObject?.crmData?.crmLinkedInURL !== '' && {
              crmLinkedInURL: addhttps(hubSpotUpdateObject?.crmData?.crmLinkedInURL!),
            }),
          },
        };
        doc.ref.set(finalUpdate, { merge: true }).then(() => {
          console.log('🌷 successfully updated/saved client contact data', doc.id);
        });
      }
    });
  }

  return;
};

export const getClientDataContactByCompanyName = async (companyName: string): Promise<ClientContact[]> => {
  const contactsQuerySnapshot = await clientContactsCollection.where('clientName', '==', companyName).get();

  const contacts: ClientContact[] = [];

  contactsQuerySnapshot.forEach((doc) => {
    const contact = doc.data() as ClientContact;
    contact.id = doc.id;
    contacts.push(contact);
  });

  return contacts;
};

export const getClientDataContactByClientId = async (clientId: string): Promise<ClientContact[]> => {
  const contactsQuerySnapshot = await clientContactsCollection.where('clientId', '==', clientId).get();

  const contacts: ClientContact[] = [];

  contactsQuerySnapshot.forEach((doc) => {
    const contact = doc.data() as ClientContact;
    contact.id = doc.id;
    contacts.push(contact);
  });

  return contacts;
};

export const getClientDataContactsByContactDataId = async (
  contactDataId: string
): Promise<Partial<ClientContact>[]> => {
  const clientContactsQuerySnapshot = await clientContactsCollection.where('contactDataId', '==', contactDataId).get();

  const clientContacts: Partial<ClientContact>[] = [];

  clientContactsQuerySnapshot.forEach(async (doc) => {
    const contact: Partial<ClientContact> = doc.data();
    contact.id = doc.id;

    clientContacts.push(contact);
  });
  return clientContacts;
};

export const getContactDataContactsByCompanyName = async (companyName: string): Promise<any[]> => {
  const clientContactsQuerySnapshot = await clientContactsCollection.where('clientName', '==', companyName).get();

  const contactRefs: FirebaseFirestore.DocumentReference<FirebaseFirestore.DocumentData>[] = [];

  clientContactsQuerySnapshot.forEach((doc) => {
    const contactId: string = doc.data().contactDataId;

    if (contactId) {
      const contactRef = contactDataCollection.doc(contactId);
      contactRefs.push(contactRef);
    }
  });

  const contactDataContacts: ContactData[] = [];

  await db.getAll(...contactRefs).then(async (docs) => {
    docs.forEach(async (doc) => {
      if (doc.exists) {
        const contactDataContact = (await doc.data()) as ContactData;
        contactDataContact.ID = doc.id;
        if (contactDataContact) {
          contactDataContacts.push(contactDataContact);
        }
      }
    });
  });

  return contactDataContacts;
};

export const getContactDataContactsByCompanyNameAndTrackFlag = async (
  companyName: string,
  trackFlag?: boolean
): Promise<any[]> => {
  const clientContactsQuerySnapshot = trackFlag
    ? await clientContactsCollection.where('clientName', '==', companyName).where('trackFlag', '==', trackFlag).get()
    : await clientContactsCollection.where('clientName', '==', companyName).get();

  console.log(clientContactsQuerySnapshot);

  const contactRefs: FirebaseFirestore.DocumentReference<FirebaseFirestore.DocumentData>[] = [];

  clientContactsQuerySnapshot.forEach((doc) => {
    const contactId: string = doc.data().contactDataId;

    if (contactId) {
      const contactRef = contactDataCollection.doc(contactId);
      contactRefs.push(contactRef);
    }
  });

  const contactDataContacts: ContactData[] = [];

  await db.getAll(...contactRefs).then(async (docs) => {
    docs.forEach(async (doc) => {
      if (doc.exists) {
        const contactDataContact = (await doc.data()) as ContactData;
        contactDataContact.ID = doc.id;
        if (contactDataContact) {
          contactDataContacts.push(contactDataContact);
        }
      }
    });
  });

  return contactDataContacts;
};

export const getClientContactByEmailAndClientId = async (
  email: string,
  clientId: string
): Promise<ClientContact | undefined> => {
  const clientContactSnapshot = await clientContactsCollection
    .where(ClientContactField.EMAIL, '==', email)
    .where(ClientContactField.CLIENT_ID, '==', clientId)
    .get();

  if (!clientContactSnapshot.empty) {
    const clientContactDoc = clientContactSnapshot.docs[0];
    const clientContact = { ...(clientContactDoc.data() as ClientContact), id: clientContactDoc.id };
    return clientContact;
  } else {
    return;
  }
};

export const getClientContactByFullNameAndClientId = async (
  fullName: string,
  clientId: string
): Promise<ClientContact | undefined> => {
  const clientContactSnapshot = await clientContactsCollection
    .where(ClientContactField.FULL_NAME, '==', fullName)
    .where(ClientContactField.CLIENT_ID, '==', clientId)
    .get();

  if (!clientContactSnapshot.empty) {
    const clientContactDoc = clientContactSnapshot.docs[0];
    const clientContact = { ...(clientContactDoc.data() as ClientContact), id: clientContactDoc.id };
    return clientContact;
  } else {
    return;
  }
};

export const getClientContactBySalesforceIdAndClientId = async (
  salesforceId: string,
  clientId: string
): Promise<ClientContact | undefined> => {
  const clientContactSnapshot = await clientContactsCollection
    .where(ClientContactField.SALESFORCE_ID, '==', salesforceId)
    .where(ClientContactField.CLIENT_ID, '==', clientId)
    .get();

  if (!clientContactSnapshot.empty) {
    const clientContactDoc = clientContactSnapshot.docs[0];
    const clientContact = { ...(clientContactDoc.data() as ClientContact), id: clientContactDoc.id };
    return clientContact;
  } else {
    return;
  }
};

export const getClientContactByFirstAndLastName = async (
  firstName: string,
  lastName: string,
  clientId: string
): Promise<ClientContact | undefined> => {
  const clientContactSnapshot = await clientContactsCollection
    .where(ClientContactField.FIRST_NAME, '==', firstName)
    .where(ClientContactField.LAST_NAME, '==', lastName)
    .where(ClientContactField.CLIENT_ID, '==', clientId)
    .get();

  if (!clientContactSnapshot.empty) {
    const clientContactDoc = clientContactSnapshot.docs[0];
    const clientContact = { ...(clientContactDoc.data() as ClientContact), id: clientContactDoc.id };
    return clientContact;
  } else {
    return;
  }
};

export const getClientContactByHubspotIdAndClientId = async (
  hubspotVid: string,
  clientId: string
): Promise<ClientContact | undefined> => {
  const clientContactSnapshot = await clientContactsCollection
    .where('crmData.vid', '==', hubspotVid)
    .where(ClientContactField.CLIENT_ID, '==', clientId)
    .get();

  if (!clientContactSnapshot.empty) {
    const clientContactDoc = clientContactSnapshot.docs[0];
    const clientContact = { ...(clientContactDoc.data() as ClientContact), id: clientContactDoc.id };
    return clientContact;
  } else {
    return;
  }
};

export const getClientContactsByClientId = async (clientId: string, limit?: number): Promise<ClientContact[]> => {
  let query = clientContactsCollection.where(ClientContactField.CLIENT_ID, '==', clientId);

  if (limit) {
    query = query.limit(limit);
  }

  const clientContactSnapshot = await query.get();

  if (!clientContactSnapshot.empty) {
    return clientContactSnapshot.docs.map((clientContactDoc) => {
      return { ...(clientContactDoc.data() as ClientContact), id: clientContactDoc.id };
    });
  } else {
    return [];
  }
};

type FieldValue = string | number | boolean | null | Timestamp;

interface GetDocumentsByField {
  collection: COLLECTION;
  field: ClientContactField | ContactDataField | ClientField | UserField | CompaniesField;
  operation: FirebaseFirestore.WhereFilterOp;
  fieldValue: FieldValue | FieldValue[];
  limit?: number;
}

interface GetDocumentsByFields {
  collection: COLLECTION;
  field: ClientContactField | ContactDataField | ClientField | UserField | CompaniesField;
  operation: FirebaseFirestore.WhereFilterOp;
  fieldValue: FieldValue | FieldValue[];
  field2: ClientContactField | ContactDataField | ClientField | UserField | CompaniesField;
  operation2: FirebaseFirestore.WhereFilterOp;
  fieldValue2: FieldValue | FieldValue[];
  limit?: number;
}

export const getDocumentsByField = async <T extends { id: string }>({
  collection,
  field,
  operation,
  fieldValue,
  limit,
}: GetDocumentsByField): Promise<T[]> => {
  let query = db.collection(collection).where(field, operation, fieldValue);

  if (limit) {
    query = query.limit(limit);
  }

  const snapshot = await query.get();

  if (!snapshot.empty) {
    return snapshot.docs.map((doc) => {
      return { ...(doc.data() as T), id: doc.id };
    });
  } else {
    return [];
  }
};

export const getDocumentsByFields = async <T extends { id: string }>({
  collection,
  field,
  operation,
  fieldValue,
  field2,
  operation2,
  fieldValue2,
  limit,
}: GetDocumentsByFields): Promise<T[]> => {
  let query = db.collection(collection).where(field, operation, fieldValue).where(field2, operation2, fieldValue2);

  if (limit) {
    query = query.limit(limit);
  }

  const snapshot = await query.get();

  if (!snapshot.empty) {
    return snapshot.docs.map((doc) => {
      return { ...(doc.data() as T), id: doc.id };
    });
  } else {
    return [];
  }
};

export const getDocumentById = async <T extends { id: string }>(
  collection: COLLECTION,
  id: string
): Promise<WithId<T> | undefined> => {
  const doc = await db.collection(collection).doc(id).get();

  if (doc.exists) {
    return { ...(doc.data() as T), id: doc.id };
  } else {
    return;
  }
};

export const getContactDataContactByProxyCrawlRID = async (rid: string): Promise<ContactData | {}> => {
  const contactsQuerySnapshot = await contactDataCollection.where('rid', '==', rid).get();

  let contact = {} as ContactData;

  contactsQuerySnapshot.forEach((doc) => {
    contact = doc.data() as ContactData;
    contact.ID = doc.id;
  });

  return contact;
};

export const flagProxyCrawlContactError = async (ID: string, errorMessage: string): Promise<undefined> => {
  const contactRef = contactDataCollection.doc(ID);

  await contactRef.set(
    {
      proxyCrawlErrorFlag: true,
      proxyCrawlErrorMessage: errorMessage,
    },
    { merge: true }
  );

  return;
};

export const peopleDataLabsError = async (ID: string, errorMessage: string): Promise<undefined> => {
  const contactRef = clientContactsCollection.doc(ID);

  await contactRef.set(
    {
      peopleDataLabsErrorFlag: true,
      peopleDataLabsErrorMessage: errorMessage,
    },
    { merge: true }
  );

  return;
};

export const updateDocumentUsingMerge = async <T>(
  collection: COLLECTION,
  updated: Partial<T> & { id: string }
): Promise<void> => {
  const { id: docId, ...docData } = updated;
  await db
    .collection(collection)
    .doc(docId!)
    .set({ ...docData }, { merge: true });
  return;
};

export const updateDocumentsUsingMerge = async <T>(
  collection: COLLECTION,
  updated: (Partial<T> & { id: string })[]
): Promise<void> => {
  const updatedChunks = chunk(updated, MAX_CHUNK_SIZE);

  // We loop through each chunk, wait for one chunk to finish writing before writing another chunk
  for (const updatedChunk of updatedChunks) {
    // We use concurrent individual writes instead of batch writes, because it's faster
    // and recommended by Firebase:
    // https://firebase.google.com/docs/firestore/manage-data/transactions
    // https://stackoverflow.com/questions/58897274/what-is-the-fastest-way-to-write-a-lot-of-documents-to-firestore
    await Promise.all(
      updatedChunk.map((doc) => {
        const { id, ...docData } = doc;
        return db.collection(collection).doc(id).set(docData, { merge: true });
      })
    );
  }
};

export const updateDocumentsWithoutMerge = async <T>(
  collection: COLLECTION,
  updated: (Partial<T> & { id: string })[]
): Promise<void> => {
  const updatedChunks = chunk(updated, MAX_CHUNK_SIZE);

  // We loop through each chunk, wait for one chunk to finish writing before writing another chunk
  for (const updatedChunk of updatedChunks) {
    // We use concurrent individual writes instead of batch writes, because it's faster
    // and recommended by Firebase:
    // https://firebase.google.com/docs/firestore/manage-data/transactions
    // https://stackoverflow.com/questions/58897274/what-is-the-fastest-way-to-write-a-lot-of-documents-to-firestore
    await Promise.all(
      updatedChunk.map((doc) => {
        const { id, ...docData } = doc;
        return db.collection(collection).doc(id).update(docData);
      })
    );
  }
};

export const addDocumentsToCollection = async <T>(
  collection: COLLECTION,
  documents: (Partial<T> & { id?: string })[]
): Promise<void> => {
  const docChunks = chunk(documents, MAX_CHUNK_SIZE);

  // We loop through each chunk, wait for one chunk to finish writing before writing another chunk
  for (const docChunk of docChunks) {
    // We use concurrent individual writes instead of batch writes, because it's faster
    // and recommended by Firebase:
    // https://firebase.google.com/docs/firestore/manage-data/transactions
    // https://stackoverflow.com/questions/58897274/what-is-the-fastest-way-to-write-a-lot-of-documents-to-firestore
    await Promise.all(
      docChunk.map((doc) => {
        if (doc.id) {
          const { id, ...docData } = doc;
          return db.collection(collection).doc(id).set(docData);
        } else {
          return db.collection(collection).doc().set(doc);
        }
      })
    );
  }
};

export const deleteDocumentsFromCollection = async (collection: COLLECTION, ids: string[]): Promise<void> => {
  const idsChunks = chunk(ids, MAX_CHUNK_SIZE);

  // We loop through each chunk, wait for one chunk to finish writing before writing another chunk
  for (const idChunk of idsChunks) {
    // We use concurrent individual writes instead of batch writes, because it's faster
    // and recommended by Firebase:
    // https://firebase.google.com/docs/firestore/manage-data/transactions
    // https://stackoverflow.com/questions/58897274/what-is-the-fastest-way-to-write-a-lot-of-documents-to-firestore
    await Promise.all(
      idChunk.map((id) => {
        return db.collection(collection).doc(id).delete();
      })
    );
  }
};

export const updateClientContactById = (
  existingClientContactId: string,
  updatedClientContactData: Partial<ClientContact>
): Promise<void> => {
  return updateDocumentUsingMerge<ClientContact>(COLLECTION.CLIENT_CONTACTS, {
    id: existingClientContactId,
    ...updatedClientContactData,
  });
};

export const checkContactDataLinkedInURL = async (linkedInURL: string): Promise<ContactData> => {
  const linkedInId = extractLinkedInIdFromUrl(linkedInURL);

  const contactDataQuerySnapshot = await contactDataCollection.where('linkedInId', '==', linkedInId).get();

  let contact = {} as ContactData;
  contactDataQuerySnapshot.forEach((doc) => {
    contact = doc.data() as ContactData;
    contact.ID = doc.id;
  });

  return contact;
};

const saveClientNameClientIdAndEmailToContactData = async (
  contactDataId: string,
  updatedContactsData: Partial<ClientContact>
): Promise<void> => {
  const contactDataRef = contactDataCollection.doc(contactDataId);
  const contact: ContactData = (await contactDataRef.get()).data() as ContactData;

  const email =
    typeof updatedContactsData.email == 'string' ? [updatedContactsData!.email!] : (updatedContactsData!.email! as any);

  // @ts-ignore
  const dedupeClientIds = Array.from(new Set([...contact!.clientIds, updatedContactsData.clientId]));
  const dedupeClientNames = Array.from(new Set([...contact!.clientNames, updatedContactsData.clientName]));
  let dedupeEmails: any = [];
  if (contact.emailArray) {
    dedupeEmails = Array.from(new Set(contact!.emailArray.concat(email)));
  }

  const emails = updateLatestEmails(contact!, email);

  if ('clientIds' in contact!) {
    contactDataRef.set(
      {
        clientIds: dedupeClientIds,
      },
      { merge: true }
    );
  } else {
    contactDataRef.set(
      {
        clientIds: [updatedContactsData.clientId],
      },
      { merge: true }
    );
  }

  if ('clientNames' in contact!) {
    contactDataRef.set(
      {
        clientNames: dedupeClientNames,
      },
      { merge: true }
    );
  } else {
    contactDataRef.set(
      {
        clientNames: [updatedContactsData.clientName],
      },
      { merge: true }
    );
  }

  if ('emailArray' in contact!) {
    contactDataRef.set(
      {
        emailData: emails,
        emailArray: dedupeEmails,
      },
      { merge: true }
    );
  } else {
    contactDataRef.set(
      {
        emailData: [{ email, dateCreated: getCurrentTimestamp(), isValid: true }],
        emailArray: email,
      },
      { merge: true }
    );
  }
};

function isEmpty(obj: object): boolean {
  for (const key in obj) {
    if (obj.hasOwnProperty(key)) return false;
  }
  return true;
}

export const createContactDataContactFromClientData = async (
  clientContactId: string,
  updatedContactsData: Partial<ClientContact>
): Promise<undefined> => {
  const existingContactData = await checkContactDataLinkedInURL(updatedContactsData.linkedInURL!);
  // If contact data exists with same LinkedIn URL, then update client data with contact data document's ID into contactDataId
  if (!isEmpty(existingContactData)) {
    updateClientContactById(clientContactId, {
      contactDataId: existingContactData.ID,
    });

    // append email, clientId, clientName to contact data array
    await saveClientNameClientIdAndEmailToContactData(existingContactData.ID, updatedContactsData);
  } else {
    // if we couldnt find an existing contact in contact_data then create one
    const contactRef = contactDataCollection.doc();
    const batch = db.batch();
    const emails =
      typeof updatedContactsData.email == 'string' ? [updatedContactsData.email] : updatedContactsData.email;

    const emailObjects = emails!.map((email) => {
      return {
        email,
        dateCreated: getCurrentTimestamp(),
        isValid: true,
      };
    });

    batch.set(contactRef, {
      ...updatedContactsData,
      emailData: emailObjects,
      emailArray: emails,
      clientIds: [updatedContactsData.clientId],
      clientNames: [updatedContactsData.clientName],
      currentJob: [updatedContactsData.currentJob],
    });

    batch.commit();
    updateClientContactById(clientContactId, {
      contactDataId: contactRef.id,
    });
  }

  return;
};

export const getContactDataSubCollectionForGoogleByContactId = async (
  contactId: string,
  subCollection: string
): Promise<GoogleSearchResult[]> => {
  const googleSearchResultRef = await contactDataCollection.doc(contactId).collection(subCollection).get();

  const googleSearchResults: GoogleSearchResult[] = [];

  googleSearchResultRef.forEach((doc) => {
    const result = doc.data() as GoogleSearchResult;
    googleSearchResults.push(result);
  });

  return googleSearchResults;
};

export const updateBulkContactsData = async (
  existingContacts: ContactData[],
  updatedContactsData: (Partial<ContactData> | {})[]
): Promise<FirebaseFirestore.WriteResult[]> => {
  const batch = db.batch();

  existingContacts.forEach((contact, i) => {
    batch.set(
      contactDataCollection.doc(contact.ID),
      { ...updatedContactsData[i], ID: contact.ID },
      {
        merge: true,
      }
    );
  });
  return batch.commit();
};

export const updateContactDataGoogleSearchOngoingFlagTrue = async (contactDataId: string): Promise<undefined> => {
  const contactDoc = contactDataCollection.doc(contactDataId);

  contactDoc.set({ googleJobChangeDetected: true }, { merge: true });
  console.log('🌷 successfully changed JobChanged Flag on Client Data Contact ID', contactDataId);

  return;
};

export const updateClientDataJobChangedFlagToTrue = async (contactDataId: string): Promise<undefined> => {
  const contactsQuerySnapshot = await clientContactsCollection.where('contactDataId', '==', contactDataId).get();

  contactsQuerySnapshot.forEach((doc) => {
    doc.ref.set({ jobChanged: true }, { merge: true }).then(() => {
      console.log('🌷 successfully changed JobChanged Flag on Client Data Contact ID', doc.id);
    });
  });
  return;
};

export const getClientIdByUserId = async (userId: string): Promise<string | undefined> => {
  let clientId;
  try {
    const userDoc = await usersCollection.doc(userId).get();

    if (userDoc.exists) {
      const userData = userDoc.data() as UserData;

      clientId = userData.clientId;
    }
  } catch (err) {
    console.error(new Error(JSON.stringify(err)));
  }

  return clientId;
};

interface AddOrUpdateClientContacts {
  newClientContacts: NewClientContact[];
  clientId: string;
  clientName: string;
  userId: string;
  fromSalesforce?: boolean;
}

// Currently we require all client contact fields to exist, even if as Null
const requiredClientContactFields = Object.values(ClientContactField);

export const addOrUpdateClientContacts = async ({
  newClientContacts,
  clientId,
  clientName,
  userId,
  fromSalesforce = false,
}: AddOrUpdateClientContacts): Promise<FirebaseFirestore.WriteResult[][] | void> => {
  const contactChunks = chunk(newClientContacts, MAX_CHUNK_SIZE);
  let count = 0;

  const limiter = new Bottleneck({
    minTime: 333,
    maxConcurrent: 10,
  });

  return await Promise.all(
    contactChunks.map(async (chunk) => {
      return limiter.schedule(async () => {
        const batch = db.batch();

        await Promise.all(
          chunk.map((contact): any => {
            count = count + 1;
            const fieldUsedToCheckExisting = fromSalesforce ? contact.salesforceId : contact.email;
            if (
              fieldUsedToCheckExisting ||
              contact.fullName ||
              (contact.firstName && contact.lastName) ||
              contact.linkedInURL
            ) {
              return (fromSalesforce
                ? getClientContactBySalesforceIdAndClientId(contact.salesforceId!, clientId!)
                : contact.crmData && contact.crmData.vid
                ? getClientContactByHubspotIdAndClientId(contact.crmData!.vid!, clientId!)
                : contact.email
                ? getClientContactByEmailAndClientId(contact.email!, clientId)
                : contact.fullName
                ? getClientContactByFullNameAndClientId(contact.fullName!, clientId!) // full name is not unique but it's a fallback if we dont have email, salesforceId, or hubspotVid
                : getClientContactByFirstAndLastName(contact.firstName!, contact.lastName!, clientId)
              ).then((existingContact) => {
                contact[ClientContactField.DATE_UPDATED] = admin.firestore.Timestamp.now();
                contact[ClientContactField.ADDED_BY_USER_ID] = userId;
                contact[ClientContactField.CLIENT_ID] = clientId;
                contact[ClientContactField.CLIENT_NAME] = clientName;

                // If linkedInUrl is provided, we extract the linkedIn Id
                const linkedInURL = contact[ClientContactField.LINKEDIN_URL];

                if (linkedInURL) {
                  const linkedInId = extractLinkedInIdFromUrl(linkedInURL);
                  if (linkedInId) {
                    contact[ClientContactField.LINKEDIN_ID] = linkedInId;
                  }

                  // We also save the linkInURL in crmData
                  const crmData = contact[ClientContactField.CRM_DATA] || {};

                  contact[ClientContactField.CRM_DATA] = { ...crmData, crmLinkedInURL: addhttps(linkedInURL) };
                }

                if (existingContact) {
                  batch.set(clientContactsCollection.doc(existingContact.id), contact, { merge: true });
                } else {
                  contact[ClientContactField.DATE_CREATED] = admin.firestore.Timestamp.now();

                  // Below we make sure that any missing field is recorded as null
                  for (const field of requiredClientContactFields) {
                    const clientContactFieldData = contact[field];
                    if (clientContactFieldData === undefined) {
                      // @ts-ignore Typescript unable to figure out the correct type
                      contact[field] = null;
                    }
                  }

                  batch.set(clientContactsCollection.doc(), contact);
                }
              });
            }
          })
        );

        return batch.commit();
      });
    })
  ).catch((err) => {
    console.error(new Error('Error with uploading contacts: \n\n' + err.toString()));
  });
};

export const addOrUpdateClientContactsFromCSV = async ({
  newClientContacts,
  clientId,
  clientName,
  userId,
}: AddOrUpdateClientContacts): Promise<void> => {
  const currentTimestamp = getCurrentTimestamp();
  const clientContactChunks = chunk(newClientContacts, MAX_CHUNK_SIZE);
  for (const clientContactChunk of clientContactChunks) {
    await Promise.all(
      clientContactChunk.map(async (clientContact) => {
        const existingContact = clientContact.email
          ? await getClientContactByEmailAndClientId(clientContact.email, clientId)
          : undefined;

        clientContact[ClientContactField.DATE_UPDATED] = currentTimestamp;
        clientContact[ClientContactField.ADDED_BY_USER_ID] = userId;
        clientContact[ClientContactField.CLIENT_ID] = clientId;
        clientContact[ClientContactField.CLIENT_NAME] = clientName;

        // If linkedInUrl is provided, we extract the linkedIn Id
        let linkedInURL = clientContact[ClientContactField.LINKEDIN_URL];

        // If the linkedin URL is a linkedIn handle rather than the full URL, we make it into a valid URL
        if (linkedInURL?.startsWith('in/')) {
          linkedInURL = `https://www.linkedin.com/${linkedInURL}`;
          clientContact[ClientContactField.LINKEDIN_URL] = linkedInURL;
        }

        if (linkedInURL) {
          const linkedInId = extractLinkedInIdFromUrl(linkedInURL);
          if (linkedInId) {
            clientContact[ClientContactField.LINKEDIN_ID] = linkedInId;
          }

          // We also save the linkInURL in crmData
          const crmData = clientContact[ClientContactField.CRM_DATA] || {};

          clientContact[ClientContactField.CRM_DATA] = { ...crmData, crmLinkedInURL: linkedInURL };
        }

        if (existingContact) {
          // If the existing contact has a linkedin URL, we do not override it
          if (existingContact.linkedInURL && existingContact.linkedInURL !== clientContact.linkedInURL) {
            clientContact.linkedInURL = existingContact.linkedInURL;
            clientContact.linkedInId = existingContact.linkedInId;
          }

          return clientContactsCollection.doc(existingContact.id).set(clientContact, { merge: true });
        } else {
          clientContact[ClientContactField.DATE_CREATED] = currentTimestamp;

          // Below we make sure that any missing field is recorded as null
          for (const field of requiredClientContactFields) {
            const clientContactFieldData = clientContact[field];
            if (clientContactFieldData === undefined) {
              // @ts-ignore Typescript unable to figure out the correct type
              clientContact[field] = null;
            }
          }

          return clientContactsCollection.doc().set(clientContact);
        }
      })
    ).catch((err) => {
      console.error(new Error('Error with uploading CSV contacts: \n\n' + err.toString()));
    });
  }
};

export const addOrUpdateClientContactsFromSalesforce = async ({
  newClientContacts,
  clientId,
  clientName,
  userId,
}: AddOrUpdateClientContacts): Promise<void> => {
  const clientContactChunks = chunk(newClientContacts, MAX_CHUNK_SIZE);
  const currentTimestamp = getCurrentTimestamp();

  for (const clientContactChunk of clientContactChunks) {
    await Promise.all(
      clientContactChunk.map((clientContact) => {
        return getClientContactBySalesforceIdAndClientId(clientContact.salesforceId!, clientId!)
          .then((existingContact) => {
            clientContact[ClientContactField.DATE_UPDATED] = currentTimestamp;
            clientContact[ClientContactField.ADDED_BY_USER_ID] = userId;
            clientContact[ClientContactField.CLIENT_ID] = clientId;
            clientContact[ClientContactField.CLIENT_NAME] = clientName;

            // If linkedInUrl is provided, we extract the linkedIn Id
            const linkedInURL = clientContact[ClientContactField.LINKEDIN_URL];

            if (linkedInURL) {
              const linkedInId = extractLinkedInIdFromUrl(linkedInURL);
              if (linkedInId) {
                clientContact[ClientContactField.LINKEDIN_ID] = linkedInId;
              }

              // We also save the linkInURL in crmData
              const crmData = clientContact[ClientContactField.CRM_DATA] || {};

              clientContact[ClientContactField.CRM_DATA] = { ...crmData, crmLinkedInURL: linkedInURL };
            }

            if (existingContact) {
              // If the existing contact has a linkedin URL, we do not override it
              if (existingContact.linkedInURL && existingContact.linkedInURL !== clientContact.linkedInURL) {
                clientContact.linkedInURL = existingContact.linkedInURL;
                clientContact.linkedInId = existingContact.linkedInId;
              }

              return clientContactsCollection.doc(existingContact.id).set(clientContact, { merge: true });
            } else {
              clientContact[ClientContactField.DATE_CREATED] = currentTimestamp;

              // Below we make sure that any missing field is recorded as null
              for (const field of requiredClientContactFields) {
                const clientContactFieldData = clientContact[field];
                if (clientContactFieldData === undefined) {
                  // @ts-ignore Typescript unable to figure out the correct type
                  clientContact[field] = null;
                }
              }

              return clientContactsCollection.doc().set(clientContact);
            }
          })
          .catch((err) => {
            console.error(new Error('Error with uploading salesforce contacts: \n\n' + err.toString()));
          });
      })
    );
  }
};

export const addContactData = async (
  contactData: Partial<ContactData>
): Promise<FirebaseFirestore.DocumentReference<FirebaseFirestore.DocumentData>> => {
  const addedContactDataRef = await contactDataCollection.add(contactData);

  return addedContactDataRef;
};

export const updateSalesforceAccessToken = (
  clientId: string,
  accessToken: string
): Promise<FirebaseFirestore.WriteResult> => {
  const clientRef = clientsCollection.doc(clientId);

  const updatedClientData: Partial<Client> = {
    salesforceIntegration: {
      accessToken,
    },
  };

  return clientRef.set(updatedClientData, { merge: true });
};

export const getUserById = async (uid: string): Promise<UserData | undefined> => {
  if (!uid) {
    return;
  }

  const userDoc = await usersCollection.doc(uid).get();

  if (userDoc.exists) {
    // Need to use Omit to suppress a weird Typescript Error
    // error TS2783: 'id' is specified more than once, so this usage will be overwritten.
    const user = { id: userDoc.id, ...(userDoc.data() as Omit<UserData, 'id'>) };

    return user;
  } else {
    return;
  }
};

export const createUserData = (userData: UserData): Promise<FirebaseFirestore.WriteResult> => {
  const { id, ...remainingUserData } = userData;
  return usersCollection.doc(id).set(remainingUserData);
};

export const createClient = (
  client: Omit<Client, 'id'>
): Promise<FirebaseFirestore.DocumentReference<FirebaseFirestore.DocumentData>> => {
  return clientsCollection.add(client);
};
