import { mTurkClient } from '../config/mTurk';
import {
  CreateHITRequest,
  CreateHITResponse,
  ListAssignmentsForHITResponse,
  ApproveAssignmentResponse,
  ApproveAssignmentRequest,
} from 'aws-sdk/clients/mturk';
import { AWSError } from 'aws-sdk/lib/error';
import { Request } from 'aws-sdk/lib/request';

export const createHit = async (hitInputObject: CreateHITRequest): Promise<Request<CreateHITResponse, AWSError>> => {
  // Construct the HIT object below
  const myHIT = hitInputObject;

  console.log('about to create hit', myHIT);

  // Publish the object created above
  return await mTurkClient.createHIT(myHIT, (err, data) => {
    if (err) {
      console.error(err.message);
    } else {
      console.log(data);
      // Save the HITId printed by data.HIT.HITId and use it in the RetrieveAndApproveResults.js code sample
      if (data.HIT) {
        console.log(
          'HIT has been successfully published here: https://workersandbox.mturk.com/mturk/preview?groupId=' +
            data.HIT.HITTypeId +
            ' with this HITId: ' +
            data.HIT.HITId
        );
      }
    }
  });
};

export const approveHit = async (HITId: string): Promise<Request<ApproveAssignmentResponse, AWSError>> => {
  return await mTurkClient.listAssignmentsForHIT(
    { HITId: HITId },
    (err: AWSError, assignmentsForHIT: ListAssignmentsForHITResponse) => {
      if (err) {
        console.error(err.message);
      } else {
        console.log('Completed Assignments found: ' + assignmentsForHIT.NumResults);
        if (assignmentsForHIT.NumResults && assignmentsForHIT.Assignments) {
          for (let i = 0; i < assignmentsForHIT.NumResults; i++) {
            console.log(
              'Answer from Worker with ID - ' + assignmentsForHIT.Assignments[i].WorkerId + ': ',
              assignmentsForHIT.Assignments[i].Answer
            );

            const approveAssignmentRequestObject = {
              AssignmentId: assignmentsForHIT.Assignments[i].AssignmentId,
              RequesterFeedback: 'Thanks for the great work!',
            } as ApproveAssignmentRequest;

            // Approve the work so the Worker is paid with and optional feedback message
            mTurkClient.approveAssignment(approveAssignmentRequestObject, (err) => {
              if (err) {
                console.error(err, err.stack);
              }
            });
          }
        }
      }
    }
  );
};
