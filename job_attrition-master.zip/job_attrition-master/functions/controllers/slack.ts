import { IncomingWebhook, IncomingWebhookResult, IncomingWebhookSendArguments } from '@slack/webhook';
import Axios from 'axios';

import { CloudFunctionsErrorReportingBody, WebErrorReportingBody } from '../triggers/logging';
import { CURRENT_ENVIRONMENT, Environment, ProjectId } from '../utils/constants';

enum SLACK_WEBHOOK_URL {
  ENGINEERING_SUPPORT = 'https://hooks.slack.com/services/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',
  ENGINEERING_NOTIFICATIONS = 'https://hooks.slack.com/services/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',
  ENGINEERING_ERRORS = 'https://hooks.slack.com/services/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',
  CLIENT_NOTIFICATIONS = 'https://hooks.slack.com/services/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',
  CLIENT_NOTIFICATIONS_TEST = 'https://hooks.slack.com/services/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',
}

const setMessageHeader = (message: string): string => {
  if (CURRENT_ENVIRONMENT === Environment.Development) {
    message = '[DEV] ' + message;
  } else if (CURRENT_ENVIRONMENT === Environment.Staging) {
    message = '[STAGING] ' + message;
  } else if (CURRENT_ENVIRONMENT !== Environment.Production) {
    // In the rare event that CURRENT_ENVIRONMENT is not set correctly, we want to know
    message = '[ENV UNKNOWN] ' + message;
  }

  return message;
};

export const sendToEngineeringSupportSlack = (message: string): Promise<void> => {
  message = setMessageHeader(message);

  const data = {
    text: message,
  };

  const config = {
    headers: { 'content-type': 'application/json' },
  };

  return Axios.post(SLACK_WEBHOOK_URL.ENGINEERING_SUPPORT, data, config);
};

export const sendToClientNotificationsSlack = (message: string): Promise<void> => {
  message = setMessageHeader(message);

  const data = {
    text: message,
  };

  const config = {
    headers: { 'content-type': 'application/json' },
  };

  const postURL = CURRENT_ENVIRONMENT === Environment.Production ? SLACK_WEBHOOK_URL.CLIENT_NOTIFICATIONS : SLACK_WEBHOOK_URL.CLIENT_NOTIFICATIONS_TEST

  return Axios.post(postURL, data, config);
};

export const sendToEngineeringNotificationsSlack = (message: string, code?: string): Promise<IncomingWebhookResult> => {
  message = setMessageHeader(message);

  let data = {
    text: message,
  } as IncomingWebhookSendArguments;

  if (code) {
    data = {
      blocks: [
        {
          type: 'section',
          text: {
            type: 'plain_text',
            text: message,
          },
        },
        {
          type: 'section',
          text: {
            type: 'mrkdwn',
            text: '```' + code + '```',
          },
        },
      ],
    };
  }

  const webhook = new IncomingWebhook(SLACK_WEBHOOK_URL.ENGINEERING_NOTIFICATIONS);

  return webhook.send(data);
};

export const sendToEngineeringErrorsSlack = (message: string, code?: string): Promise<IncomingWebhookResult> => {
  message = setMessageHeader(message);

  let data = {
    text: message,
  } as IncomingWebhookSendArguments;

  if (code) {
    data = {
      blocks: [
        {
          type: 'section',
          text: {
            type: 'plain_text',
            text: message,
          },
        },
        {
          type: 'section',
          text: {
            type: 'mrkdwn',
            text: '```' + code + '```',
          },
        },
      ],
    };
  }

  const webhook = new IncomingWebhook(SLACK_WEBHOOK_URL.ENGINEERING_ERRORS);

  return webhook.send(data);
};

const getProjectId = (): string => {
  return CURRENT_ENVIRONMENT === Environment.Production
    ? ProjectId.Production
    : CURRENT_ENVIRONMENT === Environment.Staging
    ? ProjectId.Staging
    : ProjectId.Development;
};

export const sendWebErrorToEngineeringErrorsSlack = (
  errorBody: WebErrorReportingBody
): Promise<IncomingWebhookResult> => {
  const messageHeader = setMessageHeader('🚨 *Web Error Reporting* 🚨');

  const projectId = errorBody.resource?.labels?.project_id || getProjectId();
  const insertId = errorBody.insertId || ''

  const serviceName = errorBody?.jsonPayload?.serviceContext?.service || 'Unknown service';
  const url = errorBody?.jsonPayload?.context?.httpRequest?.url || 'Unknown url';
  const user = errorBody?.jsonPayload?.context?.user || 'Unknown user';
  const errMessage = errorBody?.jsonPayload?.message || 'No error message';

  const data = {
    blocks: [
      {
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: messageHeader,
        },
      },
      {
        type: 'divider',
      },
      {
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: `*Service*: _${serviceName}_`,
        },
      },
      {
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: `*URL*: ${url}`,
        },
      },
      {
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: `*User*: ${user}`,
        },
      },
      {
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: '*Error Message*\n' + '```' + errMessage + '```',
        },
      },
      {
        type: 'divider',
      },
      {
        type: 'actions',
        elements: [
          {
            type: 'button',
            text: {
              type: 'plain_text',
              text: 'View Errors',
              emoji: true,
            },
            url: `https://console.cloud.google.com/errors?project=${projectId}`,
          },
          {
            type: 'button',
            text: {
              type: 'plain_text',
              text: 'View Logs',
              emoji: true,
            },
            url: `https://console.cloud.google.com/logs/viewer?project=${projectId}&advancedFilter=insertId%3D%22${insertId}%22`,
          },
        ],
      },
    ],
  };

  const webhook = new IncomingWebhook(SLACK_WEBHOOK_URL.ENGINEERING_ERRORS);

  return webhook.send(data);
};

export const sendCloudFunctionsErrorToEngineeringErrorsSlack = (
  errorBody: CloudFunctionsErrorReportingBody
): Promise<IncomingWebhookResult> => {
  const messageHeader = setMessageHeader('🚨 *Cloud Functions Error Reporting* 🚨');

  const functionName = errorBody.resource?.labels?.function_name || "function unknown"
  const projectId = errorBody.resource?.labels?.project_id || getProjectId();
  const insertId = errorBody.insertId || ''

  const errMessage = errorBody.textPayload || 'No error message'



  const data = {
    blocks: [
      {
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: messageHeader,
        },
      },
      {
        type: 'divider',
      },
      {
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: `*Function*: _${functionName}_`,
        },
      },
      {
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: '*Error Message*\n' + '```' + errMessage + '```',
        },
      },
      {
        type: 'divider',
      },
      {
        type: 'actions',
        elements: [
          {
            type: 'button',
            text: {
              type: 'plain_text',
              text: 'View Errors',
              emoji: true,
            },
            url: `https://console.cloud.google.com/errors?project=${projectId}`,
          },
          {
            type: 'button',
            text: {
              type: 'plain_text',
              text: 'View Logs',
              emoji: true,
            },
            url: `https://console.cloud.google.com/logs/viewer?project=${projectId}&advancedFilter=insertId%3D%22${insertId}%22`,
          },
        ],
      },
    ],
  };

  const webhook = new IncomingWebhook(SLACK_WEBHOOK_URL.ENGINEERING_ERRORS);

  return webhook.send(data);
};
