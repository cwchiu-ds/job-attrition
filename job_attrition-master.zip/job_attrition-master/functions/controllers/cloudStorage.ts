import Axios from 'axios';
import fs from 'fs';
import { nanoid } from 'nanoid';
import os from 'os';
import path from 'path';
import { Readable } from 'stream';

import admin from '../config/firebaseConfig';
import { CURRENT_ENVIRONMENT, Environment, HTTP_METHOD } from '../utils/constants';

const storageBucket = {
  photos:
    CURRENT_ENVIRONMENT !== Environment.Production
      ? 'gs://warmly-staging.appspot.com'
      : 'gs://jobattrition-profile-photos',
  other:
    CURRENT_ENVIRONMENT !== Environment.Production
      ? 'gs://warmly-staging.appspot.com'
      : 'gs://jobattrition.appspot.com',
};

const photoStorageBucket = admin.storage().bucket(storageBucket.photos);
const defaultBucket = admin.storage().bucket(storageBucket.other);

export const uploadPhoto = async (photoURL: string, fileName: string): Promise<string> => {
  // We use nanoid to generate a token to improve security
  // https://stackoverflow.com/questions/42956250/get-download-url-from-file-uploaded-with-cloud-functions-for-firebase
  const tokenId = nanoid();
  const tempFilePath = path.join(os.tmpdir(), fileName);

  try {
    await Axios({
      method: HTTP_METHOD.GET,
      url: photoURL,
      responseType: 'stream',
    }).then(function (response) {
      response.data.pipe(fs.createWriteStream(tempFilePath));
    });

    await photoStorageBucket.upload(tempFilePath, {
      destination: fileName,
      metadata: {
        metadata: {
          firebaseStorageDownloadTokens: tokenId,
        },
      },
    });

    const uploadedPhotoURL =
      'https://firebasestorage.googleapis.com/v0/b/' +
      photoStorageBucket.name +
      '/o/' +
      encodeURIComponent(fileName) +
      '?alt=media&token=' +
      tokenId;

    return uploadedPhotoURL;
  } catch (err) {
    console.error('ERROR Uploading photo');
    console.log(err);
    return '';
  }
};

export const getFile = async (filePath: string): Promise<Buffer | undefined> => {
  let file;

  try {
    // https://googleapis.dev/nodejs/storage/latest/File.html#download
    const fileDownloadResponse = await defaultBucket.file(filePath).download();

    file = fileDownloadResponse[0];

    console.log(file.length);
  } catch (err) {
    console.log(err);
  } finally {
    return file;
  }
};

export const getFileAsReadable = (filePath: string): Readable | undefined => {
  let readable;

  try {
    // https://googleapis.dev/nodejs/storage/latest/File.html#createReadStream
    const fileReadable = defaultBucket.file(filePath).createReadStream();

    readable = fileReadable;
  } catch (err) {
    console.log(err);
  } finally {
    return readable;
  }
};
