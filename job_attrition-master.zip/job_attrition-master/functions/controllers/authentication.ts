import admin from '../config/firebaseConfig';

export const firebaseAuth = admin.auth();

interface CreateAuthUser {
  email: string;
  password: string;
  phoneNumber?: string;
}

export const createAuthUser = ({ email, phoneNumber, password }: CreateAuthUser): Promise<admin.auth.UserRecord> => {
  return firebaseAuth.createUser({
    email,
    phoneNumber,
    password,
  });
};

export const getAuthUserByEmail = (email: string): Promise<admin.auth.UserRecord> => {
  return firebaseAuth.getUserByEmail(email);
};

export const getUserEmailByUid = async (uid: string): Promise<admin.auth.UserRecord> => {
  return firebaseAuth.getUser(uid).then((user) => user);
};
