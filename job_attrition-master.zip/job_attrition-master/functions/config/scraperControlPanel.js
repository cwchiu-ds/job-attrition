// Development / Local:
module.exports.scraperControlPanel = {
  proxyCrawlerName: 'linkedInCrawler', // linkedInCrawler vs. testCrawler change this to reflect the proxyCrawler name that sends data back to our proxyCrawler webhook
  testCookie: true, // Whether to use a dev/test/rotating cookie. Keep 'true' on dev/local. But on production for demo turn to false
  linkedInFlag: true, // LinkedIn Search vs. Google Search Query to LinkedIn
  checkEmailFlag: false, // email costs money so leave this false unless you need it
  headless: false, // turn to true if you want to turn off
  skipScrapedFailedFlagAndLinkedInUrlScraped: false, // when rescraping don't want to scrape contacts we already scraped so set to true to skip
  onlyScrapeScoredContactsWithLinkedInURLDiff: false, // Only scrape LinkedIn profiles that we re-imported with scoring data & found better LinkedIn URL after first scrape.
  onlyScrapeCompanyDataFromEmailAddress: false, // Only grab company name from email domain. Skip scraping LinkedIn page.
  addLongerWaitTimesBetweenScraping: true, // Set to true to add additional longer wait times between queries and clicks to seem more human for bulk profile scraping.
  randomizeUserAgents: false, // Change up HTTP header user agent every batch of scrapes.
  minutesBeforeCookieLimitReset: 720, // after X minutes the cookie limitExceeded will be reset back to false so the cookie can be used again
  minuteIntervalCookieLimit: 60, // If cookies scrapes cookieCountLimit in minuteIntervalCookieLimit, apply imit to cookie
  cookieCountLimit: 50, // If cookies scrapes cookieCountLimit in minuteIntervalCookieLimit, apply imit to cookie
  turnProxyServersOn: false,
};

// Production:
// module.exports.scraperControlPanel = {
//   proxyCrawlerName: "linkedInCrawler", // change this to reflect the proxyCrawler name that sends data back to our proxyCrawler webhook
//   testCookie: false, // Whether to use a dev/test cookie. Keep 'false' for deploying to prod.
//   linkedInFlag: true, // LinkedIn Search vs. Google Search Query to LinkedIn. But going forward should use google -> LinkedIn because there's no limit
//   checkEmailFlag: false, // email costs money so leave this false unless you need it
//   headless: true, // turn to true if you want to turn off
//   skipScrapedFailedFlagAndLinkedInUrlScraped: false, // when rescraping don't want to scrape contacts we already scraped so set to true to skip
//   onlyScrapeScoredContactsWithLinkedInURLDiff: false, // Only scrape LinkedIn profiles that we re-imported with scoring data & found better LinkedIn URL after first scrape.
//   onlyScrapeCompanyDataFromEmailAddress: false, // Only grab company name from email domain. Skip scraping LinkedIn page.
//   addLongerWaitTimesBetweenScraping: false, // Set to false for Sales demos, to make "Run Demo" as fast as possible and not wait randomized additional times.
//   randomizeUserAgents: false, // Change up HTTP header user agent every batch of scrapes.
//   minutesBeforeCookieLimitReset: 720, // after X minutes the cookie limitExceeded will be reset back to false so the cookie can be used again
//   minuteIntervalCookieLimit: 60, // If cookies scrapes cookieCountLimit in minuteIntervalCookieLimit, apply imit to cookie
//   cookieCountLimit: 50, // If cookies scrapes cookieCountLimit in minuteIntervalCookieLimit, apply imit to cookie
//   turnProxyServersOn: false,
// };
