import admin from 'firebase-admin';
import path from 'path';

import { CURRENT_ENVIRONMENT, Environment } from '../utils/constants';

const SECRETS = path.resolve(__dirname, '../secrets');

const pathToKey = {
  [Environment.Development]: SECRETS + '/warmly-staging-firebase-adminsdk-dkg4u-8933487e80.json',
  [Environment.Staging]:  SECRETS + '/warmly-staging-firebase-adminsdk-dkg4u-8933487e80.json',
  [Environment.Production]:  SECRETS + '/jobattrition-firebase-adminsdk-gc6d2-861d6e2361.json',
};

// @typescript/eslint prohibits the use of require but we need it to dynamically import the json
const serviceAccount = require(pathToKey[CURRENT_ENVIRONMENT]); // eslint-disable-line

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

export default admin;
