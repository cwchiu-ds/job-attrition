import { cloudFunctionsBaseAPIURL, CURRENT_ENVIRONMENT, Environment } from '../utils/constants';

export const HUBSPOT_URL = cloudFunctionsBaseAPIURL.HUBSPOT_INTEGRATION;

export const HUBSPOT_PATH =
  CURRENT_ENVIRONMENT === Environment.Production
    ? '/hubSpotIntegration'
    : CURRENT_ENVIRONMENT === Environment.Staging
    ? 'https://us-central1-warmly-staging.cloudfunctions.net/hubSpotIntegration'
    : '/warmly-staging/us-central1/hubSpotIntegration';
