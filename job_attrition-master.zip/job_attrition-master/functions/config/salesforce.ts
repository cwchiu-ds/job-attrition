import jsforce from 'jsforce';

import { apiURLs } from '../utils/constants';

const SF_CLIENT_ID = process.env.SALESFORCE_CONSUMER_KEY;
const SF_CLIENT_SECRET = process.env.SALESFORCE_CONSUMER_SECRET;

export const salesforceOAuth2 = new jsforce.OAuth2({
  clientId: SF_CLIENT_ID,
  clientSecret: SF_CLIENT_SECRET,
  redirectUri: apiURLs.Salesforce.Token,
});
