// // // local enviornemnt
module.exports.HUBSPOT_URL = 'http://localhost:5001/jobattrition/us-central1/hubSpotIntegration';
module.exports.HUBSPOT_PATH = '/jobattrition/us-central1/hubSpotIntegration';
module.exports.FRONTEND_HOST = 'http://localhost:3000';

// production environment
module.exports.HUBSPOT_URL = 'https://us-central1-jobattrition.cloudfunctions.net/hubSpotIntegration';
module.exports.HUBSPOT_PATH = '/hubSpotIntegration';
module.exports.FRONTEND_HOST = 'https://dashboard.getwarmly.com';
