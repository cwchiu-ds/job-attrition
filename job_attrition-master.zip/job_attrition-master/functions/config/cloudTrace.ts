import { CURRENT_ENVIRONMENT, Environment, ProjectId } from '../utils/constants';
import path from 'path';

import opentelemetry from '@opentelemetry/api';
import { NodeTracerProvider } from '@opentelemetry/node';
import { SimpleSpanProcessor, Tracer } from '@opentelemetry/tracing';
import { TraceExporter } from '@google-cloud/opentelemetry-cloud-trace-exporter';

const projectId =
  CURRENT_ENVIRONMENT === Environment.Production
    ? ProjectId.Production
    : CURRENT_ENVIRONMENT === Environment.Staging
    ? ProjectId.Staging
    : ProjectId.Development;

let cloudTrace;

// https://cloud.google.com/trace/docs/setup/nodejs-ot?authuser=1#compute-engine
if (projectId) {
  const SECRETS = path.resolve(__dirname, '../secrets');

  const pathToKey = {
    [Environment.Development]: SECRETS + '/warmly-staging-cloud-trace-82728b6c1b3a.json',
    [Environment.Staging]: undefined,
    [Environment.Production]: undefined,
  };

  const provider = new NodeTracerProvider();

  const exporter = new TraceExporter({ projectId, keyFile: pathToKey[CURRENT_ENVIRONMENT] });

  provider.addSpanProcessor(new SimpleSpanProcessor(exporter));

  provider.register();

  cloudTrace = opentelemetry.trace.getTracer('cloud-functions-tracer');
}

export default cloudTrace as Tracer;
