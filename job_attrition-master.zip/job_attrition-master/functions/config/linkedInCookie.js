/**
 * Proxy Servers.
 * Need to remember to change accses IP to either your public IP or the cloud function IP
 *
 */
let MA = "51.91.197.158:2000";
let AZ = "51.91.197.158:2000";
let SF = "51.91.197.158:2000";

/**
 * LinkedIn profile accounts
 * Make sure to check if still valid
 *
 */

//Demo Account - Don't abuse!
const linkedInCookieMaxGreenwald = {
  domain: ".www.linkedin.com",
  expirationDate: 1617677829.279852,
  hostOnly: false,
  httpOnly: true,
  name: "li_at",
  path: "/",
  sameSite: "no_restriction",
  secure: true,
  session: false,
  storeId: "0",
  value:
    "AQEDARMJafAEOxQGAAABcSleJDYAAAFxcXgcY04AYjfeQ56oEg-kwDYao8YWu4JfTvUaoZ5CDcXY7wX1eQSc5_XyrBDA9tM01R5ExEO8yhSDx7SWyQ66fnzY53ioeKFEySOc3Nos-zL0CPTLQlrWG-oq",
  id: 21,
};

linkedInCookieCooperRogers = {
  domain: ".www.linkedin.com",
  expirationDate: 1617695318.535537,
  hostOnly: false,
  httpOnly: true,
  name: "li_at",
  path: "/",
  sameSite: "no_restriction",
  secure: true,
  session: false,
  storeId: "0",
  value:
    "AQEDATAE1qADElH8AAABcU52dZoAAAFxcoL5mk4ANkCdyxqRDnv_S-aEycKb6bKBknFuYo2fRzuj7a38ozbtY0LOwoe3ae-M_Htm8aZPVxObIFWAm2HAAaae_SRqfNbZ7j8KF3AiCJcDm8BgA_w742v7",
  id: 22,
};

linkedInCookieGaryGest = {
  domain: ".www.linkedin.com",
  expirationDate: 1617903656.316284,
  hostOnly: false,
  httpOnly: true,
  name: "li_at",
  path: "/",
  sameSite: "no_restriction",
  secure: true,
  session: false,
  storeId: "0",
  value:
    "AQEDATAE2lEBD4LuAAABcVrhcQ0AAAFxfu31DU4AR5A8Ry132O3dngIovHf2AgXhcCtd--G6Cqn9eUCztchTVAVbk3TpZm8nkbWS99HstUBSVUY7P1IhF6IIj03kk8VZ0bblDiKwLAM423hkcc68unkQ",
  id: 22,
};

/**
 * Cookie Rotation
 * cookie is index 0, server address is index 1
 *
 * @param {*} Cookie Index 0 in cookieRotation or productionCookie
 * @param {*} ProxyServerIP index 1 cookieRotation or productionCookie
 */

module.exports.cookieRotation = [
  {
    name: "cooper_rogers",
    cookie: linkedInCookieCooperRogers,
    proxyIP: MA,
    userAgent:
      "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36", // Chrome Carina
  },
  {
    name: "gary_gest",
    cookie: linkedInCookieGaryGest,
    proxyIP: AZ,
    userAgent:
      "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.1 Safari/605.1.15", // Safari Carina
  },
];

module.exports.productionCookie = {
  name: "max_greenwald",
  cookie: linkedInCookieMaxGreenwald,
  proxyIP: SF,
  productionCookie: true,
  userAgent:
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36",
};
