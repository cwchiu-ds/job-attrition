import AWS from 'aws-sdk';
import { ServiceConfigurationOptions } from 'aws-sdk/lib/service';
import { MTURK_ENVIRONMENT, Environment } from '../utils/constants';

const endpoint =
  MTURK_ENVIRONMENT === Environment.Production
    ? 'https://mturk-requester.us-east-1.amazonaws.com'
    : 'https://mturk-requester-sandbox.us-east-1.amazonaws.com';

// remove endpoint to get out of sandbox environment
AWS.config.update({
  accessKeyId: process.env.AWS_ACCESS_KEY,
  secretAccessKey: process.env.AWS_SECRET,
  region: 'us-east-1',
  endpoint: endpoint,
} as ServiceConfigurationOptions);

export const mTurkClient = new AWS.MTurk();
