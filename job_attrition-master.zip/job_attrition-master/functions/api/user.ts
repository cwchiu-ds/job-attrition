import cors from 'cors';
import express from 'express';

import { validationErrorMiddleware } from '../modules/expressMiddleware';
import router from './user/router'

const userApi = express()

// https://expressjs.com/en/advanced/best-practice-security.html#at-a-minimum-disable-x-powered-by-header
userApi.disable('x-powered-by')

userApi.use(cors({ origin: true }))

userApi.use('/', router)

userApi.use(validationErrorMiddleware);

export { userApi }