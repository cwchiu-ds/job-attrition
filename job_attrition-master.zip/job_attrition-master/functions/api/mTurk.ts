import cors from 'cors';
import express from 'express';

import { validationErrorMiddleware } from '../modules/expressMiddleware';
import router from './mTurk/router';

const mTurkApi = express();

// https://expressjs.com/en/advanced/best-practice-security.html#at-a-minimum-disable-x-powered-by-header
mTurkApi.disable('x-powered-by');

mTurkApi.use(cors({ origin: true }));

mTurkApi.use('/', router);

mTurkApi.use(validationErrorMiddleware);

export { mTurkApi };
