import { Router } from 'express';

import { firebaseAuthMiddleware } from '../../modules/expressMiddleware';
import { EmailReportEndpoint } from '../../utils/constants';
import { sendWeeklyReport } from './sendWeeklyReport';

const router = Router();

router.post(EmailReportEndpoint.WEEKLY_REPORT, sendWeeklyReport);

export default router;
