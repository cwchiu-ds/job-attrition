import { Request, Response } from 'firebase-functions';
import { HTTP_RESPONSE, HTTP_METHOD, SendGridEmailTemplate, COLLECTION, UserField } from '../../utils/constants';
import { sendWeeklyEmail } from '../../modules/sendEmail';
import { getClientDataContactByClientId, getDocumentsByField, getDocumentById } from '../../controllers/firestore';
import { getUserEmailByUid } from '../../controllers/authentication';
import {
  getClientContactName,
  dayDiffCalc,
  capitalizeFirstLetter,
  getLastClientContactJob,
  getCurrentClientContactJob,
} from '../../utils/functions';

const getEmailGreetingTitleNames = (receiverEmails: string[], client: Client, name: string[]): string => {
  if (receiverEmails.length !== name.length) {
    return capitalizeFirstLetter(name[0]);
  } else if (receiverEmails.length > 1 && receiverEmails.length < 3) {
    return `${capitalizeFirstLetter(name[0])} and ${capitalizeFirstLetter(name[1])}`;
  } else if (receiverEmails.length > 2) {
    return `${client?.name} Team`;
  } else {
    return capitalizeFirstLetter(name[0]);
  }
};

export const sendWeeklyReport = async (req: Request, res: Response): Promise<Response<{}> | void> => {
  if (req.method !== HTTP_METHOD.POST) {
    console.log('🛑 Bad Request - End Google Search Query');
    return res.sendStatus(HTTP_RESPONSE.BAD_REQUEST);
  }

  // using Twilio SendGrid's v3 Node.js Library
  // https://github.com/sendgrid/sendgrid-nodejs

  let { clientId } = req.body as {
    clientId?: string;
  };
  const { testEmail } = req.body as {
    testEmail?: string | undefined;
  };

  clientId = clientId?.trim();

  if (!clientId) {
    return res.sendStatus(HTTP_RESPONSE.BAD_REQUEST);
  }

  const contacts: ClientContact[] = await getClientDataContactByClientId(clientId);

  const newJobChangeContacts = contacts.filter((contact) => {
    return contact.jobChanged && dayDiffCalc(new Date(), contact.dateUpdated!.toDate()) < 5;
  });

  const jobChangesNew = newJobChangeContacts.length || 0;

  const peopleChangedJobsNew = newJobChangeContacts
    .filter((contact) => contact.contactData && contact.contactData.profilePhoto)
    .map((contact) => {
      return {
        name: getClientContactName(contact),
        photoURL: contact.contactData?.profilePhoto || '',
        jobPrevious: getLastClientContactJob(contact),
        jobNew: getCurrentClientContactJob(contact),
      };
    })
    .slice(0, 3);

  const totalJobChanges = contacts.reduce((total, contact) => {
    return contact.jobChanged === true ? total + 1 : total;
  }, 0);

  const jobChangesPrevious: number = totalJobChanges - jobChangesNew;

  let users: UserData[] = await getDocumentsByField<UserData>({
    collection: COLLECTION.USERS,
    field: UserField.CLIENT_ID,
    operation: '==',
    fieldValue: clientId,
  });

  users = users.filter((user) => user.doNotSendWeeklyEmail !== true);

  const name: string[] = [];
  const receiverPromise = users.map(async (user) => {
    name.push(user.firstName);
    return getUserEmailByUid(user.id);
  });

  const client = await getDocumentById<Client>(COLLECTION.CLIENTS, clientId);
  const receivers = await Promise.all(receiverPromise);
  const receiverEmails: string[] = receivers.map((user) => {
    return user.email || '';
  });
  let testEmailFlag = false;

  // get additional emails to send weekly job changes report to but user didn't create an account
  if (client && client?.jobChangeNotificationEmails) {
    client.jobChangeNotificationEmails.map((email) => {
      receiverEmails.push(email);
    });
  }

  let dedupeReceiverEmails = [...new Set(receiverEmails)];

  console.log('original email', dedupeReceiverEmails);

  if (testEmail) {
    dedupeReceiverEmails = [testEmail];
    testEmailFlag = true;
  }

  console.log('test email', testEmail);

  const receiver = dedupeReceiverEmails;
  // if there is more than 1 user then say Hello Team vs. Hello Alan
  const receiverName = getEmailGreetingTitleNames(dedupeReceiverEmails, client!, name);
  const totaljobChangesString = totalJobChanges.toString();
  const jobChangesNewString = jobChangesNew.toString();
  const jobChangesPreviousString = jobChangesPrevious.toString();
  const template = jobChangesNew === 0 ? SendGridEmailTemplate.NO_JOB_CHANGES : SendGridEmailTemplate.JOB_CHANGES;

  const emailStatus = await sendWeeklyEmail(
    receiver,
    receiverName,
    template,
    totaljobChangesString,
    jobChangesNewString,
    jobChangesPreviousString,
    peopleChangedJobsNew,
    testEmailFlag
  );

  if (emailStatus === 202) {
    return res.send();
  } else {
    return res.sendStatus(HTTP_RESPONSE.INTERNAL_SERVER_ERROR);
  }
};
