import cors from 'cors';
import { Request, Response } from 'firebase-functions';
import { parseCsvFileAndAddClientContacts } from '../modules/parseClientCsv';
import { HTTP_METHOD, HTTP_RESPONSE, COLLECTION, UserType } from '../utils/constants';
import { getAuthenticatedUID } from '../utils/functions';
import { getDocumentById } from '../controllers/firestore';
import { sendToEngineeringErrorsSlack } from '../controllers/slack';

const corsHandler = cors({ origin: true });

export const parseClientCsv = (req: Request, res: Response): void => {
  return corsHandler(req, res, async () => {
    try {
      const { filePath, mappedAttributes, asClientId } = req.body as {
        filePath: string;
        mappedAttributes: MappedAttributes;
        asClientId?: string;
      };

      const authUID = await getAuthenticatedUID(req);

      if (!authUID) {
        return res.sendStatus(HTTP_RESPONSE.UNAUTHORIZED);
      }

      const authUser = await getDocumentById<UserData>(COLLECTION.USERS, authUID);

      if (req.method !== HTTP_METHOD.POST || !authUser) {
        return res.sendStatus(HTTP_RESPONSE.BAD_REQUEST);
      }

      let clientId = authUser.clientId;

      // Internal users can upload CSV's on behalf of a Client
      if (authUser?.userType === UserType.INTERNAL && asClientId) {
        clientId = asClientId;
      }

      const client = await getDocumentById<Client>(COLLECTION.CLIENTS, clientId);
      console.log('🚨 Received request for parsing client CSV for client ' + client!.name);

      if (!filePath || !mappedAttributes) {
        if (!filePath) {
          await sendToEngineeringErrorsSlack(
            `Received csv parsing request but no filePath for client ${client?.name} (id: ${client?.id})`
          );
        }
        return res.sendStatus(HTTP_RESPONSE.BAD_REQUEST);
      }

      await parseCsvFileAndAddClientContacts(filePath, mappedAttributes, authUID, client!);
      return res.send();
    } catch (err) {
      console.error(new Error(err.toString()));
      return res.sendStatus(HTTP_RESPONSE.INTERNAL_SERVER_ERROR);
    }
  });
};
