import { Request, Response } from 'firebase-functions';

import { getAuthUserByEmail } from '../../controllers/authentication';
import { getDocumentById, getUserById } from '../../controllers/firestore';
import { sendNewUserInvite } from '../../modules/sendEmail';
import { COLLECTION, HTTP_RESPONSE } from '../../utils/constants';

export const inviteNewUser = async (req: Request<AuthenticatedParams>, res: Response): Promise<void> => {
  const { inviteeEmail } = req.body as {
    inviteeEmail: string;
  };

  const authUID = req.params.authUID;

  if (!inviteeEmail) {
    res.sendStatus(HTTP_RESPONSE.BAD_REQUEST);
  }

  try {
    // Firebase throws an error if there's no existing authUser, so we catch that error
    // and return undefined instead to indicate that there's no existing authUser by that email
    const existingAuthUser = await getAuthUserByEmail(inviteeEmail).catch(() => undefined);

    if (existingAuthUser?.uid) {
      const existingUserData = await getUserById(existingAuthUser.uid);
      if (existingUserData) {
        // If there's an existing Users doc with that email, then that user has already created an account
        res.sendStatus(HTTP_RESPONSE.CONFLICT);
      }
    }

    const authUser = await getUserById(authUID);
    const authUserClient = await getDocumentById<Client>(COLLECTION.CLIENTS, authUser!.clientId!);

    const sendEmailResult = await sendNewUserInvite({
      inviteeEmail,
      inviterUser: authUser!,
      inviterClient: authUserClient!,
    });

    const emailStatus = sendEmailResult.body.Messages[0].Status;

    if (emailStatus === 'success') {
      res.send();
    } else {
      throw `Error sending email for invite new user (inviteeEmail: ${inviteeEmail}). Result: \n\n` + JSON.stringify(sendEmailResult)
    }
  } catch (err) {
    console.error(new Error(err.toString()));
    res.sendStatus(HTTP_RESPONSE.INTERNAL_SERVER_ERROR);
  }
};
