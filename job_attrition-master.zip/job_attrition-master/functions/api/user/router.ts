import { Router } from 'express';

import { firebaseAuthMiddleware } from '../../modules/expressMiddleware';
import { UserEndpoint } from '../../utils/constants';
import { inviteNewUser } from './inviteNewUser';
import { resetPassword } from './resetPassword';

const router = Router();

router.post(UserEndpoint.INVITE_NEW_USER, firebaseAuthMiddleware, inviteNewUser);
router.post(UserEndpoint.RESET_PASSWORD, resetPassword);

export default router;
