import { Request, Response } from 'firebase-functions';

import { sendPasswordResetEmail } from '../../modules/sendEmail';
import { HTTP_RESPONSE } from '../../utils/constants';
import { FirebaseError } from 'firebase-admin';

export const resetPassword = async (req: Request<AuthenticatedParams>, res: Response): Promise<void> => {
  const email = req.body.email as string;

  try {
    const sendEmailResult = await sendPasswordResetEmail(email);
    const emailStatus = sendEmailResult.body.Messages[0].Status;

    if (emailStatus === 'success') {
      res.send();
    } else {
      res.sendStatus(HTTP_RESPONSE.INTERNAL_SERVER_ERROR);
    }
  } catch (err) {
    if ((err as FirebaseError).message.includes('EMAIL_NOT_FOUND')) {
      res.status(HTTP_RESPONSE.NOT_FOUND).send('EMAIL_NOT_FOUND');
    } else if ((err as FirebaseError).message.includes('improperly formatted')) {
      res.status(HTTP_RESPONSE.BAD_REQUEST).send('EMAIL_INVALID');
    } else {
      console.error(new Error(err.toString()));
      res.sendStatus(HTTP_RESPONSE.INTERNAL_SERVER_ERROR);
    }
  }
};
