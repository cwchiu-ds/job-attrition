import { Router } from 'express';

import { firebaseAuthMiddleware } from '../../modules/expressMiddleware';
import deleteClient from './deleteClient';
import updateClient from './updateClient';

const router = Router();

router.put('/:clientId', firebaseAuthMiddleware, updateClient);
router.delete('/:clientId', firebaseAuthMiddleware, deleteClient);

export default router;
