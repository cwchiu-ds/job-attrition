import { Request, Response } from 'firebase-functions';

import { getDocumentById, getUserById } from '../../controllers/firestore';
import { deleteClientAndRelatedData } from '../../modules/client';
import { COLLECTION, HTTP_RESPONSE, UserType } from '../../utils/constants';

const deleteClient = async (req: Request<AuthenticatedParams & { clientId: string }>, res: Response): Promise<void> => {
  try {
    const clientId = req.params.clientId;

    const authUser = await getUserById(req.params.authUID);

    // Only internal users can delete clients
    if (!clientId || authUser?.userType !== UserType.INTERNAL) {
      res.sendStatus(HTTP_RESPONSE.BAD_REQUEST);
      return;
    }

    const client = await getDocumentById<Client>(COLLECTION.CLIENTS, clientId);

    if (!client) {
      res.sendStatus(HTTP_RESPONSE.BAD_REQUEST);
      return;
    }

    await deleteClientAndRelatedData(client);

    res.send();
  } catch (err) {
    console.error(err);

    res.sendStatus(HTTP_RESPONSE.INTERNAL_SERVER_ERROR);
  }
};

export default deleteClient;
