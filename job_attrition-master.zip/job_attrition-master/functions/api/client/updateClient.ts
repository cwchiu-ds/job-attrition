import { Request, Response } from 'firebase-functions';

import { getDocumentById, getUserById, updateDocumentsUsingMerge } from '../../controllers/firestore';
import {
  addCodeNameIfNotSet,
  handleNotificationEmailChanges,
  updateQAStatusDate,
  updateStatusDate,
} from '../../modules/client';
import { COLLECTION, HTTP_RESPONSE, UserType } from '../../utils/constants';

const updateClient = async (req: Request<AuthenticatedParams & { clientId: string }>, res: Response): Promise<void> => {
  try {
    let updatedClient = req.body as Partial<Client>;
    const clientId = req.params.clientId;

    const authUser = await getUserById(req.params.authUID);

    // If the authUser is NOT internal or QA, they can only update their own client
    if (
      !clientId ||
      ((authUser?.userType !== UserType.INTERNAL && authUser?.userType !== UserType.QA) &&
        clientId !== authUser?.clientId)
    ) {
      res.sendStatus(HTTP_RESPONSE.BAD_REQUEST);
      return;
    }

    const originalClient = await getDocumentById<Client>(COLLECTION.CLIENTS, clientId);

    if (!originalClient) {
      res.sendStatus(HTTP_RESPONSE.BAD_REQUEST);
      return;
    }

    handleNotificationEmailChanges(originalClient, updatedClient);

    // If client does not have a code name, we assign one
    updatedClient = await addCodeNameIfNotSet(originalClient, updatedClient);

    // If client subscription status has changed, record the time of change
    updatedClient = updateStatusDate(originalClient, updatedClient);

    // If QA status has changed, record the time of change
    updatedClient = updateQAStatusDate(originalClient, updatedClient);

    await updateDocumentsUsingMerge<Client>(COLLECTION.CLIENTS, [{ id: clientId, ...updatedClient }]);

    res.send();
  } catch (err) {
    console.error(err);

    res.sendStatus(HTTP_RESPONSE.INTERNAL_SERVER_ERROR);
  }
};

export default updateClient;
