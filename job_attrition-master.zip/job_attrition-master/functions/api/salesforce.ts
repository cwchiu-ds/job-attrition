import cors from 'cors';
import express from 'express';

import { validationErrorMiddleware } from '../modules/expressMiddleware';
import router from './salesforce/router';

const salesforceIntegrationApi = express();

// https://expressjs.com/en/advanced/best-practice-security.html#at-a-minimum-disable-x-powered-by-header
salesforceIntegrationApi.disable('x-powered-by');

salesforceIntegrationApi.use(cors({ origin: true }));

salesforceIntegrationApi.use('/', router);

salesforceIntegrationApi.use(validationErrorMiddleware);

export { salesforceIntegrationApi };
