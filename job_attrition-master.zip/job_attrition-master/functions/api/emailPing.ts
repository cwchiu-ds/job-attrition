import cors from 'cors';
import express from 'express';

import router from './emailPing/router';

const emailPingApi = express();

// https://expressjs.com/en/advanced/best-practice-security.html#at-a-minimum-disable-x-powered-by-header
emailPingApi.disable('x-powered-by');

emailPingApi.use(cors({ origin: true }));

emailPingApi.use('/', router);

export { emailPingApi };
