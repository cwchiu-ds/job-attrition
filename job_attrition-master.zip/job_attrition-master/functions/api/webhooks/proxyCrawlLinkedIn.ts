import { Request, Response } from 'firebase-functions';
import { firestore } from 'firebase-admin';
import {
  getContactDataContactByProxyCrawlRID,
  flagProxyCrawlContactError,
  updateDocumentsUsingMerge,
  updateDocumentUsingMerge,
  db,
} from '../../controllers/firestore';
import { changeJobChangedFlagTrueFromContactData, jobChangeStatusMap } from '../../modules/proxyCrawlParallel';

import { areJobsEqual } from '../../utils/helperFunctions/checkJobChangesHelperFunctions';
import { COLLECTION } from '../../utils/constants';
import { extractLinkedInCompanyIdFromUrl } from '../../utils/functions';
// import { updateEnrichedDataChangedFlagIfCurrentJobDiffBetweenClientAndContactData } from '../../modules/clientContactData';

const contactDataDB = db.collection('contact_data');

const getLatestTitleAndCompany = (
  experienceGroup: ProxyCrawlExperienceGroup[],
  experienceList: ProxyCrawlExperiencListeJob[],
  totalJobs: number
): ProxyCrawlCurrentJobCurrentCompany => {
  let currentJob = {} as ProxyCrawlExperienceGroupPosition;
  let currentCompany = {} as ProxyCrawlExperienceGroupCompanyCompany;
  experienceGroup.map((element) => {
    if (element.positions) {
      element.positions.map((job) => {
        if (job.experienceNumber == totalJobs) {
          currentJob = job;
          currentCompany = {
            name: element.groupCompany[0].name,
            link: element.groupCompany[0].link,
          };
        }
      });
    }
  });

  experienceList.map((element) => {
    if (element.experienceNumber == totalJobs) {
      currentJob = element;
      currentCompany = element.company;
    }
  });

  return { currentJob, currentCompany };
};

const addAllJobsUpdateCurrentJobInContactData = async (
  contactDataId: string,
  currentJob: CurrentJob
): Promise<void> => {
  await updateDocumentsUsingMerge(COLLECTION.CONTACT_DATA, [
    {
      id: contactDataId,
      allJobs: [currentJob],
      currentJob: [currentJob],
    },
  ]);
};

export async function moveLinkedInTitleAndCompanyToCurrentJobAndChangeJobChangedFlagTrue(
  contactId: string
): Promise<void> {
  const contact = (await contactDataDB.doc(contactId).get()).data();

  if (contact && contact.lastLinkedInData && contact.lastLinkedInData.currentJob) {
    const title = contact.lastLinkedInData.currentJob.title;
    const companyName = contact.lastLinkedInData.currentJob.companyName;
    const startDate = contact.lastLinkedInData.currentJob.startDate;
    const endDate = contact.lastLinkedInData.currentJob.endDate;
    const duration = contact.lastLinkedInData.currentJob.duration;
    const companyLink = contact.lastLinkedInData.currentJob.companyLink;
    const companyId = extractLinkedInCompanyIdFromUrl(companyLink);
    const currentJob = {
      title,
      companyName,
      lastUpdated: firestore.Timestamp.fromDate(new Date()),
      startDate,
      endDate,
      duration,
      companyId,
      companyLink,
    };

    if (contact?.allJobs) {
      const updatedJobsArray = contact.allJobs;
      if (!areJobsEqual(currentJob, contact.allJobs[contact.allJobs.length - 1])) {
        // If new job detected, append the new job to the contact and flag the contact.

        // get type of job change status
        const jobChangedStatus = jobChangeStatusMap(currentJob, contact.allJobs[contact.allJobs.length - 1]);

        // push new job into all jobs array
        updatedJobsArray.push(currentJob);

        // update jobChangeStatus and jobChanged flag
        await changeJobChangedFlagTrueFromContactData(contactId, jobChangedStatus);

        await updateDocumentUsingMerge(COLLECTION.CONTACT_DATA, {
          id: contactId,
          allJobs: updatedJobsArray,
          currentJob: [currentJob],
        });

        console.log('🟢 Updated CurrentJob', contactId);
      } else {
        await updateDocumentUsingMerge(COLLECTION.CONTACT_DATA, {
          id: contactId,
          currentJob: [currentJob],
        });
        console.log('🟡 No change detected so dont update Current Job or All Jobs', contactId);
      }
    } else {
      // if there is no allJobs field present
      console.log('🟢 Created CurrentJob', contactId);
      await addAllJobsUpdateCurrentJobInContactData(contactId, currentJob);
    }
  } else {
    console.log('🛑 No contact or lastLinkedInData');
  }
}

async function uploadProxyCrawlDataToDb(jobObject: Partial<ContactData>, contact: ContactData): Promise<undefined> {
  const contactDocID = contact.ID;

  if (!contact.ID) {
    console.log('🛑 NO Contact ID');
  }
  if (jobObject) {
    console.log('🤖 Scraped object returned to callback:', contactDocID);
    if (
      contact.lastLinkedInData &&
      contact.lastLinkedInData.workExperience &&
      contact.lastLinkedInData.workExperience.length > 0
    ) {
      const updatedJobsArray = contact.lastLinkedInData.workExperience;

      // Check if the new job is equal to the latest job we have in the DB.
      const latestJobInDB = updatedJobsArray[updatedJobsArray.length - 1];

      if (!areJobsEqual(jobObject.lastLinkedInData!.currentJob, latestJobInDB)) {
        // If new job detected, append the new job to the contact and flag the contact.
        updatedJobsArray.push(jobObject.lastLinkedInData!.currentJob!);
      } else {
        console.log('👍 No job changes found for:', contactDocID);
      }

      const obj = {
        ...jobObject,
        lastLinkedInData: {
          ...jobObject.lastLinkedInData,
          workExperience: updatedJobsArray,
        },
        proxyCrawlCompletedFlag: true,
      };

      try {
        await updateDocumentsUsingMerge(COLLECTION.CONTACT_DATA, [
          {
            id: contactDocID,
            ...obj,
          },
        ]);

        console.log('🍏 Contact Data Document successfully updated - UPDATE:', contactDocID);
        await moveLinkedInTitleAndCompanyToCurrentJobAndChangeJobChangedFlagTrue(contactDocID);
      } catch (error) {
        // The document probably doesn't exist
        console.error('🛑 Error updating document:', contactDocID, error);
      }
    } else {
      // If we have no job data in the DB for the contact yet, save it to the DB.

      const obj = {
        ...jobObject,
        lastLinkedInData: {
          ...jobObject.lastLinkedInData,
          workExperience: [jobObject.lastLinkedInData?.currentJob],
          dateCreated: firestore.Timestamp.fromDate(new Date()),
        },
        proxyCrawlCompletedFlag: true,
      };

      console.log('Saving ProxyCrawl from webhook to contact_data contact for first time', contactDocID);

      try {
        await updateDocumentsUsingMerge(COLLECTION.CONTACT_DATA, [
          {
            id: contactDocID,
            ...obj,
          },
        ]);

        console.log('🍏 Contact Data Document successfully updated - CREATE:', contactDocID);
        await moveLinkedInTitleAndCompanyToCurrentJobAndChangeJobChangedFlagTrue(contactDocID);
      } catch (error) {
        // The document probably doesn't exist
        console.error('🛑 Error updating document:', contactDocID, error);
      }
    }
  }
  return;
}

export const proxyCrawlLinkedIn = async (req: Request, res: Response): Promise<void> => {
  const { headers, body } = req;

  console.log('headers', headers);
  if (headers == undefined || !body) {
    console.log('Not webhook data - Exit cloud function early');
    res.send();
  }

  let result;
  let rid;

  try {
    result = JSON.parse(body);
    rid = headers.rid;

    if (result && result.body !== '' && typeof rid == 'string') {
      let error = false;
      let errorMessage = 'No Error';
      const totalJobs = result.experience.experienceTotal;
      const experienceGroup: [] = result.experience.experienceGroup;
      const experienceList: [] = result.experience.experienceList;
      const { currentJob, currentCompany } = getLatestTitleAndCompany(experienceGroup, experienceList, totalJobs);

      const obj: Partial<ContactData> = {
        profilePhoto: result.profileImage || '',
        lastLinkedInData: {
          name: result.title || '',
          header: result.headline || '',
          location: result.sublines.length > 0 ? result.sublines[0] : '',
          education: result.educationInfo.school || '',
          linkedInURL: result.profileUrl || '',
          currentJob: {
            companyName: currentCompany.name || '',
            title: currentJob.title || '',
            dateRange: `${currentJob.startDate} - ${currentJob.endDate}` || '',
            currentPosition: currentJob.currentPosition || true,
            companyLink: currentCompany.link || '',
            startDate: currentJob.startDate || '',
            endDate: currentJob.endDate || '',
            duration: currentJob.duration || '',
            location: currentJob.location || '',
            description: currentJob.description || '',
            lastUpdated: firestore.Timestamp.fromDate(new Date()),
            source: 'LinkedIn-ProxyCrawl',
          },
          fullData: result,
        },
        proxyCrawlCompletedFlag: true,
        proxyCrawlErrorFlag: error,
        proxyCrawlErrorMessage: errorMessage,
        lastUpdatedProxyCrawl: firestore.Timestamp.fromDate(new Date()),
      };

      // Get proxycrawl RID to save inbound data to in DB
      const contact = (await getContactDataContactByProxyCrawlRID(rid)) as ContactData;

      // check if LinkedIn Profile is private or not found. If so then send error flag up
      if (
        result.title === '' ||
        (result.experience.experienceGroup.length === 0 && result.experience.experienceList.length === 0)
      ) {
        error = true;
        errorMessage = 'Could not scrape title or company name from LinkedIn URL';
        try {
          await flagProxyCrawlContactError(contact.ID, errorMessage);
          console.log('🛑 Private profile, could not save', contact.ID, contact.linkedInURL);
        } catch (e) {
          console.log('🛑 Error saving error flag', contact.ID);
        } finally {
          res.send();
        }
      } else {
        uploadProxyCrawlDataToDb(obj, contact);
      }
    }
  } catch (e) {
    console.log('ProxyCrawl Webhook Error', e);
    res.send();
  }

  res.send();
};
