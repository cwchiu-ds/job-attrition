import { Request, Response } from 'firebase-functions';
import { getDocumentsByField, updateDocumentsUsingMerge, updateDocumentUsingMerge } from '../../controllers/firestore';
import { COLLECTION, ClientContactField, ClientField, QAJobChangeStatus } from '../../utils/constants';
import { getCurrentTimestamp } from '../../utils/functions';

export const theCheckerWebhook = async (req: Request, res: Response): Promise<void> => {
  const { body } = req;

  if (body) {
    const emailPingId = body.id;
    const undeliverable = body.undeliverable;
    const invalidEmails = undeliverable.rejected_email
      .concat(undeliverable.no_connect)
      .concat(undeliverable.invalid_email)
      .concat(undeliverable.invalid_domain);

    if (invalidEmails.length > 0) {
      const clients: Client[] = await getDocumentsByField<Client>({
        collection: COLLECTION.CLIENTS,
        field: ClientField.EMAIL_PING_ID,
        operation: '==',
        fieldValue: emailPingId,
      });
      if (clients) {
        const updatedContactDatas: any = [];
        const updatedClientContacts: any = [];

        const clientContacts = (await getDocumentsByField<ClientContact>({
          collection: COLLECTION.CLIENT_CONTACTS,
          field: ClientContactField.CLIENT_ID,
          operation: '==',
          fieldValue: clients[0].id,
        })) as WithId<Partial<ClientContact>>[];

        clientContacts.forEach((contact) => {
          if (
            contact.email &&
            invalidEmails.includes(contact.email) &&
            contact.isValidEmail !== false &&
            contact.jobChanged !== true
          ) {
            updatedClientContacts.push({
              id: contact.id,
              isValidEmail: false,
              jobChanged: true,
              jobChangedStatus: QAJobChangeStatus.EMAIL_INVALID,
              dateUpdated: getCurrentTimestamp(),
            });
          } else if (contact.contactData && contact.contactData.emailData) {
            const emailData = contact.contactData.emailData;
            const newEmailData = emailData.map((emails) => {
              if (invalidEmails.includes(emails.email)) {
                return { ...emails, isValid: false, dateUpdated: getCurrentTimestamp() };
              } else {
                return emails;
              }
            });
            updatedContactDatas.push({ id: contact.contactDataId, emailData: newEmailData });
          }
        });

        await updateDocumentUsingMerge<Client>(COLLECTION.CLIENTS, { id: clients[0].id, emailPingId: null });
        await updateDocumentsUsingMerge<ClientContact>(COLLECTION.CLIENT_CONTACTS, updatedClientContacts);
        await updateDocumentsUsingMerge<ContactData>(COLLECTION.CONTACT_DATA, updatedContactDatas);
      }
    } else {
      console.log('✅ No invalid emails');
    }
  }

  res.send();
};
