import { Request, Response } from 'firebase-functions';
import {
  HTTP_METHOD,
  HTTP_RESPONSE,
  COLLECTION,
  ClientContactField,
  ClientInternalField,
} from '../../../utils/constants';
import { getCurrentTimestamp } from '../../../utils/functions';
import { chunk } from 'lodash';
import { calculateMatchScoreGoogleSearchResults } from '../../../modules/googleMatchAlgorithm';
import { getDocumentsByField, updateDocumentsUsingMerge } from '../../../controllers/firestore';

export const googleSearchMatchSelectLinkedInURL = async (req: Request, res: Response): Promise<Response<{}>> => {
  if (req.method !== HTTP_METHOD.POST) {
    console.log('🛑 Bad Request - End Google Search Query');
    return res.sendStatus(HTTP_RESPONSE.BAD_REQUEST);
  }

  let { clientName, clientId } = req.body as {
    clientName?: string;
    clientId: string;
  };
  clientName = clientName?.trim();
  clientId = clientId!.trim();

  if (!clientName && !clientId) {
    return res.sendStatus(HTTP_RESPONSE.BAD_REQUEST);
  }

  const contacts: ClientContact[] = await getDocumentsByField({
    collection: COLLECTION.CLIENT_CONTACTS,
    field: clientId ? ClientContactField.CLIENT_ID : ClientContactField.CLIENT_NAME || '',
    operation: '==',
    fieldValue: clientId ? clientId : clientName || '',
  });

  // const contactsForSearch = contacts!.filter((contact) => contact.linkedInURL);
  const contactsForSearchChunks = chunk(contacts, 400);

  for (const contactChunk of contactsForSearchChunks) {
    await calculateMatchScoreGoogleSearchResults(contactChunk);
  }

  // We also update the client internal data to reflect the denormalization date
  await updateDocumentsUsingMerge<ClientInternal>(COLLECTION.CLIENT_INTERNAL, [
    { id: clientId, [ClientInternalField.CONTACTS_CONTACT_DATA_ID_UPDATED]: getCurrentTimestamp() },
  ]);
  return res.send();
};
