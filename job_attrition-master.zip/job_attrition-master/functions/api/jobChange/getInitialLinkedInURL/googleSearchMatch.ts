import { Request, Response } from 'firebase-functions';
import { chunk } from 'lodash';
import { HTTP_METHOD, HTTP_RESPONSE } from '../../../utils/constants';
import {
  executeCustomSearch,
  generatedSearchQueryString,
  processSearchResultsGetLinkedInURL,
} from '../../../modules/googleSearch';
import { getClientDataContactByCompanyName } from '../../../controllers/firestore';

export const googleSearchLinkedInURL = async (req: Request, res: Response): Promise<Response<{}>> => {
  console.log('req', req.method);
  if (req.method !== HTTP_METHOD.POST) {
    console.log('🛑 Bad Request - End Google Search Query');
    return res.sendStatus(HTTP_RESPONSE.BAD_REQUEST);
  }

  let { clientName } = req.body as {
    clientName?: string;
  };
  clientName = clientName?.trim();

  if (!clientName) {
    return res.sendStatus(HTTP_RESPONSE.BAD_REQUEST);
  }

  const contacts: ClientContact[] = await getClientDataContactByCompanyName(clientName);

  // Filter out contacts that do not have LinkedInURL
  const contactsForSearch = contacts!.filter((contact) => !contact.linkedInURL);
  const contactsForSearchChunks = chunk(contactsForSearch, 400);

  console.log('contacts for search chunks', contactsForSearchChunks);

  for (const contactChunk of contactsForSearchChunks) {
    // TODO consider using siterestrict to be able to run unlimited queries per day
    // https://developers.google.com/custom-search/v1/site_restricted_api

    const queryStringList: [string, string][] = [];
    const searchPromises = contactChunk.map((contact) => {
      const queryString: [string, string] = generatedSearchQueryString(contact);
      queryStringList.push(queryString);
      return executeCustomSearch(queryString[0]!);
    });

    const searchResultsArray = await Promise.all(searchPromises);

    await processSearchResultsGetLinkedInURL(contactChunk, searchResultsArray, queryStringList);
  }

  return res.send();
};
