import { Request, Response } from 'firebase-functions';
import { HTTP_METHOD, HTTP_RESPONSE } from '../../utils/constants';
// import { updateAllClientData } from '../controllers/adHocUpdateFunctions';
import {
  parseCSVUploadClientContacts,
  // postQAFinalUpdatete,
  // markTrackFlagClientData,
  // addClientIdsToContactData,
  // addLinkedInURLsToClientData,
  // addCRMLinkedInURLsOnlyToClientData,
  // addHubspotVidsToClientData,
  // addCurrentJobToClientData,
  changeJobChangedFlagToTrue,
  // moveLinkedInTitleAndCompanyToCurrentJob,
} from '../../modules/parseCSVUploadClientContacts';

export const adHocUpdateDB = async (req: Request, res: Response): Promise<Response<{}>> => {
  console.log('req', req.method);

  if (req.method !== HTTP_METHOD.POST) {
    console.log('🛑 Bad Request - End Google Search Query');
    return res.sendStatus(HTTP_RESPONSE.BAD_REQUEST);
  }

  // await updateAllClientData();

  // **initial upload of client csv - 5 columns**

  await parseCSVUploadClientContacts('Pulse Q&A', 'pulseQA', false);

  // **post QA final upload. Updates client data and contact data
  // await postQAFinalUpdatete('Heartbeat', 'Heartbeat_Updated');

  // update contacts in client contacts that are being tracked
  // await markTrackFlagClientData('Bellwethr', 'Bellwethr_Tracked');

  // add clientIds to contactData contact
  // await addClientIdsToContactData('Bellwethr', 'Bellwethr_clientIds');

  // add LinkedInURLs for a client given email
  // addLinkedInURLsToClientData('alantest25', 'Test');

  // add Hubspot vid for a client given email
  // addHubspotVidsToClientData('Kamana', 'Test');

  // add CRM LinkedInURL to a client contact given email
  // addCRMLinkedInURLsOnlyToClientData('User Interviews', 'Test');

  // add currentJob to client contact given email
  // addCurrentJobToClientData('Iterable', 'Iterable_jobChanges');

  // add currentJob to contact data given contactdataId
  // addCurrentJobToContactData('Bellwethr', 'Bellwethr_jobChanges_contact');

  // change jobChanged flag to true on Client Contacts

  // changeJobChangedFlagToTrue('Optimizely');

  // move title and company from lastLinkedInData to currentJob array and allJobs array in contact_data
  // set true to do entire company rather than select contacts
  // moveLinkedInTitleAndCompanyToCurrentJob('Monday.vc', true);

  return res.send();
};
