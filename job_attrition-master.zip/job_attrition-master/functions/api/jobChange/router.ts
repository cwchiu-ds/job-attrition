import { Router } from 'express';

import { firebaseAuthMiddleware } from '../../modules/expressMiddleware';
import { JobChangeEndpoint } from '../../utils/constants';
import { sendContactsToProxyCrawl } from './scrapers/sendToProxyCrawl';
import { googleSearchLinkedInURL } from './getInitialLinkedInURL/googleSearchMatch';
import { adHocUpdateDB } from './adHocUpdateDB';
import { sendToPDL } from './scrapers/sendToPDL';
import { googleSearchMatchSelectLinkedInURL } from './createContactData/googleSearchMatch';
import { googleSearchOngoing } from './scrapers/sendToGoogle';
import { sendToFullContact } from './scrapers/sendToFullContact';
import { sendCompaniesToProxyCrawl } from './scrapers/sendCompaniesToProxyCrawl';

const router = Router();

// need to add back firebaseAuthMiddleware when we add
router.post(JobChangeEndpoint.SEND_CONTACTS_TO_PROXYCRAWL, sendContactsToProxyCrawl);

router.post(JobChangeEndpoint.SEND_COMPANIES_TO_PROXYCRAWL, sendCompaniesToProxyCrawl);

router.post(JobChangeEndpoint.GET_LINKEDIN_URL, googleSearchLinkedInURL);

router.post(JobChangeEndpoint.ADHOC_UPDATE, adHocUpdateDB);

router.post(JobChangeEndpoint.SEND_CONTACTS_TO_PDL, sendToPDL);

router.post(JobChangeEndpoint.CREATE_CONTACT_DATA, googleSearchMatchSelectLinkedInURL);

router.post(JobChangeEndpoint.SEND_CONTACTS_TO_GOOGLE_ONGOING, googleSearchOngoing);

router.post(JobChangeEndpoint.SEND_CONTACTS_TO_FULLCONTACT, sendToFullContact);

export default router;
