import Bottleneck from 'bottleneck';
import { Request, Response } from 'firebase-functions';
import {
  HTTP_METHOD,
  HTTP_RESPONSE,
  COLLECTION,
  ClientContactField,
  ClientInternalField,
  ContactDataField,
} from '../../../utils/constants';
import { proxyCrawlLinkedIn } from '../../../modules/proxyCrawlParallel';
import {
  flagProxyCrawlContactError,
  getContactDataContactsByCompanyName,
  updateDocumentsUsingMerge,
  getDocumentsByField,
} from '../../../controllers/firestore';
import { scraperControlPanel } from '../../../config/scraperControlPanel';

import https from 'https';
import Axios from 'axios';

import { chunk } from 'lodash';
import { getCurrentTimestamp } from '../../../utils/functions';

const keepAliveAgent = new https.Agent({ keepAlive: true });
const linkedInToken = process.env.PROXYCRAWL_NORMAL_TOKEN;

function timeDiffCalc(dateFuture: Date, dateNow: Date): number {
  const diffInMilliSeconds = Math.abs(dateFuture.getTime() - dateNow.getTime());

  const minutes = Math.floor(diffInMilliSeconds / 60000);

  return minutes;
}

/**
 *
 * Sends requests to Proxy Crawl. Takes 2 params
 * @param {String} CompanyName company name you want to run proxycrawl scraper on (must have LinkedIn URLs)
 * @param {Number} Minutes If more than X minutes have gone by then run scraper. otherwise keep
 */

const sendRequest = async (contacts: ContactData[], minutes: number): Promise<any> => {
  // const filteredContacts = contacts.filter((c) => c.proxyCrawlCompletedFlag);
  let count = 0;

  const limiter = new Bottleneck({
    minTime: 1,
    maxConcurrent: 1,
  });

  return Promise.all(
    contacts.map((contact: ContactData) => {
      return limiter.schedule(async () => {
        count = count + 1;
        // filter out contacts that have been recently scraped. Need input of number of minutes that have elapsed threshold before rescraping.
        if (contact.linkedInURL && contact.linkedInURL !== '') {
          if (minutes && contact.lastUpdatedProxyCrawl) {
            if (timeDiffCalc(new Date(), contact.lastUpdatedProxyCrawl.toDate()) > minutes) {
              await proxyCrawlLinkedIn(contact.linkedInURL, contact.id);

              console.log('count', count);
              //console.log('proxyCrawlLinkedIn ran success');
            } else {
              console.log('✅ Already crawled this guy recently within ', minutes, ' minutes');
              console.log('count', count);
            }
          } else {
            // if there is no lastUpdatedProxyCrawl date then this contact was never run through ProxyCrawl

            console.log('processing proxyCrawl');
            await proxyCrawlLinkedIn(contact.linkedInURL, contact.id);
            console.log('proxyCrawlLinkedIn ran success', contact.clientNames);
            console.log('count', count);
          }
        } else {
          await flagProxyCrawlContactError(contact.id, 'No LinkedIn URL');
          console.log('🛑 Unable to use proxyCrawl LinkedIn Scraper. No email or LinkedIn', contact.id);
        }
      });
    })
  );
};

export const sendCompaniesToProxyCrawl = async (req: Request, res: Response): Promise<Response<{}>> => {
  try {
    const response = await Axios({
      method: 'GET',
      url:
        `https://api.proxycrawl.com/?token=${linkedInToken}&callback=true&crawler=${scraperControlPanel.proxyCrawlerName}&scraper=linkedin-company&url=` +
        'https://www.linkedin.com/company/wellsfargo/',
      // responseType: 'stream',
      httpsAgent: keepAliveAgent,
    }).catch((e) => console.log(e));
    console.log('response is', response);
  } catch (err) {
    console.log('🛑 an error occuredd==>>>');
  }

  console.log('✅ ProxyCrawl Send company complete');

  return res.send();
};
