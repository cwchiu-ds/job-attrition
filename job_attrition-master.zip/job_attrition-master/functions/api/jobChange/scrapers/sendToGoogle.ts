import { Request, Response } from 'firebase-functions';
import { HTTP_METHOD, HTTP_RESPONSE } from '../../../utils/constants';
import { chunk } from 'lodash';
import { executeCustomSearch, processSearchResults } from '../../../modules/googleSearch';
import { getContactDataContactsByCompanyNameAndTrackFlag } from '../../../controllers/firestore';

function sleep(milliseconds: number): void {
  const date = Date.now();
  let currentDate = null;
  do {
    currentDate = Date.now();
  } while (currentDate - date < milliseconds);
}

export const googleSearchOngoing = async (req: Request, res: Response): Promise<Response<{}> | void> => {
  if (req.method !== HTTP_METHOD.POST) {
    console.log('🛑 Bad Request - End Google Search Query');
    return res.sendStatus(HTTP_RESPONSE.BAD_REQUEST);
  }

  // @ts-ignore
  let { clientName, trackFlag } = req.body as {
    clientName: string;
    trackFlag?: boolean;
  };

  console.log('clientName', clientName, 'trackFlag', trackFlag);

  clientName = clientName?.trim();
  let contacts: ContactData[] = [];
  if (!clientName) {
    return res.sendStatus(HTTP_RESPONSE.BAD_REQUEST);
  } else if (clientName) {
    contacts = await getContactDataContactsByCompanyNameAndTrackFlag(clientName, trackFlag);
  }

  // contacts = contacts.slice(40, 100);

  // Filter out contacts that do not have LinkedInURL
  const contactsForSearch = contacts!.filter((contact) => contact.linkedInURL);

  // contactsForSearch = contactsForSearch.filter((contact) => {
  //   return contact.ID === '0HADYRSRWYPrcD8947Ed';
  // });

  // Google has QPS limit of 10 per IP address: https://developers.google.com/analytics/devguides/config/mgmt/v3/limits-quotas
  const contactsForSearchChunks = chunk(contactsForSearch, 90);

  for (const contactChunk of contactsForSearchChunks) {
    sleep(1000);
    // TODO consider using siterestrict to be able to run unlimited queries per day
    // https://developers.google.com/custom-search/v1/site_restricted_api
    const searchPromises = contactChunk.map((contact) =>
      executeCustomSearch(`site:linkedin.com/in/${contact.linkedInId!}`)
    );
    const searchResultsArray = await Promise.all(searchPromises);

    // console.log("search result array", searchResultsArray);
    await processSearchResults(contactChunk, searchResultsArray);
  }

  console.log('🟢 Ongoing search complete');

  return res.send();
};
