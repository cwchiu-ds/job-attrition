import Bottleneck from 'bottleneck';
import { Request, Response } from 'firebase-functions';
import {
  HTTP_METHOD,
  HTTP_RESPONSE,
  COLLECTION,
  ClientContactField,
  ClientInternalField,
  ContactDataField,
} from '../../../utils/constants';
import { proxyCrawlLinkedIn } from '../../../modules/proxyCrawlParallel';
import {
  flagProxyCrawlContactError,
  getContactDataContactsByCompanyName,
  updateDocumentsUsingMerge,
  getDocumentsByField,
} from '../../../controllers/firestore';

import { chunk } from 'lodash';
import { getCurrentTimestamp } from '../../../utils/functions';

function timeDiffCalc(dateFuture: Date, dateNow: Date): number {
  const diffInMilliSeconds = Math.abs(dateFuture.getTime() - dateNow.getTime());

  const minutes = Math.floor(diffInMilliSeconds / 60000);

  return minutes;
}

/**
 *
 * Sends requests to Proxy Crawl. Takes 2 params
 * @param {String} CompanyName company name you want to run proxycrawl scraper on (must have LinkedIn URLs)
 * @param {Number} Minutes If more than X minutes have gone by then run scraper. otherwise keep
 */

const sendRequest = async (contacts: ContactData[], minutes: number): Promise<any> => {
  // const filteredContacts = contacts.filter((c) => c.proxyCrawlCompletedFlag);
  let count = 0;

  const limiter = new Bottleneck({
    minTime: 1,
    maxConcurrent: 1,
  });

  return Promise.all(
    contacts.map((contact: ContactData) => {
      return limiter.schedule(async () => {
        count = count + 1;
        // filter out contacts that have been recently scraped. Need input of number of minutes that have elapsed threshold before rescraping.
        if (contact.linkedInURL && contact.linkedInURL !== '') {
          if (minutes && contact.lastUpdatedProxyCrawl) {
            if (timeDiffCalc(new Date(), contact.lastUpdatedProxyCrawl.toDate()) > minutes) {
              await proxyCrawlLinkedIn(contact.linkedInURL, contact.id);

              console.log('count', count);
              //console.log('proxyCrawlLinkedIn ran success');
            } else {
              console.log('✅ Already crawled this guy recently within ', minutes, ' minutes');
              console.log('count', count);
            }
          } else {
            // if there is no lastUpdatedProxyCrawl date then this contact was never run through ProxyCrawl

            console.log('processing proxyCrawl');
            await proxyCrawlLinkedIn(contact.linkedInURL, contact.id);
            console.log('proxyCrawlLinkedIn ran success', contact.id);
            console.log('count', count);
          }
        } else {
          await flagProxyCrawlContactError(contact.id, 'No LinkedIn URL');
          console.log('🛑 Unable to use proxyCrawl LinkedIn Scraper. No email or LinkedIn', contact.id);
        }
      });
    })
  );
};

export const sendContactsToProxyCrawl = async (req: Request, res: Response): Promise<Response<{}>> => {
  if (req.method !== HTTP_METHOD.POST) {
    console.log('🛑 Bad Request - End Proxy Crawl');
    return res.sendStatus(HTTP_RESPONSE.BAD_REQUEST);
  }

  let { clientName, clientId } = req.body as {
    clientName?: string;
    clientId: string;
  };
  const { minutes } = req.body as {
    minutes: string;
  };
  clientName = clientName?.trim();
  clientId = clientId!.trim();
  const minutesConverted = parseInt(minutes.trim());

  console.log('company name to send to proxyCrawl', clientName, clientId);

  if (!clientName && !clientId) {
    return res.sendStatus(HTTP_RESPONSE.BAD_REQUEST);
  }

  const contacts: ContactData[] = await getDocumentsByField({
    collection: COLLECTION.CONTACT_DATA,
    field: clientId ? ContactDataField.CLIENT_IDS : ContactDataField.CLIENT_NAMES,
    operation: 'array-contains',
    fieldValue: clientId ? clientId : clientName || '',
  });

  // // // specific list of Contact Ids to crawl. use this formula in excel to get ids comma separated: ="'"&L6&"'"&","
  // const specificContacts = [
  //   'TXRTgRMDJH4S7gJRHLXi',
  //   'cKWdeNFzDs4qaEZbMfmF',
  // ];

  // // remove these specifics by LinkedInId
  // contacts = contacts.filter((contact) => {
  //   return specificContacts.includes(contact.id);
  // });

  // contacts = contacts.slice(0, 2);

  console.log('chuckss==>>>>', contacts.length, minutesConverted);

  /*contactChunks.map(async (chunk) => {
    await sendRequest(chunk, minutes);
    // res.send();
  });*/

  sendRequest(contacts, minutesConverted);

  // you need to send a response with no data otherwise the socket will hang up and error the server

  await updateDocumentsUsingMerge<ClientInternal>(COLLECTION.CLIENT_INTERNAL, [
    { id: clientId, [ClientInternalField.CONTACTS_CONTACT_DATA_SCRAPED]: getCurrentTimestamp() },
  ]);
  console.log('✅ ProxyCrawl Send complete');

  return res.send();
};
