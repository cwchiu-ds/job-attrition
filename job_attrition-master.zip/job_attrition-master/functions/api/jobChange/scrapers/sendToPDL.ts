import { Request, Response } from 'firebase-functions';
import { HTTP_METHOD, HTTP_RESPONSE, PEOPLEDATALABS_API_KEY } from '../../../utils/constants';

import Axios from 'axios';
import { firestore } from 'firebase-admin';

import Bottleneck from 'bottleneck';
import { getClientDataContactByCompanyName, updateClientContactById } from '../../../controllers/firestore';

interface PDLResponse {
  name?: any;
  last_name?: string;
  linkedin?: string;
}

const cleanClientDataObject = (data: PDLResponse, contact: ClientContact): Partial<ClientContact> => {
  const linkedInURL = contact.linkedInURL === '' || !contact.linkedInURL ? data.linkedin : contact.linkedInURL;
  const firstName = contact.firstName === '' || !contact.firstName ? data.name.first_name : contact.firstName;
  const lastName = contact.lastName === '' || !contact.lastName ? data.name.last_name : contact.lastName;
  const fullName = contact.fullName === '' || !contact.fullName ? data.name.clean : contact.fullName;
  return { linkedInURL, firstName, lastName, fullName };
};

export const sendToPDL = async (req: Request, res: Response): Promise<Response<{}>> => {
  console.log('req', req.method);
  if (req.method !== HTTP_METHOD.POST) {
    console.log('🛑 Bad Request - End Google Search Query');
    return res.sendStatus(HTTP_RESPONSE.BAD_REQUEST);
  }

  let { clientName } = req.body as {
    clientName?: string;
  };

  clientName = clientName?.trim();
  console.log('company name to send to People Data Labs', clientName);

  if (!clientName) {
    return res.sendStatus(HTTP_RESPONSE.BAD_REQUEST);
  }

  const contacts: ClientContact[] = await getClientDataContactByCompanyName(clientName);

  // contacts = contacts.slice(400, 500);

  const limiter = new Bottleneck({
    minTime: 333,
    maxConcurrent: 1,
  });
  let count = 0;

  contacts.map((contact) => {
    return limiter.schedule(async () => {
      count = count + 1;
      console.log('starting contact', contact.id, contact.email);
      if ((contact.email || contact.fullName) && (!contact.linkedInURL || contact.linkedInURL === '')) {
        console.log(count, 'running PDL on this person', contact.email, contact.id);

        const companyString = contact.currentJob?.companyName ? `&company=${contact.currentJob.companyName}` : '';
        const firstNameString = contact.firstName ? `&first_name=${contact.firstName}` : '';
        const lastNameString = contact.lastName ? `&last_name=${contact.lastName}` : '';
        const fullNameString = contact.fullName ? `&name=${contact.fullName}` : '';
        const emailString = contact.email ? `&email=${contact.email}` : '';

        const response = await Axios({
          method: 'GET',
          url:
            `https://api.peopledatalabs.com/v4/person?pretty=true&api_key=${PEOPLEDATALABS_API_KEY}&required=profiles.network:linkedin &min_likelihood=6` +
            companyString +
            firstNameString +
            lastNameString +
            fullNameString +
            emailString,
        })
          .then((result) => {
            return result;
          })
          .catch((err) => {
            if (err.response.status === 404) {
              console.log('🛑 PDL Error', err.response.status, contact.email);
            }
          });

        if (response && response.data) {
          const data = response.data.data.primary as PDLResponse;

          const updatedClientDataObject = cleanClientDataObject(data, contact);

          updateClientContactById(contact.id, {
            ...updatedClientDataObject,
            dateUpdated: firestore.Timestamp.fromDate(new Date()),
          });
        }
      }
    });
  });

  return res.send();
};
