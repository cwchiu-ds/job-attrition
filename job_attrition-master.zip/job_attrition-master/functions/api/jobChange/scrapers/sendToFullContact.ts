import Axios from 'axios';
import { Request, Response } from 'firebase-functions';
import { HTTP_METHOD, HTTP_RESPONSE, FULLCONTACT_API_KEY } from '../../../utils/constants';
import https from 'https';
import { getClientDataContactByCompanyName } from '../../../controllers/firestore';

const keepAliveAgent = new https.Agent({ keepAlive: true });

export const sendToFullContact = async (req: Request, res: Response): Promise<Response<{}>> => {
  console.log('req method', req.method);
  if (req.method !== HTTP_METHOD.POST) {
    console.log('🛑 Bad Request - End Google Search Query');
    return res.sendStatus(HTTP_RESPONSE.BAD_REQUEST);
  }

  let { clientName } = req.body as {
    clientName?: string;
  };
  if (!clientName) {
    return res.sendStatus(HTTP_RESPONSE.BAD_REQUEST);
  }

  clientName = clientName?.trim();
  console.log('company name to send to FullContact', clientName);

  //   let contacts: ClientContact[] = await getClientDataContactByCompanyName(clientName);

  //   contacts = contacts.slice(5, 20);

  console.log('FULL API', FULLCONTACT_API_KEY);

  const response = await Axios({
    method: 'POST',
    url: `https://api.fullcontact.com/v3/person.enrich`,
    headers: {
      Authorization: `Bearer ${FULLCONTACT_API_KEY}`,
    },
    httpsAgent: keepAliveAgent,
  });

  console.log('done hello', response);

  return res.send();
};
