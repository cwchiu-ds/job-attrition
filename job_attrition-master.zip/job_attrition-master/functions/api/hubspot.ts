import cors from 'cors';
import express from 'express';

import router from './hubspot/router';

const hubspotApi = express();

// https://expressjs.com/en/advanced/best-practice-security.html#at-a-minimum-disable-x-powered-by-header
hubspotApi.disable('x-powered-by');

hubspotApi.use(cors({ origin: true }));

hubspotApi.use('/', router);

export { hubspotApi };
