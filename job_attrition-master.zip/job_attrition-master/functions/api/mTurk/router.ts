import { Router } from 'express';

import { mTurkEndpoint } from '../../utils/constants';
import CreateHits from './CreateHits';
import ApproveHit from './ApproveHit';

const router = Router();

router.post(mTurkEndpoint.CREATE_TASKS, CreateHits);

router.post(mTurkEndpoint.APPROVE_TASKS, ApproveHit);

export default router;
