import { Request, Response } from 'firebase-functions';

import { getUserById } from '../../controllers/firestore';
import { createHits } from '../../modules/mTurk';
import { COLLECTION, HTTP_RESPONSE, UserType } from '../../utils/constants';

// create AWS Mechanical Turk HITs for finding Client Contact LI URLs and whether they changed jobs
const CreateHits = async (req: Request<AuthenticatedParams & { clientId: string }>, res: Response): Promise<void> => {
  try {
    const clientId = req.body.clientId;

    if (!clientId) {
      res.sendStatus(HTTP_RESPONSE.BAD_REQUEST);
      return;
    }

    // const authUser = await getUserById(req.params.authUID);

    // if (authUser?.userType !== UserType.INTERNAL) {
    //   res.sendStatus(HTTP_RESPONSE.BAD_REQUEST);
    //   return;
    // }

    await createHits(clientId);

    res.send();
  } catch (err) {
    console.error(err);

    res.sendStatus(HTTP_RESPONSE.INTERNAL_SERVER_ERROR);
  }
};

export default CreateHits;
