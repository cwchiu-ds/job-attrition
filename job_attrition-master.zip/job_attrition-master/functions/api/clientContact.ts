import cors from 'cors';
import express from 'express';

import router from './clientContact/router';

const clientContactApi = express();

// https://expressjs.com/en/advanced/best-practice-security.html#at-a-minimum-disable-x-powered-by-header
clientContactApi.disable('x-powered-by');

clientContactApi.use(cors({ origin: true }));

clientContactApi.use('/', router);

export { clientContactApi };
