import { Request, Response } from 'firebase-functions';

import { getUserById } from '../../controllers/firestore';
import { getSalesforceTokens } from '../../modules/salesforce';
import { DashboardURL, HTTP_RESPONSE } from '../../utils/constants';

const token = async (req: Request, res: Response): Promise<void> => {
  const code = req.query.code as string;
  const stateQueryString = req.query.state as string;

  if (!code || !stateQueryString) {
    res.sendStatus(HTTP_RESPONSE.BAD_REQUEST);
    return;
  }

  const state = JSON.parse(decodeURIComponent(stateQueryString)) as { userId: string };
  const user = await getUserById(state.userId);

  if (!user) {
    res.sendStatus(HTTP_RESPONSE.BAD_REQUEST);
    return;
  }

  try {
    await getSalesforceTokens(user, code);

    res.redirect(DashboardURL.SalesforceIntegration);
  } catch (err) {
    console.error(err);
  }
};

export default token;
