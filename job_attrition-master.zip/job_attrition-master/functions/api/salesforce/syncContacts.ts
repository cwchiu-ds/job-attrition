import { Request, Response } from 'firebase-functions';

import { getDocumentById, getUserById } from '../../controllers/firestore';
import { syncSalesforceContacts } from '../../modules/salesforce';
import { COLLECTION, HTTP_RESPONSE } from '../../utils/constants';
import { hasSalesforceMapping, hasSalesforceToken } from '../../utils/salesforce';

const syncContacts = async (req: Request<AuthenticatedParams>, res: Response): Promise<void> => {
  const authUID = req.params.authUID;

  try {
    const authUser = await getUserById(authUID);
    const authUserClient = await getDocumentById<Client>(COLLECTION.CLIENTS, authUser!.clientId!);

    if (!authUser || !authUserClient || !hasSalesforceToken(authUserClient) || !hasSalesforceMapping(authUserClient)) {
      console.error(new Error(`Unable to sync contacts. Salesforce integration data missing for clientId ${authUserClient?.id}`));
      res.sendStatus(HTTP_RESPONSE.BAD_REQUEST);
      return;
    }

    await syncSalesforceContacts(authUserClient, authUser);

    res.send();
  } catch (err) {
    console.error(new Error(err.toString()));
    res.sendStatus(HTTP_RESPONSE.INTERNAL_SERVER_ERROR);
  }
};

export default syncContacts;
