import { Request, Response } from 'firebase-functions';

import { salesforceOAuth2 } from '../../config/salesforce';

const auth = async (req: Request<AuthenticatedParams>, res: Response): Promise<void> => {
  // Once salesforce auth has completed, the redirected URI needs to know which user is associated with the auth
  const state = encodeURIComponent(JSON.stringify({ userId: req.params.authUID }));

  const authRedirectUrl = salesforceOAuth2.getAuthorizationUrl({ scope: 'api web refresh_token', state });
  res.send(authRedirectUrl);
};

export default auth;
