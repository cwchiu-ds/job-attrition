import { Request, Response } from 'firebase-functions';

import { getDocumentById, getUserById, updateDocumentsUsingMerge } from '../../controllers/firestore';
import { enrichSalesforceContacts } from '../../modules/salesforce';
import { COLLECTION, HTTP_RESPONSE, SalesforceCustomField, SalesforceCustomFieldType } from '../../utils/constants';
import { hasSalesforceMapping, hasSalesforceToken } from '../../utils/salesforce';
import { SalesforceEnrichContacts } from '../../modules/validation/salesforce';
import { createCustomSalesforceContactField } from '../../controllers/salesforce';

const enrichContacts = async (req: Request<AuthenticatedParams>, res: Response): Promise<void> => {
  const authUID = req.params.authUID;

  try {
    const authUser = await getUserById(authUID);
    const authUserClient = await getDocumentById<Client>(COLLECTION.CLIENTS, authUser!.clientId!);
    const { clientContactIds } = req.body as SalesforceEnrichContacts;

    if (!authUser || !authUserClient || !hasSalesforceToken(authUserClient) || !hasSalesforceMapping(authUserClient)) {
      throw new Error(
        `Unable to sync back contacts. Salesforce integration data missing for client ${authUserClient?.name} (id ${authUserClient?.id})`
      );
    }

    const isFirstTimeEnrichment =
      !authUserClient.salesforceIntegration?.latestJobCompanyFieldName ||
      !authUserClient.salesforceIntegration?.latestJobTitleFieldName ||
      !authUserClient.salesforceIntegration?.latestLinkedInURLFieldName ||
      !authUserClient.salesforceIntegration?.jobChangedFieldName;

    // If we have not previously created the custom fields in LinkedIn, we create them now
    if (isFirstTimeEnrichment) {
      await createCustomSalesforceContactField(authUserClient, SalesforceCustomField.LatestJobCompany);

      await createCustomSalesforceContactField(authUserClient, SalesforceCustomField.LatestJobTitle);

      await createCustomSalesforceContactField(authUserClient, SalesforceCustomField.LatestLinkedIn);

      await createCustomSalesforceContactField(authUserClient, SalesforceCustomField.JobChanged);

      await updateDocumentsUsingMerge<Client>(COLLECTION.CLIENTS, [
        {
          id: authUserClient.id,
          salesforceIntegration: {
            latestJobCompanyFieldName: SalesforceCustomField.LatestJobCompany.name,
            latestJobTitleFieldName: SalesforceCustomField.LatestJobTitle.name,
            latestLinkedInURLFieldName: SalesforceCustomField.LatestLinkedIn.name,
            jobChangedFieldName: SalesforceCustomField.JobChanged.name,
          },
        },
      ]);
    }

    await enrichSalesforceContacts(clientContactIds, authUser, authUserClient);

    res.send();
  } catch (err) {
    console.error(new Error(JSON.stringify(err)));
    res.sendStatus(HTTP_RESPONSE.INTERNAL_SERVER_ERROR);
  }
};

export default enrichContacts;
