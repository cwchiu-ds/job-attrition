import { Request, Response } from 'firebase-functions';

import { getDocumentById, getUserById, updateDocumentsUsingMerge } from '../../controllers/firestore';
import { SalesforceSetupFields } from '../../modules/validation/salesforce';
import { COLLECTION, HTTP_RESPONSE } from '../../utils/constants';
import { hasSalesforceToken } from '../../utils/salesforce';

// NOTE: this function does not sync data with Salesforce, but rather it updates
// the Client data with the information needed to sync with Salesforce
const setupFields = async (req: Request<AuthenticatedParams>, res: Response): Promise<void> => {
  const authUID = req.params.authUID;
  const { salesforceMapping } = req.body as SalesforceSetupFields;

  try {
    const authUser = await getUserById(authUID);
    const authUserClient = await getDocumentById<Client>(COLLECTION.CLIENTS, authUser!.clientId!);

    // This API function should only be called if Salesforce has been authorized (i.e., we have the token)
    if (!authUserClient || !hasSalesforceToken(authUserClient)) {
      throw new Error(
        `Unable to set Salesforce fields. Salesforce authorization data missing for clientId ${authUserClient?.id}`
      );
    }

    const updatedClient: Partial<Client> = {
      ...authUserClient,
      salesforceIntegration: {
        ...authUserClient!.salesforceIntegration,
        salesforceMapping,
      },
    };

    await updateDocumentsUsingMerge<Client>(COLLECTION.CLIENTS, [{ id: authUser!.clientId, ...updatedClient }])

    res.send();
  } catch (err) {
    console.error(err);
    res.sendStatus(HTTP_RESPONSE.BAD_REQUEST);
  }
};

export default setupFields;
