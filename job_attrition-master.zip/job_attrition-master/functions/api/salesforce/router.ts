import { Router } from 'express';

import { firebaseAuthMiddleware } from '../../modules/expressMiddleware';
import { salesforceValidationMiddleware } from '../../modules/validation/salesforce';
import { SalesforceIntegrationEndpoint } from '../../utils/constants';
import auth from './auth';
import setupFields from './setupFields';
import syncContacts from './syncContacts';
import token from './token';
import enrichContacts from './enrichContacts';

const router = Router();

router.get(SalesforceIntegrationEndpoint.AUTH, firebaseAuthMiddleware, auth);

router.put(
  SalesforceIntegrationEndpoint.SETUP_FIELDS,
  [firebaseAuthMiddleware, salesforceValidationMiddleware.setupFields],
  setupFields
);

router.put(
  SalesforceIntegrationEndpoint.ENRICH_CONTACTS,
  [firebaseAuthMiddleware, salesforceValidationMiddleware.enrichContacts],
  enrichContacts
);

router.get(SalesforceIntegrationEndpoint.SYNC_CONTACTS, firebaseAuthMiddleware, syncContacts);

router.get(SalesforceIntegrationEndpoint.TOKEN, token);

export default router;
