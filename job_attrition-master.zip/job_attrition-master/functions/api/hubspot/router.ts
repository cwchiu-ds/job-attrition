import { Router } from 'express';

import { HubspotIntegrationEndpoint } from '../../utils/constants';
import { HubspotSyncJobChanges, HubspotSyncDataEnrichment, HubspotSaveAllContactsToDB } from './hubspotAPI';

const router = Router();

router.post(HubspotIntegrationEndpoint.SYNC_JOB_CHANGES, HubspotSyncJobChanges);

router.post(HubspotIntegrationEndpoint.SYNC_DATA_ENRICHMENT, HubspotSyncDataEnrichment);

router.post(HubspotIntegrationEndpoint.SAVE_ALL_CONTACTS_TO_DB, HubspotSaveAllContactsToDB);

export default router;
