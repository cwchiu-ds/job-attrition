import { Request, Response } from 'firebase-functions';
import { HTTP_METHOD, HTTP_RESPONSE } from '../../utils/constants';
import { getAuthenticatedUID } from '../../utils/functions';
import {
  updateClientContactById,
  getHubSpotVidsByClientContactId,
  getHubSpotVidsAndContactDataTitleAndCompanyByClientContactId,
} from '../../controllers/firestore';
import { firestore } from 'firebase-admin';
import { RequestHandler } from 'express';
import cors from 'cors';
import {
  hubspotSyncJobChanges,
  getHubspotRefreshToken,
  hubspotSyncDataEnrichment,
  hubspotSaveAllContactsToDB,
} from './hubspotFunctions';

const corsHandler = cors({ origin: true });

export const HubspotSyncJobChanges = async (req: Request, res: Response): Promise<Response<{}> | void> => {
  return corsHandler(req, res, async () => {
    const { clientId, clientContactIds } = req.body as {
      clientId: string;
      clientContactIds: string[];
    };

    if (req.method !== HTTP_METHOD.POST || !clientId || !clientContactIds) {
      console.log('🛑 Bad Request - End Hubspot Data Enrichment');
      return res.sendStatus(HTTP_RESPONSE.BAD_REQUEST);
    }

    let vids: string[] = [];

    const refreshToken = (await getHubspotRefreshToken(clientId)) || '';

    try {
      if (clientContactIds.length > 0) {
        const clientContactPromises = clientContactIds.map(async (clientContactId) => {
          const updateObject = {
            jobChanged: false,
            dateUpdated: firestore.Timestamp.fromDate(new Date()),
          };
          // turn off jobChanged flag
          await updateClientContactById(clientContactId, updateObject);
          return getHubSpotVidsByClientContactId(clientContactId);
        });
        vids = await Promise.all(clientContactPromises);
        console.log('hubspot vids', vids);
      }

      await hubspotSyncJobChanges(vids, refreshToken, res);
    } catch (e) {
      console.log('🛑 Error Internal Server', e);
      res.sendStatus(HTTP_RESPONSE.INTERNAL_SERVER_ERROR);
    }
    return res.send();
  });
};

export const HubspotSyncDataEnrichment = async (req: Request, res: Response): Promise<RequestHandler> => {
  console.log('req', req.method);
  return corsHandler(req, res, async () => {
    const { clientId, clientContactIds } = req.body as {
      clientId: string;
      clientContactIds: string[];
    };

    if (req.method !== HTTP_METHOD.POST || !clientId || !clientContactIds) {
      console.log('🛑 Bad Request - End Hubspot Data Enrichment');
      return res.sendStatus(HTTP_RESPONSE.BAD_REQUEST);
    }

    const authUID = await getAuthenticatedUID(req);

    if (!authUID) {
      return res.sendStatus(HTTP_RESPONSE.FORBIDDEN);
    }

    try {
      let clientContacts: Partial<HubSpotEnrichment>[] = [];

      const refreshToken = (await getHubspotRefreshToken(clientId)) || '';

      if (clientContactIds.length > 0) {
        const clientContactPromises = clientContactIds.map((clientContactId) => {
          return getHubSpotVidsAndContactDataTitleAndCompanyByClientContactId(clientContactId);
        });
        clientContacts = await Promise.all(clientContactPromises);
      }
      await hubspotSyncDataEnrichment(clientContacts, refreshToken, res);
    } catch (e) {
      console.log('🛑 Error Internal Server', e);
      return res.sendStatus(HTTP_RESPONSE.INTERNAL_SERVER_ERROR);
    }
    return res.send();
  });
};

export const HubspotSaveAllContactsToDB = async (req: Request, res: Response): Promise<Response<{}> | void> => {
  return corsHandler(req, res, async () => {
    console.log('req', req.method);

    const { clientId } = req.body as {
      clientId: string;
    };

    if (req.method !== HTTP_METHOD.POST || !clientId) {
      console.log('🛑 Bad Request - End Hubspot Data Enrichment');
      return res.sendStatus(HTTP_RESPONSE.BAD_REQUEST);
    }

    console.log('clientId', clientId);

    const refreshToken = (await getHubspotRefreshToken(clientId)) || '';

    const returnedContacts: any = [];

    try {
      await hubspotSaveAllContactsToDB(clientId, returnedContacts, refreshToken, res, undefined);
    } catch (e) {
      console.log('🛑 Error Internal Server', e);
      res.sendStatus(HTTP_RESPONSE.INTERNAL_SERVER_ERROR);
    }
    console.log('✅ All Hubspot contacts synced back to client_data DB');
    return res.send();
  });
};
