import express from 'express';

import { firestore } from 'firebase-admin';
import { Response } from 'firebase-functions';
import request from 'request-promise-native';
import { addOrUpdateClientContacts, updateDocumentUsingMerge } from '../../controllers/firestore';
import admin from '../../config/firebaseConfig';
import { HUBSPOT_PATH, HUBSPOT_URL } from '../../config/hubspotConfig';
import { sendNewHubspotIntegrationUploadAlert } from '../../modules/slack';
import { DashboardURL, COLLECTION } from '../../utils/constants';
import { addhttps } from '../../utils/functions';
import tracer from '../../config/cloudTrace';

const app = express();
const db = admin.firestore();

const clientsCollection = db.collection('clients');

interface AuthCodeProof {
  grant_type?: string;
  client_id?: string;
  client_secret?: string;
  redirect_uri?: string;
  code?: string;
  refresh_token?: string;
}

if (!process.env.HUBSPOT_CLIENT_ID || !process.env.HUBSPOT_CLIENT_SECRET) {
  throw new Error('Missing CLIENT_ID or CLIENT_SECRET environment variable.');
}

//===========================================================================//
//  HUBSPOT APP CONFIGURATION
//
//  All the following values must match configuration settings in your app.
//  They will be used to build the OAuth URL, which users visit to begin
//  installing. If they don't match your app's configuration, users will
//  see an error page.

// Replace the following with the values from your app auth config,
// or set them as environment variables before running.
const CLIENT_ID = process.env.HUBSPOT_CLIENT_ID;
const CLIENT_SECRET = process.env.HUBSPOT_CLIENT_SECRET;

// Scopes for this app will default to `contacts`
// To request others, set the SCOPE environment variable instead
let SCOPES: string[] = ['contacts'];
if (process.env.SCOPE) {
  SCOPES = process.env.SCOPE.split(/ |, ?|%20/).join(' ') as any;
}

// On successful install, users will be redirected to /oauth-callback
// const REDIRECT_URI = `http://localhost:${PORT}/jobattrition/us-central1/hubSpotIntegration/oauth-callback`;

const REDIRECT_URI = `${HUBSPOT_URL}/oauth-callback`;

// const REDIRECT_URI = `https://us-central1-jobattrition.cloudfunctions.net/hubSpotIntegration/oauth-callback`;

//===========================================================================//

//================================//
//   Running the OAuth 2.0 Flow   //
//================================//

// Redirect the user from the installation page to
// the authorization URL
app.get('/install', (req, res) => {
  const companyName = req.query.companyName;
  const companyEmail = req.query.companyEmail;
  const clientId = req.query.clid;

  console.log('req company', companyName, companyEmail, clientId);

  // Step 1
  // Build the authorization URL to redirect a user
  // to when they choose to install the app
  const authUrl =
    'https://app.hubspot.com/oauth/authorize' +
    `?client_id=${encodeURIComponent(CLIENT_ID)}` + // app's client ID]
    // @ts-ignore
    `&scope=${encodeURIComponent(SCOPES)}` + // scopes being requested by the app
    `&redirect_uri=${encodeURIComponent(REDIRECT_URI)}&state=${companyName}[***]${companyEmail}[***]${clientId}`; // where to send the user after the consent page

  console.log('');
  console.log('=== Initiating OAuth 2.0 flow with HubSpot ===');
  console.log('');
  console.log("===> Step 1: Redirecting user to your app's OAuth URL");
  res.redirect(authUrl);
  console.log('===> Step 2: User is being prompted for consent by HubSpot');
});

//==========================================//
//   Exchanging Proof for an Access Token   //
//==========================================//

const exchangeForTokens = async (exchangeProof: AuthCodeProof, clientId: string): Promise<string> => {
  try {
    const responseBody = await request.post('https://api.hubapi.com/oauth/v1/token', {
      form: exchangeProof,
    });
    // Usually, this token data should be persisted in a database and associated with
    // a user identity.
    const tokens = JSON.parse(responseBody);
    // refreshTokenStore[userId] = tokens.refresh_token;

    await clientsCollection.doc(clientId).set(
      {
        accessToken: tokens.access_token,
        refreshToken: tokens.refresh_token,
      },
      { merge: true }
    );

    console.log('saved token', tokens.access_token, tokens.refresh_token);

    console.log('       > Received an access token and refresh token');
    return tokens.access_token as string;
  } catch (e) {
    console.error(`       > Error exchanging ${exchangeProof.grant_type} for access token`);

    return '';
  }
};

// Step 2
// The user is prompted to give the app access to the requested
// resources. This is all done by HubSpot, so no work is necessary
// on the app's end

// Step 3
// Receive the authorization code from the OAuth 2.0 Server,
// and process it based on the query parameters that are passed
app.get('/oauth-callback', async (req, res) => {
  console.log('===> Step 3: Handling the request sent by the server');

  const state = req.query.state as string;

  // parse out company name and company email sent as 'state' parameter during hubspot oauth 2.0

  const clientId = state.split('[***]')[2];

  // Received a user authorization code, so now combine that with the other
  // required values and exchange both for an access token and a refresh token
  if (req.query.code) {
    const authCodeProof: AuthCodeProof = {
      grant_type: 'authorization_code',
      client_id: CLIENT_ID,
      client_secret: CLIENT_SECRET,
      redirect_uri: REDIRECT_URI,
      code: req.query.code as string,
    };

    // Step 4
    // Exchange the authorization code for an access token and refresh token
    console.log('===> Step 4: Exchanging authorization code for an access token and refresh token');
    await exchangeForTokens(authCodeProof, clientId);
    // if (typeof token === 'object' && token.message) {
    //   return res.redirect(`/error?msg=${token.message}`);
    // }

    // Once the tokens have been retrieved, use them to make a query
    // to the HubSpot API
    res.redirect(`${HUBSPOT_PATH}/save-to-crm?state=${req.query.state}`);
  }
});

const refreshAccessToken = async (clientId: string): Promise<string> => {
  const refreshToken = (await clientsCollection.doc(clientId).get()).data()!.refreshToken;
  console.log(refreshToken);

  const refreshTokenProof: AuthCodeProof = {
    grant_type: 'refresh_token',
    client_id: CLIENT_ID,
    client_secret: CLIENT_SECRET,
    redirect_uri: REDIRECT_URI,
    refresh_token: refreshToken,
    // refresh_token: refreshTokenStore[userId]
  };
  return await exchangeForTokens(refreshTokenProof, clientId);
};

//====================================================//
//   Using an Access Token to Query the HubSpot API   //
//====================================================//

const getContact = async (
  accessToken: string,
  returnedContacts: any,
  clientId: string,
  clientName: string,
  refreshToken: string,
  res: any,
  offset: any
): Promise<any> => {
  console.log('=== Retrieving a contact from HubSpot using the access token ===');
  const span = tracer.startSpan('hubspot.alan.auth()');
  try {
    const count = 100; // how many contacts pulled at once

    const headers = {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    };
    let offsetParam;
    if (typeof offset == 'undefined') {
      offsetParam = null;
    } else {
      offsetParam = `vidOffset=${offset}`;
    }
    const paramsString = `?count=${count}&${offsetParam}&property=email&property=firstname&property=lastname&property=company&property=jobtitle&property=jobfunction&property=lifecyclestage&property=hs_linkedinid&property=linkedin_profile&property=linkedin_url`;
    const finalUrl = `https://api.hubapi.com/contacts/v1/lists/all/contacts/all${paramsString}`;

    const options = {
      url: finalUrl,
      headers: headers,
    };

    await request(
      options,
      async (error, response, body: any): Promise<any> => {
        if (error) {
          console.log('error', error);
          throw new Error();
        }

        const parsedBody = JSON.parse(body);

        parsedBody.contacts.forEach((contact: any) => {
          returnedContacts.push(contact);
        });

        if (parsedBody['has-more']) {
          await getContact(
            accessToken,
            returnedContacts,
            clientId,
            clientName,
            refreshToken,
            res,
            parsedBody['vid-offset']
          );
        } else {
          //print out all contacts
          console.log('Hubspot upload total client contact count', returnedContacts.length);

          const newClientContacts = [];
          for (const contact of returnedContacts) {
            const firstName = contact.properties.firstname ? contact.properties.firstname.value : '';
            const lastName = contact.properties.lastname ? contact.properties.lastname.value : '';
            const name = firstName === '' && lastName === '' ? '' : `${firstName} ${lastName}`;
            const companyName = contact.properties.company ? contact.properties.company.value : '';

            const email = contact.properties.email ? contact.properties.email.value : '';
            const hubspotVid = contact.vid;
            const jobTitle = contact.properties.jobtitle ? contact.properties.jobtitle.value : '';

            const lifeCycleStage = contact.properties.lifecyclestage ? contact.properties.lifecyclestage.value : '';

            // linkedin URL property does not exist as default in hubspot CRM. So this field will be different depending on company
            let crmLinkedInURL = '';
            if (contact.properties.hs_linkedinid) {
              crmLinkedInURL = contact.properties.hs_linkedinid.value;
            } else if (contact.properties.linkedin_profile) {
              crmLinkedInURL = contact.properties.linkedin_profile.value;
            } else if (contact.properties.linkedin_url) {
              crmLinkedInURL = contact.properties.linkedin_url.value;
            }

            const newClientContact: Partial<ClientContact> = {
              clientId,
              clientName,
              fullName: name,
              firstName,
              lastName,
              linkedInURL: addhttps(crmLinkedInURL),
              currentJob: {
                title: jobTitle,
                companyName: companyName,
              },
              email: email,
              crmData: {
                vid: hubspotVid,
                crmLinkedInURL: addhttps(crmLinkedInURL),
              },
              lifeCycleStage,
            };

            newClientContacts.push(newClientContact);
          }

          await addOrUpdateClientContacts({
            newClientContacts,
            clientId,
            clientName,
            userId: '',
            fromSalesforce: false,
          });

          // Update clients DB.

          await updateDocumentUsingMerge(COLLECTION.CLIENTS, {
            id: clientId,
            name: clientName,
            ranJobChanges: false,
            accessToken,
            refreshToken,
            integrationType: 'hubspot',
            createdDate: firestore.Timestamp.fromDate(new Date()),
          });

          await sendNewHubspotIntegrationUploadAlert(clientName, newClientContacts.length);

          span.end();

          res.redirect(DashboardURL.EnrichedCrm);

          return;
        }
      }
    );

    // return JSON.parse(result).contacts;
  } catch (e) {
    console.error('  > Unable to retrieve contact');
    return JSON.parse(e.response.body);
  }
};

//========================================//
//   Displaying information to the user   //
//========================================//

// Main function to re pull data from company's CRM if company authenticated using HubSpot
const rePullCRM = async (clientName: string, companyEmail: string, clientId: string, res: Response): Promise<void> => {
  console.log('✅ Saving to CRM - sessionID available');

  const accessToken = await refreshAccessToken(clientId);
  const refreshToken = (await clientsCollection.doc(clientId).get()).data()!.refreshToken;
  const returnedContacts: any = [];
  console.log('accessToken', accessToken);
  console.log('refresh token', refreshToken);
  await getContact(accessToken, returnedContacts, clientId, clientName, refreshToken, res, undefined);
};

app.get('/save-to-crm', async (req, res) => {
  const state = req.query.state as string;

  // parse out company name and company email sent as 'state' parameter during hubspot oauth 2.0
  const companyName = state.split('[***]')[0];
  const companyEmail = state.split('[***]')[1];
  const clientId = state.split('[***]')[2];

  res.setHeader('Content-Type', 'text/html');

  rePullCRM(companyName, companyEmail, clientId, res);

  // console.log('🛑 Unable to save-to-crm - User not authorized, no sessionID');
});

app.get('/error', (req, res) => {
  res.setHeader('Content-Type', 'text/html');
  res.write(`<h4>Error: ${req.query.msg}</h4>`);
  res.end();
});

export const auth = app;

export const hubSpotIntegration = app;
