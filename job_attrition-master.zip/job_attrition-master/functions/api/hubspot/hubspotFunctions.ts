import request from 'request';
import Hubspot from 'hubspot';
import { firestore } from 'firebase-admin';
import { COLLECTION, HubspotEnrichmentAttributes } from '../../utils/constants';
import { Response } from 'express';
import { db, updateClientContactById, updateClientContactsByHubSpotVid } from '../../controllers/firestore';
import { HUBSPOT_URL } from '../../config/hubspotConfig';
import { addhttps } from '../../utils/functions';

const clientCollection = db.collection(COLLECTION.CLIENTS);

const REDIRECT_URI = `${HUBSPOT_URL}/oauth-callback`;

if (!process.env.HUBSPOT_CLIENT_ID || !process.env.HUBSPOT_CLIENT_SECRET) {
  throw new Error('Missing CLIENT_ID or CLIENT_SECRET environment variable.');
}

export const getHubspotRefreshToken = async (clientId: string): Promise<string | undefined> => {
  let refreshToken;
  try {
    const clientRef = await clientCollection.doc(clientId).get();

    if (clientRef.exists) {
      const client = clientRef.data() as Client;
      refreshToken = client.refreshToken;
    }
  } catch (err) {
    console.log(err);
  }
  return refreshToken;
};

export const hubspotSyncJobChanges = async (vids: string[], refreshToken: string, res: any): Promise<void> => {
  const hubspot = new Hubspot({
    clientId: process.env.HUBSPOT_CLIENT_ID || '',
    clientSecret: process.env.HUBSPOT_CLIENT_SECRET || '',
    redirectUri: REDIRECT_URI,
    refreshToken: refreshToken,
  });
  const token = await hubspot.refreshAccessToken();
  const accessToken = token.access_token;

  const headers = {
    Authorization: `Bearer ${accessToken}`,
    'Content-Type': 'application/json',
  };

  const options = {
    method: 'POST',
    url: 'https://api.hubapi.com/properties/v1/contacts/properties',
    headers: headers,
    body: {
      name: 'job_changed',
      label: 'Job Changed',
      description: 'Indicates if person changed jobs',
      groupName: 'contactinformation',
      type: 'enumeration',
      fieldType: 'booleancheckbox',
      formField: true,
      displayOrder: 6,
      options: [
        { label: 'Yes', value: 'true' },
        { label: 'No', value: 'false' },
      ],
    },
    json: true,
  };

  // create Job Changed field in hubspot
  await request(options, async (error, response) => {
    console.log('status code', response.statusCode);

    if (error) throw new Error(error);
  });

  // for each person in hubspot crm, mark Job Changed field to true using hubspot vid
  vids.forEach(async (vid) => {
    if (vids.length > 0) {
      try {
        const options = {
          method: 'POST',
          url: 'https://api.hubapi.com/contacts/v1/contact/batch/',
          headers: headers,
          body: [
            {
              vid: vid,
              properties: [{ property: 'job_changed', value: 'true' }],
            },
          ],
          json: true,
        };

        try {
          await request(options, function async(error, response) {
            console.log('status code', response.statusCode);

            if (error) throw new Error(error);

            res.send();
          });
        } catch (e) {
          console.log('🛑 Hubspot write error: ', e);
          res.send();
        }
        res.send();
      } catch (e) {
        console.log('🛑 Hubspot write error: ', e);
        res.send();
      }
    } else {
      console.log('🛑 Hubspot write error: No vids received so no jobchanges recorded to Hubspot');
      res.send();
    }
  });
};

export const hubspotSyncDataEnrichment = async (
  contactInfo: Partial<HubSpotEnrichment>[],
  refreshToken: string,
  res: any
): Promise<void> => {
  const hubspot = new Hubspot({
    clientId: process.env.HUBSPOT_CLIENT_ID || '',
    clientSecret: process.env.HUBSPOT_CLIENT_SECRET || '',
    redirectUri: REDIRECT_URI,
    refreshToken: refreshToken,
  });
  const token = await hubspot.refreshAccessToken();
  const accessToken = token.access_token;

  const headers = {
    Authorization: `Bearer ${accessToken}`,
    'Content-Type': 'application/json',
  };

  // for each person in hubspot crm, mark Job Changed field to true using hubspot vid
  contactInfo.forEach(async (contact) => {
    if (contact.crmData && contact.crmData.vid && contact.currentJob && contact.currentJob.length > 0) {
      const vid = contact.crmData.vid;
      const currentJob = contact.currentJob[0] as any;
      const clientContactId = contact.id as string;

      const properties = [];
      const keys = Object.keys(currentJob);
      for (const key of keys) {
        if (currentJob[key] !== '') {
          if (HubspotEnrichmentAttributes[key]) {
            properties.push({
              property: HubspotEnrichmentAttributes[key],
              value: currentJob[key],
            });
          }
        }
      }

      console.log('hubspot properties to update', properties);

      try {
        const options = {
          method: 'POST',
          url: 'https://api.hubapi.com/contacts/v1/contact/batch/',
          headers: headers,
          body: [
            {
              vid: vid,
              properties: properties,
            },
          ],
          json: true,
        };

        try {
          await request(options, function async(error, response) {
            console.log('status code', response.statusCode);

            if (error) {
              throw new Error(error);
            } else {
              const currentJobUpdateObj = currentJob;

              Object.keys(currentJob).forEach((key) => {
                currentJobUpdateObj[key] === '' && delete currentJobUpdateObj[key];
              });
              console.log('object to send', currentJobUpdateObj);
              updateClientContactById(clientContactId, {
                currentJob: currentJobUpdateObj,
              });
            }

            res.send();
          });
        } catch (e) {
          console.log('🛑 Hubspot write error: ', e);
          res.send();
        }
        res.send();
      } catch (e) {
        console.log('🛑 Hubspot write error: ', e);
        res.send();
      }
    } else {
      console.log('🛑 Hubspot write error: No contacts found so no data enrichment recorded to Hubspot');
      res.send();
    }
  });
};

export const hubspotSaveAllContactsToDB = async (
  clientId: string,
  returnedContacts: any,
  refreshToken: string,
  res: Response,
  offset: any
): Promise<void> => {
  try {
    const hubspot = new Hubspot({
      clientId: process.env.HUBSPOT_CLIENT_ID || '',
      clientSecret: process.env.HUBSPOT_CLIENT_SECRET || '',
      redirectUri: REDIRECT_URI,
      refreshToken: refreshToken,
    });

    const token = await hubspot.refreshAccessToken();
    const accessToken = token.access_token;

    const count = 100; // how many contacts pulled at once

    const headers = {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    };
    let offsetParam;
    if (typeof offset == 'undefined') {
      offsetParam = null;
    } else {
      offsetParam = `vidOffset=${offset}`;
    }
    const paramsString = `?count=${count}&${offsetParam}&property=email&property=firstname&property=lastname&property=company&property=jobtitle&property=jobfunction&property=lifecyclestage&property=hs_linkedinid&property=linkedin_profile&property=linkedin_url`;
    const finalUrl = `https://api.hubapi.com/contacts/v1/lists/all/contacts/all${paramsString}`;

    const options = {
      url: finalUrl,
      headers: headers,
    };

    await request(options, async (error, response, body: any) => {
      console.log('response code', response);
      if (error) {
        console.log('error', error);
        throw new Error();
      }

      const parsedBody = JSON.parse(body);

      parsedBody.contacts.forEach((contact: any) => {
        returnedContacts.push(contact);
      });

      if (parsedBody['has-more']) {
        hubspotSaveAllContactsToDB(clientId, returnedContacts, refreshToken, res, parsedBody['vid-offset']);
      } else {
        //print out all contacts
        console.log('finished count', returnedContacts.length);

        for (const contact of returnedContacts) {
          const firstName = contact.properties.firstname ? contact.properties.firstname.value : '';
          const lastName = contact.properties.lastname ? contact.properties.lastname.value : '';
          const name = firstName === '' && lastName === '' ? '' : `${firstName} ${lastName}`;
          const companyName = contact.properties.company ? contact.properties.company.value : '';

          const email = contact.properties.email ? contact.properties.email.value : '';
          const hubspotVid = contact.vid;
          const jobTitle = contact.properties.jobtitle ? contact.properties.jobtitle.value : '';

          const lifeCycleStage = contact.properties.lifecyclestage ? contact.properties.lifecyclestage.value : '';

          // linkedin URL property does not exist as default in hubspot CRM. So this field will be different depending on company
          let crmLinkedInURL = '';
          if (contact.properties.hs_linkedinid) {
            crmLinkedInURL = contact.properties.hs_linkedinid.value;
          } else if (contact.properties.linkedin_profile) {
            crmLinkedInURL = contact.properties.linkedin_profile.value;
          } else if (contact.properties.linkedin_url) {
            crmLinkedInURL = contact.properties.linkedin_url.value;
          }

          console.log('crmLinkedInURL', crmLinkedInURL, contact.properties);

          console.log(name, companyName, hubspotVid, email, jobTitle);

          const hubspotObjectToUpdateClientData = {
            fullName: name,
            firstName,
            lastName,
            currentJob: {
              title: jobTitle,
              companyName: companyName,
            },
            email: email,
            crmData: {
              vid: hubspotVid,
              crmLinkedInURL: addhttps(crmLinkedInURL),
            },
            lifeCycleStage,
            dateUpdated: firestore.Timestamp.fromDate(new Date()),
          };
          await updateClientContactsByHubSpotVid(clientId, hubspotVid, hubspotObjectToUpdateClientData);
        }
        return;
      }
    });
  } catch (e) {
    console.log('🛑 Error Hubspot Saving Data to DB');
    return;
  }
};
