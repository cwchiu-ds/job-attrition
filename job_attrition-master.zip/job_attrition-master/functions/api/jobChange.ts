import cors from 'cors';
import express from 'express';

import router from './jobChange/router';

const jobChangeApi = express();

jobChangeApi.disable('x-powered-by');

jobChangeApi.use(cors({ origin: true }));

jobChangeApi.use('/', router);

export { jobChangeApi };
