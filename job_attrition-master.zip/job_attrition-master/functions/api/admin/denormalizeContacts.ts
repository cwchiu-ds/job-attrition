import { Request, Response } from 'firebase-functions';

import { getDocumentById, getUserById } from '../../controllers/firestore';
import { denormalizeContactData } from '../../modules/admin';
import { COLLECTION, HTTP_RESPONSE, UserType } from '../../utils/constants';

// This function is called in order to synchronize the contactData stored in client_data (for a given client) with the
// contact_data collection. We have a trigger function that automatically does this everytime a contact_data
// is created or modified, but we may need to manually invoke this time for time for various reasons
// (e.g., conform legacy data, fix broken data)
const denormalizeContacts = async (
  req: Request<AuthenticatedParams & { clientId: string }>,
  res: Response
): Promise<void> => {
  try {
    const clientId = req.params.clientId;

    if (!clientId) {
      res.sendStatus(HTTP_RESPONSE.BAD_REQUEST);
      return;
    }

    const authUser = await getUserById(req.params.authUID);
    const client = await getDocumentById<Client>(COLLECTION.CLIENTS, clientId);

    if (!client || authUser?.userType !== UserType.INTERNAL) {
      res.sendStatus(HTTP_RESPONSE.BAD_REQUEST);
      return;
    }

    await denormalizeContactData(client);

    res.send();
  } catch (err) {
    console.error(err);

    res.sendStatus(HTTP_RESPONSE.INTERNAL_SERVER_ERROR);
  }
};

export default denormalizeContacts;
