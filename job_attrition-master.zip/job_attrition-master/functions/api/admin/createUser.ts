import { Request, Response } from 'firebase-functions';

import { createAuthUser } from '../../controllers/authentication';
import { createClient, createUserData } from '../../controllers/firestore';
import { CreateNewUser } from '../../modules/validation/admin';
import { HTTP_RESPONSE } from '../../utils/constants';
import { getCurrentTimestamp } from '../../utils/functions';

const createUser = async (req: Request<AuthenticatedParams & { clientId: string }>, res: Response): Promise<void> => {
  try {
    const { firstName, lastName, email, password, userType, companyName } = req.body as CreateNewUser;

    const authUser = await createAuthUser({ email, password });

    let clientId;

    if (req.body.clientId) {
      clientId = req.body.clientId;
    } else {
      const newClient = await createClient({ name: companyName });
      clientId = newClient.id;
    }

    await createUserData({
      id: authUser.uid,
      email,
      firstName,
      lastName,
      clientId,
      userType,
      createdDate: getCurrentTimestamp()
    });

    res.send();
  } catch (err) {
    console.error(err);
    res.sendStatus(HTTP_RESPONSE.INTERNAL_SERVER_ERROR);
  }
};

export default createUser;
