import { Request, Response } from 'firebase-functions';

import { getDocumentById, getUserById } from '../../controllers/firestore';
import { generateJobChangesForRandomContacts } from '../../modules/admin';
import { COLLECTION, CURRENT_ENVIRONMENT, Environment, HTTP_RESPONSE, UserType } from '../../utils/constants';
import tracer from '../../config/cloudTrace';

const generateJobChanges = async (
  req: Request<AuthenticatedParams & { clientId: string }>,
  res: Response
): Promise<void> => {
  const span = tracer.startSpan('admin.generateJobChanges()');

  try {
    const clientId = req.params.clientId;

    if (!clientId) {
      res.sendStatus(HTTP_RESPONSE.BAD_REQUEST);
      return;
    }

    const authUser = await getUserById(req.params.authUID);
    const client = await getDocumentById<Client>(COLLECTION.CLIENTS, clientId);

    // Only internal users can run this, and this should never be run in prod environment
    if (!client || authUser?.userType !== UserType.INTERNAL || CURRENT_ENVIRONMENT === Environment.Production) {
      res.sendStatus(HTTP_RESPONSE.BAD_REQUEST);
      return;
    }

    await generateJobChangesForRandomContacts(client);

    span.end();

    res.send();
  } catch (err) {
    console.error(err);

    span.end();

    res.sendStatus(HTTP_RESPONSE.INTERNAL_SERVER_ERROR);
  }
};

export default generateJobChanges;
