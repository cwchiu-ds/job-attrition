import { Request, Response } from 'firebase-functions';

import { getUserById, getDocumentsByField, updateDocumentsUsingMerge } from '../../controllers/firestore';
import { appendCompanyURL } from '../../modules/appendCompanyURL';
import { COLLECTION, HTTP_RESPONSE, UserType, ContactDataField } from '../../utils/constants';

// This function is called in order to synchronize the contactData stored in client_data (for a given client) with the
// contact_data collection. We have a trigger function that automatically does this everytime a contact_data
// is created or modified, but we may need to manually invoke this time for time for various reasons
// (e.g., conform legacy data, fix broken data)
const appendCompanyURLToContact = async (
  req: Request<AuthenticatedParams & { clientId: string }>,
  res: Response
): Promise<void> => {
  try {
    const clientId = req.params.clientId;

    console.log('client id', clientId);

    if (!clientId) {
      res.sendStatus(HTTP_RESPONSE.BAD_REQUEST);
      return;
    }

    const authUser = await getUserById(req.params.authUID);

    if (authUser?.userType !== UserType.INTERNAL) {
      res.sendStatus(HTTP_RESPONSE.BAD_REQUEST);
      return;
    }

    const contacts: ContactData[] = await getDocumentsByField({
      collection: COLLECTION.CONTACT_DATA,
      field: clientId ? ContactDataField.CLIENT_IDS : ContactDataField.CLIENT_NAMES,
      operation: 'array-contains',
      fieldValue: clientId,
    });

    contacts.map(async (contact) => {
      if (contact?.allJobs && contact.currentJob) {
        const currentJob = contact.currentJob;
        const allJobs = contact.allJobs;

        // appending Company URL to each current job of contact
        const currentJobPromises = currentJob.map(async (currentJob) => {
          return appendCompanyURL(currentJob);
        });
        const newCurrentJob = await Promise.all(currentJobPromises);

        // appending Company URL to each all job of contact
        const allJobsPromises = allJobs.map(async (currentJob) => {
          return appendCompanyURL(currentJob);
        });
        const newAllJobs = await Promise.all(allJobsPromises);

        const updatedContactData: Partial<ContactData> = {
          currentJob: newCurrentJob,
          allJobs: newAllJobs,
        };

        await updateDocumentsUsingMerge<ContactData>(COLLECTION.CONTACT_DATA, [
          { ...updatedContactData, id: contact.id },
        ]);
      }
    });

    res.send();
  } catch (err) {
    console.error(err);

    res.sendStatus(HTTP_RESPONSE.INTERNAL_SERVER_ERROR);
  }
};

export default appendCompanyURLToContact;
