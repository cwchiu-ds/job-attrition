import { Router } from 'express';

import { firebaseAuthMiddleware } from '../../modules/expressMiddleware';
import { adminValidationMiddleware } from '../../modules/validation/admin';
import { AdminEndpoint } from '../../utils/constants';
import createUser from './createUser';
import denormalizeContacts from './denormalizeContacts';
import generateJobChanges from './generateJobChanges';
import appendCompanyURLToContact from './appendCompanyURL';

const router = Router();

router.get(`${AdminEndpoint.GENERATE_JOB_CHANGES}/:clientId`, firebaseAuthMiddleware, generateJobChanges);
router.get(`${AdminEndpoint.DENORMALIZE_CONTACTS}/:clientId`, firebaseAuthMiddleware, denormalizeContacts);
router.get(`${AdminEndpoint.APPEND_COMPANY_URL}/:clientId`, firebaseAuthMiddleware, appendCompanyURLToContact);

router.post(
  AdminEndpoint.CREATE_NEW_USER,
  [firebaseAuthMiddleware, adminValidationMiddleware.createNewUser],
  createUser
);

export default router;
