import cors from 'cors';
import express from 'express';

import { validationErrorMiddleware } from '../modules/expressMiddleware';
import router from './admin/router'

const adminApi = express()

// https://expressjs.com/en/advanced/best-practice-security.html#at-a-minimum-disable-x-powered-by-header
adminApi.disable('x-powered-by')

adminApi.use(cors({ origin: true }))

adminApi.use('/', router)

adminApi.use(validationErrorMiddleware);

export { adminApi }