import { Router } from 'express';

import { firebaseAuthMiddleware } from '../../modules/expressMiddleware';
import { ClientContactEndpoint } from '../../utils/constants';
import { dismissClientContactJobChange } from './updateClientContact';

const router = Router();

router.post(
  ClientContactEndpoint.DISMISS_CLIENT_CONTACT_JOB_CHANGE,
  firebaseAuthMiddleware,
  dismissClientContactJobChange
);

export default router;
