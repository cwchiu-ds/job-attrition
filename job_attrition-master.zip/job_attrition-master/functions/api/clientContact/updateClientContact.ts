import { Request, Response } from 'firebase-functions';
import { HTTP_RESPONSE, HTTP_METHOD } from '../../utils/constants';
import { updateClientContactById } from '../../controllers/firestore';
import { getCurrentTimestamp } from '../../utils/functions';

export const dismissClientContactJobChange = async (req: Request, res: Response): Promise<Response<{}> | void> => {
  const { clientContactIds } = req.body as {
    clientContactIds: string[];
  };

  if (req.method !== HTTP_METHOD.POST || !clientContactIds) {
    return res.sendStatus(HTTP_RESPONSE.BAD_REQUEST);
  }

  try {
    if (clientContactIds.length > 0) {
      clientContactIds.map(async (clientContactId) => {
        const updateObject = {
          jobChanged: false,
          dateUpdated: getCurrentTimestamp(),
        };
        // turn off jobChanged flag
        await updateClientContactById(clientContactId, updateObject);
      });
    }
  } catch (e) {
    console.error(new Error('Error dismissing client contact job change \n\n' + e.toString()));
    res.sendStatus(HTTP_RESPONSE.INTERNAL_SERVER_ERROR);
  }
  return res.send();
};
