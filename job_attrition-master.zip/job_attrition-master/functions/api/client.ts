import cors from 'cors';
import express from 'express';

import { validationErrorMiddleware } from '../modules/expressMiddleware';
import router from './client/router'

const clientApi = express()

// https://expressjs.com/en/advanced/best-practice-security.html#at-a-minimum-disable-x-powered-by-header
clientApi.disable('x-powered-by')

clientApi.use(cors({ origin: true }))

clientApi.use('/', router)

clientApi.use(validationErrorMiddleware);

export { clientApi }