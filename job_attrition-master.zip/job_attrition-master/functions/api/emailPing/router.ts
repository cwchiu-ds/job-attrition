import { Router } from 'express';

import { firebaseAuthMiddleware } from '../../modules/expressMiddleware';
import { EmailPingEndpoint } from '../../utils/constants';
import TheChecker from './theChecker';

const router = Router();

router.post(EmailPingEndpoint.THE_CHECKER, TheChecker);

export default router;
