import { Request, Response } from 'firebase-functions';
import { COLLECTION, HTTP_RESPONSE, ClientContactField, THE_CHECKER_API_KEY } from '../../utils/constants';
import { getDocumentsByField, updateDocumentUsingMerge } from '../../controllers/firestore';
import Axios from 'axios';

const sendBatchEmailsToChecker = async (emails: string[]): Promise<string | void> => {
  // send batch email validation check to TheChecker
  const url = `https://api.thechecker.co/v2/verifications?api_key=${THE_CHECKER_API_KEY}`;
  const response = await Axios.post(url, {
    emails: emails,
    high_precision_mode: true,
  })
    .then((result) => {
      return result;
    })
    .catch((err) => {
      console.error(err);
    });

  if (response && response.data) {
    console.log('The Checker email ping send response', response.data);
    return response.data.id;
  } else {
    return;
  }
};

const TheChecker = async (req: Request<AuthenticatedParams>, res: Response): Promise<void> => {
  try {
    const clientId = req.body.clientId;
    if (!clientId) {
      res.sendStatus(HTTP_RESPONSE.BAD_REQUEST);
      return;
    }

    const clientContacts: ClientContact[] = await getDocumentsByField<ClientContact>({
      collection: COLLECTION.CLIENT_CONTACTS,
      field: ClientContactField.CLIENT_ID,
      operation: '==',
      fieldValue: clientId,
    });

    let emails: string[] = [];

    clientContacts.forEach((contact) => {
      if (!contact.contactData && contact.email) {
        emails.push(contact.email);
        return;
      } else {
        if (contact.contactData && contact.contactData.emailArray) {
          emails = emails.concat(contact.contactData.emailArray);
        }
      }
    });

    const emailsDeduped = new Set(emails);
    const emailArray = [...emailsDeduped];
    console.log('emails to check', emailArray);

    if (emailArray.length > 0) {
      const emailPingId = await sendBatchEmailsToChecker(emailArray);

      if (emailPingId) {
        // append emailPingId that the webhook will need to use to pull the right client
        await updateDocumentUsingMerge(COLLECTION.CLIENTS, { id: clientId, emailPingId });
      }
    }

    res.send();
  } catch (err) {
    console.error(err);
    res.sendStatus(HTTP_RESPONSE.BAD_REQUEST);
  }
};

export default TheChecker;
