import cors from 'cors';
import express from 'express';

import router from './emailReports/router';

const emailReportsApi = express();

// https://expressjs.com/en/advanced/best-practice-security.html#at-a-minimum-disable-x-powered-by-header
emailReportsApi.disable('x-powered-by');

emailReportsApi.use(cors({ origin: true }));

emailReportsApi.use('/', router);

export { emailReportsApi };
