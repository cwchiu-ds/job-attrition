interface GoogleTitleParsedObject {
  name: string;
  jobTitle: string;
  companyName: string;
  titleLength: number;
  location: string;
}
