import { Field } from 'jsforce';

import { scraperControlPanel } from '../config/scraperControlPanel';
import {
  ClientContactAttribute,
  ClientContactField,
  ClientField,
  ClientInternalField,
  ClientStatus,
  ContactDataField,
  IntegrationType,
  QAStatus,
  SyncStatus,
  UserField,
  UserType,
  SalesforceCustomFieldName,
  CompaniesField,
  SalesforceCustomFieldType,
} from '../utils/constants';

declare global {
  type Timestamp = FirebaseFirestore.Timestamp;

  type AuthenticatedParams = {
    authUID: string;
  };

  type CrmData = {
    [key: string]: string;
  };

  type Block = {
    [block: number]: { startAtId: string; blockSize: number };
  };

  type ScraperControlPanel = typeof scraperControlPanel;

  type WithId<T> = T & { id: string };

  interface InitialGoogleSearch {
    topThreeSearchResults?: PotentialSearch[];
    highestScoreObject?: HighestScoreObject;
    queryString?: string;
    queryParams?: string;
    searchTime?: Timestamp;
    fillError?: boolean;
  }

  interface HighestScoreObject {
    highestScore?: string;
    googleSearchResult?: PotentialSearch;
    parsedName?: string;
    parsedTitle?: string;
    parsedCompanyName?: string;
    parsedLocation?: string;
  }

  interface PotentialSearch {
    linkedInURL: string;
    title: string;
    snippet: string;
    score?: string;
  }

  interface DetectedJobChange {
    title: string;
    companyName: string;
    timestamp: boolean;
    dateDetected: Timestamp;
    source: string;
  }

  interface HubSpotEnrichment {
    crmData: CrmData;
    currentJob: CurrentJob[];
    id: string;
  }

  interface HubSpotEnrichmentAttributes {
    [key: string]: string;
  }

  interface ContactData {
    ID: string; // linkedIn url ID
    [ContactDataField.ID]: string; // document id
    [ContactDataField.FULL_NAME]: string;
    [ContactDataField.FIRST_NAME]: string;
    [ContactDataField.LAST_NAME]: string;
    [ContactDataField.CLIENT_IDS]?: string[];
    [ContactDataField.CLIENT_NAMES]?: string[];
    [ContactDataField.CURRENT_JOBS]: CurrentJob[];
    [ContactDataField.ALL_JOBS]: CurrentJob[];
    [ContactDataField.LAST_UPDATED_PROXY_CRAWL]?: Timestamp;
    [ContactDataField.DETECTED_JOB_CHANGES]?: DetectedJobChange;
    [ContactDataField.LINKEDIN_URL]?: string;
    [ContactDataField.LINKEDIN_ID]?: string;
    [ContactDataField.DETECTED_JOB_CHANGES_STATUS]?: DetectedJobChangesStatus;
    [ContactDataField.DATE_UPDATED]?: Timestamp;
    [ContactDataField.WEBSITES]?: string[];
    [ContactDataField.EMAIL_DATA]?: EmailData[];
    [ContactDataField.EMAIL_ARRAY]: string[];
    [ContactDataField.LAST_LINKEDIN_DATA]: LastLinkedInData;
    [ContactDataField.PEOPLE_DATA_LABS_DATA]: PeopleDataLabsData;
    [ContactDataField.GOOGLE_SEARCH_RESULTS]: GoogleSearchResults;
    [ContactDataField.SHOULD_RESCRAPE]?: boolean;
    [ContactDataField.PROFILE_PHOTO]?: string;
    [ContactDataField.PROXY_CRAWL_COMPLETED_FLAG]: boolean;
    [ContactDataField.PROXY_CRAWL_ERROR_FLAG]: boolean;
    [ContactDataField.PROXY_CRAWL_ERROR_MESSAGE]: string;
  }

  interface EmailData {
    isValid?: boolean;
    dateCreated?: Timestamp;
    email?: string;
    source?: string;
  }

  interface PeopleDataLabsData {
    dateCreated: Timestamp;
    currentJob: CurrentJob;
    workExperience: CurrentJob[];
  }

  interface GoogleSearchResults {
    searchResultTitle?: string;
    searchResultDescription?: string;
    searchTime: Timestamp;
    jobsCount?: number;
    googleSearchResultChanges: GoogleSearchResultChanges[];
    googleScrapeFailed?: boolean;
    photoURL?: string;
  }

  interface GoogleSearchResultChanges {
    searchResultTitle?: string;
    searchResultDescription?: string;
    searchTime?: Timestamp;
    jobsCount?: number;
    photoURL?: string;
  }

  interface LastLinkedInData {
    name?: string;
    header?: string;
    location?: string;
    education?: string;
    workExperience?: CurrentJob[];
    currentJob?: CurrentJob;
    source?: string;
    dateCreated?: Timestamp;
    linkedInURL?: string;
    fullData?: any;
  }

  interface GoogleSearchResult {
    currentJob: CurrentJob;
    jobCount?: number;
    photoURL?: string;
    searchResultDescription: string;
    searchResultTitle: string;
    searchTime: Timestamp;
  }

  interface GoogleSearchData {
    currentJob: CurrentJob;
    searchResultTitle: string;
    searchResultDescription: string;
    searchTime: Timestamp;
    jobsCount?: number;
    photoURL?: string;
  }

  interface DetectedJobChangesStatus {
    title: string;
    companyName: string;
    dateDetected: Timestamp;
    source: string;
  }

  interface CurrentJob {
    companyName?: string;
    title?: string;
    lastUpdated?: Timestamp;
    dateRange?: string;
    source?: string;
    companyId?: string;
    currentPosition?: boolean;
    startDate?: string;
    endDate?: string;
    companyLink?: string;
    duration?: string;
    location?: string;
    description?: string[];
    companySize?: string;
    titleLevel?: string;
    companyURL?: string;
    companyURLDomain?: string;
  }

  interface HitLayoutParamter {
    Name?: string;
    Value?: string;
  }

  interface QualificationRequirement {
    QualificationTypeId?: string;
    Comparator?: string;
    LocaleValues?: any;
  }

  interface CreateHitInputObject {
    Title?: string;
    Description?: string;
    MaxAssignments?: number;
    LifetimeInSeconds?: number;
    AssignmentDurationInSeconds?: number;
    Reward?: string;
    HITLayoutId?: string;
    HITLayoutParameters?: HitLayoutParamter[];
    Keywords?: string;
    QualificationRequirements?: QualificationRequirement[];
  }

  interface JobObject {
    company?: string;
    title?: string;
    lastUpdated?: Timestamp;
    dateRange?: string;
  }

  interface ClientContact {
    id: string;
    [ClientContactField.CLIENT_ID]: string;
    [ClientContactField.CLIENT_NAME]: string;
    [ClientContactField.FIRST_NAME]: string | null;
    [ClientContactField.LAST_NAME]: string | null;
    [ClientContactField.FULL_NAME]: string | null;
    [ClientContactField.EMAIL]: string | null;
    [ClientContactField.IS_VALID_EMAIL]?: boolean | null;
    [ClientContactField.VERIFIED]: boolean | null;
    [ClientContactField.LINKEDIN_URL]: string | null;
    [ClientContactField.JOB_CHANGED_STATUS]: string | null;
    [ClientContactField.LINKEDIN_ID]: string | null;
    [ClientContactField.CRM_DATA]: CrmData | null;
    [ClientContactField.ADDED_BY_USER_ID]: string | null;
    [ClientContactField.DATE_UPDATED]: Timestamp | null;
    [ClientContactField.DATE_CREATED]: Timestamp | null;
    [ClientContactField.CONTACT_DATA_ID]: string | null;
    [ClientContactField.CONTACT_DATA]?: ContactData | null;
    [ClientContactField.INITIAL_GOOGLE_SEARCH]: InitialGoogleSearch | null;
    [ClientContactField.JOB_CHANGED]: boolean | null;
    [ClientContactField.ENRICHED_DATA_CHANGED]: boolean | null;
    [ClientContactField.LAST_VERIFIED]: Timestamp | null;
    [ClientContactField.LAST_VERIFIED_USER_ID]: string | null;
    [ClientContactField.LAST_CLAIMED]: Timestamp | null;
    [ClientContactField.LAST_CLAIMED_USER_ID]: string | null;
    [ClientContactField.LEAD_LIFE_CYCLE]: string | null;
    [ClientContactField.UNCERTAIN_URLS]: string[] | null;
    [ClientContactField.PROFILE_PHOTO]: string | null;
    [ClientContactField.CURRENT_JOB]: CurrentJob | null;
    [ClientContactField.TRACK_FLAG]: string | null;
    [ClientContactField.SALESFORCE_ID]: string | null;
    [ClientContactField.LAST_SALESFORCE_ENRICHMENT_DATE]: Timestamp | null;
    [ClientContactField.LAST_SALESFORCE_ENRICHED_COMPANY_NAME]: string | null;
    [ClientContactField.LAST_SALESFORCE_ENRICHED_TITLE]: string | null;
    [ClientContactField.LAST_SALESFORCE_ENRICHED_LINKEDIN_URL]: string | null;
  }

  interface ClientInternal {
    [ClientInternalField.ID]: string; // Should be same as the Client's ID
    [ClientInternalField.NOTES]?: string;
    [ClientInternalField.CONTACTS_DENORMALIZATION_DATE]?: Timestamp;
    [ClientInternalField.CONTACTS_CONTACT_DATA_ID_UPDATED]?: Timestamp;
    [ClientInternalField.CONTACTS_CONTACT_DATA_SCRAPED]?: Timestamp;
  }

  type NewClientContact = Partial<ClientContact>;

  // ContactData may be from a CSV, our database, or a third-party source,
  // so the key could be anything
  type CsvContactData = {
    [key: string]: string;
  };

  type MappedAttributes = {
    [headerName: string]: ClientContactAttribute;
  };

  interface UserData {
    id: string;
    [UserField.FIRST_NAME]: string;
    [UserField.LAST_NAME]: string;
    [UserField.EMAIL]: string;
    [UserField.PHONE_NUMBER]?: string;
    [UserField.CLIENT_ID]: string;
    [UserField.USER_TYPE]: UserType;
    [UserField.CREATED_DATE]: Timestamp;
    [UserField.DO_NOT_SEND_WEEKLY_EMAIL]?: boolean;
  }

  type SalesforceMapping = {
    [key in ClientContactAttribute]?: string;
  };

  interface SalesforceIntegration {
    accessToken?: string;
    refreshToken?: string;
    instanceUrl?: string;
    lastSyncDate?: Timestamp;
    lastSyncUpdatedCount?: number;
    contactCount?: number;
    fields?: Field[];
    salesforceMapping?: SalesforceMapping;
    jobChangedFieldName?: string;
    latestJobTitleFieldName?: string;
    latestJobCompanyFieldName?: string;
    latestLinkedInURLFieldName?: string;
    syncStatus?: SyncStatus;
  }

  interface CSVUpload {
    lastSyncDate?: Timestamp;
    syncStatus?: SyncStatus;
    lastSyncUpdatedCount?: number;
  }

  interface SalesforceCustomFieldData {
    name: SalesforceCustomFieldName;
    label: string;
    description: string;
    fieldType: SalesforceCustomFieldType;
    length?: number;
    defaultValue?: number | string | boolean;
  }
  interface Company {
    id: string;
    [CompaniesField.COMPANY_DOMAINS]?: string[] | null;
    [CompaniesField.COMPANY_LINKEDIN_URL]?: string | null;
    [CompaniesField.COMPANY_NAMES]?: string[] | null;
    [CompaniesField.COMPANY_URL]?: string | null;
    [CompaniesField.COMPANY_URL_DOMAIN]?: string | null;
    [CompaniesField.COMPANY_LINKEDIN_ID]?: string | null;
  }

  interface Client {
    [ClientField.ID]: string;
    [ClientField.NAME]: string;
    [ClientField.CODE_NAME]?: string;
    [ClientField.MAPPED_ATTRIBUTES]?: MappedAttributes;
    [ClientField.ACCESS_TOKEN]?: string;
    [ClientField.REFRESH_TOKEN]?: string;
    [ClientField.INTEGRATION_TYPE]?: IntegrationType;
    [ClientField.SALESFORCE_INTEGRATION]?: SalesforceIntegration;
    [ClientField.SALESFORCE_CONTACTS_ENRICHED]?: number;
    [ClientField.SALESFORCE_JOB_CHANGES_APPROVED]?: number;
    [ClientField.JOB_CHANGE_NOTIFICATION_EMAILS]?: string[];
    [ClientField.QA_STATUS]?: QAStatus;
    [ClientField.QA_STATUS_DATE]?: Timestamp;
    [ClientField.EMAIL_PING_ID]?: string | null;
    [ClientField.QA_USER_IDS]?: string[];
    [ClientField.STATUS]?: ClientStatus;
    [ClientField.STATUS_DATE]?: Timestamp;
    [ClientField.CLIENT_CONTACT_BLOCKS]?: Block;
    [ClientField.CSV_UPLOAD]?: CSVUpload;
  }
}
