interface ProxyCrawlExperienceGroup {
  groupCompany: ProxyCrawlExperienceGroupCompany[];
  positions: ProxyCrawlExperienceGroupPosition[];
}

interface ProxyCrawlExperienceGroupCompany {
  name: string;
  link: string;
  image: string;
  duration: string;
}

interface ProxyCrawlExperiencListeJob {
  title: string;
  company: ProxyCrawlExperiencListeJobCompany;
  startDate: string;
  endDate: string;
  duration: string;
  currentPosition: boolean;
  experienceNumber: number;
  location: string;
  description: [];
}

interface ProxyCrawlExperiencListeJobCompany {
  name: string;
  link: string;
}

interface ProxyCrawlExperienceGroupCompanyCompany {
  name: string;
  link: string;
}

interface ProxyCrawlExperienceGroupPosition {
  title: string;
  startDate: string;
  endDate: string;
  duration: string;
  currentPosition: boolean;
  experienceNumber: number;
  location: string;
  description: [];
}

interface ProxyCrawlCurrentJobCurrentCompany {
  currentJob: ProxyCrawlExperienceGroupPosition;
  currentCompany: ProxyCrawlExperienceGroupCompanyCompany;
}

interface ProxyCrawlWebhookObject {
  name: string;
  profilePhoto: string;
  header: string;
  location: string;
  education: string;
  linkedInURL: string;
  job: ProxyCrawlJobObjectJob;
  error: boolean;
  proxyCrawlCompletedFlag: boolean;
  lastUpdatedProxyCrawl: Timestamp;
  fullProxyCrawlData: any;
}

interface ProxyCrawlJobObjectJob {
  companyName: string;
  companyLink: string;
  title: string;
  dateRange: string;
  startDate: string;
  endDate: string;
  duration: string;
  location: string;
  description: [];
  lastUpdated: Timestamp;
}
