const Hubspot = require('hubspot');
const { firestore } = require('firebase-admin');
const short = require('short-uuid');

const REDIRECT_URI = `${HUBSPOT_URL}/oauth-callback`;

/**
 * Run this script to re-pull hubspot CRM data and stor einto database
 *
 */
const admin = require('firebase-admin');

// @typescript/eslint prohibits the use of require but we need it to dynamically import the json
const serviceAccount = require(`../secrets/jobattrition-firebase-adminsdk-gc6d2-861d6e2361.json`); // eslint-disable-line

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

// const admin = require('../lib/config/firebaseConfig.js');
let db = admin.firestore();
let contacts_db = db.collection('contacts');
let companies_db = db.collection('companies');
let raw_csv_uploads_db = db.collection('raw_csv_uploads');

const hubspot = new Hubspot({
  clientId: '26c7ea6b-258f-46cc-ae3a-e85488c0fb5e',
  clientSecret: '8813d837-a810-47df-a9a3-6baeb4ff48eb',
  redirectUri: REDIRECT_URI,
  refreshToken: 'e2616ef5-6b6d-4a38-92e1-49ed3c7a0f7e',
});

const getToken = async () => {
  const token = await hubspot.refreshAccessToken();
  console.log('token"', token);
};

// getToken();

var request = require('request');

const { HUBSPOT_URL, HUBSPOT_PATH, FRONTEND_HOST } = require('../config/hostURL');
const returnedContacts = [];
const API_KEY = 'demo';
const count = 100;
let companyDocID = 'Kamana'; // Change to email ending? E.g. fitco.com
// let companyEmail = 'brian@heartbeat.com';

const getContacts = async (offset) => {
  const token = await hubspot.refreshAccessToken();
  const accessToken = token.access_token;
  console.log('token"', token);
  const headers = {
    Authorization: `Bearer ${accessToken}`,
    'Content-Type': 'application/json',
  };
  if (typeof offset == 'undefined') {
    offsetParam = null;
  } else {
    offsetParam = `vidOffset=${offset}`;
  }
  const paramsString = `?count=${count}&${offsetParam}&property=email&property=firstname&property=lastname&property=company&property=jobtitle&property=jobfunction&property=lifecyclestage&property=hs_linkedinid&property=linkedin_profile&property=linkedin_url`;

  // const paramsString = `?count=${count}&property=email&property=firstname&property=lastname&property=company&property=jobtitle&property=jobfunction&property=lifecyclestage`;

  const finalUrl = `https://api.hubapi.com/contacts/v1/lists/all/contacts/all${paramsString}`;

  const options = {
    url: finalUrl,
    headers: headers,
  };
  request(options, (error, response, body) => {
    if (error) {
      console.log('error', error);
      throw new Error();
    }

    const parsedBody = JSON.parse(body);
    console.log('parsed body', parsedBody);

    parsedBody.contacts.forEach((contact) => {
      console.log('conso first', contact);
      returnedContacts.push(contact);
    });
    // console.log('parsedBody', parsedBody);
    if (parsedBody['has-more']) {
      console.log('count', returnedContacts.length);
      getContacts(parsedBody['vid-offset']);
    } else {
      //print out all contacts
      console.log('finished');
      console.log(returnedContacts);

      let contactIDs = [];
      for (contact of returnedContacts) {
        let firstName = contact.properties.firstname ? contact.properties.firstname.value : '';
        let lastName = contact.properties.lastname ? contact.properties.lastname.value : '';
        let name = `${firstName} ${lastName}`;
        let companyName = contact.properties.company ? contact.properties.company.value : '';

        let email = contact.properties.email ? contact.properties.email.value : '';
        let hubspot_vid = contact.vid;
        let jobTitle = contact.properties.jobtitle ? contact.properties.jobtitle.value : '';

        let lifeCycleStage = contact.properties.lifecyclestage ? contact.properties.lifecyclestage.value : '';

        // linkedin URL property does not exist as default in hubspot CRM. So this field will be different depending on company
        let linkedInURL = contact.properties.linkedInURL ? contact.properties.linkedInURL.value : '';
        let verifiedLinkedInURL = false;
        if (linkedInURL) {
          verifiedLinkedInURL = true;
        }

        console.log('contact', contact);
        console.log(name, companyName, hubspot_vid, email, jobTitle);

        let contactDocID = email; // Using email for now to generate a unique ID, although won't scale as the user changes jobs.

        if (email === '') {
          contactDocID = short().new();
          console.log('no email so dont save');
          // return;
        } else {
          contactIDs.push(contactDocID);

          let contactRef = contacts_db.doc(contactDocID);
          contactRef
            .set(
              {
                companyName: companyDocID,
                name: name,
                title: jobTitle,
                account: companyName,
                hubspot_vid,
                email: email,
                linkedInURL,
                lifeCycleStage,
                verifiedLinkedInURL,
                createdDate: firestore.Timestamp.fromDate(new Date()),
                jobs: [],
              },
              { merge: true }
            )
            .then((result) => {
              console.log('🥳 Successfully re-saved hubspot CRM to contacts DB:', contactDocID);
            });
        }
      }

      // Update companies DB.
      let companyRef = companies_db.doc(companyDocID);

      companyRef
        .set(
          {
            companyName: companyDocID,
            // companyEmail: companyEmail,
            contacts: contactIDs,
            ranJobChanges: false,
            createdDate: firestore.Timestamp.fromDate(new Date()),
            // accessToken: accessToken,
            // refreshToken: refreshToken,
            integrationType: 'hubspot',
          },
          { merge: true }
        )
        .then((result) => {
          console.log('🥰 Successfully re-saved CRM to companies DB:', companyDocID);
        })
        .catch((err) => {
          console.log('🛑 error saving data into company collection during hubspot data pull');
        });
    }
  });
};

getContacts();
