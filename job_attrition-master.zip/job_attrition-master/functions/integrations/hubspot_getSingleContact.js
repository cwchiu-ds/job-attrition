var request = require('request');
const Hubspot = require('hubspot');

const admin = require('firebase-admin');

// @typescript/eslint prohibits the use of require but we need it to dynamically import the json
const serviceAccount = require(`../secrets/jobattrition-firebase-adminsdk-gc6d2-861d6e2361.json`); // eslint-disable-line

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});
// const admin = require('../config/firebaseConfig');
let db = admin.firestore();
let contacts_db = db.collection('contacts');
let companies_db = db.collection('companies');

const {
  HUBSPOT_URL,
  HUBSPOT_PATH,
  FRONTEND_HOST,
} = require('../config/hostURL');

const REDIRECT_URI = `${HUBSPOT_URL}/oauth-callback`;

const hubspot = new Hubspot({
  clientId: '26c7ea6b-258f-46cc-ae3a-e85488c0fb5e',
  clientSecret: '8813d837-a810-47df-a9a3-6baeb4ff48eb',
  redirectUri: REDIRECT_URI,
  refreshToken: '1937e2ed-eb3c-47f6-9a36-5e4474aff04c',
});

const getContacts = async () => {
  const token = await hubspot.refreshAccessToken();
  const accessToken = token.access_token;

  const headers = {
    Authorization: `Bearer ${accessToken}`,
    'Content-Type': 'application/json',
  };

  var options = {
    method: 'GET',
    url: 'https://api.hubapi.com/contacts/v1/contact/vid/7751/profile',
    headers: headers,
  };
  request(options, function (error, response, body) {
    if (error) throw new Error(error);

    // console.log(Object.keys(body));
    const parsedJSON = JSON.parse(body);
    console.log(parsedJSON);
    // console.log(parsedJSON["associated-company"].properties.name.value);
    // console.log("identify me", parsedJSON["identity-profiles"][0]);
  });
};

const writeToHubspot = async () => {
  let companyRef = await companies_db.doc(companyDocID);

  companyRef.get().then(async (doc) => {
    if (doc.exists) {
      let contactIDs = doc.data().contacts;

      console.log('contactID', contactIDs);

      // Grab the contact data from firebase
      for (let i = 19766; i < contactIDs.length; i++) {
        const token = await hubspot.refreshAccessToken();
        const accessToken = token.access_token;
        console.log('access', accessToken, 'index ', i);
        const headers = {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        };

        const customer_email = (
          await contacts_db.doc(contactIDs[i]).get()
        ).data().properties.email.value;

        console.log('customer_email');

        var request = require('request');

        var options = {
          method: 'POST',
          url: `https://api.hubapi.com/contacts/v1/contact/createOrUpdate/email/${customer_email}`,
          headers: headers,
          body: {
            properties: [
              {
                property: 'name',
                value: 'jobchangeflag',
              },
              {
                property: 'label',
                value: 'Job Change',
              },
              {
                property: 'description',
                value: 'Indicates if customer changed jobs',
              },
              {
                property: 'groupName',
                value: 'contactinformation',
              },
              {
                property: 'type',
                value: 'string',
              },
              {
                property: 'fieldType',
                value: 'booleancheckbox',
              },
            ],
          },
          json: true,
        };

        await request(options, function (error, response, body) {
          if (error) throw new Error(error);

          //update firebase here?

          console.log(parsedJSON);
        });
      }
    } else {
      console.log('🛑 Error - Company Doc ID not found');
    }
  });
};

const getBulkContacts = async () => {
  const token = await hubspot.refreshAccessToken();
  const accessToken = token.access_token;

  const headers = {
    Authorization: `Bearer ${accessToken}`,
    'Content-Type': 'application/json',
  };

  var options = {
    method: 'GET',
    url:
      'https://api.hubapi.com/contacts/v1/contact/vids/batch/?vid=3234574&vid=3714024&hapikey=demo',
    headers: headers,
  };
  request(options, function (error, response, body) {
    if (error) throw new Error(error);

    // console.log(Object.keys(body));
    const parsedJSON = JSON.parse(body);
    console.log(parsedJSON);
    // console.log(parsedJSON["associated-company"].properties.name.value);
    // console.log("identify me", parsedJSON["identity-profiles"][0]);
  });
};

const enrichCompanyInfoIntoHubspotContact = async (companyDocID) => {
  let companyRef = await companies_db.doc(companyDocID);

  companyRef.get().then(async (doc) => {
    if (doc.exists) {
      let contactIDs = doc.data().contacts;

      console.log('contactID', contactIDs);

      // Grab the contact data.
      for (let i = 19766; i < contactIDs.length; i++) {
        const token = await hubspot.refreshAccessToken();
        const accessToken = token.access_token;
        console.log('access', accessToken, 'index ', i);
        const headers = {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        };

        const hubspot_vid = (await contacts_db.doc(contactIDs[i]).get()).data()
          .hubspot_vid;

        console.log('hubspot_vid');

        var options = {
          method: 'GET',
          url: `https://api.hubapi.com/contacts/v1/contact/vid/${hubspot_vid}/profile`,
          headers: headers,
        };
        await request(options, function (error, response, body) {
          if (error) throw new Error(error);

          const parsedJSON = JSON.parse(body);
          console.log(parsedJSON);

          let company_name = parsedJSON['associated-company']
            ? parsedJSON['associated-company'].properties.name.value
            : '';

          let company_hubspot_id = parsedJSON['associated-company']
            ? parsedJSON['associated-company']['company-id']
            : '';

          let company_hubspot_linkedIn = '';

          if (parsedJSON['associated-company']) {
            company_hubspot_linkedIn = parsedJSON['associated-company']
              .properties.linkedin_company_page
              ? parsedJSON['associated-company'].properties
                  .linkedin_company_page.value
              : '';
          }

          console.log('company name found', company_name, contactIDs[i]);

          let contactRef = contacts_db.doc(contactIDs[i]);
          contactRef
            .set(
              {
                account: company_name,
                company_hubspot_id,
                company_hubspot_linkedIn,
              },
              { merge: true }
            )
            .then((result) => {
              console.log(
                '🥳 Successfully re-saved hubspot CRM to contacts DB:',
                contactDocID
              );
            })
            .catch((error) => {
              console.log(
                "🛑 Error - can't update company name to contact in contacts DB",
                contactDocID
              );
            });
          // console.log(parsedJSON["associated-company"].properties.name.value);
          // console.log("identify me", parsedJSON["identity-profiles"][0]);
        });
      }
    } else {
      console.log('🛑 Error - Company Doc ID not found');
    }
  });
};

enrichCompanyInfoIntoHubspotContact('Heartbeat');

// getContacts();
