export const hasSalesforceToken = (client: Client): boolean => {
  if (!client.salesforceIntegration?.refreshToken || !client.salesforceIntegration.instanceUrl) {
    return false;
  } else {
    return true;
  }
};

export const hasSalesforceMapping = (client: Client): boolean => {
  if (!client.salesforceIntegration?.salesforceMapping) {
    return false;
  } else {
    return true;
  }
};
