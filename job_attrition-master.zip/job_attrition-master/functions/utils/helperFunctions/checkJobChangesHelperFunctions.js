const admin = require('firebase-admin');
let db = admin.firestore();
let cookies_db = db.collection('cookies');
const { scraperControlPanel } = require('../../config/scraperControlPanel');
var parse = require('url-parse');

function getRandomInt(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

/**
 * Returns a random milliseconds between min seconds and max seconds.
 * E.g. randomMillisecondsBetweenSeconds(1,10)
 *      > 8689
 * @param {Number} min Maxium seconds
 * @param {Number} max Minimum seconds
 */
function randomMillisecondsBetweenSeconds(min, max) {
  let minMilliseconds = min * 1000;
  let maxMilliseconds = max * 1000;
  return Math.floor(Math.random() * (maxMilliseconds - minMilliseconds + 1)) + minMilliseconds;
}

/**
 * Waits for a random amount of time between min and max seconds.
 * @param {Page} page Chrome headless web page
 * @param {Number} min Maxium seconds
 * @param {Number} max Minimum seconds
 * @param {String} [message=""] Optional message to console log
 */
async function waitRandomSecondsBetween(page, min, max, message) {
  let milliseconds = randomMillisecondsBetweenSeconds(min, max);
  message = typeof message !== 'undefined' ? message : '';
  console.log('⏳⌛️ Wating for:', milliseconds, 'ms', '(', message, ')');
  await page.waitFor(milliseconds);
}

/**
 * Waits for a random amount of time between 0.8 and 3.5 seconds.
 * @param {Page} page Chrome headless web page
 */
async function waitRandomSeconds(page) {
  await waitRandomSecondsBetween(page, 0.8, 3.5);
}

/**
 * Splits apart the email into the name and company/domain:
 *
 * E.g. "carina.boo@conceptionsrepro.com" returns:
 * {
 *   name: carina.boo,
 *   company: conceptionsrepro,
 *   domain: conceptionsrepro.com
 * }
 *
 * @param {String} email
 * @param {Boolean} [skipBlacklist=true] If true, skips the gmail.com, yahoo.com, etc. emails by returning "" as domain/fompany.
 */
function generateNameCompanyFromEmail(email, skipBlacklist) {
  skipBlacklist = typeof skipBlacklist !== 'undefined' ? skipBlacklist : true;

  let nonWorkEmailDomains = [
    'gmail.com',
    'googlemail.com',
    'outlook.com',
    'hotmail.com',
    'yahoo.com',
    'qq.com',
    'live.com',
    'hotmail.co.uk',
    'icloud.com',
  ];
  var name = email.substring(0, email.lastIndexOf('@'));
  var domain = email.substring(email.lastIndexOf('@') + 1);
  var company = domain.split('.')[0];
  if (skipBlacklist && nonWorkEmailDomains.includes(domain)) {
    // Filter out any gmail/hotmail/yahoo emails b/c it's not the actual work email.
    domain = '';
    company = '';
  }
  return {
    name: name,
    company: company,
    domain: domain,
  };
}

/**
 * Generates the Google/Bing/etc search query string. Will use a combination of data that's available:
 *   Full Name, Company, Title
 *   E.g. "Joseph Turner Google Software Engineer LinkedIn"
 *
 * @param {*} contact 'contacts' DB object
 * @param {String} site Options: "google", "linkedin"
 */
function generateSearchQueryForContact(contact, site) {
  let queryList = [];
  let searchFilter = '';
  switch (site) {
    case 'google':
      searchFilter = 'site:linkedin.com/in/';
      break;
    case 'linkedin':
      break;
  }

  if (!contact.account && !contact.title) {
    let country = '';
    let companyFromEmail = '';
    if (contact.crmData && contact.crmData.Country) {
      // Use country if it exists. E.g. "United Kingdom".
      country = contact.crmData.Country;
    } else if (contact.email) {
      // Else use the company/domain pulled from email. E.g. "2-3degrees" from azzees@2-3degrees.com.
      companyFromEmail = generateNameCompanyFromEmail(contact.email).company;
    }
    queryList = [searchFilter, contact.name, companyFromEmail, country];
  } else {
    queryList = [searchFilter, contact.name, contact.account, contact.title];
  }
  queryList = queryList.filter((item) => item != '');
  return queryList.join(' ');
}

function createJobObject(company, title, dateRange) {
  return {
    company: company,
    title: title,
    dateRange: dateRange,
  };
}

function areJobsEqual(jobA, jobB) {
  if (jobA.companyName != jobB.companyName) {
    return false;
  }
  if (jobA.title != jobB.title) {
    return false;
  }
  return true;
}

function isValidLinkedInProfileURL(url) {
  return url.includes('linkedin.com/in/');
}

function hasVerifiedLinkedInURL(contact) {
  return contact.linkedInURL && isValidLinkedInProfileURL(contact.linkedInURL) && contact.verifiedLinkedInURL;
}

function hasValidDetectedLinkedInURL(contact) {
  return contact.linkedInURLScraped && isValidLinkedInProfileURL(contact.linkedInURLScraped);
}

/**
 * Converts any xx.linkedin.com URL to US www.linkedin.com URL. Otherwise URLs that are uk.linkedin.com or some other country
 * has unreliable HTML, and the session cookie also does not work across subdomains. Also the profile not found page
 * is different in US than UK, etc.
 *
 * @param {String} linkedInURL
 */
function convertToUSLinkedInURL(linkedInURL) {
  var parsedURL = parse(linkedInURL);
  if (parsedURL.hostname.includes('linkedin.com') && !parsedURL.hostname.startsWith('www.')) {
    parsedURL.set('hostname', 'www.linkedin.com');
  }
  return parsedURL.toString();
}

function timeDiffCalc(dateFuture, dateNow) {
  let diffInMilliSeconds = Math.abs(dateFuture.getTime() - dateNow.getTime());

  // // calculate days
  // const days = Math.floor(diffInMilliSeconds / 86400);
  // diffInMilliSeconds -= days * 86400;
  // console.log("calculated days", days);

  // // calculate hours
  // const hours = Math.floor(diffInMilliSeconds / 3600) % 24;
  // diffInMilliSeconds -= hours * 3600;
  // console.log("calculated hours", hours);

  // calculate minutes
  const minutes = Math.floor(diffInMilliSeconds / 60000);

  console.log('minutes', minutes);

  // let difference = "";
  // if (days > 0) {
  //   difference += days === 1 ? `${days} day, ` : `${days} days, `;
  // }

  // difference +=
  //   hours === 0 || hours === 1 ? `${hours} hour, ` : `${hours} hours, `;

  // difference +=
  //   minutes === 0 || hours === 1 ? `${minutes} minutes` : `${minutes} minutes`;

  // return { days, hours, minutes };
  return { minutes };
}

async function checkIfAllCookiesLimitExceeded() {
  let exitFunctionAllCookiesLimitExceeded = false;
  console.log('hello');
  await cookies_db
    .get()
    .then((snapshot) => {
      if (snapshot.size === 0) {
        exitFunctionAllCookiesLimitExceeded = false;
        return;
      }
      let limitExceedList = [];
      snapshot.forEach(async (doc) => {
        let check = false;
        let cookieData = doc.data();
        if (cookieData.limitExceeded) {
          check = true;
          const cookieIntervalDate = cookieData.intervalDateStart.toDate();
          const cookieIntervalMinDiff = timeDiffCalc(new Date(), cookieIntervalDate).minutes;
          // if it's been past 12 hours (720 min) before using cookie, reset limit time interval start date
          if (cookieIntervalMinDiff > scraperControlPanel.minutesBeforeCookieLimitReset) {
            console.log('start');
            cookies_db.doc(doc.id).update({
              limitExceeded: false,
              intervalDateStart: new Date(),
              count: 0,
            });
            console.log('get here');
            check = false;
          }
        }
        limitExceedList.push(check);
      });
      console.log('Cookie limit exceeded array', limitExceedList);

      // check if every cookie in the array is showing a limitexceeded flag true. If yes, then exit scraper
      let allCookiesLimitExceeded = limitExceedList.every((limitStatus) => limitStatus === true);
      if (allCookiesLimitExceeded) {
        exitFunctionAllCookiesLimitExceeded = true;
      }
    })
    .catch((err) => {
      console.log('Error getting documents', err);
    });

  // Exit check job checker LinkedIn scraper if all cookies have reached their set limits
  if (exitFunctionAllCookiesLimitExceeded) {
    console.log('🛑🍪🛑 Exiting LinkedIn Scraper - All cookies have reached their set run limits');
    return true;
  }

  return false;
}

async function getCookieAndProxyIP(scraperControlPanel, cookieRotation, productionCookie) {
  // no cookies left in cookieRotation to try. All limits exceeded so return false to end functions
  if (cookieRotation.length === 0) {
    console.log(' 🛑🍪 no cookies left in cookieRotation to try. All limits exceeded so return false to end functions');
    return false;
  }
  const randomCookieIndex = getRandomInt(0, cookieRotation.length - 1);

  let proxyServerURL = scraperControlPanel.testCookie
    ? cookieRotation[randomCookieIndex].proxyIP
    : productionCookie.proxyIP;
  let linkedInCookie = scraperControlPanel.testCookie
    ? cookieRotation[randomCookieIndex].cookie
    : productionCookie.cookie;
  let cookieID = scraperControlPanel.testCookie ? cookieRotation[randomCookieIndex].name : productionCookie.name;
  let cookieInUse = scraperControlPanel.testCookie ? cookieRotation[randomCookieIndex] : productionCookie;

  if (scraperControlPanel.testCookie) {
    console.log(`Using rotating cookies ${cookieID} and proxy IPs on rotation ${proxyServerURL}`);
  } else {
    console.log(`Using production cookie ${cookieID} and proxy IPs ${proxyServerURL}`);
  }

  const cookieRef = cookies_db.doc(cookieID);

  const cookie = await cookieRef.get().catch((err) => {
    console.log(`🛑🍪 Could not get Cookie Doc`, cookieID);
  });

  const cookieExists = cookie.exists;

  if (cookieExists) {
    const cookieData = cookie.data();
    const cookieIntervalDate = cookieData.intervalDateStart;
    const cookieCount = cookieData.count;
    const limitCheck = cookieData.limitExceeded;
    const cookieIntervalMinDiff = timeDiffCalc(new Date(), cookieIntervalDate.toDate()).minutes;

    // If profile limit was hit within a set time interval (in minutes), then try another cookie
    if (limitCheck) {
      console.log('👆 Limit already exceeded try another cookie', cookieID);
      const newCookieRotation = await recurseNewCookie(cookieRef, cookieRotation, cookieID);

      if (newCookieRotation.length === 0) {
        console.log('🛑🍪 All cookies have hit their limit, exit getCookieAndProxyAPI function with false');
        return false;
      }

      return await getCookieAndProxyIP(scraperControlPanel, newCookieRotation, productionCookie);
    } else {
      if (
        cookieIntervalMinDiff < scraperControlPanel.minuteIntervalCookieLimit &&
        cookieCount > scraperControlPanel.cookieCountLimit
      ) {
        console.log('👆 Hit interval scrape limit try another cookie', cookieID);
        const newCookieRotation = await recurseNewCookie(cookieRef, cookieRotation, cookieID);

        if (newCookieRotation === []) {
          console.log('🛑🍪 All cookies have hit their limit, exit getCookieAndProxyAPI function with false');
          return false;
        }

        return await getCookieAndProxyIP(scraperControlPanel, newCookieRotation, productionCookie);
      } else {
        await cookieRef.set({ count: cookieData.count + 1, limitExceeded: false }, { merge: true });
        console.log('🍪 updated cookie count', cookieID, 'count ', cookieData.count + 1);
      }
    }
  } else {
    let obj = {
      ...cookieInUse,
      count: 1,
      intervalDateStart: new Date(),
      limitExceeded: false,
    };
    await cookieRef.set(obj, { merge: true });
    console.log('🍪 created new cookie ', cookieID);
  }

  console.log('👱‍♂️👩‍🦳 LinkedIn Profile Cookie Name', cookieID);

  console.log('Profile hit count', cookieID);

  return {
    proxyServerURL,
    linkedInCookie,
    name: cookieID,
    userAgent: cookieInUse.userAgent,
  };
}

async function recurseNewCookie(cookieRef, cookieRotation, cookieID) {
  await cookieRef.set({ limitExceeded: true, limitDate: new Date() }, { merge: true });
  // Remove the cookie just tested from cookieRotation
  newCookieRotation = cookieRotation.filter((cookie) => {
    return cookie.name !== cookieID;
  });

  console.log('newCookieRotation', newCookieRotation);

  return newCookieRotation;
}

module.exports = {
  getRandomInt,
  randomMillisecondsBetweenSeconds,
  convertToUSLinkedInURL,
  hasValidDetectedLinkedInURL,
  hasVerifiedLinkedInURL,
  areJobsEqual,
  createJobObject,
  isValidLinkedInProfileURL,
  generateNameCompanyFromEmail,
  generateSearchQueryForContact,
  waitRandomSeconds,
  waitRandomSecondsBetween,
  checkIfAllCookiesLimitExceeded,
  timeDiffCalc,
  getCookieAndProxyIP,
};
