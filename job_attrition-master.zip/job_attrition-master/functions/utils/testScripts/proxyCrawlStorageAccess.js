const https = require("https");
// const { ProxyCrawlAPI } = require("proxycrawl");
const linkedInToken = process.env.PROXYCRAWL_NORMAL_TOKEN;
const axios = require("axios");
// const api = new ProxyCrawlAPI({ token: linkedInToken });

const admin = require("../../config/firebaseConfig");

const options = {
  hostname: "https://api.proxycrawl.com/storage",
  path: `/?token=${linkedInToken}&rid=bb7d20435a17c73dcabd5404`,
};

let rids = ["abc", "sadf", "asdf"];

https.request(options, (response) => {
  let body = "";
  response
    .on("data", (chunk) => (body += chunk))
    .on("end", () => {
      const result = JSON.parse(body);

      console.log("response", result);
    });
});

for (i of rids) {
  const options = {
    hostname: "https://api.proxycrawl.com/storage",
    path: `/?token=${linkedInToken}&rid=${i}`,
  };
  https.request(options, (response) => {
    let body = "";
    response
      .on("data", (chunk) => (body += chunk))
      .on("end", () => {
        const result = JSON.parse(body);

        console.log("response", result);
      });
  });
}
