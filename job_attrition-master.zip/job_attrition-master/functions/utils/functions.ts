import admin from 'firebase-admin';
import { Request } from 'firebase-functions';

export const extractLinkedInIdFromUrl = (url: string): string => {
  const match = url.match(/https?:\/\/.*\.?linkedin.com\/in\/([^?|\/]*)/);
  if (!match) {
    return '';
  }

  const [, linkedInId] = match;

  return linkedInId;
};

export const extractLinkedInCompanyIdFromUrl = (url: string): string => {
  const match = url.match(/https?:\/\/.*\.?linkedin.com\/company\/([^?|\/]*)/);
  if (!match) {
    return '';
  }

  const [, linkedInId] = match;

  return linkedInId;
};

export const capitalizeFirstLetter = (string: string) => {
  return string.charAt(0).toUpperCase() + string.slice(1);
};

export const dayDiffCalc = (dateFuture: Date, dateNow: Date): number => {
  const diffInMilliSeconds = Math.abs(dateFuture.getTime() - dateNow.getTime());

  const days = Math.floor(diffInMilliSeconds / 60000 / 60 / 24);

  return days;
};

export const getAuthenticatedUID = async (req: Request): Promise<string | undefined> => {
  let authUID;

  try {
    if (req.headers.authorization && req.headers.authorization.startsWith('Bearer ')) {
      const authToken = req.headers.authorization.split('Bearer ')[1];

      if (authToken) {
        authUID = await admin
          .auth()
          .verifyIdToken(authToken)
          .then((decodedToken) => decodedToken.uid);
      }
    }
  } catch (err) {
    console.error(err);
  } finally {
    return authUID;
  }
};

export const getCurrentTimestamp = (): Timestamp => {
  return admin.firestore.Timestamp.now();
};

export const getClientContactName = (clientContact: ClientContact, initials?: boolean): string => {
  const { firstName = '', lastName = '', fullName = '' } = clientContact;

  if (firstName && lastName) {
    if (initials) {
      return firstName === '' && lastName === ''
        ? ''
        : `${firstName !== '' ? firstName[0]?.toUpperCase() : ''} ${lastName !== '' ? lastName[0]?.toUpperCase() : ''}`;
    } else {
      return `${firstName} ${lastName}`;
    }
  } else if (fullName) {
    if (initials) {
      return `${fullName.slice(0, 2)}`;
    } else {
      return fullName;
    }
  } else {
    return '';
  }
};

export const getLastClientContactJob = (contact: ClientContact): { company: string; title: string } => {
  const allJobsLength = contact.contactData?.allJobs ? contact.contactData?.allJobs.length : 0;
  if (allJobsLength! <= 1) {
    return {
      company: contact.currentJob?.companyName!,
      title: contact.currentJob?.title!,
    };
  } else {
    return {
      company: contact.contactData?.allJobs[allJobsLength! - 2].companyName!,
      title: contact.contactData?.allJobs[allJobsLength! - 2].title!,
    };
  }
};

export const getCurrentClientContactJob = (
  contact: ClientContact
): { company: string; title: string; startDate: string } => {
  return {
    company: contact.contactData?.currentJob[0].companyName!,
    title: contact.contactData?.currentJob[0].title!,
    startDate: contact.contactData?.currentJob[0].startDate!,
  };
};

export const addhttps = (url: string): string => {
  if (!/^(?:f|ht)tps?\:\/\//.test(url)) {
    url = 'https://' + url;
  }
  return url;
};

export const updateLatestEmails = (contactData: ContactData, email: string[]): EmailData[] => {
  let emails: EmailData[];
  if (contactData!.emailData && !contactData!.emailArray.includes(email[0])) {
    emails = contactData!.emailData;
    email!.map((email) => {
      emails.push({
        email,
        dateCreated: getCurrentTimestamp(),
        isValid: true,
      });
    });
  } else if (contactData!.emailData) {
    emails = contactData!.emailData;
  } else {
    emails = [
      {
        email: email[0],
        dateCreated: getCurrentTimestamp(),
        isValid: true,
      },
    ];
  }
  return emails;
};
