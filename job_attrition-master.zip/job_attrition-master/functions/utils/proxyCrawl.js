const https = require("https");

const { firestore } = require("firebase-admin");

const javascriptToken = "v66a2A4TswFIp4pGNnn0jA";
const normalToken = process.env.PROXYCRAWL_NORMAL_TOKEN;
const linkedInToken = process.env.PROXYCRAWL_LINKEDIN_TOKEN;
const admin = require("../config/firebaseConfig");
let db = admin.firestore();
let contacts_db = db.collection("contacts");

const {
  areJobsEqual,
  isValidLinkedInProfileURL,
} = require("./helperFunctions/checkJobChangesHelperFunctions");

function sleep(milliseconds) {
  const date = Date.now();
  let currentDate = null;
  do {
    currentDate = Date.now();
  } while (currentDate - date < milliseconds);
}

const checkDuplicateString = (string) => {
  let halfStringLength = string.length / 2;
  if (
    string.substring(0, halfStringLength) ===
    string.substring(halfStringLength, string.length)
  ) {
    console.log("split string");
    return string.substring(0, halfStringLength);
  } else {
    console.log("return same string");
    return string;
  }
};

async function callback(jobObject, contact) {
  console.log("contact");
  contactDocID = contact.email;
  if (jobObject) {
    console.log(
      "🤖 Scraped object returned to callback:",
      contactDocID,
      "\n",
      contact
    );
    if (contact.jobs && contact.jobs.length > 0) {
      let updatedJobsArray = contact.jobs;

      // If previously scraped LinkedIn URL was wrong, then remove the previous job stored in jobs array.
      // The first job in the array is the CSV imported one. Ignore that one.
      if (updatedJobsArray.length > 1 && contact.linkedInURLScrapedDiff) {
        updatedJobsArray = updatedJobsArray.slice(
          0,
          updatedJobsArray.length - 1
        );
      }

      // Check if the new job is equal to the latest job we have in the DB.
      let latestJobInDB = updatedJobsArray[updatedJobsArray.length - 1];
      console.log("compare these two", latestJobInDB, jobObject.job);
      if (!areJobsEqual(jobObject.job, latestJobInDB)) {
        // If new job detected, append the new job to the contact and flag the contact.
        updatedJobsArray.push(jobObject.job);
      } else {
        console.log("👍 No job changes found for:", contactDocID);
      }

      let contactRef = contacts_db.doc(contactDocID);

      // Override query and query results if new scraped query results are not empty.
      let query = contact.linkedInScrapedData.query;
      let queryResults = contact.linkedInScrapedData.queryResults;
      if (jobObject.queryResults && jobObject.queryResults.length > 0) {
        query = jobObject.query;
        queryResults = jobObject.queryResults;
      }

      // console.log(
      //   "Query results! Original:",
      //   contact.linkedInScrapedData.queryResults,
      //   "New:",
      //   jobObject.queryResults
      // );

      await contactRef.get().then((doc) => {
        let contact = doc.data();
        let obj = {
          linkedInScrapedData: {
            name: jobObject.name,
            header: jobObject.header,
            location: jobObject.location,
            education: jobObject.education,
          },
          alert: true,
          jobs: updatedJobsArray,
          scrapeFailedFlag: false,
          errorFlag: jobObject.error,
          linkedInUrlDiffFlag: false,
        };

        if (isValidLinkedInProfileURL(jobObject.linkedInURL)) {
          if (!contact.verifiedLinkedInURL) {
            console.log("👁  Scraped LinkedInURL", jobObject.linkedInURL);
          }
          if (
            contact.linkedInURL &&
            contact.linkedInURL !== jobObject.linkedInURL
          ) {
            console.log("👁  old LinkedIn URL", contact.linkedInURL);
            console.log("👁  new scraped LinkedIn URL", jobObject.linkedInURL);
            obj.linkedInUrlDiffFlag = true;
          }
          obj.linkedInURLScraped = jobObject.linkedInURL;
        }

        if (contact.linkedInURLScrapedDiff) {
          obj.linkedInURLScrapedDiff = false;
        }

        contactRef
          .set(obj, { merge: true })
          .then(function () {
            console.log(
              "🍏 Document successfully updated - APPEND:",
              contactDocID,
              updatedJobsArray
            );
          })
          .catch(function (error) {
            // The document probably doesn't exist.
            console.error("🛑 Error updating document:", contactDocID, error);
          });
      });
    } else {
      // If we have no job data in the DB for the contact yet, save it to the DB.

      let contactRef = contacts_db.doc(contactDocID);

      await contactRef.get().then((doc) => {
        let contact = doc.data();
        let obj = {
          linkedInScrapedData: {
            query: jobObject.query ? jobObject.query : "",
            name: jobObject.name,
            header: jobObject.header,
            location: jobObject.location,
            education: jobObject.education,
          },
          alert: false,
          jobs: [jobObject.job],
          scrapeFailedFlag: false,
          errorFlag: jobObject.error,
          linkedInUrlDiffFlag: false,
        };

        console.log("Im a linkedin url", jobObject.linkedInURL);

        if (isValidLinkedInProfileURL(jobObject.linkedInURL)) {
          if (!contact.verifiedLinkedInURL) {
            obj.linkedInURLScraped = jobObject.linkedInURL;
            console.log("👁 found new LinkedInURL ", jobObject.linkedInURL);
          }

          if (contact.linkedInURL !== jobObject.linkedInURL) {
            console.log("👁 old LinkedIn URL ", contact.linkedInURL);
            console.log("👁 new scraped LinkedIn URL ", jobObject.linkedInURL);
            obj.linkedInUrlDiffFlag = true;
            obj.linkedInURLScraped = jobObject.linkedInURL;
          }
        }

        contactRef
          .set(obj, { merge: true })
          .then(function () {
            console.log(
              "🍏 Document successfully updated - NEW:",
              contactDocID,
              jobObject
            );
          })
          .catch(function (error) {
            // The document probably doesn't exist.
            console.error("🛑 Error updating document:", contactDocID, error);
          });
      });
    }
  }
}

const proxyCrawlLinkedIn = async (url, contact, tryCount = 0) => {
  if (tryCount >= 10) {
    console.log(
      "🛑 Exit Proxy Crawl - Tried hitting proxycrawl more than 10 times ",
      url
    );
    return;
  }
  console.log("👁 Sending Proxy Crawl Request for ", url);
  console.log("try Count", tryCount);
  const options = {
    hostname: "api.proxycrawl.com",
    path: `/?token=${linkedInToken}&scraper=linkedin-profile&url=` + url,
  };
  console.log("Sleep 2 seconds - ProxyCrawl limit is 1 request per second");
  sleep(1500);
  console.log("Sleep end");

  https
    .request(options, async (response) => {
      let body = "";
      response
        .on("data", (chunk) => (body += chunk))
        .on("end", async () => {
          let result = JSON.parse(body);
          console.log("here is result", result);

          if (
            result.original_status === 504 ||
            result.original_status === "504"
          ) {
            proxyCrawlLinkedIn(url, contact, tryCount + 1);
          } else {
            // update data if
            let obj = {
              name: result.body.title.trim(),
              header: result.body.headline.trim(),
              location:
                result.body.sublines.length > 0
                  ? result.body.sublines[0].trim()
                  : "",
              education: result.body.educationInfo.school.trim(),
              linkedInURL: result.body.profileUrl,
              job: {
                company:
                  result.body.experience.experienceList.length > 0
                    ? result.body.experience.experienceList[0].company.name.trim()
                    : "",
                title:
                  result.body.experience.experienceList.length > 0
                    ? checkDuplicateString(
                        result.body.experience.experienceList[0].title.trim()
                      )
                    : "",
                dateRange:
                  result.body.experience.experienceList.length > 0
                    ? `${result.body.experience.experienceList[0].startDate} - ${result.body.experience.experienceList[0].endDate}`
                    : "",
                duration:
                  result.body.experience.experienceList.length > 0
                    ? result.body.experience.experienceList[0].duration.trim()
                    : "",
                lastUpdated: firestore.Timestamp.fromDate(new Date()),
              },
              error: false,
            };
            console.log("object before submission", obj);
            callback(obj, contact);
            // console.log("submit object", obj);
            // console.log("result", result);
            console.log("-------------------------------------");
            console.log("result.body", result.body);
            console.log("-------------------------------------");

            console.log("-------------------------------------");
            result.body.experience.experienceGroup.map((element) => {
              console.log("experience Group", element);
              // console.log("company", element.company);
            });
            // console.log("result.body.experience", result.body.experience);
            console.log("-------------------------------------");
            result.body.experience.experienceList.map((element) => {
              console.log("experience List", element);
              // console.log("company", element.company);
            });
          }
        });
    })
    .end();
};

module.exports = {
  proxyCrawlLinkedIn,
};

// proxyCrawlLinkedIn(url, "carina@gmail.com");
