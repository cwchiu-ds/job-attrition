export enum HTTP_METHOD {
  GET = 'GET',
  POST = 'POST',
  PUT = 'PUT',
  DELETE = 'DELETE',
}

export enum Environment {
  Development = 'development',
  Staging = 'staging',
  Production = 'production',
}

export enum HTTP_RESPONSE {
  OK = 200,
  NO_CONTENT = 204,
  REDIRECT = 303,
  BAD_REQUEST = 400,
  UNAUTHORIZED = 401,
  FORBIDDEN = 403,
  NOT_FOUND = 404,
  CONFLICT = 409,
  INTERNAL_SERVER_ERROR = 500,
}

export enum UserType {
  INTERNAL = 'INTERNAL',
  CLIENT = 'CLIENT',
  QA = 'QA',
}

export enum COLLECTION {
  CLIENTS = 'clients',
  CLIENT_CONTACTS = 'client_contacts',
  CLIENT_INTERNAL = 'client_internal',
  CONTACT_DATA = 'contact_data',
  USERS = 'users',
  COMPANIES = 'companies',
}

export enum ClientContactField {
  CLIENT_ID = 'clientId',
  CLIENT_NAME = 'clientName',
  FIRST_NAME = 'firstName',
  LAST_NAME = 'lastName',
  FULL_NAME = 'fullName',
  EMAIL = 'email',
  IS_VALID_EMAIL = 'isValidEmail',
  VERIFIED = 'verified',
  LINKEDIN_URL = 'linkedInURL',
  LINKEDIN_ID = 'linkedInId',
  CRM_DATA = 'crmData',
  ADDED_BY_USER_ID = 'addedByUserId',
  DATE_UPDATED = 'dateUpdated',
  DATE_CREATED = 'dateCreated',
  CONTACT_DATA_ID = 'contactDataId',
  CONTACT_DATA = 'contactData',
  INITIAL_GOOGLE_SEARCH = 'initialGoogleSearch',
  JOB_CHANGED = 'jobChanged',
  JOB_CHANGED_STATUS = 'jobChangedStatus',
  ENRICHED_DATA_CHANGED = 'enrichedDataChanged',
  LAST_VERIFIED = 'lastVerified',
  LAST_VERIFIED_USER_ID = 'lastVerifiedUserId',
  LAST_CLAIMED = 'lastClaimed',
  LAST_CLAIMED_USER_ID = 'lastClaimedUserId',
  UNCERTAIN_URLS = 'uncertainURLs',
  LEAD_LIFE_CYCLE = 'lifeCycleStage',
  PROFILE_PHOTO = 'profilePhoto',
  CURRENT_JOB = 'currentJob',
  TRACK_FLAG = 'trackFlag',
  SALESFORCE_ID = 'salesforceId',
  LAST_SALESFORCE_ENRICHMENT_DATE = 'lastSalesforceEnrichmentDate',
  LAST_SALESFORCE_ENRICHED_COMPANY_NAME = 'lastSalesforceEnrichedCompanyName',
  LAST_SALESFORCE_ENRICHED_TITLE = 'lastSalesforceEnrichedTitle',
  LAST_SALESFORCE_ENRICHED_LINKEDIN_URL = 'lastSalesforceEnrichedLinkedInURL',
}

export const HubspotEnrichmentAttributes: HubSpotEnrichmentAttributes = {
  companyName: 'company',
  title: 'jobtitle',
};

export enum QAJobChangeStatus {
  NO_JOB_CHANGE = 'No job change',
  LEFT_OLD_JOB_NO_NEW_JOB = 'Left old job but no new job',
  JOB_CHANGED = 'Job changed',
  JOB_CHANGED_SAME_COMPANY = 'Job changed but same company',
  EMAIL_INVALID = 'Email invalid',
}

export enum ClientContactAttribute {
  FULL_NAME = 'FULL_NAME',
  FIRST_NAME = 'FIRST_NAME',
  LAST_NAME = 'LAST_NAME',
  CURRENT_COMPANY = 'CURRENT_COMPANY',
  CURRENT_TITLE = 'CURRENT_TITLE',
  LINKEDIN_URL = 'LINKEDIN_URL',
  EMAIL = 'EMAIL',
  OTHER = 'OTHER',
}

export enum UserField {
  FIRST_NAME = 'firstName',
  LAST_NAME = 'lastName',
  EMAIL = 'email',
  PHONE_NUMBER = 'phoneNumber',
  CLIENT_ID = 'clientId',
  USER_TYPE = 'userType',
  CREATED_DATE = 'createdDate',
  DO_NOT_SEND_WEEKLY_EMAIL = 'doNotSendWeeklyEmail',
}

export const ClientContactAttributeField = {
  [ClientContactAttribute.FULL_NAME]: ClientContactField.FULL_NAME,
  [ClientContactAttribute.FIRST_NAME]: ClientContactField.FIRST_NAME,
  [ClientContactAttribute.LAST_NAME]: ClientContactField.LAST_NAME,
  [ClientContactAttribute.CURRENT_COMPANY]: ClientContactField.CURRENT_JOB,
  [ClientContactAttribute.CURRENT_TITLE]: ClientContactField.CURRENT_JOB,
  [ClientContactAttribute.LINKEDIN_URL]: ClientContactField.LINKEDIN_URL,
  [ClientContactAttribute.EMAIL]: ClientContactField.EMAIL,
  [ClientContactAttribute.OTHER]: ClientContactField.CRM_DATA,
};

export const GOOGLE_SEARCH_API_KEY = process.env.GOOGLE_SEARCH_API_KEY || '';
export const GOOGLE_SEARCH_CSE_KEY = process.env.GOOGLE_SEARCH_CSE_KEY || '';
export const CURRENT_ENVIRONMENT: Environment = process.env.WARMLY_ENVIRONMENT as Environment;

export const MJ_PUBLIC_API_KEY = process.env.MJ_PUBLIC_API_KEY || '';
export const MJ_PRIVATE_API_KEY = process.env.MJ_PRIVATE_API_KEY || '';

export const SENDGRID_API_KEY = process.env.SENDGRID_API_KEY || '';
export const FULLCONTACT_API_KEY = process.env.FULLCONTACT_API_KEY || '';
export const PEOPLEDATALABS_API_KEY = process.env.PEOPLEDATALABS_API_KEY || '';
export const THE_CHECKER_API_KEY =
  CURRENT_ENVIRONMENT === Environment.Production
    ? process.env.THE_CHECKER_API_KEY_PROD || ''
    : process.env.THE_CHECKER_API_KEY_DEV || '';

export const MTURK_ENVIRONMENT: Environment = process.env.MTURK_ENVIRONMENT as Environment;

export enum MailJetEmaiTemplate {
  INVITE_NEW_USER = 1384258,
  RESET_PASSWORD = 1517977,
}

export enum SendGridEmailTemplate {
  NO_JOB_CHANGES = 'd-90b63bc9fc224e87b3ac52c721141e59',
  JOB_CHANGES = 'd-746ad47446f044d78e185b5274e57670',
}

export const MAX_CHUNK_SIZE = 400;

const DASHBOARD_BASE_URL =
  CURRENT_ENVIRONMENT === Environment.Production
    ? 'https://dashboard.getwarmly.com'
    : CURRENT_ENVIRONMENT === Environment.Staging
    ? 'https://warmly-staging.firebaseapp.com'
    : 'http://localhost:3000';

export const DashboardURL = {
  Onboard: `${DASHBOARD_BASE_URL}/onboard`,
  SalesforceIntegration: `${DASHBOARD_BASE_URL}/integration/salesforce`,
  EnrichedCrm: `${DASHBOARD_BASE_URL}/enriched-crm`,
  ResetPassword: `${DASHBOARD_BASE_URL}/reset-password`,
};

export enum ClientStatus {
  TRIAL = 'TRIAL',
  UNPAID = 'UNPAID',
  PAID = 'PAID',
  TRIAL_EXPIRED = 'TRIAL_EXPIRED',
  DISABLED = 'DISABLED',
}

export enum CompaniesField {
  COMPANY_URL = 'companyURL',
  COMPANY_LINKEDIN_URL = 'companyLinkedInURL',
  COMPANY_DOMAINS = 'companyDomains',
  COMPANY_NAMES = 'companyNames',
  COMPANY_LINKEDIN_ID = 'companyLinkedInId',
  COMPANY_URL_DOMAIN = 'companyURLDomain',
}

export enum ClientField {
  ID = 'id',
  NAME = 'name',
  CODE_NAME = 'codeName',
  ACCESS_TOKEN = 'accessToken',
  REFRESH_TOKEN = 'refreshToken',
  INTEGRATION_TYPE = 'integrationType',
  MAPPED_ATTRIBUTES = 'mappedAttributes',
  SALESFORCE_INTEGRATION = 'salesforceIntegration',
  SALESFORCE_CONTACTS_ENRICHED = 'salesforceContactsEnriched',
  SALESFORCE_JOB_CHANGES_APPROVED = 'salesforceJobChangesApproved',
  JOB_CHANGE_NOTIFICATION_EMAILS = 'jobChangeNotificationEmails',
  QA_STATUS = 'QAStatus',
  QA_STATUS_DATE = 'QAStatusDate',
  QA_USER_IDS = 'QAUserIds',
  STATUS = 'status',
  STATUS_DATE = 'statusDate',

  CLIENT_CONTACT_BLOCKS = 'clientContactBlocks',
  CSV_UPLOAD = 'csvUpload',
  EMAIL_PING_ID = 'emailPingId',
}

export enum ClientInternalField {
  ID = 'id',
  NOTES = 'notes',
  CONTACTS_DENORMALIZATION_DATE = 'contactsDenormalizationDate',
  CONTACTS_CONTACT_DATA_ID_UPDATED = 'contactDataIdsUpdatedDate',
  CONTACTS_CONTACT_DATA_SCRAPED = 'contactDataScrapedDate',
}

export enum QAStatus {
  QA_ASSIGNED = 'QA Assigned',
  QA_COMPLETED = 'QA Completed',
  QA_SUSPENDED = 'QA Suspended',
}

const CLOUD_FUNCTIONS_BASE_URL =
  CURRENT_ENVIRONMENT === Environment.Production
    ? 'https://us-central1-jobattrition.cloudfunctions.net/'
    : CURRENT_ENVIRONMENT === Environment.Staging
    ? 'https://us-central1-warmly-staging.cloudfunctions.net/'
    : 'http://localhost:5001/warmly-staging/us-central1/';

export enum SalesforceIntegrationEndpoint {
  AUTH = '/auth',
  TOKEN = '/token',
  SETUP_FIELDS = '/setup-fields',
  SYNC_CONTACTS = '/sync-contacts',
  ENRICH_CONTACTS = '/enrich-contacts',
}

export enum EmailReportEndpoint {
  WEEKLY_REPORT = '/weekly-report',
}

export enum EmailPingEndpoint {
  THE_CHECKER = '/the-checker',
}

export enum HubspotIntegrationEndpoint {
  SYNC_JOB_CHANGES = '/sync-job-changes',
  SAVE_ALL_CONTACTS_TO_DB = '/sync-all-contacts-to-db',
  SYNC_DATA_ENRICHMENT = '/sync-data-enrichment',
}

export enum ClientContactEndpoint {
  DISMISS_CLIENT_CONTACT_JOB_CHANGE = '/dismiss-client-contact-job-change',
}

export enum AdminEndpoint {
  GENERATE_JOB_CHANGES = '/generate-job-changes',
  DENORMALIZE_CONTACTS = '/denormalize-contacts',
  CREATE_NEW_USER = '/create-new-user',
  APPEND_COMPANY_URL = '/append-company-url',
}

export enum UserEndpoint {
  INVITE_NEW_USER = '/invite-new-user',
  RESET_PASSWORD = '/reset-password',
}

export enum JobChangeEndpoint {
  SEND_COMPANIES_TO_PROXYCRAWL = '/send-companies-to-proxycrawl',
  SEND_CONTACTS_TO_PROXYCRAWL = '/send-contacts-to-proxycrawl',
  SEND_CONTACTS_TO_PDL = '/send-contacts-to-pdl',
  SEND_CONTACTS_TO_GOOGLE_ONGOING = '/send-contacts-to-google-ongoing',
  SEND_CONTACTS_TO_FULLCONTACT = '/send-contacts-to-fullcontact',
  GET_LINKEDIN_URL = '/get-initial-linkedin-url',
  ADHOC_UPDATE = '/adhoc-update',
  CREATE_CONTACT_DATA = '/create-contact-data',
}

export enum mTurkEndpoint {
  CREATE_TASKS = '/create-tasks',
  APPROVE_TASKS = '/approve-tasks',
}

export const cloudFunctionsBaseAPIURL = {
  SALESFORCE_INTEGRATION: CLOUD_FUNCTIONS_BASE_URL + 'sf',
  HUBSPOT_INTEGRATION: CLOUD_FUNCTIONS_BASE_URL + 'hubSpotIntegration',
  CLIENT: CLOUD_FUNCTIONS_BASE_URL + 'client',
  ADMIN: CLOUD_FUNCTIONS_BASE_URL + 'admin',
};

export const apiURLs = {
  Salesforce: {
    Auth: cloudFunctionsBaseAPIURL.SALESFORCE_INTEGRATION + SalesforceIntegrationEndpoint.AUTH,
    Token: cloudFunctionsBaseAPIURL.SALESFORCE_INTEGRATION + SalesforceIntegrationEndpoint.TOKEN,
    SetupFields: cloudFunctionsBaseAPIURL.SALESFORCE_INTEGRATION + SalesforceIntegrationEndpoint.SETUP_FIELDS,
    SyncContacts: cloudFunctionsBaseAPIURL.SALESFORCE_INTEGRATION + SalesforceIntegrationEndpoint.SYNC_CONTACTS,
  },
  Client: cloudFunctionsBaseAPIURL.CLIENT,
  Admin: {
    GenerateJobChanges: cloudFunctionsBaseAPIURL.ADMIN + AdminEndpoint.GENERATE_JOB_CHANGES,
    DenormalizeContacts: cloudFunctionsBaseAPIURL.ADMIN + AdminEndpoint.DENORMALIZE_CONTACTS,
  },
};

export enum SalesforceObject {
  ACCOUNT = 'Account',
  CONTACT = 'Contact',
  PROFILE = 'Profile',
}

// Custom salesforce field names are required to have "__c" suffix
// https://developer.salesforce.com/docs/atlas.en-us.object_reference.meta/object_reference/custom_fields.htm
export enum SalesforceCustomFieldName {
  JOB_CHANGED = 'WarmlyJobChanged__c',
  LATEST_JOB_TITLE = 'WarmlyLatestJobTitle__c',
  LATEST_JOB_COMPANY = 'WarmlyLatestJobCompany__c',
  LATEST_LINKEDIN = 'WarmlyLatestLinkedIn__c',
}

// Valid field types:
// https://developer.salesforce.com/docs/atlas.en-us.api_meta.meta/api_meta/meta_field_types.htm#meta_type_fieldtype
export enum SalesforceCustomFieldType {
  TEXT = 'Text',
  URL = 'Url',
  CHECKBOX = 'Checkbox',
}

// This is used to accurately type the SalesforceCustomField object literal:
// https://stackoverflow.com/questions/51237668/typescript-declare-that-all-properties-on-an-object-must-be-of-the-same-type
type SalesforceCustomFieldKeys = 'JobChanged' | 'LatestJobTitle' | 'LatestJobCompany' | 'LatestLinkedIn';

export const SalesforceCustomField: Record<SalesforceCustomFieldKeys, SalesforceCustomFieldData> = {
  JobChanged: {
    name: SalesforceCustomFieldName.JOB_CHANGED,
    label: 'Job Changed',
    description: 'Indicates whether Warmly detected a job change',
    fieldType: SalesforceCustomFieldType.CHECKBOX,
    defaultValue: false,
  },
  LatestJobTitle: {
    name: SalesforceCustomFieldName.LATEST_JOB_TITLE,
    label: 'Latest Job Title',
    description: 'Most recent job title detected by Warmly',
    fieldType: SalesforceCustomFieldType.TEXT,
    length: 255,
  },
  LatestJobCompany: {
    name: SalesforceCustomFieldName.LATEST_JOB_COMPANY,
    label: 'Latest Job Company',
    description: 'Most recent company name detected by Warmly',
    fieldType: SalesforceCustomFieldType.TEXT,
    length: 255,
  },
  LatestLinkedIn: {
    name: SalesforceCustomFieldName.LATEST_LINKEDIN,
    label: 'Latest LinkedIn',
    description: 'Most recent LinkedIn URL detected by Warmly',
    fieldType: SalesforceCustomFieldType.URL,
  },
};

export enum IntegrationType {
  HUBSPOT = 'hubspot',
  SALESFORCE = 'salesforce',
}

export enum SyncStatus {
  SYNCING = 'SYNCING',
  COMPLETE = 'COMPLETE',
  ERROR = 'ERROR',
}

export enum WARMLY_EMAIL {
  CEO = 'max@warmlycomma.com',
  CTO = 'carina@warmlycomma.com',
  SUPPORT_GENERAL = 'support@warmlycomma.com',
  SUPPORT_TECH = 'tech@warmlycomma.com',
  CSM = 'csm@warmlycomma.com',
  FULL_TEAM = 'team@warmlycomma.com',
}

// All test Clients should have a suffix so we can easily identify test data
// and prevent accidental modification of non-test Client data
export const TEST_CLIENT_NAME_SUFFIX = '__TEST';

export enum ContactDataField {
  ID = 'id',
  FULL_NAME = 'fullName',
  FIRST_NAME = 'firstName',
  LAST_NAME = 'lastName',
  CLIENT_IDS = 'clientIds',
  CLIENT_NAMES = 'clientNames',
  CURRENT_JOBS = 'currentJob',
  ALL_JOBS = 'allJobs',
  EMAILS = 'emailData',
  EMAIL_ARRAY = 'emailArray',
  LAST_UPDATED_PROXY_CRAWL = 'lastUpdatedProxyCrawl',
  EMAIL_DATA = 'emailData',
  DETECTED_JOB_CHANGES = 'detectedJobChanges',
  LINKEDIN_URL = 'linkedInURL',
  LINKEDIN_ID = 'linkedInId',
  DETECTED_JOB_CHANGES_STATUS = 'detectedJobChangesStatus',
  DATE_UPDATED = 'dateUpdated',
  WEBSITES = 'websites',
  LAST_LINKEDIN_DATA = 'lastLinkedInData',
  PEOPLE_DATA_LABS_DATA = 'peopleDataLabsData',
  GOOGLE_SEARCH_RESULTS = 'googleSearchResults',
  SHOULD_RESCRAPE = 'shouldRescrape',
  PROFILE_PHOTO = 'profilePhoto',
  PROXY_CRAWL_COMPLETED_FLAG = 'proxyCrawlCompletedFlag',
  PROXY_CRAWL_ERROR_FLAG = 'proxyCrawlErrorFlag',
  PROXY_CRAWL_ERROR_MESSAGE = 'proxyCrawlErrorMessage',
}

export enum JobChangeStatus {
  NO_JOB_CHANGE = 'No job change',
  LEFT_OLD_JOB_NO_NEW_JOB = 'Left old job but no new job',
  JOB_CHANGED = 'Job changed',
  JOB_CHANGED_SAME_COMPANY = 'Job changed but same company',
}

export enum ProjectId {
  Development = 'warmly-staging',
  Staging = 'warmly-staging',
  Production = 'jobattrition',
}

// This is used by the web-dashboard for Stackdriver Error Reporting
export const WEB_SERVICE_NAME = 'trackadvocates-web';
