#!/bin/bash
set -eo pipefail

function deploy {
  echo "firebase use $1"
  echo "firebase deploy $2"
}

PS3='Select deployment environment: '
options=("Staging" "Production" "Cancel")

select opt in "${options[@]}"
do
    case $opt in
        "Staging")
            DeployEnvironment='staging'
            break
            ;;
        "Production")
            read -p "Deploying to prod, please type in our CTO's name to continue: " CONT
              if [ "$CONT" = "carina" ] || [ "$CONT" = "Carina" ]; then
                DeployEnvironment='default'
                break
              else
                echo "Invalid entry. Exiting"
                break
              fi
            ;;
        "Cancel")
            break
            ;;
        *) echo "invalid option $REPLY";;
    esac
done

if [ "$DeployEnvironment" = "default" ]; then
    echo $'⚠️ You are deploying to \033[33;7m production \033[0m please be extra careful ⚠️'
fi

if [ -n "$DeployEnvironment" ]; then
  PS3='Select app to be deployed: '
  AppOptions=("Web dashboard" "Assistant" "Functions" "Cancel")

  select app in "${AppOptions[@]}"
  do
      case $app in
          "Web dashboard")
              deploy $DeployEnvironment '--only hosting:web-dashboard'
              break
              ;;
          "Assistant")
              deploy $DeployEnvironment '--only hosting:assistant'
              break
              ;;
          "Functions")
              deploy $DeployEnvironment '--only functions'
              break
              ;;
          "Cancel")
              break
              ;;
          *) echo "invalid option $REPLY";;
      esac
  done
fi