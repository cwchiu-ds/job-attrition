# Database Considerations

### Firebase requires composite indices to support compound queries
> For example, querying `clientContactsCollection.where('clientId', '==', '1234).orderBy('dateUpdated', 'asc)` requires manual creation of a composite index between `clientId` and `dateUpdated`.

> **Note**: the order matters for `dateUpdated` because we are using `orderby` in the query. When setting up the composite index the order selected for `dateUpdated` must be `Ascending` for the above query to work. The order for `clientId` does not matter in this case since we are using `==` (equality) operator.

- See https://firebase.google.com/docs/firestore/query-data/index-overview for more details
