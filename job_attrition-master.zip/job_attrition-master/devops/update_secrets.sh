#!/bin/bash
set -eo pipefail

read -p "⚠️  Did you make sure to update the staging and production secrets? (Y/n)" CONT
if [ "$CONT" = "Y" ] || [ "$CONT" = "y" ]; then
    SecretsUpdated='true'
else
    echo $'\033[33;7m Please ensure dev/staging/prod secrets are all updated \033[0m'
fi

if [ -n "$SecretsUpdated" ]; then
    GCLOUD_ACCOUNT=$(gcloud config get-value account)

    if [ -z "$GCLOUD_ACCOUNT" ]; then
        gcloud auth login
    fi

    echo "💽  Backing up old secrets..."

    foldername=$(date +%Y%m%d%H%M)

    # Back up old .env files first
    gsutil -m cp -r gs://jobattrition-devops/dev gs://jobattrition-devops/dev-backup/"$foldername"/
    gsutil -m cp -r gs://jobattrition-devops/staging gs://jobattrition-devops/staging-backup/"$foldername"/
    gsutil -m cp -r gs://jobattrition-devops/production gs://jobattrition-devops/production-backup/"$foldername"/

    echo "✅  Back up complete"

    echo "⏫  Uploading functions secrets..."

    gsutil -m cp "$(dirname "$0")/../functions/.env" gs://jobattrition-devops/dev/functions/.env
    gsutil -m cp "$(dirname "$0")/../functions/.env-staging" gs://jobattrition-devops/staging/functions/.env
    gsutil -m cp "$(dirname "$0")/../functions/.env-production" gs://jobattrition-devops/production/functions/.env

    gsutil -m cp -r "$(dirname "$0")/../functions/secrets" gs://jobattrition-devops/dev/functions/
    gsutil -m cp -r "$(dirname "$0")/../functions/secrets" gs://jobattrition-devops/staging/functions/
    gsutil -m cp -r "$(dirname "$0")/../functions/secrets" gs://jobattrition-devops/production/functions/

    echo "⏫  Uploading web dashboard secrets..."

    gsutil -m cp "$(dirname "$0")/../web-dashboard/.env" gs://jobattrition-devops/dev/web-dashboard/.env
    gsutil -m cp "$(dirname "$0")/../web-dashboard/.env-staging" gs://jobattrition-devops/staging/web-dashboard/.env
    gsutil -m cp "$(dirname "$0")/../web-dashboard/.env-production" gs://jobattrition-devops/production/web-dashboard/.env

    echo "🎉  Secrets updated!"

    curl -X POST -H 'Content-type: application/json' --data '{"text":"🤫 Secrets updated, please re-download!"}' https://hooks.slack.com/services/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
fi
