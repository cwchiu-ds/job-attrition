#!/bin/bash
set -eo pipefail

GCLOUD_ACCOUNT=`gcloud config get-value account`

if [ -z "$GCLOUD_ACCOUNT" ]; then
  gcloud auth login
fi

echo "⏬  Downloading secrets"

# copy & replace functions secrets / .env
# Note that the secrets folder (the one with .json files) in functions is the same for all three environments, so we don't need
# to re-download it for each environment
gsutil -m cp -r gs://jobattrition-devops/dev/functions/secrets "$(dirname "$0")/../functions/"

gsutil -m cp gs://jobattrition-devops/dev/functions/.env "$(dirname "$0")/../functions/.env"
gsutil -m cp gs://jobattrition-devops/staging/functions/.env "$(dirname "$0")/../functions/.env-staging"
gsutil -m cp gs://jobattrition-devops/production/functions/.env "$(dirname "$0")/../functions/.env-production"

# copy & replace web dashboard secrets
gsutil -m cp gs://jobattrition-devops/dev/web-dashboard/.env "$(dirname "$0")/../web-dashboard/.env"
gsutil -m cp gs://jobattrition-devops/staging/web-dashboard/.env "$(dirname "$0")/../web-dashboard/.env-staging"
gsutil -m cp gs://jobattrition-devops/production/web-dashboard/.env "$(dirname "$0")/../web-dashboard/.env-production"

echo "🥳  Secrets downloaded, go you!"

echo "⏬  Downloading / updating Sentry CLI"

curl -sL https://sentry.io/get-cli/ | bash

echo "🥳  Sentry CLI installed"

echo "✅  All tasks completed"